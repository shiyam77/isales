import { NgModule, LOCALE_ID } from '@angular/core';
import { CommonModule, registerLocaleData } from '@angular/common';
import { PartialsModule } from '../../../partials/partials.module';
import { CoreModule } from '../../../../core/core.module';
import { AngularEditorModule } from '@kolkov/angular-editor';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {
	MatIconRegistry,
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatSliderModule,
	MatListModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatSlideToggleModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatSidenavModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatSnackBarModule,
	MatGridListModule,
	MatTableModule,
	MatExpansionModule,
	MatToolbarModule,
	MatSortModule,
	MatDividerModule,
	MatStepperModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	MatRadioModule,
	DateAdapter,
	MAT_DATE_FORMATS,
	MAT_DATE_LOCALE,
	MatPaginatorIntl
} from '@angular/material';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface, PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { FullCalendarModule } from 'ng-fullcalendar';
import { SubheaderService } from '../../../../core/services/layout/subheader.service';
import { NgxPermissionsModule, NgxPermissionsGuard } from 'ngx-permissions';
import { PersonalService } from '../personal/_core/services/personal.service';
import { SharedService } from '../../../../core/services/pages/shared.service';
import localeSvSe from '@angular/common/locales/sv';
import { FileUploadModule } from 'ng2-file-upload';
import { ImageCropperModule } from 'ngx-image-cropper';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { RequestTypeSettingComponent } from '../request-type-setting/request-type-setting.component';
import { RequestListComponent } from '../request-list/request-list.component';
import { EmployeeRequestsComponent } from './employee-requests.component';
import { RouterModule } from '@angular/router';
import { EmployeeRequestsService } from './_core/services/employee-requests.service';

registerLocaleData(localeSvSe);

export const MY_FORMATS = {
	parse: {
	  dateInput: 'LL',
	},
	display: {
	  dateInput: 'YYYY-MM-DD',
	  monthYearLabel: 'YYYY',
	  dateA11yLabel: 'LL',
	  monthYearA11yLabel: 'YYYY',
	},
};

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
};

const swedishRangeLabel = (page: number, pageSize: number, length: number) => {
	if (length == 0 || pageSize == 0) { return `0 av ${length}`; }
	length = Math.max(length, 0);
	const startIndex = page * pageSize;
	// If the start index exceeds the list length, do not try and fix the end index to the end.
	const endIndex = startIndex < length ?
		Math.min(startIndex + pageSize, length) :
		startIndex + pageSize;
	return `${startIndex + 1} - ${endIndex} av ${length}`;
  }
  
  function getSwedishPaginatorIntl() {
	const paginatorIntl = new MatPaginatorIntl();
	paginatorIntl.itemsPerPageLabel = 'Objekt per sida:';
	paginatorIntl.getRangeLabel = swedishRangeLabel;
	return paginatorIntl;
  }

@NgModule({
	declarations: [
		RequestTypeSettingComponent,
		RequestListComponent,
		EmployeeRequestsComponent
	],
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		CoreModule,
		PartialsModule,
		AngularEditorModule,
		MatInputModule,
		MatDatepickerModule,
		MatFormFieldModule,
		MatAutocompleteModule,
		MatSliderModule,
		MatListModule,
		MatCardModule,
		MatSelectModule,
		MatButtonModule,
		MatIconModule,
		MatNativeDateModule,
		MatSlideToggleModule,
		MatCheckboxModule,
		MatMenuModule,
		MatTabsModule,
		MatTooltipModule,
		MatSidenavModule,
		MatProgressBarModule,
		MatProgressSpinnerModule,
		MatSnackBarModule,
		MatGridListModule,
		MatTableModule,
		MatExpansionModule,
		MatToolbarModule,
		MatSortModule,
		MatDividerModule,
		MatStepperModule,
		MatChipsModule,
		MatPaginatorModule,
		MatDialogModule,
		MatRadioModule,
		TranslateModule,
		NgbModule,
		FullCalendarModule,
		NgxPermissionsModule,
		PerfectScrollbarModule,
		FileUploadModule,
		ImageCropperModule,
		NgxPermissionsModule.forChild(),
		RouterModule.forChild([
			{
			  path: '',
			  component: EmployeeRequestsComponent,
			  canActivateChild:[NgxPermissionsGuard],
			  children: [
				{
				  path:'',
				  redirectTo:'list',
				  pathMatch:'full'
				},
				{
				  path:'list',
				  component:RequestListComponent ,
				  data:{
						permissions:{
							only:['employeeRequests'],
							redirectTo:'/my-salary/list'
						}
					}
				},
				{
				  path:'request-type-settings',
				  component:RequestTypeSettingComponent,
				  data:{
					permissions:{
						only:['employeeRequestSettings'],
						redirectTo:'/my-salary/list'
					}
				  }
				}
			  ]
			}
		]),		
	],
	providers: [
		MatIconRegistry,
		PersonalService,		
		NgbAlertConfig, 
		{
			provide: PERFECT_SCROLLBAR_CONFIG,
			useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
		},
		SubheaderService,
		SharedService,
		EmployeeRequestsService,
		{
			provide: LOCALE_ID,
			useValue:'sv-SE'
		},
		{provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
		{provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
		{ provide: MatPaginatorIntl, useValue: getSwedishPaginatorIntl() }
	]
})
export class EmployeeRequestsModule { }
