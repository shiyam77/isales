import { Injectable } from '@angular/core';
import { ApiEndpointConstants } from '../../../../../../core/models/api-endpoint-constants';
import { TokenStorage } from '../../../../../../core/auth/token-storage.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class EmployeeRequestsService {
  private get_request_type_list = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.GET_ALL_REQUEST_TYPE_LIST;
  private add_request_type = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ADD_REQUEST_TYPE;
  private edit_request_type = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.EDIT_REQUEST_TYPE;
  private delete_request_type = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.DELETE_REQUEST_TYPE;
  private get_request_type_id = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.GET_REQUEST_TYPE_BY_ID;
  private save_enquiry = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.SAVE_ENQUIRY;
  private get_enquiry_by_id = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.GET_ENQUIRY_BY_ID;
  private get_all_enquiries = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.GET_ALL_ENQUIRIES;
  private get_all_enquires_for_employee = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.GET_ALL_ENQUIRIES_FOR_EMPLOYEE;
  private change_enquiry_status = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.CHANGE_ENQUIRY_STATUS;
  private get_all_enquiries_by_status = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.GET_ALL_ENQUIRIES_BY_STATUS;
  private get_all_enquiries_by_status_for_employee = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.GET_ALL_ENQUIRIES_BY_STATUS_FOR_EMPLOYEE;

  constructor(private http: HttpClient) { }

  getAllRequestTypes(): Observable<any> {
    return this.http.get(`${this.get_request_type_list}`).pipe(map((res: any) => res));
  }

  addRequestType(requestTypeData): Observable<any> {
    return this.http.post(`${this.add_request_type}`, requestTypeData).pipe(map((res: any) => res));
  }

  updateRequestTypeById(requestTypeData): Observable<any> {
    return this.http.put(`${this.edit_request_type}/${requestTypeData.id}`, requestTypeData).pipe(map((res: any) => res));
  }

  getRequestTypeById(requestTypeId): Observable<any> {
    return this.http.get(`${this.get_request_type_id}/${requestTypeId}`).pipe(map((res: any) => res));
  }

  deleteRequestTypeById(requestTypeId): Observable<any> {
    return this.http.delete(`${this.delete_request_type}/${requestTypeId}`).pipe(map((res: any) => res));
  }

  addEnquiry(enquiryData): Observable<any> {
    return this.http.post(`${this.save_enquiry}`, enquiryData).pipe(map((res: any) => res));
  }

  updateEnquiry(enquiryData): Observable<any> {
    return this.http.put(`${this.save_enquiry}`, enquiryData).pipe(map((res: any) => res));
  }

  changeEnquiryStatus(enquiryData): Observable<any> {
    return this.http.post(`${this.change_enquiry_status}`, enquiryData).pipe(map((res: any) => res));
  }

  getEnquiryById(enquiryId): Observable<any> {
    return this.http.get(`${this.get_enquiry_by_id}/${enquiryId}`).pipe(map((res: any) => res));
  }

  getAllEnquiries(): Observable<any> {
    return this.http.get(`${this.get_all_enquiries}`).pipe(map((res: any) => res));
  }

  getAllEnquiriesByEmployeeId(userId): Observable<any> {
    return this.http.get(`${this.get_all_enquires_for_employee}/${userId}`).pipe(map((res: any) => res));
  }

  getAllEnquiriesByStatus(enquiryReq): Observable<any> {
    return this.http.post(`${this.get_all_enquiries_by_status}`, enquiryReq).pipe(map((res: any) => res));
  }

  getAllEnquiriesByStatusByEmployeeId(enquiryReq, userId): Observable<any> {
    return this.http.post(`${this.get_all_enquiries_by_status_for_employee}/${userId}`, enquiryReq).pipe(map((res: any) => res));
  }
}
