import { EmployeeRequestsModule } from './employee-requests.module';

describe('EmployeeRequestsModule', () => {
  let employeeRequestsModule: EmployeeRequestsModule;

  beforeEach(() => {
    employeeRequestsModule = new EmployeeRequestsModule();
  });

  it('should create an instance', () => {
    expect(employeeRequestsModule).toBeTruthy();
  });
});
