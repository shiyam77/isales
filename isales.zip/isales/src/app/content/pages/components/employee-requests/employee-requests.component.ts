import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-employee-requests',
  templateUrl: './employee-requests.component.html',
  styleUrls: ['./employee-requests.component.scss']
})
export class EmployeeRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
