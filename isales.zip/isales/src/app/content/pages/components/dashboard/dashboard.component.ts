import { ChangeDetectionStrategy, Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import * as _moment from 'moment';
import { Options } from 'fullcalendar';
import { CalendarComponent } from 'ng-fullcalendar';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PersonalService } from '../personal/_core/services/personal.service';
import { SharedService } from '../../../../core/services/pages/shared.service';
const dateObj = new Date();
const yearMonth = dateObj.getUTCFullYear() + '-' + (dateObj.getUTCMonth() + 1);

@Component({
    selector: 'm-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class DashboardComponent implements OnInit {

    empGroup: FormGroup;
    employee_id: string;
    empArr: Array<any> = [];
    changeView: any = {
        viewValue: 'charts'
    };
    yearSelected = "2019";
    monthSelected = "januari";
    reasonSelected = "reason1";
    projectSelected = ['project1', 'project2', 'project3', 'project4'];
    userData: any = {};
    getUserData: any = {};
    total: any = {};
    role: any;
    totalData: any = [{ name: "Totala Sälj", img: "total_sales_icon", value: 1 },
    { name: "Totala Sälj", img: "total_sales_icon", value: 1 },
    { name: "Totala Sälj", img: "total_sales_icon", value: 1 }
    ];
    narvaroManadsvisData = {
        labelunit: 'Hrs',
        backgroundColor: '#E7ADD5',
        data: [10, 30, 120, 55, 80, 90, 110, 100, 81, 56, 150, 80],
        label: ['Jan', 'Feb', 'Mar', 'Apr', 'maj', 'juni', 'juli', 'Aug', 'Sept', 'okt', 'Nov', 'Dec']
    };
    narvaroReasonData = {
        labelunit: 'Hrs',
        backgroundColor: '#c8aee2',
        data: [10, 30, 120, 55, 80, 90, 110, 100, 81, 56, 150, 80],
        label: ['narvaro', 'narvaro-Godkant sen', 'Sjuk', 'Ogiltig Frånvaro', 'Godkand Frånvaro', 'Narvaro Utbildning', 'Sjuk Vab']
    };
    forsaljningsrapportData = {
        labelunit: 'tkr',
        backgroundColor: '#E6BEAC',
        data: [50, 30, 20, 55, 50, 40, 10, 10, 45, 56, 60, 80],
        label: ['Jan', 'Feb', 'Mar', 'Apr', 'maj', 'juni', 'juli', 'Aug', 'Sept', 'okt', 'Nov', 'Dec']
    };
    projektvisforsaljningData = {
        lineChartData: [
            { data: [40, 55, 70, 90, 110, 140, 150, 160, 165, 170, 180, 181], fill: false, lineTension: 0, label: 'Telenor IPTV' },
            { data: [55, 40, 48, 53, 52, 51, 80, 110, 130, 140, 150, 155], fill: false, lineTension: 0, label: 'Comhem Prospekts' },
            { data: [165, 180, 170, 160, 165, 160, 155, 140, 130, 120, 100, 40], fill: false, lineTension: 0, label: 'Cmore Premium' },
            { data: [175, 152, 125, 110, 102, 75, 51, 53, 54, 48, 45, 51], fill: false, lineTension: 0, label: 'Telenor Premium' }
        ],
        label: ['Jan', 'Feb', 'Mar', 'Apr', 'maj', 'Jun', 'Jul', 'Aug', 'Sep', 'okt', 'Nov', 'Dec'],
        labelunit: 'tkr',
        legendDisplay: true,
        lineChartColors: [
            { // Pink
                backgroundColor: 'rgba(249, 98, 172, 1)',
                borderColor: 'rgba(249, 98, 172, 1)',
                pointBackgroundColor: 'rgba(249, 98, 172, 1)',

            },
            { // Lavender
                backgroundColor: 'rgba(187, 98, 249, 1)',
                borderColor: 'rgba(187, 98, 249, 1)',
                pointBackgroundColor: 'rgba(187, 98, 249, 1)',

            },
            { // blue
                backgroundColor: 'rgba(98, 172, 249, 1)',
                borderColor: 'rgba(98, 172, 249, 1)',
                pointBackgroundColor: 'rgba(98, 172, 249, 1)',
            },
            { // orange
                backgroundColor: 'rgb(249, 165, 98, 1)',
                borderColor: 'rgb(249, 165, 98, 1)',
                pointBackgroundColor: 'rgb(249, 165, 98, 1)',
            }
        ]
    };
    forsaljningRapportDiagramData = {
        lineChartData: [
            {
                data: [16400, 17400, 18700, 19400, 20400, 21700, 21800, 21400, 21000, 21800,
                    21800, 21800, 22800, 22800, 22400, 22800, 22800, 21800, 22800, 21800,
                    20000, 20000, 20000, 22000, 21000, 21000, 21000, 20000, 21000, 21800], fill: false, lineTension: 0, label: ''
            },
        ],
        label: ['Jan', 'Feb', 'Mar', 'Apr', 'maj', 'Jun', 'Jul', 'Aug', 'Sep', 'okt', 'Nov', 'Dec'],
        labelunit: 'tkr',
        legendDisplay: false,
        lineChartColors: [
            {
                backgroundColor: 'rgba(249, 165, 99, 1)',
                borderColor: 'rgba(249, 165, 99, 1)',
                pointBackgroundColor: 'rgba(249, 165, 99, 1)',
            }
        ],
        stepSize: 5000,
        scaleStartValue: 20,
        min: 5000,
        beginAtZero: false
    };

    //admin change starts
    calendarEventData: any = [];
    public config: any;
    attendanceReasonProjectwiseData = {
        lineChartData: [
            { data: [40, 55, 70, 90, 110], fill: false, lineTension: 0, label: 'Telenor IPTV' },
            { data: [55, 40, 48, 53, 52], fill: false, lineTension: 0, label: 'Comhem Prospekts' },
            { data: [165, 180, 170, 160, 165], fill: false, lineTension: 0, label: 'Cmore Premium' },
        ],
        label: ['Narvaro', 'sjuk', 'ogiltig Frånvaro', 'Godkand Frånvaro', 'Narvaro utbildning'],
        labelunit: 'Hrs',
        legendDisplay: true,
        lineChartColors: [
            { // Pink
                backgroundColor: 'rgba(249, 98, 172, 1)',
                borderColor: 'rgba(249, 98, 172, 1)',
                pointBackgroundColor: 'rgba(249, 98, 172, 1)',

            },
            { // blue
                backgroundColor: 'rgba(98, 172, 249, 1)',
                borderColor: 'rgba(98, 172, 249, 1)',
                pointBackgroundColor: 'rgba(98, 172, 249, 1)',
            },
            { // orange
                backgroundColor: 'rgb(249, 165, 98, 1)',
                borderColor: 'rgb(249, 165, 98, 1)',
                pointBackgroundColor: 'rgb(249, 165, 98, 1)',
            }
        ],
        scaleStartValue: 200,
        stepSize: 50,
        min: 0,
        beginAtZero: true
    };
    StatisticsData = {
        lineChartData: [
            {
                data: [6000, 12000, 14000, 16000, 17000, 18000, 19000, 20000, 21000, 21800,
                    21800, 21800, 22800, 22800, 22400, 22800, 22800, 21800, 22800, 21800,
                    20000, 20000, 20000, 16000, 17000, 18000, 19000, 20000, 21000, 21800], fill: false, lineTension: 0, label: ''
            },
        ],
        label: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16',
            '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30'],
        labelunit: 'tkr',
        legendDisplay: false,
        lineChartColors: [
            {
                backgroundColor: 'rgba(249, 165, 99, 1)',
                borderColor: 'rgba(249, 165, 99, 1)',
                pointBackgroundColor: 'rgba(249, 165, 99, 1)',

            }
        ],
        stepSize: 5000,
        scaleStartValue: 20,
        min: 5000,
        beginAtZero: false
    };
    //barchart
    salesData = {
        labelunit: 'tkr',
        backgroundColor: '#e5acd7',
        data: [150, 230, 120, 155, 280],
        label: ['Telenor IPTV', 'Comhem prospekts', 'Cmore Premium', 'Telenor Premium', 'Comhem Prospekts LAN'],
        stepSize: 50
    };
    revenueData = {
        labelunit: 'tkr',
        backgroundColor: '#acbae5',
        data: [2000, 1630, 600, 2455, 1500],
        label: ['Telenor IPTV', 'Comhem prospekts', 'Cmore Premium', 'Telenor Premium', 'Comhem Prospekts LAN'],
        stepSize: 500
    };
    attendanceReasonData = {
        labelunit: 'Hrs',
        backgroundColor: '#b6e5ac',
        data: [140, 60, 155, 110, 180],
        label: ['Narvaro', 'sjuk', 'ogiltig Frånvaro', 'Godkand Frånvaro', 'Narvaro utbildning'],
        stepSize: 50
    };
    totalSales: any;
    //admin change ends
    constructor(
        private personalService: PersonalService,
        private fb: FormBuilder,
        private sharedServices: SharedService,
        private _ref: ChangeDetectorRef
    ) {
        this.getUserData = this.personalService.getRoleAndId();
        this.getUserData.userId.subscribe(id => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.getUserData.role.subscribe(role => {
            this.userData.role = role.toString();
        });
        this.sharedServices.getDashboard(this.userData.id).subscribe(res => {
            this.total.sales = res.total_sales_salary;
            this.total.product = res.total_orders;
            this.total.rejectedProduct = res.rejected_orders;
            this.total.hours = res.attendance_worked_hours;
            this.total.revenue = res.total_salary;
            this.role = res.role;
            this.totalData[0].value = res.attendance_worked_hours;
            this._ref.detectChanges();
        });
    }
    calendarOptions: Options;
    @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;

    ngOnInit(): void {
        this.empGroup = this.fb.group({
            empSelected: [null, Validators.required]
        });
        this.calendarOptions = {
            editable: false,
            eventLimit: false,
            header: {
                left: 'prev,next',
                center: 'title',
                right: 'month,agendaWeek'
            },
            events: this.calendarEventData,
            locale: 'sv',
            droppable: false,
            eventStartEditable: false,
            eventDurationEditable: false,
            eventOverlap: false
        };
        this.sharedServices.employeeListSub$.subscribe((isEmployeeListSet) => {
            if (isEmployeeListSet) {
                this.sharedServices.allEmployeeListData.forEach((obj) => {
                    this.empArr.push({
                        id: obj.Employee_id,
                        name: obj.first_name + "" + obj.last_name
                    });
                    this.empGroup.get('empSelected').setValue(obj.Employee_id);
                });
                this.employee_id = this.empArr[0].id;
                this.getView();
            }
        });
        this.loadEmployee();
    }

    getView() {
        if (this.userData.role == 'sales') {
            this.getLeave(this.userData.id);
        } else {
            this.getLeave(this.employee_id);
        }
    }

    getLeave(event) {
        this.employee_id = event;
        this.calendarEventData = [];
        var fromDate = _moment(this.ucCalendar.fullCalendar('getView').intervalStart).format('YYYY-MM-DD');
        var toDate = _moment(this.ucCalendar.fullCalendar('getView').intervalEnd).format('YYYY-MM-DD');
        this.personalService.calendarMonthly(event, { start_date: fromDate, end_date: toDate }).subscribe(res => {
            if (res) {
                if (res.length > 0) {
                    this.calendarEventData = [];
                    res.forEach((item, index) => {
                        if (item.start_time != "00:00" && item.end_time != "00:00" && item.leave == 0) {
                            item.backgroundColor = "#508250";
                            this.calendarEventData.push(item);
                        } else if (item.leave == 1) {
                            item.backgroundColor = "#de9943";
                            this.calendarEventData.push(item);
                        }
                    });
                    this.ucCalendar.renderEvents(this.calendarEventData);
                }
            }
        });
    }

    loadEmployee() {
        this.sharedServices.getAllEmployees().subscribe(res => {
            res.forEach((obj) => {
                this.empArr.push({
                    id: obj.Employee_id,
                    name: obj.first_name + "" + obj.last_name
                });
                this.empGroup.get('empSelected').setValue(obj.Employee_id);
            })
            this.employee_id = this.empArr[0].id;
        });
        this.getView();
    }

    getcalEventBgColor(status) {
        switch (status) {
            case 0:
                //'Närvaro'
                return '#2d9448';
            case 1:
                //'Närvaro - Godkänt sen'
                return '#FF8000';
            case 2:
                //'Sjuk'
                return '#f94d51';
            case 3:
                //'Ogiltig frånvaro'
                return '#f92e00';
            case 4:
                //'Godkänd frånvaro'
                return '#39d1a1';
            case 5:
                //'Närvaro Utbildning'
                return '#4d62f9';
            case 6:
                //'Sjuk Vab'
                return '#FF8000';
            default:
                return '';
        }
    }

    getCalEventTitle(status) {
        switch (status) {
            case 0:
                return 'Närvaro';
            case 1:
                return 'Närvaro - Godkänt sen';
            case 2:
                return 'Sjuk';
            case 3:
                return 'Ogiltig frånvaro';
            case 4:
                return 'Godkänd frånvaro';
            case 5:
                return 'Närvaro Utbildning';
            case 6:
                return 'Sjuk Vab';
            default:
                return '';
        }
    }
}
