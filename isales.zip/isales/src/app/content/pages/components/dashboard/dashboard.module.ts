import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { RouterModule } from '@angular/router';
import { LayoutModule } from '../../../layout/layout.module';
import { PartialsModule } from '../../../partials/partials.module';
import { ListTimelineModule } from '../../../partials/layout/quick-sidebar/list-timeline/list-timeline.module';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { MatCardModule, MatDatepickerModule, MatSelectModule, MatFormFieldModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { MomentDateModule } from '@angular/material-moment-adapter';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
import { PersonalService } from '../personal/_core/services/personal.service';

@NgModule({
	imports: [
		CommonModule,
		LayoutModule,
		PartialsModule,
		ListTimelineModule,
		WidgetChartsModule,
		FormsModule,
		ReactiveFormsModule,
		RouterModule.forChild([
			{
				path: '',
				component: DashboardComponent
			}
		]),
		NgxPermissionsModule,
		MatCardModule,
		MatDatepickerModule,
		MatSelectModule,
		MatFormFieldModule,
		TranslateModule.forChild(),
		MomentDateModule,
		FullCalendarModule			
	],
	providers: [PersonalService],
	declarations: [DashboardComponent]
})
export class DashboardModule {}
