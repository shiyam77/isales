import { TestBed } from '@angular/core/testing';

import { ImportordertimeService } from './importordertime.service';

describe('ImportordertimeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ImportordertimeService = TestBed.get(ImportordertimeService);
    expect(service).toBeTruthy();
  });
});
