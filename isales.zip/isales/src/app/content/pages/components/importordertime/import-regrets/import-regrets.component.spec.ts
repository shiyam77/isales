import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportRegretsComponent } from './import-regrets.component';

describe('ImportRegretsComponent', () => {
  let component: ImportRegretsComponent;
  let fixture: ComponentFixture<ImportRegretsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportRegretsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportRegretsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
