import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportordertimeComponent } from './importordertime.component';

describe('ImportordertimeComponent', () => {
  let component: ImportordertimeComponent;
  let fixture: ComponentFixture<ImportordertimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportordertimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportordertimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
