import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { CoreModule } from '../../../../core/core.module';
import { PartialsModule } from '../../../partials/partials.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { CodePreviewModule } from '../../../partials/content/general/code-preview/code-preview.module';
import { MaterialPreviewModule } from '../../../partials/content/general/material-preview/material-preivew.module';
import {
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatSliderModule,
	MatListModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatSlideToggleModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatSidenavModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatSnackBarModule,
	MatGridListModule,
	MatTableModule,
	MatExpansionModule,
	MatToolbarModule,
	MatSortModule,
	MatDividerModule,
	MatStepperModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	MatRadioModule,
  MatPaginatorIntl,	
} from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { QRCodeModule } from 'angularx-qrcode';
import { NgxPermissionsModule, NgxPermissionsGuard } from 'ngx-permissions';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { ImportordertimeComponent } from './importordertime.component';
import { ImportorderComponent } from './importorder/importorder.component';
import { FileUploadModule } from 'ng2-file-upload';
import { ImportordertimeService } from './_core/services/importordertime.service';
import { ImporttimeComponent } from './importtime/importtime.component';
import { ImportRegretsComponent } from './import-regrets/import-regrets.component';
import { ImportLogComponent } from './importlog/importlog.component';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
const routes: Routes = [
	{
		path: '',
    component: ImportordertimeComponent,
    canActivateChild:[NgxPermissionsGuard],
		children: [
      {
        path:'import-order/list',
        component:ImportorderComponent,
        data:{
					permissions:{
            only:["importSales"],
						redirectTo:'/attendance/overview'
					}
				}
      },
      {
        path:'import-time/list',
        component:ImporttimeComponent,
        data:{
					permissions:{
            only:["importHours"],
						redirectTo:'/attendance/overview'
					}
				}
      },
      {
        path:'import-regrets/list',
        component:ImportRegretsComponent,
        data:{
					permissions:{
            only:["importRegrets"],
						redirectTo:'/attendance/overview'
					}
				}
      },
      {
        path:'import-log/list',
        component:ImportLogComponent,
        data:{
					permissions:{
            only:["importHours","importSales","importRegrets"],
						redirectTo:'/attendance/overview'
					}
				}
      },
	],
	}
];

const swedishRangeLabel = (page: number, pageSize: number, length: number) => {
  if (length == 0 || pageSize == 0) { return `0 av ${length}`; }
  length = Math.max(length, 0);
  const startIndex = page * pageSize;
  // If the start index exceeds the list length, do not try and fix the end index to the end.
  const endIndex = startIndex < length ?
      Math.min(startIndex + pageSize, length) :
      startIndex + pageSize;
  return `${startIndex + 1} - ${endIndex} av ${length}`;
}

function getSwedishPaginatorIntl() {
  const paginatorIntl = new MatPaginatorIntl();
  paginatorIntl.itemsPerPageLabel = 'Objekt per sida:';
  paginatorIntl.getRangeLabel = swedishRangeLabel;
  return paginatorIntl;
}

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    PartialsModule,
    NgbModule,
    CodePreviewModule,
    CoreModule,
    MaterialPreviewModule,
    FormsModule,
    ReactiveFormsModule,    
    PerfectScrollbarModule,	
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatSliderModule,
    MatListModule,
    MatCardModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    MatMenuModule,
    MatTabsModule,
    MatTooltipModule,
    MatSidenavModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatGridListModule,
    MatTableModule,
    MatExpansionModule,
    MatToolbarModule,
    MatSortModule,
    MatDividerModule,
    MatStepperModule,
    MatChipsModule,
    MatPaginatorModule,
    MatDialogModule,
    MatRadioModule,
    TranslateModule,
    QRCodeModule,
    WidgetChartsModule,
    NgxPermissionsModule.forChild(),
    NgxDaterangepickerMd,
    FileUploadModule,
    NgxMatSelectSearchModule
  ],
  declarations: [ImportordertimeComponent, ImportorderComponent, ImporttimeComponent, ImportRegretsComponent,ImportLogComponent],
  providers:[
    ImportordertimeService,
    { provide: MatPaginatorIntl, useValue: getSwedishPaginatorIntl() }
  ]
})
export class ImportordertimeModule { }
