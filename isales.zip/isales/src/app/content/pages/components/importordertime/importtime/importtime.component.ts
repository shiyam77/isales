import { Component, OnInit, ViewChild, ChangeDetectorRef, Inject } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource, MatSelect } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ClientList } from '../../project/_core/models/client-list.model';
import { ProjectService } from '../../project/_core/services/project.service';
import { FileUploader } from 'ng2-file-upload';
import { ImportordertimeService } from '../_core/services/importordertime.service';
import { startWith, map, takeUntil } from 'rxjs/operators';
import { Observable, Subject, ReplaySubject } from 'rxjs';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { TranslateService } from '@ngx-translate/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
const URL = 'https://viafoneerp.azurewebsites.net/api/File/SalesFileUpload ';
type AOA = any[][];

@Component({
  selector: 'm-importtime',
  templateUrl: './importtime.component.html',
  styleUrls: ['./importtime.component.scss']
})

export class ImporttimeComponent implements OnInit {

  public uploader: FileUploader = new FileUploader({ url: URL, allowedMimeType: ['text/csv', 'application/vnd.ms-excel'] });
  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;
  filedata: any = new Array<string>();
  uspFile: any = new Array<string>();
  timeCreateOrupdate: string;
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  seconds = true;
  impTimeList: any[] = [];
  clientsArr: Array<any> = [];
  projectsArr: Array<any> = [];
  productsArr: Array<any> = [];
  clientProjectsArr: Array<any> = [];
  clientsProductsArr: Array<any> = [];
  empArr: Array<any> = [];
  empFilterArr: Observable<any[]>;
  isImportError: boolean;
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  getClientList() {
    this.sharedServices.getClientList().subscribe((res: any) => {
      if (res) {
        this.clientsArr = res;
        this.clientsArr.sort(function (a, b) {
          if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
          if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
          return 0;
        });
      }
    });
  }

  getProjectList() {
    this.sharedServices.getProjectList().subscribe((res: any) => {
      if (res) {
        this.projectsArr = res;
        this.projectsArr.sort(function (a, b) {
          if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
          if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
          return 0;
        });
        this._projectFilter();
      }
    });
  }

  dropped(event) {
    this.updateUspFileErrMsg = false;
    this.filedata = [];
    this.uspFile = [];
    for (let i = 0; i < event.length; i++) {
      if (event[i].type != "text/csv" && event[i].type != "application/vnd.ms-excel") {
        this.updateUspFileErrMsg = true;
        this.uspFile.push(event[i].name);
      }
    }
    if (this.uploader.queue.length === 1) {
      this.filedata.push(this.uploader.queue[0]);
    } else {
      for (let i = 0; i < this.uploader.queue.length; i++) {
        this.filedata.push(this.uploader.queue[i]);
      }
    }
  }

  removeFile(file) { }

  UploadFile() {
    if (this.filedata.length != 0) {
      this.spinner.active = true;
      this.impOrderService.uploadTimesFile(this.filedata, this.uploadOption).subscribe((res: any) => {

        if (res && res.message == "File updated successfully" && res.status == 'Success') {
          this.resCreateMessage.success = true;
          this.resCreateMessage.error = false;
          this.isImportError = false;
          this.deleteEmpModalRef.close('submitted');
          let at = document.createElement('a');
          document.body.appendChild(at);
          at.setAttribute('style', 'display: none');

          at.href = this.documentObj.location.origin + '/import/import-log/list?id=' + res.import_id + '&type=hours';
          at.target = '_blank';
          at.click();
          at.remove();
          this.loadImportTime();
        } else {
          this.deleteEmpModalRef.close('submitted');
          let at = document.createElement('a');
          document.body.appendChild(at);
          at.setAttribute('style', 'display: none');
          at.href = this.documentObj.location.origin + '/import/import-log/list?id=' + res.import_id + '&type=hours';
          at.target = '_blank';
          at.click();
          at.remove();
        }
        setTimeout(() => {
          this.resCreateMessage.success = false;
          this.resCreateMessage.error = false;
          this._ref.detectChanges();
        }, 5000);
        this._ref.detectChanges();
        this.spinner.active = false;
      }, err => {
        this.spinner.active = false;
        this.updateErrMsg = true;
      });
    }
  }

  AddImportTime() {
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let form1 = this.modalFormGroup.getRawValue();
      let tosendImportTime = {
        "WorkingDate": _moment(form1.date).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss'),
        "Project_id": form1.project_name.Project_id,
        "LoxySoftId": form1.LoxySoftId,
        "Time1": _moment().set({ hours: form1.Overksamtid.hour, minute: form1.Overksamtid.minute, second: form1.Overksamtid.second }).format('HH:mm:ss'),
        "TotalTime": _moment().set({ hours: form1.Inloggadtid.hour, minute: form1.Inloggadtid.minute, second: form1.Inloggadtid.second }).format('HH:mm:ss'),
        "Time3": _moment().set({ hours: form1.Efterberabetningstid.hour, minute: form1.Efterberabetningstid.minute, second: form1.Efterberabetningstid.second }).format('HH:mm:ss'),
        "Start_time": _moment().set({ hours: form1.Start_time.hour, minute: form1.Start_time.minute, second: form1.Start_time.second }).format('HH:mm:ss'),
        "End_time": _moment().set({ hours: form1.End_time.hour, minute: form1.End_time.minute, second: form1.End_time.second }).format('HH:mm:ss'),
      };

      if (this.timeCreateOrupdate === 'create') {
        this.impOrderService.updateImportTime(tosendImportTime).subscribe(res => {
          if (res.message === 'Updated Successfully') {
            this.loadImportTime();
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.deleteEmpModalRef.close('submitted');
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          setTimeout(() => {
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this._ref.detectChanges();
          }, 5000);
          this._ref.detectChanges();
          this.spinner.active = false;
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      } else if (this.timeCreateOrupdate === 'update') {
        this.impOrderService.updateImportTime(tosendImportTime).subscribe(res => {
          if (res.message === 'Updated Successfully') {
            this.loadImportTime();
            this.resUpdateeMessage.success = true;
            this.resUpdateeMessage.error = false;
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.deleteEmpModalRef.close('submitted');
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = true;
          }
          setTimeout(() => {
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = false;
            this._ref.detectChanges();
          }, 5000);
          this._ref.detectChanges();
          this.spinner.active = false;
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      }
      this.spinner.active = false;
    }
  }

  public fileChangeEvent(fileInput: any) {
    if (fileInput.target.files && fileInput.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(fileInput.target.files[0]);
    }
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }

  modalFormGroup: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  arrToPrint: AOA = [];
  selection = new SelectionModel<ClientList>(true, []);
  dataSource: any;
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  displayColumnToShow = ['LoxySoftId', 'first_name', 'last_name', 'Project_name', 'Start_time', 'End_time', 'Time1', 'TotalTime', 'Time3', 'effectivity', 'WorkingDate', 'ImportId'];
  errDisplayColumnToShow = ['Lineno', 'Reason', 'LoxySoftId', 'Client_name', 'Project_name', 'Starttime', 'Endtime', 'Time1', 'TotalTime', 'Time3', 'WorkingDate', 'ImportId'];
  allClientList: ClientList[] = [];
  xpandStatus: boolean = false;
  searchInput: string = '';
  deleteEmpModalRef: any;
  closeResult: string;
  clientTitle: string;
  delTimeData: any;
  updateClientID: any;
  deleteErrMsg: boolean = false;
  updateErrMsg: boolean = false;
  updateUspFileErrMsg: boolean = false;

  resDeleteMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  spinners = false;
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  toggleColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'LoxySoftId' },
    { arrIndex: 2, column: 'FIRSTNAME', checked: true, label: 'first_name' },
    { arrIndex: 3, column: 'LASTNAME', checked: true, label: 'last_name' },
    { arrIndex: 4, column: 'PROJECT', checked: true, label: 'Project_name' },
    { arrIndex: 4, column: 'Start_time', checked: true, label: 'Start_time' },
    { arrIndex: 5, column: 'End_time', checked: true, label: 'End_time' },
    { arrIndex: 6, column: 'OVERKSAMTID', checked: true, label: 'Time1' },
    { arrIndex: 7, column: 'INLOGGATID', checked: true, label: 'TotalTime' },
    { arrIndex: 8, column: 'EFTERBERABETNINGSTID', checked: true, label: 'Time3' },
    { arrIndex: 9, column: 'Effektivitet', checked: true, label: 'effectivity' },
    { arrIndex: 10, column: 'DATUM', checked: true, label: 'WorkingDate' },
    { arrIndex: 11, column: 'IMPORTID', checked: true, label: 'ImportId' },
    { arrIndex: 12, column: 'ACTIONS', checked: true, label: 'actions' },
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  uploadOption: any = '0';
  multiColFilter = {
    LoxySoftId: '',
    first_name: '',
    last_name: '',
    Time1: '',
    TotalTime: '',
    Project_name: '',
    Time3: '',
    WorkingDate: '',
    ImportId: '',
    Start_time: '',
    End_time: '',
    effectivity: ''
  };
  deleteImportId: FormControl = new FormControl(null, Validators.required);
  showDeleteImportIdErrMsg: boolean = false;
  deleteImportIdErrMsg: string = '';
  previousEmployee: any;
  errDataSource: any = new MatTableDataSource([]);
  errMultiColFilter = {
    Lineno: '',
    LoxySoftId: '',
    SoldQty: '',
    Client_name: '',
    Project_name: '',
    Time1: '',
    TotalTime: '',
    Time3: '',
    Status: '',
    Reason: '',
    WorkingDate: '',
    ImportId: ''
  };
  monthList = [
    { label: "Jan", value: 1 },
    { label: "Feb", value: 2 },
    { label: "Mar", value: 3 },
    { label: "Apr", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Jun", value: 6 },
    { label: "Jul", value: 7 },
    { label: "Aug", value: 8 },
    { label: "Sep", value: 9 },
    { label: "Okt", value: 10 },
    { label: "Nov", value: 11 },
    { label: "Dec", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  unchangedSelectedYear = null;
  unchangedSelectedMonth = null;
  errImportArr: any[] = [];
  errImportArrLength: any = 0;
  errPageSize: any = 20;
  errPageIndex: any = 0;
  moment_date = _moment;
  filterDisplayColumnToShow = ['loxySoftId', 'firstname', 'lastname', 'projectName', 'startTime', 'endTime', 'time1', 'totalTime', 'time3', 'Effectivity', 'workingDate', 'importId', 'Actions'];
  toggleFilterColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'loxySoftId', params: 'li', key: 'LoxySoftId' },
    { arrIndex: 2, column: 'FIRSTNAME', checked: true, label: 'firstname', params: 'fn', key: 'first_name' },
    { arrIndex: 3, column: 'LASTNAME', checked: true, label: 'lastname', params: 'ln', key: 'last_name' },
    { arrIndex: 4, column: 'PROJECT', checked: true, label: 'projectName', params: 'pn', key: 'Project_name' },
    { arrIndex: 4, column: 'Start_time', checked: true, label: 'startTime', params: 'st', key: 'Start_time' },
    { arrIndex: 5, column: 'End_time', checked: true, label: 'endTime', params: 'et', key: 'End_time' },
    { arrIndex: 6, column: 'OVERKSAMTID', checked: true, label: 'time1', params: 't1', key: 'Time1' },
    { arrIndex: 7, column: 'INLOGGATID', checked: true, label: 'totalTime', params: 'tt', key: 'TotalTime' },
    { arrIndex: 8, column: 'EFTERBERABETNINGSTID', checked: true, label: 'time3', params: 't3', key: 'Time3' },
    { arrIndex: 9, column: 'Effektivitet', checked: true, label: 'Effectivity', params: 'ef', key: 'effectivity' },
    { arrIndex: 10, column: 'DATUM', checked: true, label: 'workingDate', params: 'wd', key: 'WorkingDate' },
    { arrIndex: 11, column: 'IMPORTID', checked: true, label: 'importId', params: 'ii', key: 'ImportId' },
    { arrIndex: 12, column: 'ACTIONS', checked: true, label: 'Actions', params: 'ac', key: 'action' },
  ];
  @ViewChild('projectSearchSelect') projectSearchSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  projectFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  pageIndexNumber: number = 0;
  pageChanged: boolean = false;
  sortKey: string = '';
  sortDir: string = '';

  constructor(
    private projectService: ProjectService,
    private impOrderService: ImportordertimeService,
    private modalService: NgbModal,
    private _formBuilder: FormBuilder,
    private _ref: ChangeDetectorRef,
    private sharedServices: SharedService,
    private translate: TranslateService,
    @Inject(DOCUMENT) private documentObj: Document,
    private router: Router,
    private activeRoute: ActivatedRoute) { }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= (new Date().getFullYear() - 2020)); y++) {
      this.yearList.push(2020 + y);
    }
    this.dataSource = new MatTableDataSource();
    this.errDataSource = new MatTableDataSource();
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.sortKey = 'WorkingDate';
    this.sortDir = 'desc';
    this.getClientList();
    this.getProjectList();
    this.loadEmployee();
    this.modalFormGroup = this._formBuilder.group({
      name: ['', Validators.required],
      project_name: ['', Validators.required],
      projectNameFilter: [''],
      Overksamtid: ['', Validators.required],
      Inloggadtid: ['', Validators.required],
      Efterberabetningstid: ['', Validators.required],
      date: ['', Validators.required],
      LoxySoftId: [''],
      Start_time: ['', Validators.required],
      End_time: ['', Validators.required]
    });
    this.empFilterArr = this.modalFormGroup.controls['name'].valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
    this.modalFormGroup.controls['projectNameFilter'].valueChanges
      .pipe(takeUntil(this._onDestroy)).subscribe(() => this._projectFilter());
    this.activeRoute.queryParams.subscribe((params) => {
      this.yearSelected = this.converToInteger(params['sa']) ? this.converToInteger(params.sa) : (new Date().getFullYear());
      this.monthSelected = this.converToInteger(params['ms']) ? this.converToInteger(params.ms) : (new Date().getMonth() + 1);
      this.toggleFilterColumns.forEach((tfc) => {
        if (params[tfc.params]) {
          this.multiColFilter[tfc.key] = params[tfc.params];
        }
      });
      this.pageIndexNumber = params['pin'] ? params['pin'] : 0;
      this.itemsPerPage = params['ipp'] ? params['ipp'] : this.itemsPerPage;
      this.pageChanged = params['pac'] == 'false' ? false : true;
      this.sortKey = params['sKey'] ? params['sKey'] : 'WorkingDate';
      this.sortDir = params['sDir'] ? params['sDir'] : 'desc';
      this.showHideCols();
      this.setExcelHeaders();
      if ((!params['fic'] || params['fic'] == 'false') || (this.dataSource.data.length == 0)) {
        this.loadImportTime();
      } else {
        this.applyColumnFilter();
      }
    });
  }

  getFirstname(client) {
    return client && client.first_name ? client.first_name : '';
  }

  getLastname(client) {
    return client && client.last_name ? client.last_name : '';
  }

  getWorkingDate(client) {
    return _moment(client.WorkingDate).format('YYYY-MM-DD');
  }

  slideToggleChange(e) { }

  loadImportTime() {
    this.loader = true;
    this.tRowErr = false;
    this.tRowNoRecord = false;
    if (!this.yearSelected) {
      this.yearSelected = new Date().getFullYear();
    }
    if (!this.monthSelected) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.dataSource = new MatTableDataSource([]);
    this.impOrderService.getAllImportTime({ month: this.monthSelected, year: this.yearSelected }).subscribe(res => {
      if (res) {
        //for download
        let resultarr = [];
        res.forEach((obj) => {
          let datasourceObj: any = {};
          datasourceObj.LoxySoftId = obj.LoxySoftId;
          datasourceObj.first_name = this.getFirstname(obj);
          datasourceObj.last_name = this.getLastname(obj);
          datasourceObj.Project_name = obj.Project_name;
          datasourceObj.WorkingDate = obj.WorkingDate;
          datasourceObj.Time1 = obj.Time1;
          datasourceObj.TotalTime = obj.TotalTime;
          datasourceObj.Time3 = obj.Time3;
          datasourceObj.ImportId = obj.ImportId;
          resultarr.push(datasourceObj);
        });
        this.impTimeList = resultarr;
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.tRowNoRecord = true;
        this.loader = false;
      }
      this.loader = false;
      this.selection.clear();
      this.showHideCols();
    }, err => {
      this.tRowErr = true;
      this.loader = false;
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.LoxySoftId + this.getFirstname(item) + this.getLastname(item) + item.Project_name + item.Time1 + item.Time3 + item.TotalTime + item.WorkingDate + item.ImportId;
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private setExcelHeaders() {
    this.arrToPrint = [];
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      if (this.displayColumnToShow.indexOf(obj.label) > -1 && obj.label != 'actions') {
        this.arrToPrint[0].push(obj.column)
      }
    });
  }

  private setExcelValues() {
    if (this.dataSource && this.dataSource.data.length) {
      this.dataSource.filteredData.forEach((val: any) => {
        let newLine = [];
        this.displayColumnToShow.forEach((key) => {
          if (key != 'actions') {
            let str = key.split('.').reduce((o, i) => { if (o && o[i]) { return o[i] } }, val);
            if (key == 'WorkingDate') {
              let toSetDate = {
                WorkingDate: str
              }
              str = this.getWorkingDate(toSetDate).toString();
            }
            newLine.push(str);
          }
        });
        this.arrToPrint.push(newLine);
      });
    }
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols() {
    this.displayColumnToShow = [];
    this.filterDisplayColumnToShow = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        this.displayColumnToShow.push(obj.label);
        this.filterDisplayColumnToShow.push(this.toggleFilterColumns[ind].label);
        if (this.multiColFilter[obj.label] === undefined) {
          this.multiColFilter[obj.label] = '';
        }
      } else {
        if (this.multiColFilter[obj.label]) {
          this.multiColFilter[obj.label] = '';
          this.applyColumnFilter();
        }
      }
    });
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      /* generate worksheet */
      this.setExcelHeaders();
      this.setExcelValues();
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Import_Time_List_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }

  getHour(time) {
    if (time && time.includes('T')) {
      return _moment(time, 'YYYY-MM-DDTHH:mm:ss').hour();
    }
    return _moment(time, 'HH:mm:ss').hour();
  }

  getMinute(time) {
    return _moment(time, 'HH:mm:ss').minute();
  }

  getSecond(time) {
    return _moment(time, 'HH:mm:ss').second();
  }

  openModal(content, contentAccessId, toClient?) {
    if (content === 'create') {
      this.modalFormGroup.get('project_name').enable();
      this.modalFormGroup.get('name').enable();
      this.modalFormGroup.get('date').enable();
      this.modalFormGroup.reset();
      this.timeCreateOrupdate = 'create';
      this.updateErrMsg = false;
      this.clientTitle = "Lägg till fil";
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'update') {
      this.timeCreateOrupdate = 'update';
      this.modalFormGroup.patchValue({
        project_name: { Project_id: toClient.ProjectID, Project_name: toClient.Project_name },
        Overksamtid: { hour: this.getHour(toClient.Time1), minute: this.getMinute(toClient.Time1), second: this.getSecond(toClient.Time1) },
        Inloggadtid: { hour: this.getHour(toClient.TotalTime), minute: this.getMinute(toClient.TotalTime), second: this.getSecond(toClient.Time1) },
        Efterberabetningstid: { hour: this.getHour(toClient.Time3), minute: this.getMinute(toClient.Time3), second: this.getSecond(toClient.Time3) },
        date: toClient.WorkingDate,
        LoxySoftId: toClient.LoxySoftId,
        Start_time: { hour: this.getHour(toClient.Start_time), minute: this.getMinute(toClient.Start_time), second: this.getSecond(toClient.Start_time) },
        End_time: { hour: this.getHour(toClient.End_time), minute: this.getMinute(toClient.End_time), second: this.getSecond(toClient.End_time) }
      });
      this.modalFormGroup.patchValue({
        name: this._setEmployeeInEdit(toClient.Employee_id),
      });
      this.modalFormGroup.get('project_name').disable();
      this.modalFormGroup.get('name').enable();
      this.modalFormGroup.get('date').disable();
      this.updateErrMsg = false;
      this.clientTitle = "Uppdaterings tid";
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'import') {
      this.updateErrMsg = false;
      this.isImportError = false;
      this.clientTitle = "Importera Tider";
      this.uploader.clearQueue();
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-import', backdrop: "static" });
    } else if (content === 'delete') {
      this.deleteErrMsg = false;
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-delete-time', backdrop: "static" });
    } else if (content === 'deleteForImportId') {
      this.deleteImportId.patchValue(null);
      this.showDeleteImportIdErrMsg = false;
      this.deleteImportIdErrMsg = '';
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-delete-time', backdrop: "static" });
    }
    this.uploadOption = '0';
    this.delTimeData = toClient;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  deleteTime() {
    this.spinner.active = true;
    this.impOrderService.deleteTime(this.delTimeData).subscribe(res => {
      if (res.message === 'Record deleted successfully') {
        this.loadImportTime();
        this.resDeleteMessage.success = true;
        this.resDeleteMessage.error = false;
        this.deleteEmpModalRef.close('submitted');
      } else {
        this.deleteEmpModalRef.close('submitted');
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = true;
      }
      setTimeout(() => {
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = false;
        this._ref.detectChanges();
      }, 5000);
      this._ref.detectChanges();
      this.spinner.active = false;
    }, error => {
      if (error.error.message) {
        this.deleteErrMsg = true;
      }
    });
    this.spinner.active = false;
  }

  getProjectListByClient(clientId) {
    this.clientProjectsArr = [];
    this.clientsProductsArr = [];
    this.modalFormGroup.controls.project_name.reset();
    this.modalFormGroup.controls.product_name.reset();
    this.projectsArr.forEach((obj) => {
      if (obj.Client_id === clientId._id) {
        this.clientProjectsArr.push(obj);
      }
    });
  }

  compareModalClient(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1._id === opt2._id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalProject(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.Project_id === opt2.Project_id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalProduct(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.prod_id === opt2.Product_id) {
      return true;
    } else {
      return false;
    }
  }

  loadEmployee() {
    this.sharedServices.getAllActiveInactiveEmployeeList().subscribe(res => {
      let allEmployeeData = res;
      allEmployeeData.forEach((obj) => {
        this.empArr.push({
          id: obj.Employee_id,
          name: obj.first_name + " " + obj.last_name
        });
      });
      this.empArr.sort(function (a, b) {
        if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
        if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
        return 0;
      });
    });
  }

  displayFn(user?: any): string | undefined {
    return user ? user.name : '';
  }

  onAddEmployeeFromClick(event) {
    if (event.option.value) {
      this.projectService.getEmployee(event.option.value.id).subscribe(res => {
        if (res) {
          this.modalFormGroup.patchValue({
            LoxySoftId: res.loxysoft_id
          });
        }
      });
    }
  }

  private _filter(value: string): string[] {
    let filterValue = '';
    if (typeof value === 'string') {
      filterValue = value.toLowerCase();
    }
    return this.empArr.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  private _setEmployeeInEdit(empId: any) {
    return this.empArr.find((employee) => employee.id === empId);
  }

  applyColumnFilter() {
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(item).forEach((key) => {
        if ((item[key] && filterString[key]) || ((item[key] >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (typeof item[key] != 'string') {
            itemString = item[key].toString();
          } else {
            if (key === 'WorkingDate') {
              itemString = this.getWorkingDate(item).toString();
            } else {
              itemString = item[key];
            }
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!item[key] || (item[key] <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  deleteByImportId() {
    if (this.deleteImportId.valid) {
      this.spinner.active = true;
      this.impOrderService.deleteByImportId(this.deleteImportId.value, 'Hours').subscribe(res => {
        if (res.message === 'Record deleted successfully') {
          this.loadImportTime();
          this.resDeleteMessage.success = true;
          this.resDeleteMessage.error = false;
          this.deleteEmpModalRef.close('submitted');
        } else {
          this.spinner.active = false;
          this.deleteEmpModalRef.close('submitted');
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = true;
        }
        setTimeout(() => {
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = false;
          this._ref.detectChanges();
        }, 5000);
        this.spinner.active = false;
        this._ref.detectChanges();
      }, error => {
        if (error.error.message) {
          if (error.error.message === 'Wrong import id') {
            this.deleteImportIdErrMsg = this.translate.instant('COMMON.ERROR') + "!Felaktigt import-ID!";
          } else {
            this.deleteImportIdErrMsg = this.translate.instant('COMMON.ERROR') + "!Ser ut som något gick fel!";
          }
          this.showDeleteImportIdErrMsg = true;
          setTimeout(() => {
            this.showDeleteImportIdErrMsg = false;
            this._ref.detectChanges();
          }, 5000);
        }
        this.spinner.active = false;
        this._ref.detectChanges();
      });
    }
  }

  getSelectedYear(year?: any) {
    if (year) {
      this.yearSelected = year;
    } else {
      this.yearSelected = new Date().getFullYear();
    }
    this.monthSelected = null;
  }

  getSelectedMonth(monthObj?: any) {
    if (monthObj && monthObj.value) {
      this.monthSelected = monthObj.value;
    } else {
      this.monthSelected = new Date().getMonth() + 1;
    }
    if (!((this.monthSelected == this.unchangedSelectedMonth) && (this.yearSelected == this.unchangedSelectedYear))) {
      this.unchangedSelectedMonth = this.monthSelected;
      this.unchangedSelectedYear = this.yearSelected;
      this.setPageParams(false);
    }
  }

  protected _projectFilter(): any[] {
    if (this.projectsArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['projectNameFilter'].value && (typeof this.modalFormGroup.controls['projectNameFilter'].value == 'string') && this.modalFormGroup.controls['projectNameFilter'].value.trim() != '') {
      const depfilterValue = this.modalFormGroup.controls['projectNameFilter'].value.toLowerCase();
      this.projectFilteredOptions.next(
        this.projectsArr.filter(dep => (dep.Project_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.projectFilteredOptions.next(this.projectsArr.slice());
      return;
    }
  }

  converToNumber(val) {
    if (typeof val != 'number') {
      return parseFloat(val);
    } else {
      return val;
    }
  }

  converToInteger(val) {
    if (typeof val != 'number') {
      return parseInt(val);
    } else {
      return null;
    }
  }

  setPageParams(filterChanged: boolean, pageEvent?: any) {
    if (pageEvent) {
      this.pageIndexNumber = pageEvent.pageIndex;
      this.itemsPerPage = pageEvent.pageSize;
      this.pageChanged = true;
    } else {
      this.pageChanged = false;
    }
    if (filterChanged) {
      this.pageIndexNumber = 0;
    }
    let toSetQueryParams: any = {
      ms: this.monthSelected,
      sa: this.yearSelected,
      pin: this.pageIndexNumber,
      ipp: this.itemsPerPage,
      fic: filterChanged,
      pac: this.pageChanged,
      sKey: this.sortKey,
      sDir: this.sortDir
    };
    this.toggleFilterColumns.forEach((tfc) => {
      if (this.multiColFilter[tfc.key]) {
        toSetQueryParams[tfc.params] = this.multiColFilter[tfc.key];
      }
    });
    this.router.navigate([],
      {
        queryParams: toSetQueryParams,
      });
  }

  sortChanges(ev) {
    if (ev) {
      this.sortKey = ev.active;
      this.sortDir = ev.direction;
    }
    this.setPageParams(false);
  }
}
