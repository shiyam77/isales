import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import * as _moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ImportordertimeService } from '../_core/services/importordertime.service';
type AOA = any[][];

@Component({
    selector: 'm-import-log',
    templateUrl: './importlog.component.html',
    styleUrls: ['./importlog.component.scss']
})
export class ImportLogComponent implements OnInit {

    spinner: SpinnerButtonOptions = {
        active: false,
        spinnerSize: 18,
        raised: true,
        buttonColor: 'primary',
        spinnerColor: 'accent',
        fullWidth: false
    };
    errDataSource:any = new MatTableDataSource([]);
    errImportArr: any[] = [];
    errImportArrLength: any = 0;
    errPageSize: any = 20;
    errPageIndex: any = 0;

    resCreateMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    id: number;
    type: string;
    errDisplayColumnToShow:any;
    moment_date = _moment;
    sortParams:any = {
        sort_by:'',
        sort_order:'',
        sort_view:''
    };

    constructor(
        private impRegretService: ImportordertimeService,
        private _ref: ChangeDetectorRef,
        private route: ActivatedRoute) {
            this.errDataSource = new MatTableDataSource<any>([]);
        }

    ngOnInit() {
        this.route.queryParams.subscribe(params => {
           this.id=params.id;
           this.type=params.type;
        });
        if(this.type=='sales'){
            this.errDisplayColumnToShow = ['Lineno','Reason','LoxySoftId','Client_name','Project_name','Product_name','SoldQty','WorkingDate','ImportId'];
        }else if(this.type=='regret'){
          this.errDisplayColumnToShow = ['Lineno','Reason','LoxySoftId','Client_name','Project_name','Product_name','SoldQty','WorkingDate','ImportId'];
        }else if(this.type=='hours'){
          this.errDisplayColumnToShow = ['Lineno','Reason','LoxySoftId','Client_name','Project_name','Start_time','End_time','Time1','TotalTime','Time3','WorkingDate','ImportId'];
        }
        this.UploadLogFile();
    }

    totalCount:number=0;
    successCount:number=0;
    failureCount:number=0;
       
    UploadLogFile() {
        this.spinner.active = true;
        let toSendLogReq:any = {
            import_id:this.id
        };
        if(this.sortParams.sort_order){
            toSendLogReq.sort_by = this.sortParams.sort_by;
            toSendLogReq.sort_order = this.sortParams.sort_order;
        }
        toSendLogReq.sort_view = this.sortParams.sort_view;
        this.impRegretService.logfile(toSendLogReq,this.type).subscribe((res: any) => {
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            let resultarr = [];
            this.spinner.active=true;
            this.totalCount=res[0].total_count;
            this.successCount=res[0].success_count;
            this.failureCount=res[0].failure_count;
            if(this.type == 'sales' || this.type == 'regret'){
                if(res[0].data && (res[0].data.length > 0)){
                    res[0].data.forEach((obj) => {
                        let datasourceObj: any = {};
                        datasourceObj.Lineno = obj.Lineno;
                        datasourceObj.LoxySoftId = obj.LoxySoftId;
                        datasourceObj.SoldQty = obj.SoldQty;
                        datasourceObj.Client_name = obj.Client_name;
                        datasourceObj.Project_name = obj.Project_name;
                        datasourceObj.Product_name = obj.Product_name;
                        datasourceObj.Status = obj.Status;
                        datasourceObj.Reason = obj.Reason;
                        datasourceObj.WorkingDate = this.getWorkingDate(obj);
                        datasourceObj.ImportId = obj.ImportId;
                        resultarr.push(datasourceObj);
                    });
                }
            }else if(this.type == 'hours'){
                if(res[0].data && (res[0].data.length > 0)){
                    res[0].data.forEach((obj) => {
                        let datasourceObj: any = {};
                        datasourceObj.Lineno = obj.Lineno;
                        datasourceObj.LoxySoftId = obj.LoxySoftId;
                        datasourceObj.Time1 = obj.Time1;
                        datasourceObj.Client_name = obj.Client_name;
                        datasourceObj.Project_name = obj.Project_name;
                        datasourceObj.TotalTime = obj.TotalTime;
                        datasourceObj.Time3 = obj.Time3;
                        datasourceObj.Status = obj.Status;
                        datasourceObj.Reason = obj.Reason;
                        datasourceObj.WorkingDate = this.getWorkingDate(obj);
                        datasourceObj.ImportId = obj.ImportId;
                        resultarr.push(datasourceObj);
                    });
                }
            }
            this.errImportArr = resultarr;
            this.errDataSource = this.errImportArr;
            setTimeout(() => {
                this.resCreateMessage.success = false;
                this.resCreateMessage.error = false;
                this._ref.detectChanges();
            }, 5000)
            this._ref.detectChanges();
            this.spinner.active = false;
        }, err => {
            this.spinner.active = false;
        });
    }

    handleErrImportPage(e: any) {
        this.errPageIndex = e.pageIndex;
        this.errPageSize = e.pageSize;
        this.errImportArrPageIterator();
    }

    errImportArrPageIterator() {
        let start = this.errPageIndex * this.errPageSize;
        let end = (this.errPageIndex + 1) * this.errPageSize;
        let tempErrArr = this.errImportArr.slice(start, end);
        this.errDataSource = new MatTableDataSource(tempErrArr);
    }
    
    getWorkingDate(client) {
        return _moment(new Date(client.WorkingDate)).format('YYYY-MM-DD');
    }

    logSort(sortEvent){
        if(sortEvent.direction == ''){
            this.sortParams.sort_by = '';
            this.sortParams.sort_order = '';
        }else{
            this.sortParams.sort_by = sortEvent.active;
            this.sortParams.sort_order = sortEvent.direction;
        }
        this.UploadLogFile();
    }

    setCountStatus(status){
        if(status == 'total'){
            this.sortParams.sort_view = '';     
        }else{
            this.sortParams.sort_view = status; 
        }
        this.UploadLogFile();        
    }

}
