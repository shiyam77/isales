import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-importordertime',
  templateUrl: './importordertime.component.html',
  styleUrls: ['./importordertime.component.scss']
})
export class ImportordertimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
