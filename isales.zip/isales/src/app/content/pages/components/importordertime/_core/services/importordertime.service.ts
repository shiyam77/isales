import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { ApiEndpointConstants } from '../../../../../../core/models/api-endpoint-constants';
import { TokenStorage } from '../../../../../../core/auth/token-storage.service';

const API_URL = ApiEndpointConstants.api_url;
const SALES_FILE_UPLOAD_URL = ApiEndpointConstants.ROUTES.SALES_FILE_UPLOAD;
const TIMES_FILE_UPLOAD_URL = ApiEndpointConstants.ROUTES.TIMES_FILE_UPLOAD;
const SALES_FILE_ADD_URL = ApiEndpointConstants.ROUTES.SALES_FILE_ADD;
const SALES_FILE_EDIT_URL = ApiEndpointConstants.ROUTES.SALES_FILE_EDIT;
const TIME_FILE_EDIT_URL = ApiEndpointConstants.ROUTES.TIME_FILE_EDIT;
const TOTAL_ORDER_EDIT_URL = ApiEndpointConstants.ROUTES.TOTAL_ORDER_EDIT;
const DELETE_TOTAL_ORDER_URL = ApiEndpointConstants.ROUTES.ECONOMY + '/orderDelete';
const GET_ALL_SALES_URL = ApiEndpointConstants.ROUTES.SALES_LIST;
const GET_ALL_HOURS_DETAILS = ApiEndpointConstants.ROUTES.HOURS_LIST;
const REGRETS_FILE_UPLOAD_URL = ApiEndpointConstants.ROUTES.REGRETS_FILE_UPLOAD;
const GET_ALL_REGRETS_DETAILS = ApiEndpointConstants.ROUTES.REGRETS_LIST;
const REGRETS_FILE_ADD_URL = ApiEndpointConstants.ROUTES.REGRETS_FILE_ADD;
const REGRETS_FILE_EDIT_URL = ApiEndpointConstants.ROUTES.REGRETS_FILE_EDIT;
const DELETE_ORDER_RECORD_URL = ApiEndpointConstants.ROUTES.ECONOMY + '/salesDelete';
const DELETE_TIME_RECORD_URL = ApiEndpointConstants.ROUTES.ECONOMY + '/hoursDelete';
const DELETE_REGRET_RECORD_URL = ApiEndpointConstants.ROUTES.ECONOMY + '/regretDelete';
const DELETE_BY_IMPORT_ID_URL = ApiEndpointConstants.ROUTES.ECONOMY + '/DeleteImportRecords';
const SALES_MOVE_URL = ApiEndpointConstants.ROUTES.ECONOMY + '/salesMove';
const LOG_SALES = ApiEndpointConstants.ROUTES.LOG_SALES;
const LOG_HOURS = ApiEndpointConstants.ROUTES.LOG_HOURS;
const LOG_REGRET = ApiEndpointConstants.ROUTES.LOG_REGRET;
const DOCUMENTS_UPLOAD_FOR_LEAVES_URL = ApiEndpointConstants.ROUTES.DOCUMENTS_UPLOAD_FOR_LEAVES;

@Injectable()
export class ImportordertimeService {

  constructor(private http: HttpClient, private tokenStorage: TokenStorage) { }

  getRoleAndId(): Observable<any> {
    let userData: any = {};
    userData.role = this.tokenStorage.getUserRoles().pipe(role => role);
    userData.userId = this.tokenStorage.getUserId().pipe(id => id);
    return userData;
  }

  logfile(reqData: any, option?: any): Observable<any> {
    if (option == "hours") {
      return this.http.post(`${API_URL}${LOG_HOURS}`, reqData).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
    } else if (option == "sales") {
      return this.http.post(`${API_URL}${LOG_SALES}`, reqData).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
    } else if (option == "regret") {
      return this.http.post(`${API_URL}${LOG_REGRET}`, reqData).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
    }
  }

  uploadOrderfile(file: any, option?: any): Observable<any> {
    let fileData = file;
    let formData: FormData = new FormData();
    if (fileData.length && fileData.length > 0) {
      fileData.forEach((fileObj) => {
        formData.append('fileSelect', fileObj.some);
      });
      if (option == 0 || option == 1) {
        formData.append('replace', option);
      } else {
        formData.append('replace', '0');
      }
    }
    return this.http.post(`${API_URL}${SALES_FILE_UPLOAD_URL}`, formData).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
  }

  uploadTimesFile(file: any, option?: any): Observable<any> {
    let fileData = file;
    let formData: FormData = new FormData();
    if (fileData.length && fileData.length > 0) {
      fileData.forEach((fileObj) => {
        formData.append('fileSelect', fileObj.some);
      });
      if (option == 0 || option == 1) {
        formData.append('replace', option);
      } else {
        formData.append('replace', '0');
      }
    }
    return this.http.post(`${API_URL}${TIMES_FILE_UPLOAD_URL}`, formData).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
  }


  addImportOrder(imp: any): Observable<any> {
    let form = imp;
    return this.http.post(`${API_URL}${SALES_FILE_ADD_URL}`, form).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
  }

  updateImportOrder(imp: any): Observable<any> {
    return this.http.post(`${API_URL}${SALES_FILE_EDIT_URL}`, imp).pipe(map((res: any) => res));
  }

  updateTotalOrder(imp: any): Observable<any> {
    return this.http.post(`${API_URL}${TOTAL_ORDER_EDIT_URL}`, imp).pipe(map((res: any) => res));
  }

  deleteTotalOrder(orderData: any) {
    return this.http.post(`${API_URL}${DELETE_TOTAL_ORDER_URL}`, orderData).pipe(map((res: any) => res));
  }

  updateImportTime(imp: any): Observable<any> {
    return this.http.post(`${API_URL}${TIME_FILE_EDIT_URL}`, imp).pipe(map((res: any) => res));
  }

  getAllImportOrder(query?: any): Observable<any> {
    return this.http.post(`${API_URL}${GET_ALL_SALES_URL}`, { month: query.month, year: query.year }).pipe(map((res: any) => res));
  }

  getAllImportTime(query?: any): Observable<any> {
    return this.http.post(`${API_URL}${GET_ALL_HOURS_DETAILS}`, { month: query.month, year: query.year }).pipe(map((res: any) => res));
  }

  getAllImportRegret(query?: any): Observable<any> {
    return this.http.post(`${API_URL}${GET_ALL_REGRETS_DETAILS}`, { month: query.month, year: query.year }).pipe(map((res: any) => res));
  }

  uploadRegretfile(file: any, option?: any): Observable<any> {
    let fileData = file;
    let formData: FormData = new FormData();
    if (fileData.length && fileData.length > 0) {
      fileData.forEach((fileObj) => {
        formData.append('fileSelect', fileObj.some);
      });
      if (option == 0 || option == 1) {
        formData.append('replace', option);
      } else {
        formData.append('replace', '0');
      }
    }
    return this.http.post(`${API_URL}${REGRETS_FILE_UPLOAD_URL}`, formData).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
  }

  addImportRegret(imp: any): Observable<any> {
    let form = imp;
    return this.http.post(`${API_URL}${REGRETS_FILE_ADD_URL}`, form).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
  }

  updateImportRegret(imp: any): Observable<any> {
    return this.http.post(`${API_URL}${REGRETS_FILE_EDIT_URL}`, imp).pipe(map((res: any) => res));
  }

  deleteOrder(orderData: any) {
    let deleteOrderData = {
      WorkingDate: orderData.WorkingDate,
      ClientId: orderData.Client_id,
      ProjectId: orderData.Project_id,
      ProductId: orderData.Product_id,
      LoxySoftId: orderData.LoxySoftId
    };
    return this.http.post(`${API_URL}${DELETE_ORDER_RECORD_URL}`, deleteOrderData).pipe(map((res: any) => res));
  }

  deleteTime(timeData: any) {
    let deleteTimeData = {
      WorkingDate: timeData.WorkingDate,
      ProjectId: timeData.Project_id,
      LoxySoftId: timeData.LoxySoftId
    };
    return this.http.post(`${API_URL}${DELETE_TIME_RECORD_URL}`, deleteTimeData).pipe(map((res: any) => res));
  }

  deleteRegret(regretData: any) {
    let deleteRegretData = {
      WorkingDate: regretData.WorkingDate,
      ClientId: regretData.Client_id,
      ProjectId: regretData.Project_id,
      ProductId: regretData.Product_id,
      LoxySoftId: regretData.LoxySoftId
    };
    return this.http.post(`${API_URL}${DELETE_REGRET_RECORD_URL}`, deleteRegretData).pipe(map((res: any) => res));
  }

  deleteByImportId(importId: any, importType: string) {
    return this.http.post(`${API_URL}${DELETE_BY_IMPORT_ID_URL}`, { ImportId: importId, ImportType: importType }).pipe(map((res: any) => res));
  }

  moveSalesDetails(moveData: any) {
    return this.http.post(`${API_URL}${SALES_MOVE_URL}`, moveData).pipe(map((res: any) => res));
  }

  getTotalOrderList(id): Observable<any> {
    let params = "";
    if (id !== "") {
      params = "/" + id;
    }
    return this.http.get(ApiEndpointConstants.api_url + `/totalorders` + params).pipe(
      map((res: any) => res
      ));
  }

  getImportOrderDataList(requestParams): Observable<any> {
    return this.http.post(ApiEndpointConstants.api_url + `/file/GetOverAllSalesDetails`, requestParams).pipe(
      map((res: any) => res
      ));
  }

  getImportRegretDataList(requestParams): Observable<any> {
    return this.http.post(ApiEndpointConstants.api_url + `/file/GetOverAllRegretDetails`, requestParams).pipe(
      map((res: any) => res
      ));
  }

  updateImportOrderData(data, id): Observable<any> {
    return this.http.put(ApiEndpointConstants.api_url + `/totalorderlist/` + id, data).pipe(
      map((res: any) => res
      ));
  }

  private handleError<T>(operation = 'operation', result?: any) {
    return (error: any): Observable<any> => {
      return throwError(result);
    };
  }

  getEmployeeSalesDetails(requestParams) {
    return this.http.post(ApiEndpointConstants.api_url + `/file/GetAllEmployeeSalesDetails`, requestParams).pipe(
      map((res: any) => res
      ));
  }

  getAllLoxysoftOverview(requestParams) {
    return this.http.post(ApiEndpointConstants.api_url + `/file/getLoxysoftOverview`, requestParams).pipe(
      map((res: any) => res
      ));
  }

  getEmployeeLoxysoftOverview(requestParams) {
    return this.http.post(ApiEndpointConstants.api_url + `/file/getEmployeeLoxysoftOverview`, requestParams).pipe(
      map((res: any) => res
      ));
  }

  getEmployeeRegretDetails(requestParams) {
    return this.http.post(ApiEndpointConstants.api_url + `/file/GetAllEmployeeRegretDetails`, requestParams).pipe(
      map((res: any) => res
      ));
  }

  uploadDocumentsForLeave(file: any, option?: any , emp_id?: any): Observable<any> {
    let fileData = file;
     let formData = new FormData();
    if (fileData.length && fileData.length > 0) {
      fileData.forEach((fileObj) => {
        formData.append('fileSelect', fileObj.some);
      });
      if (option == 0 || option == 1) {
        formData.append('replace', option);
      } else {
        formData.append('replace', '0');
      }
      formData.append('employee_id',emp_id);
    }
    return this.http.post(`${API_URL}${DOCUMENTS_UPLOAD_FOR_LEAVES_URL}`, formData).pipe(map((res: any) => res), catchError(this.handleError('Employee project', [])));
  }

}

