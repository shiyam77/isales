import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImporttimeComponent } from './importtime.component';

describe('ImporttimeComponent', () => {
  let component: ImporttimeComponent;
  let fixture: ComponentFixture<ImporttimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImporttimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImporttimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
