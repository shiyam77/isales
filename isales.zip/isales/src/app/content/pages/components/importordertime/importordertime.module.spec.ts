import { ImportordertimeModule } from './importordertime.module';

describe('ImportordertimeModule', () => {
  let importordertimeModule: ImportordertimeModule;

  beforeEach(() => {
    importordertimeModule = new ImportordertimeModule();
  });

  it('should create an instance', () => {
    expect(importordertimeModule).toBeTruthy();
  });
});
