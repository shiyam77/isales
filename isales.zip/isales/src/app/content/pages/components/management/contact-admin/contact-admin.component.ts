import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PersonalService } from '../../personal/_core/services/personal.service';

@Component({
  selector: 'm-contact-admin',
  templateUrl: './contact-admin.component.html',
  styleUrls: ['./contact-admin.component.scss']
})
export class ContactAdminComponent implements OnInit {

  @ViewChild('form') form;
  loader: boolean = false;
  addComplaint: FormGroup;
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  updateErrMsg: boolean;
  departmentCreateOrupdate: string;
  branches: Array<any> = [
    { value: 'Stockholm', viewValue: 'Stockholm' },
    { value: 'Dubai', viewValue: 'Dubai' }
  ];

  constructor(
    private _formBuilder: FormBuilder,
    private personalService: PersonalService,
    private _ref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.addComplaint = this._formBuilder.group({
      description: ['', Validators.required],
    });
  }

  createComplaint() {
    if (this.addComplaint.valid) {
      this.loader = true;
      let form1 = this.addComplaint.value;
      let comData: any = {
        "description": form1.description
      }
      this.personalService.addComplaint(comData).subscribe(res => {
        if (res.message === 'Complaints updated successfully') {
          this.resCreateMessage.success = true;
          this.resCreateMessage.error = false;
          this.form.resetForm();
        } else {
          this.resCreateMessage.success = false;
          this.resCreateMessage.error = true;
        }
        this.loader = false;
        this._ref.detectChanges();
        this.resetAlert();
        this.addComplaint.reset();

      }, error => {
        if (error.message) {
          this.addComplaint.reset();
          this.updateErrMsg = true;
          this.loader = false;
        }
      });
    }
  }

  private resetAlert() {
    setTimeout(() => {
      this.resCreateMessage.success = false;
      this.resCreateMessage.error = false;
      this._ref.detectChanges();
    }, 3000);
  }
}
