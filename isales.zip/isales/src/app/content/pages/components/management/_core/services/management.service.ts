import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ManagementService {

  Url: string = "http://localhost:3000";
  
  constructor(private http: HttpClient) { }

  getNotificationList(id): Observable<any> {
    let params = "";
    if (id !== "") {
      params = "/" + id;
    }
    return this.http.get(this.Url + `/notifications` + params).pipe(
      map((res: any) => res
      ));
  }

  addNotifications(data): Observable<any> {
    return this.http.post(this.Url + `/notifications`, data).pipe(
      map((res: any) => res
      ));
  }


}
