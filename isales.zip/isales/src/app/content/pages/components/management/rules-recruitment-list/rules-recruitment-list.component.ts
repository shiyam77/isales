import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatSelect } from '@angular/material';
import { Employee } from '../../personal/_core/models/employee.model';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { ReplaySubject, Subject } from 'rxjs';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';

@Component({
  selector: 'm-rules-recruitment-list',
  templateUrl: './rules-recruitment-list.component.html',
  styleUrls: ['./rules-recruitment-list.component.scss']
})
export class RulesRecruitmentListComponent implements OnInit {

  [x: string]: any;
  employeeId: number;
  userData: any = {};
  getUserData: any = {};
  itemsPerPage: number = 10;
  itemsInPageList: Array<number> = [10, 50, 500];
  departmentHistoryDisplayColumnToShow: any = ['branch', 'name', 'email', 'mobile', 'age', 'description', 'created_at'];
  departmentHistoryDataSource: any = [];
  addDepartment: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  loader: boolean = false;
  productsArr: Array<any> = [];
  clientsArr: Array<any> = [];
  projectsArr: Array<any> = [];
  st4projectsArr: Array<any> = [];
  statusHistoryList: any = [];
  profileStatus: any = {};
  momentFormatDate = moment;
  employeeData: Employee = new Employee();
  userQRCode: string = btoa('test');
  resMessage: {
    success?: boolean;
    error?: boolean;
    message?: string;
  } = {
      success: false,
      error: false,
      message: ''
    };
  updateErrMsg: boolean;
  spinners = false;
  addLoxy: FormGroup;
  modalRef: any;
  errorMsg: string = '';
  closeResult: any;
  descriptiondata: any;
  datas: any = [];
  deleteLeaveModalRef: any;
  deleteLeaveData: any;
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };


  @ViewChild('departmnetSearchSelect') departmnetSearchSelect: MatSelect;
  protected _onClientDestroy = new Subject<void>();
  departmentFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  fromDate: any = '';
  toDate: any = '';
  minDate = new Date();
  isFromPastDate: boolean = false;
  isToPastDate: boolean = false;
  userInitials: string;
  momentDateFormat = moment;
  departmentId: any;
  emp_status: string = 'G';
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tarRowNoRecord: boolean = false;
  tarRowErr: boolean = false;
  changeView: any = {
    viewVal: "EmployeeInfo"
  };
  departmentArr: Array<any> = [];
  private isSetProvisionAndCommission: any = {
    clientLoaded: false,
    projectLoaded: false,
    productLoaded: false,
    employeeLoaded: false
  };
  paramsSub: any;

  constructor(
    private _formBuilder: FormBuilder,
    private personalService: PersonalService,
    private sharedServices: SharedService,
    private _ref: ChangeDetectorRef,
    private modalService: NgbModal,
    private route: ActivatedRoute
  ) {
    this.route.params.subscribe(params => this.employeeId = +params.id);
  }

  ngOnInit() {
    this.getUserData = this.personalService.getRoleAndId();
    this.getUserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getUserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.getEmployeeReference();
    this.noteForm()
  }

  private resetTableAlert() {
    setTimeout(() => {
      this.resMessage.success = false;
      this.resMessage.error = false;
      this._ref.detectChanges();
    }, 5000);
  }

  getEmployeeData() {
    this.personalService.getEmployee(this.employeeId).subscribe((res: any) => {
      if (res) {
        if (res.employeestatus.length > 0) {
          this.statusHistoryList = res.employeestatus;
          res.employeestatus = res.employeestatus[res.employeestatus.length - 1];
        } else {
          this.statusHistoryList = [];
          let todates = moment(new Date()).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
          res.employeestatus = { fromdate: todates, todate: todates, Employeestatus: "G" };
        }
        this.profileStatus = res.employeestatus;
        this.employeeData = res;
        this.emp_status = res.emp_status;
        this.userInitials = this.employeeData.first_name.charAt(0).toUpperCase() + this.employeeData.last_name.charAt(0).toUpperCase();
        if (this.employeeData.Employee_id == this.userData.id && this.employeeData.img) {
          this.sharedServices.profileImgSub$.next(this.employeeData.img);
        }
        this.employeeData.provision = [];
        this.employeeData.compensation = [];
        if (res.bank && res.bank[0]) {
          this.employeeData.bank = res.bank[0];
        }
        let projectsArray = [];
        if (res.Projects && res.Projects.length > 0) {
          res.Projects.forEach((obj, ind) => {
            projectsArray.push({ Project_id: obj.Project_id, Project_name: obj.Project_name });
          });
        }
      }
      this.userQRCode = btoa(this.employeeData.Employee_id + '' + this.employeeData.first_name + '' + this.employeeData.last_name + '' + this.employeeData.personal_id);
    });
  }

  noteForm() {
    this.addNote = this._formBuilder.group({
      description: ['', [Validators.required]],
    });
  }

  openModal(content, contentAccessId, toContent?) {
    if (content == 'notes') {
      this.addNote.patchValue({
        description: toContent.description
      });
      this.addNote.disable();
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
    }
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  getEmployeeReference() {
    this.loader = true;
    this.personalService.getEmployeeReference().subscribe((res: any) => {
      if (res && (res.length > 0)) {
        this.departmentHistoryDataSource = new MatTableDataSource(res);
        this.departmentHistoryDataSource.paginator = this.paginator;
        this.departmentHistoryDataSource.sort = this.sort;
        this.tRowNoRecord = false;
        this.tRowErr = false;
      }
      else {
        this.departmentHistoryDataSource.paginator = this.paginator;
        this.tRowNoRecord = true;
        this.tRowErr = false;
        this.loader = false;
      }
      this._ref.detectChanges();
      this.resetTableAlert();
      this.loader = false;
    }, err => {
      this.tarRowNoRecord = false;
      this.tarRowErr = true;
      this._ref.detectChanges();
      this.loader = true;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}
