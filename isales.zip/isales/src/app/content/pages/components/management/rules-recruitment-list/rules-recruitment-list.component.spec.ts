import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RulesRecruitmentListComponent } from './rules-recruitment-list.component';

describe('RulesRecruitmentListComponent', () => {
  let component: RulesRecruitmentListComponent;
  let fixture: ComponentFixture<RulesRecruitmentListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RulesRecruitmentListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RulesRecruitmentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
