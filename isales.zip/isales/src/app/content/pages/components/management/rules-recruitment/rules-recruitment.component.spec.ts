import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RulesRecruitmentComponent } from './rules-recruitment.component';

describe('RulesRecruitmentComponent', () => {
  let component: RulesRecruitmentComponent;
  let fixture: ComponentFixture<RulesRecruitmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RulesRecruitmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RulesRecruitmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
