import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { PersonalService } from '../../personal/_core/services/personal.service';

@Component({
  selector: 'm-rules-recruitment',
  templateUrl: './rules-recruitment.component.html',
  styleUrls: ['./rules-recruitment.component.scss']
})

export class RulesRecruitmentComponent implements OnInit {
  branch = new FormControl('Stockholm');
  @ViewChild('form') form;
  loader: boolean = false;
  addReference: FormGroup;
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  updateErrMsg: boolean;
  departmentCreateOrupdate: string;
  modalRef: any;
  branches: Array<any> = [];
  title: string = "Regler för rekryteringsbonus";
  notes: any;
  selectedOption: any;
  constructor(
    private _formBuilder: FormBuilder,
    private personalService: PersonalService,
    private _ref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    //this.getRecruitment();
    this.addReference = this._formBuilder.group({
      branch: [this.branch.value],
      reference_name: ['', Validators.required],
      reference_email: [''],
      reference_mobile: ['', Validators.required],
      //reference_age: [''],
      //description: [''],
      surname:['',Validators.required]
    });
    
  }

  createDepartment() {
    if (this.addReference.valid) {
      this.loader = true;
      let form1 = this.addReference.value;
      let refData: any = {
        "branch": form1.branch,
        "reference_name": form1.reference_name,
        "reference_email": form1.reference_email,
        "reference_mobile": form1.reference_mobile,
        //"reference_age": form1.reference_age,
        //"description": form1.description,
        "surname": form1.surname
      }
      this.personalService.addReference(refData).subscribe(res => {
        if (res.message === 'Reference updated successfully') {
          this.resCreateMessage.success = true;
          this.resCreateMessage.error = false;
          this.form.resetForm();
          this.addReference.get('branch').setValue(this.branch.value);
        } else {
          this.resCreateMessage.success = false;
          this.resCreateMessage.error = true;
        }
        this.loader = false;
        this._ref.detectChanges();
        this.resetAlert();
      }, error => {
        if (error.message) {
          this.form.resetForm();
          this.updateErrMsg = true;
          this.loader = false;
        }
      });
    }
  }

  getRecruitment() {
    this.branches = [];
    this.notes = [];
    this.personalService.getRecruitment().subscribe(res => {
      if (res) {
        res.forEach(element => {
          this.branches.push({
            value: element.city, label: element.city, title: element.title, notes: element.Recruittext
          })
          const toSelect = this.branches.find(c => c.value =="Stockholm");
          this.addReference.get('branch').setValue(toSelect);

          if (element.city == 'Stockholm') {
            this.title = element.title,
            this.notes = element.Recruittext
          }
        });

      }
    });
  }

  recruitmentTitle(event) {
    // this.title = e.title;
    // this.notes = e.notes;
    this.addReference.get('branch').setValue(event.value);
  }
  compareModalRecuirment(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.city === opt2.city) {
      return true;
    } else {
      return false;
    }
  }

  private resetAlert() {
    setTimeout(() => {
      this.resCreateMessage.success = false;
      this.resCreateMessage.error = false;
      this._ref.detectChanges();
    }, 3000);
  }
}