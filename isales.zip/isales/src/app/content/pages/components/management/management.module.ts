import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagementGroupComponent } from './management-group/management-group.component';

import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { CoreModule } from '../../../../core/core.module';
import { PartialsModule } from '../../../partials/partials.module';
import { NgbModule, NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { CodePreviewModule } from '../../../partials/content/general/code-preview/code-preview.module';
import { MaterialPreviewModule } from '../../../partials/content/general/material-preview/material-preivew.module';
import {
	MatIconRegistry,
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatSliderModule,
	MatListModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatSlideToggleModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatSidenavModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatSnackBarModule,
	MatGridListModule,
	MatTableModule,
	MatExpansionModule,
	MatToolbarModule,
	MatSortModule,
	MatDividerModule,
	MatStepperModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	MatRadioModule,
} from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { QRCodeModule } from 'angularx-qrcode';
import { NgxPermissionsModule } from 'ngx-permissions';
import { FullCalendarModule } from 'ng-fullcalendar';
import { FileUploadModule } from 'ng2-file-upload';
import { ImageCropperModule } from 'ngx-image-cropper';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { ChartsModule } from 'ng2-charts';
import { MglTimelineModule } from 'angular-mgl-timeline';
import { RulesRecruitmentComponent } from './rules-recruitment/rules-recruitment.component';
import { RulesRecruitmentListComponent } from './rules-recruitment-list/rules-recruitment-list.component';
import { NotificationComponent } from './notification/notification.component';
import { ManagementService } from './_core/services/management.service';
import { SubheaderService } from '../../../../core/services/layout/subheader.service';
import { PersonalService } from '../personal/_core/services/personal.service';
import { ContactAdminComponent } from './contact-admin/contact-admin.component';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
}

const routes: Routes = [
	{
		path: '',
		children: [
			{
				path:'',
				component:ManagementGroupComponent,
				data:{
					permissions:{
						// only:['admin','employeeInfo'],
						only:['employeeInfo'],
						redirectTo:'/personal/employee/list'
					}
				}
      		},
      		{
				path:'recruitment',
				component:RulesRecruitmentComponent,
				data:{
					permissions:{
						// only:['admin','employeeInfo'],
						only:['employeeInfo'],
						redirectTo:'/personal/employee/list'
					}
				}
      		},
      		{
				path:'recruitment/list',
				component:RulesRecruitmentListComponent,
				data:{
					permissions:{
						// only:['admin','employeeInfo'],
						only:['employeeInfo'],
						redirectTo:'/personal/employee/list'
					}
				}
			},
			{
				path:'contact-admin',
				component:ContactAdminComponent,
				data:{
					permissions:{
						// only:['admin','employeeInfo'],
						only:['employeeInfo'],
						redirectTo:'/personal/employee/list'
					}
				}
			},
      		{
				path:'notification',
				component:NotificationComponent,
				data:{
					permissions:{
						// only:['admin','employeeInfo'],
						only:['employeeInfo'],
						redirectTo:'/personal/employee/list'
					}
				}
			}
		]
	}
];

@NgModule({
  imports: [
    CommonModule,
    PartialsModule,
    NgbModule,
    CodePreviewModule,
    CoreModule,
    MaterialPreviewModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,	
    PerfectScrollbarModule,	
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatSliderModule,
    MatListModule,
    MatCardModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    MatMenuModule,
    MatTabsModule,
    MatTooltipModule,
    MatSidenavModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatGridListModule,
    MatTableModule,
    MatExpansionModule,
    MatToolbarModule,
    MatSortModule,
    MatDividerModule,
    MatStepperModule,
    MatChipsModule,
    MatPaginatorModule,
    MatDialogModule,
    MatRadioModule,
    TranslateModule,
    QRCodeModule,
    WidgetChartsModule,
    NgxPermissionsModule.forChild(),
    FullCalendarModule,
    FileUploadModule,
    ImageCropperModule,
    NgxMatSelectSearchModule,
    ChartsModule,
    MglTimelineModule,
  ],
  declarations: [ManagementGroupComponent, RulesRecruitmentComponent, RulesRecruitmentListComponent, NotificationComponent, ContactAdminComponent],
  providers: [
	ManagementService,
	NgbAlertConfig, 
    {
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    MatIconRegistry,
    PersonalService,
    SubheaderService
  ]
})
export class ManagementModule { }
