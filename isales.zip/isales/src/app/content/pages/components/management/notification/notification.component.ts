import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatSelect, MatSort, MatTableDataSource } from '@angular/material';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ManagementService } from '../_core/services/management.service';

@Component({
  selector: 'm-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})

export class NotificationComponent implements OnInit {
  dataSource = new MatTableDataSource();
  notificationList = [];
  displayColumnToShow = ['message', 'send_to.name', 'actions'];
  modalFormGroup: FormGroup;
  deleteNotificationModalRef: any;
  closeResult: string;
  notificationTitle: string;
  delNotificationData: any;
  deleteErrMsg: boolean = false;
  updateErrMsg: boolean = false;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  multiColFilter = {
    message: '',
    'send_to.name': ''
  }
  sendtoList = [];
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  @ViewChild('departmentSearchSelect') departmentSearchSelect: MatSelect;
  protected _onDepDestroy = new Subject<void>();
  depFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  departmentArr: Array<any> = [];
  @ViewChild('departmentSearchSelect') clientSearchSelect: MatSelect;
  protected _onClientDestroy = new Subject<void>();
  clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  clientArr: Array<any> = [];
  @ViewChild('departmentSearchSelect') statusSearchSelect: MatSelect;
  protected _onStatusDestroy = new Subject<void>();
  statusFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  statusArr: Array<any> = [];
  @ViewChild('departmentSearchSelect') empSearchSelect: MatSelect;
  protected _onEmpDestroy = new Subject<void>();
  empFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  empArr: Array<any> = [];
  viewMessageData: string = "";
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  loader: boolean;
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  pageEvent: any;

  constructor(private modalService: NgbModal,
    private fb: FormBuilder,
    private managementService: ManagementService,
    private _ref: ChangeDetectorRef,
  ) { }

  ngOnInit() {
    this.dataSource = new MatTableDataSource([]);
    this.modalFormGroup = this.fb.group({
      sendto: [{ id: '', name: '' }, Validators.required],
      department: [''],
      departmentFilterControls: [''],
      client: [''],
      clientFilterControls: [''],
      status: [''],
      statusFilterControls: [''],
      employee: [''],
      employeeFilterControls: [''],
      message: ['', Validators.required]
    });
    this.loadNotification();
    this.getSendToList();
    this.departmentArr = [
      { id: 1, department: "dep1" },
      { id: 2, department: "dep2" },
      { id: 3, department: "dep3" },
      { id: 4, department: "dep4" },
      { id: 5, department: "dep5" },
    ];
    this.clientArr = [
      { _id: 1, client: "client1" },
      { _id: 2, client: "client2" },
      { _id: 3, client: "client3" },
      { _id: 4, client: "client4" },
      { _id: 5, client: "client5" },
    ];
    this.statusArr = [
      { _id: 0, status: "Narvaro" },
      { _id: 1, status: "Narvaro sen" },
      { _id: 2, status: "Sjuk" },
      { _id: 3, status: "Ogilitig franavaro" },
      { _id: 4, status: "Ledighet" },
      { _id: 5, status: "Utbildning" },
      { _id: 6, status: "Sjuk Vab" },
      { _id: 7, status: "Ej Schemalagad" },
      { _id: 8, status: "Ingen status" },
    ];
    this.empArr = [
      { _id: 1, emp_name: "emp_name1" },
      { _id: 2, emp_name: "emp_name2" },
      { _id: 3, emp_name: "emp_name3" },
      { _id: 4, emp_name: "emp_name4" },
      { _id: 5, emp_name: "emp_name5" },
    ];
    this.modalFormGroup.controls['departmentFilterControls'].valueChanges
      .pipe(takeUntil(this._onDepDestroy)).subscribe(() => this._DepFilter());
    this.modalFormGroup.controls['clientFilterControls'].valueChanges
      .pipe(takeUntil(this._onClientDestroy)).subscribe(() => this._ClientFilter());
    this.modalFormGroup.controls['statusFilterControls'].valueChanges
      .pipe(takeUntil(this._onStatusDestroy)).subscribe(() => this._StatusFilter());
    this.modalFormGroup.controls['employeeFilterControls'].valueChanges
      .pipe(takeUntil(this._onEmpDestroy)).subscribe(() => this._EmpFilter());
  }

  sendToChange(event) {
  }

  compareClientData(opt1: any, opt2: any) {
    if (opt1._id === opt2._id && opt1.client === opt2.client) {
      return true;
    } else {
      return false;
    }
  }

  compareDepartmentData(opt1: any, opt2: any) {
    if (opt1._id === opt2._id && opt1.department === opt2.department) {
      return true;
    } else {
      return false;
    }
  }

  compareStatusData(opt1: any, opt2: any) {
    if (opt1._id === opt2._id && opt1.status === opt2.status) {
      return true;
    } else {
      return false;
    }
  }

  compareEmployeeData(opt1: any, opt2: any) {
    if (opt1._id === opt2._id && opt1.emp_name === opt2.emp_name) {
      return true;
    } else {
      return false;
    }
  }

  compareSendtoData(opt1: any, opt2: any) {
    if (opt1.id === opt2.id && opt1.name === opt2.name) {
      return true;
    } else {
      return false;
    }
  }

  protected _ClientFilter(): any[] {
    if (this.clientArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['clientFilterControls'].value && (typeof this.modalFormGroup.controls['clientFilterControls'].value == 'string') && this.modalFormGroup.controls['clientFilterControls'].value.trim() != '') {
      const clientfilterValue = this.modalFormGroup.controls['clientFilterControls'].value.toLowerCase();
      this.clientFilteredOptions.next(
        this.clientArr.filter(dep => (dep.client.toLowerCase().indexOf(clientfilterValue) > -1))
      );
    } else {
      this.clientFilteredOptions.next(this.clientArr.slice());
      return;
    }
  }

  protected _DepFilter(): any[] {
    if (this.departmentArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['departmentFilterControls'].value && (typeof this.modalFormGroup.controls['departmentFilterControls'].value == 'string') && this.modalFormGroup.controls['departmentFilterControls'].value.trim() != '') {
      const depfilterValue = this.modalFormGroup.controls['departmentFilterControls'].value.toLowerCase();
      this.depFilteredOptions.next(
        this.departmentArr.filter(dep => (dep.department.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.depFilteredOptions.next(this.departmentArr.slice());
      return;
    }
  }

  protected _StatusFilter(): any[] {
    if (this.statusArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['statusFilterControls'].value && (typeof this.modalFormGroup.controls['statusFilterControls'].value == 'string') && this.modalFormGroup.controls['statusFilterControls'].value.trim() != '') {
      const statusfilterValue = this.modalFormGroup.controls['statusFilterControls'].value.toLowerCase();
      this.statusFilteredOptions.next(
        this.statusArr.filter(dep => (dep.status.toLowerCase().indexOf(statusfilterValue) > -1))
      );
    } else {
      this.statusFilteredOptions.next(this.statusArr.slice());
      return;
    }
  }

  protected _EmpFilter(): any[] {
    if (this.empArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['employeeFilterControls'].value && (typeof this.modalFormGroup.controls['employeeFilterControls'].value == 'string') && this.modalFormGroup.controls['employeeFilterControls'].value.trim() != '') {
      const empfilterValue = this.modalFormGroup.controls['employeeFilterControls'].value.toLowerCase();
      this.empFilteredOptions.next(
        this.empArr.filter(dep => (dep.emp_name.toLowerCase().indexOf(empfilterValue) > -1))
      );
    } else {
      this.empFilteredOptions.next(this.empArr.slice());
      return;
    }
  }

  getSendToList() {
    this.sendtoList = [
      { id: 1, name: "All" },
      { id: 2, name: "Client" },
      { id: 3, name: "Department" },
      { id: 4, name: "Status" },
      { id: 5, name: "Employee" },
    ];
  }

  loadNotification() {
    this.managementService.getNotificationList('').subscribe(res => {
      if (res && res[0]) {
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      } else {
        this.dataSource = new MatTableDataSource([]);
      }
    });
  }

  openModal(content, contentAccessId, toClient?) {
    if (content === 'create') {
      this.notificationTitle = "Lägg till Underrättelse";
      this.modalFormGroup.patchValue({
        sendto: '',
        department: '',
        departmentFilterControls: '',
        client: '',
        clientFilterControls: '',
        status: '',
        statusFilterControls: '',
        employee: '',
        employeeFilterControls: '',
        message: '',
      });
      this.modalFormGroup.reset();
      this.deleteNotificationModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'view') {
      this.viewMessageData = toClient.message;
      this.deleteNotificationModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    }
    this.delNotificationData = toClient;
    this.deleteNotificationModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  applyColumnFilter(searchkey) {
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(filterString).forEach((key) => {
        let keyNodeValue = key.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
        if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (typeof keyNodeValue != 'string') {
            itemString = keyNodeValue.toString();
          } else {
            itemString = keyNodeValue;
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!keyNodeValue || (keyNodeValue <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  createNotification() {
    if (this.modalFormGroup.controls['sendto'].value.id == 1) {
      this.modalFormGroup.controls['sendto'].setValidators([Validators.required]);
      this.modalFormGroup.controls['message'].setValidators([Validators.required]);
      this.modalFormGroup.controls['client'].clearValidators();
      this.modalFormGroup.controls['department'].clearValidators();
      this.modalFormGroup.controls['status'].clearValidators();
      this.modalFormGroup.controls['employee'].clearValidators();
      this.modalFormGroup.controls['sendto'].updateValueAndValidity();
      this.modalFormGroup.controls['message'].updateValueAndValidity();
      this.modalFormGroup.controls['client'].updateValueAndValidity();
      this.modalFormGroup.controls['department'].updateValueAndValidity();
      this.modalFormGroup.controls['status'].updateValueAndValidity();
      this.modalFormGroup.controls['employee'].updateValueAndValidity();
    }

    if (this.modalFormGroup.controls['sendto'].value.id == 2) {
      this.modalFormGroup.controls['sendto'].setValidators([Validators.required]);
      this.modalFormGroup.controls['message'].setValidators([Validators.required]);
      this.modalFormGroup.controls['client'].setValidators([Validators.required]);
      this.modalFormGroup.controls['department'].clearValidators();
      this.modalFormGroup.controls['status'].clearValidators();
      this.modalFormGroup.controls['employee'].clearValidators();
      this.modalFormGroup.controls['sendto'].updateValueAndValidity();
      this.modalFormGroup.controls['message'].updateValueAndValidity();
      this.modalFormGroup.controls['client'].updateValueAndValidity();
      this.modalFormGroup.controls['department'].updateValueAndValidity();
      this.modalFormGroup.controls['status'].updateValueAndValidity();
      this.modalFormGroup.controls['employee'].updateValueAndValidity();
    }
    else if (this.modalFormGroup.controls['sendto'].value.id == 3) {
      this.modalFormGroup.controls['sendto'].setValidators([Validators.required]);
      this.modalFormGroup.controls['message'].setValidators([Validators.required]);
      this.modalFormGroup.controls['department'].setValidators([Validators.required]);
      this.modalFormGroup.controls['client'].clearValidators();
      this.modalFormGroup.controls['status'].clearValidators();
      this.modalFormGroup.controls['employee'].clearValidators();
      this.modalFormGroup.controls['sendto'].updateValueAndValidity();
      this.modalFormGroup.controls['message'].updateValueAndValidity();
      this.modalFormGroup.controls['department'].updateValueAndValidity();
      this.modalFormGroup.controls['client'].updateValueAndValidity();
      this.modalFormGroup.controls['status'].updateValueAndValidity();
      this.modalFormGroup.controls['employee'].updateValueAndValidity();
    }
    else if (this.modalFormGroup.controls['sendto'].value.id == 4) {
      this.modalFormGroup.controls['sendto'].setValidators([Validators.required]);
      this.modalFormGroup.controls['message'].setValidators([Validators.required]);
      this.modalFormGroup.controls['status'].setValidators([Validators.required]);
      this.modalFormGroup.controls['client'].clearValidators();
      this.modalFormGroup.controls['department'].clearValidators();
      this.modalFormGroup.controls['employee'].clearValidators();
      this.modalFormGroup.controls['sendto'].updateValueAndValidity();
      this.modalFormGroup.controls['message'].updateValueAndValidity();
      this.modalFormGroup.controls['status'].updateValueAndValidity();
      this.modalFormGroup.controls['client'].updateValueAndValidity();
      this.modalFormGroup.controls['department'].updateValueAndValidity();
      this.modalFormGroup.controls['employee'].updateValueAndValidity();
    }
    else if (this.modalFormGroup.controls['sendto'].value.id == 5) {
      this.modalFormGroup.controls['sendto'].setValidators([Validators.required]);
      this.modalFormGroup.controls['message'].setValidators([Validators.required]);
      this.modalFormGroup.controls['employee'].setValidators([Validators.required]);
      this.modalFormGroup.controls['client'].clearValidators();
      this.modalFormGroup.controls['department'].clearValidators();
      this.modalFormGroup.controls['status'].clearValidators();
      this.modalFormGroup.controls['sendto'].updateValueAndValidity();
      this.modalFormGroup.controls['message'].updateValueAndValidity();
      this.modalFormGroup.controls['employee'].updateValueAndValidity();
      this.modalFormGroup.controls['client'].updateValueAndValidity();
      this.modalFormGroup.controls['department'].updateValueAndValidity();
      this.modalFormGroup.controls['status'].updateValueAndValidity();
    }
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let data = {
        message: this.modalFormGroup.controls['message'].value,
        send_to: this.modalFormGroup.controls['sendto'].value,
        sendtoList: []
      }
      if (this.modalFormGroup.controls['sendto'].value.id == 2) {
        data.sendtoList = this.modalFormGroup.controls['client'].value
      }
      else if (this.modalFormGroup.controls['sendto'].value.id == 3) {
        data.sendtoList = this.modalFormGroup.controls['department'].value
      }
      else if (this.modalFormGroup.controls['sendto'].value.id == 4) {
        data.sendtoList = this.modalFormGroup.controls['status'].value
      }
      else if (this.modalFormGroup.controls['sendto'].value.id == 5) {
        data.sendtoList = this.modalFormGroup.controls['employee'].value
      }
      this.managementService.addNotifications(data).subscribe(res => {
        if (res) {
          this.loadNotification();
          this.resCreateMessage.success = true;
          this.resCreateMessage.error = false;
          this.deleteNotificationModalRef.close('submitted');
        } else {
          this.spinner.active = false;
          this.deleteNotificationModalRef.close('submitted');
          this.resCreateMessage.success = false;
          this.resCreateMessage.error = true;
        }
        setTimeout(() => {
          this.resCreateMessage.success = false;
          this.resCreateMessage.error = false;
          this._ref.detectChanges();
        }, 5000)
        this._ref.detectChanges();

      }, error => {
        if (error.error.message) {
          this.updateErrMsg = true;
        }
      });
    }
  }

}
