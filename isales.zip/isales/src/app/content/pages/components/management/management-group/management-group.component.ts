import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'm-management-group',
  templateUrl: './management-group.component.html',
  styleUrls: ['./management-group.component.scss']
})
export class ManagementGroupComponent implements OnInit {

  formGroup: FormGroup;
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    this.formGroup = this.fb.group({
      name: ['', Validators.required],
      message: ['', Validators.required]
    });
  }

  Submit() {
    if (this.formGroup.valid) {
      this.formGroup.patchValue({
        name: ['', Validators.required],
        message: ['', Validators.required]
      });
      this.resCreateMessage.success = true;
      this.resCreateMessage.error = false;
      setTimeout(() => {
        this.resCreateMessage.success = false;
        this.resCreateMessage.error = false;
      }, 5000)
    }
  }
}
