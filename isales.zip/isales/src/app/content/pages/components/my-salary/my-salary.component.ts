import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-my-salary',
  templateUrl: './my-salary.component.html',
  styleUrls: ['./my-salary.component.scss']
})
export class MySalaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
