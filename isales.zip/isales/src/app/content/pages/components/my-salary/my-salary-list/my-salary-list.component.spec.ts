import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MySalaryListComponent } from './my-salary-list.component';

describe('MySalaryListComponent', () => {
  let component: MySalaryListComponent;
  let fixture: ComponentFixture<MySalaryListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MySalaryListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MySalaryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
