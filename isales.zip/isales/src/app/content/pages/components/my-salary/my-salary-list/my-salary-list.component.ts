import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { EconomyService } from '../../economy/_core/services/economy.service';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';

@Component({
  selector: 'm-my-salary-list',
  templateUrl: './my-salary-list.component.html',
  styleUrls: ['./my-salary-list.component.scss']
})
export class MySalaryListComponent implements OnInit {
  statusArr:any=[{id:0,name:'Närvaro'},
    {id:1,name:'Närvaro sen'},
    { id: 11, name: 'Närvaro godkänd sen' },
    {id:2,name:'Sjuk'},
    {id:3,name:'Ogiltig frånvaro'},
    {id:4,name:'Ledighet'},
    {id:5,name:'Utbildning'},
    {id:6,name:'Sjuk Vab'},
    {id:7, name:'Ej Schemalagd'}];

  forsaljningRapportDiagramData = {   
      backgroundColor: '#ef6a0f',
      data: {
        datasets:[
          {
            label: 'Lön',
               barPercentage: 0.5,
               barThickness: 4,
               maxBarThickness: 4,
            data: [],
            backgroundColor: '#ef6a0f',
        }]
      },
    label: ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'],
    labelunit: 'tkr',
    legendDisplay: false
  };

  espDetail: Array<any> = [];
  espDetailData:Array<any> = [];
  fTotOrder: number = 0;
  fRejOrder: number = 0;
  fTotProvision: number = 0;
  fTotTimlon: number = 0;
  fTotlon: number = 0;
  fTotLonInkSem: number = 0;
  fTotLonInkSoc: number = 0;
  fTotHour: number = 0;
  fTotMin: number = 0;
  fTotsec: number = 0;
  fTotTime: string = '00:00:00';
  fTotSnitt: number = 0;
  fTotEffective:number = 0;
  fTotWorkedHours:number = 0;
  fTotBusinessHours:number = 0;
  fTotIdleHours:number = 0;
  attendanceStatuswiseSummaryData:any = {};
  attendanceSummaryMonthYear:any = {
      month:'',
      year:''
  };
  xpandStatus: boolean = true;
  lonxpandStatus: boolean = false;
  loader: boolean = false;

  monthList = [
    { label: "Jan", value: 1 },
    { label: "Feb", value: 2 },
    { label: "Mar", value: 3 },
    { label: "Apr", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Jun", value: 6 },
    { label: "Jul", value: 7 },
    { label: "Aug", value: 8 },
    { label: "Sep", value: 9 },
    { label: "Okt", value: 10 },
    { label: "Nov", value: 11 },
    { label: "Dec", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  chartYearSelected = new Date().getFullYear();
  unchangedSelectedYear = null;
  unchangedSelectedMonth = null;
  reqFilterOptions: any;
  emp_dataSource: any = [];
  salaryReportList: any = [];
  revenue: any;
  salary: any;
  salary_sem: any;
  salary_soc: any;
  profit: any;
  hourly_revenue: any;
  salary_percent: any;
  profit_percent: any;
  employeedisplayedColumns: string[] = ['employee', 'totaltimmar', 'totalorder', 'snitt','effectivity', 'provperproduckt', 'totalprovperpro', 'timlon', 'totaltprovision', 'totalhourlysalary', 'totallon'];
  dataSource: any;
  totalOrdersForIndvProducts: any = {};
  totalProvPerProd: any = [];
  productsForProject: any[] = [];
  prodtottRowErr: boolean = false;
  prodtottRowNoRecord: boolean = false;
  footerProductCountObj: any = {};
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  getUserData: any = {};
  userData: any = {};
  projectsArr: Array<any> = [];
  productsArr: Array<any> = [];
  projClientArr: Array<any> = [];
  clientsArr: Array<any> = [];
  clientSelected: any;
  projectSelected: any;
  showLegends: boolean;
  @ViewChild('salaryChart') salaryChart:any;
  salarySem:any = 0;
  initalLoader:boolean = false;

  constructor(
    private personalService: PersonalService,
    private _ref: ChangeDetectorRef,
    private sharedServices: SharedService,
    private economyService: EconomyService
    ) { }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= 5); y++) {
        this.yearList.push(2020 + y);
    }
    this.getUserData = this.personalService.getRoleAndId();
    this.getUserData.role.subscribe(role => {
        this.userData.role = role.toString();
    });
    this.getUserData.userId.subscribe(id => {
        if (id) {
            this.userData.id = parseInt(id);
        }
        this.getClientList();
        this.getProjectList();
        this.getESPMonthlyReport();
        this.getChartData();
    });
    this.salarySem = 0;   
  }

  isSticky(column: string): boolean {
    return column === 'employee' ? true : false;
  }

  showTotTable() {
    this.xpandStatus = true;
    this.lonxpandStatus = false;
    this.emp_dataSource = [];
    this.salaryReportList = [];
  }

  showlonTable(ind, proj) {
      if(proj.type == 'project'){
        this.xpandStatus = false;
        this.lonxpandStatus = true;
        let monthInd = ind;
        this.loadEconomySalaryPeriodProductWiseReport(monthInd, proj.project_id);
      }
  }

  getESPMonthlyReport() {
    this.initalLoader = true;
    this.fTotOrder = 0;
    this.fRejOrder = 0;
    this.fTotProvision = 0;
    this.fTotTimlon = 0;
    this.fTotlon = 0;
    this.fTotLonInkSem = 0;
    this.fTotLonInkSoc = 0;
    this.fTotHour = 0;
    this.fTotMin = 0;
    this.fTotsec = 0;
    this.fTotSnitt = 0;
    this.fTotEffective = 0;
    this.fTotWorkedHours = 0;
    this.fTotBusinessHours = 0;
    this.fTotIdleHours = 0;

    let espData = {
        "year": this.yearSelected,
        "Employee_id": this.userData.id,
        'month':this.monthSelected
    };
    this.personalService.getESPMonthlyReport(espData).subscribe((res: any) => {
        this.fTotHour = 0;
        this.fTotMin = 0;
        this.fTotsec = 0;
        if (res) {
            this.espDetail = res[0].salary_data;
            this.espDetail.forEach((esObj) => {
                esObj.tot_salary_amount = 0;
                esObj.tot_salary_sem_amount = 0;
                esObj.tot_salary_soc_amount = 0;
                if (esObj.salary_data.length > 0) {
                    esObj.salary_data.forEach((sdataObj) => {
                        this.fTotOrder += sdataObj.total_orders;
                        this.fRejOrder += sdataObj.rejected_orders;
                        this.fTotProvision += sdataObj.total_provision;
                        this.fTotTimlon += sdataObj.total_hourly_salary;
                        this.fTotlon += sdataObj.total_salary;
                        this.fTotLonInkSem += sdataObj.total_salary_sem;
                        this.fTotLonInkSoc += sdataObj.total_salary_soc;
                        this.fTotWorkedHours += sdataObj.worked_hours;
                        esObj.tot_salary_amount += sdataObj.total_salary;
                        esObj.tot_salary_sem_amount += sdataObj.total_salary_sem;
                        esObj.tot_salary_soc_amount += sdataObj.total_salary_soc;
                        let a = sdataObj.total_time ? (sdataObj.total_time.split(":")) : ['00','00','00'];
                        if(a.length >=2){
                            this.fTotHour += parseInt(a[0]);
                            this.fTotMin  += parseInt(a[1]);
                            this.fTotsec  += parseInt(a[2]) >= 0 ? parseInt(a[2]) : 0;
                        }
                    });
                    this.fTotSnitt = (this.fTotOrder-this.fRejOrder)/this.fTotWorkedHours;
                    let totEfft:any = (((this.fTotBusinessHours+this.fTotIdleHours)/this.fTotWorkedHours)* 100).toFixed(2);
                    this.fTotEffective = (100-totEfft);
                }
            });
            this.salarySem = res[0].summary_data[0].yearly_total_salary_sem;
            this.fTotTime = this.getTotalTime();
        }
        this.initalLoader = false;
        this._ref.detectChanges();
    })
  }

  getTotalTime() {
    let hh1 = this.fTotHour;
    let mm1 = this.fTotMin;
    let ss1 = this.fTotsec;

    if (ss1 > 59) {
        let ss2 = ss1 % 60;
        let ssx = ss1 / 60;
        let ss3 = Math.floor(ssx);//add into min
        mm1 = mm1 + ss3;
        ss1 = ss2;
    }
    if (mm1 > 59) {
        let mm2 = mm1 % 60;
        let mmx = mm1 / 60;
        let mm3 = Math.floor(mmx);//add into hour
        hh1 = hh1 + mm3;
        mm1 = mm2;
    }
    let finaladd = hh1.toFixed(0) + ':' + mm1.toFixed(0) + ':' + ss1.toFixed(0);
    return finaladd;
  }

  loadEconomySalaryPeriodProductWiseReport(monthIndx, projId) {
    let client_id_forProj = this.setClientByProject(projId);
    this.prodtottRowErr = false;
    this.prodtottRowNoRecord = false;
        if (this.monthSelected && this.yearSelected) {
            let resultarr = [];
            this.loader = true;
            this.reqFilterOptions = { month: this.monthSelected, year: this.yearSelected, Client_id: client_id_forProj, Project_id: projId, Employee_id: this.userData.id };
            this.economyService.getAllEconomySalaryPeriodReportProductwiseForProfile(this.reqFilterOptions).subscribe(res => {
                if (res) {
                    this.salaryReportList = res;
                    let ms_Data = this.salaryReportList[0].monthly_summary_data[0];
                    if(ms_Data){
                        this.revenue = ms_Data.revenue;
                        this.salary = ms_Data.salary;
                        this.salary_sem = ms_Data.salary_sem;
                        this.salary_soc = ms_Data.salary_soc;
                        this.profit = ms_Data.profit;
                        this.hourly_revenue = ms_Data.hourly_revenue;
                        this.salary_percent = ms_Data.salary_percent;
                        this.profit_percent = ms_Data.profit_percent;
                    }
                    //forming header
                    let dayscount = new Date(this.yearSelected, monthIndx + 1, 0).getDate();
                    this.employeedisplayedColumns = [];
                    this.employeedisplayedColumns.push('employee');

                    for (let i = 0; i < dayscount; i++) {
                        let dt = i + 1;
                        this.employeedisplayedColumns.push(dt + "  " + this.getDay(dt));
                    }
                    this.employeedisplayedColumns.push('Total timmar');

                    if (this.salaryReportList[0].monthly_salary_data[0]) {
                        this.salaryReportList[0].monthly_salary_data[0].provison_data.forEach((prodObj) => {
                            this.employeedisplayedColumns.push(prodObj.product_name);
                            this.productsForProject.push(prodObj.product_name);
                        });
                    }
                    this.employeedisplayedColumns.push('Total order', 'Snitt', 'Effektivitet', 'Prov per produkt', 'Total prov per pro', 'Timlön', 'Totalt provision', 'Total timlön', 'Tot lön', 'Total lön ink sem', 'tot lön ink alt', 'Timl snitt');
                    res.forEach((obj) => {
                        this.footerProductCountObj = {};
                        let msdata = obj.monthly_salary_data[0]
                        {
                            let prodColDataOrders = {};
                            let productCountObj = {};
                            if (msdata && msdata.provison_data) {
                                this.employeedisplayedColumns.forEach((col_name, col_ind) => {
                                    if (col_name != 'employee' && col_name != 'Total timmar' && col_name != 'Total order' && col_name != 'Snitt' && col_name != 'Effektivitet' && col_name != 'Total prov per pro' && col_name != 'Tot lön' && col_name != 'Total timlön' && col_name != 'Totalt provision' && col_name != 'Timlön' && col_name != 'Total timlön' && col_name != 'Tot lön' && col_name != 'Total lön ink sem' && col_name != 'tot lön ink alt' && col_name != 'Timl snitt' && col_name != 'Prov per produkt' && (this.productsForProject.indexOf(col_name) < 0)) {
                                        productCountObj[col_name] = this.getProductCountArr(msdata.monthly_sales_data[col_ind - 1].sales_data, this.salaryReportList[0].monthly_salary_data[0].provison_data, msdata.monthly_sales_data[col_ind - 1].rejected_data);
                                        this.footerProductCountObj[col_name] = this.getProductCountArr(this.salaryReportList[0].daily_summary_data[col_ind - 1].sales_data, this.salaryReportList[0].monthly_salary_data[0].provison_data, this.salaryReportList[0].daily_summary_data[col_ind - 1].rejected_data);
                                    }
                                    if (this.productsForProject.indexOf(col_name) > -1) {
                                        prodColDataOrders[col_name] = this.getProdColData(msdata.provison_data, col_name);
                                        this.totalOrdersForIndvProducts[col_name] = this.getTotOrdersForIndvProducts(col_name);
                                    }

                                });
                                this.totalProvPerProd = this.getTotalProv();
                            }
                            let datasourceObj: any = {};
                            if(msdata){
                                datasourceObj = msdata;
                                datasourceObj.prodColDataOrders = prodColDataOrders;
                                datasourceObj.productCountObj = productCountObj;
                            }
                            resultarr.push(datasourceObj);
                        }
                    });
                    this.emp_dataSource = new MatTableDataSource(resultarr);
                    this.emp_dataSource.paginator = this.paginator;
                    this.emp_dataSource.sort = this.sort;
                    this.emp_dataSource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split('.').reduce((o, i) => o[i], item);
                        if (typeof sortString === 'string') {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    }
                    this.loader = false;
                    this.emp_dataSource = new MatTableDataSource(resultarr);
                } else {
                    this.prodtottRowNoRecord = true;
                    this.loader = false;
                    this.dataSource = new MatTableDataSource([]);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;
                    this.dataSource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split('.').reduce((o, i) => o[i], item);
                        if (typeof sortString === 'string') {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    }
                }
                this._ref.detectChanges();
            }, err => {
                this.prodtottRowErr = true;
                this.loader = false;
                this._ref.detectChanges();
            });
        }
  }

  getProductCountArr(val, provData, rejVal) {
    let b: any[] = [];
    if (provData) {
        if (!val || val.length == 0) {
            provData.forEach((pdata) => {
                b.push({
                    sales_count: '',
                    reject_count: ''
                });
            });
        } else {
            provData.forEach((pdata) => {
                let noCount = true;
                if (!rejVal || rejVal.length == 0) {
                    val.forEach((vdata) => {
                        if (vdata.product_id == pdata.product_id) {
                            b.push({
                                sales_count: vdata.sales_count,
                                reject_count: ''
                            });
                            noCount = false;
                        }
                    });
                } else {
                    val.forEach((vdata) => {
                        let productMatch = false;
                        let rejectCount = '';
                        if ((vdata.product_id == pdata.product_id)) {
                            rejVal.forEach((rData) => {
                                if ((vdata.product_id == rData.product_id) && rData.sales_count) {
                                    rejectCount = rData.sales_count;
                                }
                                productMatch = true;
                            });
                        }
                        if (productMatch) {
                            b.push({
                                sales_count: vdata.sales_count,
                                reject_count: rejectCount
                            });
                            noCount = false;
                        }
                    });
                }
                if (noCount) {
                    b.push({
                        sales_count: '',
                        reject_count: ''
                    });
                }
            });
            return b;
        }
    }
    return b;
}

getTotalProv() {
    let b: any[] = [];
    if (this.salaryReportList[0] && this.salaryReportList[0].monthly_salary_data[0] && this.salaryReportList[0].monthly_salary_data[0].provison_data) {
        for (let prodL = 0; prodL < this.salaryReportList[0].monthly_salary_data[0].provison_data.length; prodL++) {
            let total_prod_provisions = 0;
            this.salaryReportList[0].monthly_salary_data.forEach((msd) => {
                msd.provison_data.forEach((pd, pdKey) => {
                    if (pdKey === prodL) {
                        total_prod_provisions += pd.total_products_provision;
                    }
                });
            });
            b.push(total_prod_provisions);
        }
    }
    return b;
}


getTotOrdersForIndvProducts(col) {
    let b: any[] = [];
    if (this.salaryReportList[0] && this.salaryReportList[0].monthly_salary_data) {
        for (let prodL = 0; prodL < (this.salaryReportList[0].monthly_salary_data[0].provison_data.length + 2); prodL++) {
            b.push({ value: "", isEmpty: true });
        }
        let total_prod_orders = 0;
        let total_prod_rejected_orders = 0;
        let product_pos;
        let prod_total_prov = 0;
        this.salaryReportList[0].monthly_salary_data.forEach((msd) => {
            msd.provison_data.forEach((pd, pdKey) => {
                if (pd.product_name === col) {
                    total_prod_orders += pd.total_orders;
                    total_prod_rejected_orders += pd.rejected_order;
                    product_pos = pdKey;
                }
            });
        });
        if (this.salaryReportList[0].monthly_total_summary[0]) {
            this.salaryReportList[0].monthly_total_summary[0].sales_data.forEach((mtsd) => {
                if (mtsd.product_name === col) {
                    prod_total_prov = mtsd.product_provison_cost;
                }
            });
        }
        if (product_pos > -1) {
            if (total_prod_rejected_orders) {
                b[0].value = total_prod_orders + '(' + total_prod_rejected_orders + ')';
            } else {
                b[0].value = total_prod_orders;
            }
            b[0].isEmpty = false;
            b[b.length - 1].value = prod_total_prov;
            b[b.length - 1].isEmpty = false;
        }
    }
    return b;
  }

  getProdColData(prov_data, col) {
    let ord: any[] = [];
    if (prov_data) {
        if (!col) {
            prov_data.forEach((pdata) => {
                ord.push({ total_order_count: '', rejected_order_count: '' });
            });
        } else {
            prov_data.forEach((pdata) => {
                if (col == pdata.product_name) {
                    if (pdata.rejected_order) {
                        ord.push({
                            total_order_count: pdata.total_orders,
                            rejected_order_count: pdata.rejected_order
                        });
                    } else {
                        ord.push({
                            total_order_count: pdata.total_orders,
                            rejected_order_count: ''
                        });
                    }
                } else {
                    ord.push({ total_order_count: '', rejected_order_count: '' });
                }
            });
            return ord;
        }
    }
    return ord;
  }

  getDay(i) {
    let daynumber = new Date(this.yearSelected, this.monthSelected - 1, i).getDay();
    switch (daynumber) {
        case 0:
            return 'Sön';
        case 1:
            return 'Mån';
        case 2:
            return 'Tis';
        case 3:
            return 'Ons';
        case 4:
            return 'Tor';
        case 5:
            return 'Fre';
        case 6:
            return 'Lör';
        default:
            return 'default';
    }
  }

  setClientByProject(getProjId) {
    let setClientId: any;
    this.projectsArr.forEach((projObj) => {
        if (projObj.Project_id === getProjId) {
            setClientId = projObj.Client_id;
        }
    });
    return setClientId;
  }

  getClientListByProject() {
    this.clientsArr.forEach((cObj) => {
        this.projClientArr.push(cObj);
    });
  }

  filterClientProjArr(toFilterArr, clientId) {
    let retObj = { id: -1 };
    if (toFilterArr.length > 0) {
    toFilterArr.forEach((obj, in1) => {
        if (obj._id == clientId) {
        retObj.id = in1;
        }
    });
    }
    return retObj;
  }

  getProjectList() {
    this.sharedServices.getProjectList().subscribe((res:any) =>{
        if(res){
            this.projectsArr = res;
        }
    });
  }


  getClientList() {
    this.sharedServices.getClientList().subscribe((res:any) =>{
        if (res) {
            this.clientsArr = res;
        }
    });
  }

  convertNumber(toNumberVal){
    if(toNumberVal){
      return parseInt(toNumberVal);
    }
  }

  getSelectedMonth(monthObj?:any){
    if(monthObj && monthObj.value){
      this.monthSelected = monthObj.value;
    }else{
      this.monthSelected = new Date().getMonth()+1;
    }
    if(!((this.monthSelected == this.unchangedSelectedMonth) && (this.yearSelected == this.unchangedSelectedYear))){
      this.unchangedSelectedMonth = this.monthSelected;
      this.unchangedSelectedYear = this.yearSelected;      
      this.getESPMonthlyReport();
    }    
  }

  getChartData(){
    this.fTotOrder = 0;
    this.fRejOrder = 0;
    this.fTotProvision = 0;
    this.fTotTimlon = 0;
    this.fTotlon = 0;
    this.fTotLonInkSem = 0;
    this.fTotLonInkSoc = 0;
    this.fTotHour = 0;
    this.fTotMin = 0;
    this.fTotsec = 0;
    let espData = {
        "year": this.yearSelected,
        "Employee_id": this.userData.id
    };
    this.personalService.getESPMonthlyReport(espData).subscribe((res: any) => {
        if (res) {
            this.espDetailData = res[0].salary_data;
            this.forsaljningRapportDiagramData.data.datasets[0].data = [];
            if(this.espDetailData.length <= 0){
              this.salaryChart.barChartData = [];
              this.salaryChart.bcd.chart.update();
            }
            this.espDetailData.forEach((esObj) => {
                esObj.tot_salary_amount = 0;
                esObj.tot_salary_sem_amount = 0;
                esObj.tot_salary_soc_amount = 0;
                if (esObj.salary_data.length > 0) {
                    esObj.salary_data.forEach((sdataObj) => {
                        esObj.tot_salary_amount += sdataObj.total_salary;
                        esObj.tot_salary_sem_amount += sdataObj.total_salary_sem;
                        esObj.tot_salary_soc_amount += sdataObj.total_salary_soc;
                    });
                    this.forsaljningRapportDiagramData.data.datasets[0].data.push(parseFloat(esObj.tot_salary_sem_amount).toFixed(2));
                }else{
                this.forsaljningRapportDiagramData.data.datasets[0].data.push(parseFloat(esObj.tot_salary_sem_amount).toFixed(2));
                }
            });
            this.showLegends = false;
            this.salaryChart.barChartLegend = false;
            this.salaryChart.barChartData = [];
            if(this.salaryChart.chartData.data && this.salaryChart.chartData.data.datasets){
                for(let i=0;i<this.salaryChart.chartData.data.datasets.length;i++){
                this.salaryChart.barChartData.push({data:this.salaryChart.chartData.data.datasets[i].data,backgroundColor:this.salaryChart.chartData.data.datasets[i].backgroundColor,label:this.salaryChart.chartData.data.datasets[i].label});		
                }
                this.showLegends = true;
                this.salaryChart.barChartLegend = true;
            }else{
                this.salaryChart.barChartData.push({data:this.salaryChart.chartData.data,backgroundColor:this.salaryChart.chartData.backgroundColor});
            }
            setTimeout(() => {
                this.salaryChart.bcd.chart.update();
            }, 2000);
        }
        this._ref.detectChanges();
    });
  }
  yearChanged(){
    this.getChartData();
    this.getESPMonthlyReport();
  }

}
