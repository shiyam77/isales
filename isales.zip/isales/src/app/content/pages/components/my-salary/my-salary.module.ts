import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PerfectScrollbarConfigInterface, PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PartialsModule } from '../../../partials/partials.module';
import { NgbModule, NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { CoreModule } from '../../../../core/core.module';
import { MatDatepickerModule, MatInputModule, MatFormFieldModule, MatAutocompleteModule, MatCardModule, MatSelectModule, MatButtonModule, MatIconModule, MatNativeDateModule, MatCheckboxModule, MatMenuModule, MatTabsModule, MatTooltipModule, MatProgressBarModule, MatProgressSpinnerModule, MatTableModule, MatExpansionModule, MatSortModule, MatDividerModule, MatChipsModule, MatPaginatorModule, MatDialogModule, MatIconRegistry } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { PersonalService } from '../personal/_core/services/personal.service';
import { SubheaderService } from '../../../../core/services/layout/subheader.service';
import { MySalaryListComponent } from './my-salary-list/my-salary-list.component';
import { MySalaryComponent } from './my-salary.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
};
const routes: Routes = [
	{
    path:'',
    component:MySalaryComponent,
    children:[
      {
        path:'',
        redirectTo:'list',
        pathMatch:'full'
      },
      {
        path:'list',
        component:MySalaryListComponent        
      }
    ]
  }
];

@NgModule({
  imports: [
	CommonModule,
	PartialsModule,
	NgbModule,
	CoreModule,
	RouterModule.forChild(routes),
	FormsModule,
	ReactiveFormsModule,	
	PerfectScrollbarModule,	
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatTableModule,
	MatExpansionModule,
	MatSortModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	TranslateModule,	
	WidgetChartsModule,
	NgxPermissionsModule.forChild()
  ],
  declarations: [MySalaryListComponent, MySalaryComponent],
  providers: [
  NgbAlertConfig, 
  {
	provide: PERFECT_SCROLLBAR_CONFIG,
	useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
	},
	MatIconRegistry,
	PersonalService,
	SubheaderService
  ]
})
export class MySalaryModule { }
