import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { SpinnerButtonOptions } from '../../../partials/content/general/spinner-button/button-options.interface';
import { ProjectService } from '../project/_core/services/project.service';
import { SharedService } from '../../../../core/services/pages/shared.service';
type AOA = any[][];

@Component({
  selector: 'm-flight-mode',
  templateUrl: './flight-mode.component.html',
  styleUrls: ['./flight-mode.component.scss']
})
export class FlightModeComponent implements OnInit {
  modalFormGroup: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  arrToPrint: AOA = [];
  selection = new SelectionModel<any>(true, []);
  dataSource: MatTableDataSource<any>;
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  displayColumnToShow = ['status', 'created_at', 'created_by'];
  flightModeList: any[] = [];
  xpandStatus: boolean = false;
  searchInput: string = '';
  deleteEmpModalRef: any;
  closeResult: string;
  clientTitle: string;
  delEmployeeData: any;
  updateClientID: any;
  showAssignedMessage: boolean = false;
  resDeleteMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  toggleColumns = [
    { arrIndex: 1, column: 'Status', checked: true, label: 'status' },
    { arrIndex: 2, column: 'Skapat Datum', checked: true, label: 'created_at' },
    { arrIndex: 3, column: 'Godkänd av', checked: true, label: 'created_by' },
    { arrIndex: 4, column: 'Månad', checked: true, label: 'month' },
    { arrIndex: 5, column: 'År', checked: true, label: 'year' },
    { arrIndex: 6, column: 'ATGARDER', checked: true, label: 'actions', onlyAdmin: true },
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  momentDateFormat = _moment;
  flightModeStatus = 0;
  monthList = [
    { label: "Januari", value: 1 },
    { label: "Februari", value: 2 },
    { label: "Mars", value: 3 },
    { label: "April", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Juni", value: 6 },
    { label: "Juli", value: 7 },
    { label: "Augusti", value: 8 },
    { label: "September", value: 9 },
    { label: "Oktober", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  fRowNoRecord: boolean = false;
  fRowErr: boolean = false;
  flightModeType: string = 'flight_mode';

  constructor(private projectService: ProjectService,
    private modalService: NgbModal,
    private _formBuilder: FormBuilder,
    private _ref: ChangeDetectorRef,
    private sharedService: SharedService) { }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= 5); y++) {
      this.yearList.push(2020 + y);
    }
    this.modalFormGroup = this._formBuilder.group({
      flightModeStatus: [''],
      month: ['', Validators.required],
      year: ['', Validators.required]
    });
    this.setExcelHeaders();
    this.dataSource = new MatTableDataSource<any>();
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.loadFlightModeList();
  }

  slideToggleChange(e) {
  }

  loadFlightModeList() {
    this.loader = true;
    this.selection.clear();
    this.sharedService.getFlightModeList().subscribe(res => {
      console.log("res-flight",res)
      if (res) {
        if (typeof res == 'object') {
          this.flightModeList = [res];
          this.dataSource = new MatTableDataSource([res]);
        } else {
          this.flightModeList = res;
          this.dataSource = new MatTableDataSource(res);
        }
        this.dataSource.data.forEach((dObj) => {
          if (dObj.month) {
            dObj.month_label = this.monthList[this.monthList.findIndex(m => m.value == dObj.month)].label;
          }
        });
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        };
        if (this.flightModeList && (this.flightModeList.length > 0) && this.flightModeList[this.flightModeList.length - 1].flightmode) {
          if (this.flightModeList[this.flightModeList.length - 1].flightmode == 1) {
            this.flightModeStatus = 0;
          } else {
            this.flightModeStatus = 1;
          }
        } else {
          this.flightModeStatus = 1;
          this.fRowNoRecord = true;
        }
        this.fRowNoRecord = false;
        this.fRowErr = false;
        this.loader = false;
        this._ref.detectChanges();
        this.setExcelValues();
      }
    }, err => {
      if (err.message == 'no records found') {
        this.dataSource = new MatTableDataSource([]);
        this.flightModeStatus = 1;
        this.fRowNoRecord = true;
      } else {
        this.fRowErr = true;
      }
      this.loader = false;
      this._ref.detectChanges();
    });
    this.selection.clear();
    this.showHideCols();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item._id + item.department;
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private setExcelHeaders() {
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      if (obj.arrIndex !== 4) {
        this.arrToPrint[0].push(obj.column);
      }
    });
  }

  private setExcelValues() {
    this.flightModeList.forEach((val) => {
      let newLine = [];
      this.toggleColumns.forEach((obj) => {
        if (obj.arrIndex === 4 || obj.arrIndex === 3) {
          if (obj.arrIndex === 3) {
          }
        } else {
          let str = obj.label.split('.').reduce((o, i) => o[i], val);
          newLine.push(str);
        }
      });
      this.arrToPrint.push(newLine);
    });
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols() {
    this.displayColumnToShow = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
          this.displayColumnToShow.push(obj.label);
        } else {
          this.displayColumnToShow.push(obj.label);
        }
      }
    });
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      /* generate worksheet */
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Client_List_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }

  openModal(content, contentAccessId, toClient?) {
    if (content === 'create') {
      this.clientTitle = "Lägg till begär typ";
      this.modalFormGroup.patchValue({
        flightModeStatus: this.flightModeStatus == 1 ? true : false,
        month: '',
        year: ''
      });
      this.modalFormGroup.controls['flightModeStatus'].disable();
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'update') {
      this.modalFormGroup.enable();
      this.clientTitle = "Uppdatera begär typ";
      this.updateClientID = toClient._id
      this.modalFormGroup.patchValue({
        flightModeStatus: toClient.flightmode == 1 ? false : true,
        month: toClient.month,
        year: toClient.year
      });
      this.modalFormGroup.controls['flightModeStatus'].disable();
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'delete') {
      this.showAssignedMessage = false;
      this.flightModeType = 'delete';
      this.modalFormGroup.enable();
      this.clientTitle = "Uppdatera begär typ";
      this.updateClientID = toClient._id
      this.modalFormGroup.patchValue({
        flightModeStatus: toClient.flightmode == 1 ? false : true,
        month: toClient.month,
        year: toClient.year
      });
      this.modalFormGroup.controls['flightModeStatus'].disable();
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-deleteClient', backdrop: "static" });
    } else if (content === 'flight_mode') {
      this.showAssignedMessage = false;
      this.flightModeType = 'flight_mode';
      this.modalFormGroup.patchValue({
        flightModeStatus: this.flightModeStatus == 1 ? true : false,
        month: '',
        year: ''
      });
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-deleteClient', backdrop: "static" });
    }
    this.delEmployeeData = toClient;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  updateFlightMode() {
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let form1 = this.modalFormGroup.value;
      let flightModeData: any = {
        flightmode: this.flightModeStatus,
        employee_id: this.userData.id,
        month: form1.month,
        year: form1.year
      };
      this.sharedService.updateFlightModeStatus(flightModeData).subscribe(res => {
        if (res.message === 'Updated Successfully') {
          this.loadFlightModeList();
          this.resDeleteMessage.success = true;
          this.resDeleteMessage.error = false;
          this.deleteEmpModalRef.close('submitted');
        } else {
          this.spinner.active = false;
          this.deleteEmpModalRef.close('submitted');
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = true;
        }
        setTimeout(() => {
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = false;
          this._ref.detectChanges();
        }, 5000)
        this._ref.detectChanges();
      }, error => {
        if (error.error.message === 'Client_id is not Present or Not allowed to delete Client when Projects or Products of this Client assigned to Employee. Pls UnAssign and proceed') {
          this.showAssignedMessage = true;
          this.spinner.active = false;
        }
      });
    }
  }
}
