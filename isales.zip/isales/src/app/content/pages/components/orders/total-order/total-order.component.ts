import { Component, OnInit, ViewChild, ChangeDetectorRef, Inject } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource, MatSelect, SortDirection } from '@angular/material';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ClientList } from '../../project/_core/models/client-list.model';
import { ProjectService } from '../../project/_core/services/project.service';
import { ImportordertimeService } from '../../importordertime/_core/services/importordertime.service';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { Observable, Subject, ReplaySubject } from 'rxjs';
import { takeUntil, take } from 'rxjs/operators';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { TranslateService } from '@ngx-translate/core';
import { DOCUMENT } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

const URL = 'https://viafoneerp.azurewebsites.net/api/File/SalesFileUpload ';

type AOA = any[][];

@Component({
  selector: 'm-total-order',
  templateUrl: './total-order.component.html',
  styleUrls: ['./total-order.component.scss']
})
export class TotalOrderComponent implements OnInit {

  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;
  filedata: any = new Array<string>();
  uspFile: any = new Array<string>();
  clientsArr: Array<any> = [];
  projectsArr: Array<any> = [];
  productsArr: Array<any> = [];
  statusList: Array<any> = [];
  impOrderList: any[] = [];
  totalOrderList: any[] = [];
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tTotRowErr: boolean = false;
  tTotRowNoRecord: boolean = false;
  salesCreateOrupdate: string;
  clientProjectsArr: Array<any> = [];
  clientsProductsArr: Array<any> = [];
  addNoticer: FormGroup;
  empFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  statusFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  statusArr: Array<any> = [];
  modalFormGroup: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('TableTwoPaginator') paginatortot: MatPaginator;
  @ViewChild('TableTwoSort') sorttot: MatSort;
  arrToPrint: AOA = [];
  selection = new SelectionModel<ClientList>(true, []);
  dataSource: any = new MatTableDataSource();
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  loaderTotal: boolean = false;
  displayColumnToShow = ['LoxySoftId','Prospect_id', 'first_name', 'last_name', 'sold_qty', 'Client_name', 'status', 'comments', 'Project_name', 'Product_name', 'EmpProvisionIn', 'EmpProvisionOut', 'WorkingDate','ImportId'];
  filterDisplayColumnToShow = ['loxySoftId','prospect_id','firstname', 'lastname', 'SoldQty', 'client_name', 'statuses', 'Comments', 'project_name', 'product_name', 'provisionIn', 'provisionOut', 'workingDate','importId'];
  allClientList: ClientList[] = [];
  xpandStatus: boolean = false;
  searchInput: string = '';
  deleteEmpModalRef: any;
  closeResult: string;
  clientTitle: string;
  delOrderData: any;
  updateClientID: any;
  deleteErrMsg: boolean = false;
  updateErrMsg: boolean = false;
  deleteStatusErrMsg: boolean = false;
  updateStatusErrMsg: boolean = false;
  resDeleteMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateStatusMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };

  toggleColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'LoxySoftId' },
    { arrIndex: 2, column: 'Prospekt ID', checked: true, label: 'Prospect_id' },
    { arrIndex: 3, column: 'Fornamn', checked: true, label: 'first_name' },
    { arrIndex: 4, column: 'Efternamn', checked: true, label: 'last_name' },
    { arrIndex: 5, column: 'Antal saida', checked: true, label: 'sold_qty' },
    { arrIndex: 6, column: 'KUND', checked: true, label: 'Client_name' },
    { arrIndex: 7, column: 'PROJEKT', checked: true, label: 'Project_name' },
    { arrIndex: 8, column: 'PRODUKT', checked: true, label: 'Product_name' },
    { arrIndex: 9, column: 'PROVISIONIN', checked: true, label: 'EmpProvisionIn' },
    { arrIndex: 10, column: 'PROVISIONUT', checked: true, label: 'EmpProvisionOut' },
    { arrIndex: 11, column: 'DATUM', checked: true, label: 'WorkingDate' },
    { arrIndex: 12, column: 'Status', checked: true, label: 'status' },
    { arrIndex: 13, column: 'Comments', checked: true, label: 'comments' },
    { arrIndex: 14, column: 'IMPORTID', checked: true, label: 'ImportId' },
    { arrIndex: 15, column: 'ACTIONS', checked: true, label: 'actions' }
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  empArr: Array<any> = [];
  empFilterArr: Observable<any[]>;
  uploadOption: any = '0';
  multiColFilter = {
    LoxySoftId: '',
    Prospect_id:'',
    first_name: '',
    last_name: '',
    sold_qty: '',
    Client_name: '',
    status: '',
    comments: '',
    Project_name: '',
    Product_name: '',
    EmpProvisionIn: '',
    EmpProvisionOut: '',
    WorkingDate: '',
    ImportId: '',
  };

  errMultiColFilter = {
    Lineno: '',
    LoxySoftId: '',
    sold_qty: '',
    Client_name: '',
    status: '',
    comments: '',
    Project_name: '',
    Product_name: '',
    Reason: '',
    WorkingDate: '',
    ImportId: '',
  };

  deleteImportId: FormControl = new FormControl(null, Validators.required);
  showDeleteImportIdErrMsg: boolean = false;
  deleteImportIdErrMsg: string = '';
  previousEmployee: any;
  errDataSource: any;
  isImportError: boolean = false;
  monthList = [
    { label: "Jan", value: 1 },
    { label: "Feb", value: 2 },
    { label: "Mar", value: 3 },
    { label: "Apr", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Jun", value: 6 },
    { label: "Jul", value: 7 },
    { label: "Aug", value: 8 },
    { label: "Sep", value: 9 },
    { label: "Okt", value: 10 },
    { label: "Nov", value: 11 },
    { label: "Dec", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  unchangedSelectedYear = null;
  unchangedSelectedMonth = null;
  errImportArr: any[] = [];
  errImportArrLength: any = 0;
  errPageSize: any = 20;
  errPageIndex: any = 0;

  filtertoggleColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'loxySoftId' },
    { arrIndex: 2, column: 'Prospect_id', checked: true, label: 'prospect_id' },
    { arrIndex: 3, column: 'Fornamn', checked: true, label: 'firstname' },
    { arrIndex: 4, column: 'Efternamn', checked: true, label: 'lastname' },
    { arrIndex: 5, column: 'Antal saida', checked: true, label: 'SoldQty' },
    { arrIndex: 6, column: 'KUND', checked: true, label: 'client_name' },
    { arrIndex: 7, column: 'PROJEKT', checked: true, label: 'project_name' },
    { arrIndex: 8, column: 'PRODUKT', checked: true, label: 'product_name' },
    { arrIndex: 9, column: 'PROVISIONIN', checked: true, label: 'provisionIn' },
    { arrIndex: 10, column: 'PROVISIONUT', checked: true, label: 'provisionOut' },
    { arrIndex: 11, column: 'DATUM', checked: true, label: 'workingDate' },
    { arrIndex: 12, column: 'Status', checked: true, label: 'statuses' },
    { arrIndex: 13, column: 'Kommentar', checked: true, label: 'Comments' },
    { arrIndex: 14, column: 'IMPORTID', checked: true, label: 'importId' },
    { arrIndex: 15, column: 'ACTIONS', checked: true, label: 'Actions' }
  ];

  @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
  protected _onClientDestroy = new Subject<void>();
  clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  @ViewChild('projectSearchSelect') projectSearchSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  projectFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  @ViewChild('productSearchSelect') productSearchSelect: MatSelect;
  protected _onProductDestroy = new Subject<void>();
  productFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);


  importOrders$: Observable<any[]>;
  updateImportOrderData: any;

  queryParams = {
    loxySoftId: null,
    prospect_id:null,
    fName: null,
    lName: null,
    sold: null,
    cName: null,
    projName: null,
    stat: null,
    comment: null,
    importId:null,

    prodName: null,
    in: null,
    out: null,
    wDate: null,
    active: null,
    direct: null,
    page: null,
    month: null,
    year: null
  };

  sortActive = "WorkingDate";
  sortDirection: SortDirection = "desc"
  currentPage = 0;
  optionVal = "";
  isQueryParams = false;

  totalOrderDataSource: any = new MatTableDataSource();
  displayColumnToShowTotal = ['order', 'regret', 'total_order', 'regret_per'];

  pageEvent: any;
  constructor(
    private projectService: ProjectService,
    private impOrderService: ImportordertimeService,
    private modalService: NgbModal,
    private _formBuilder: FormBuilder,
    private _ref: ChangeDetectorRef,
    private personalService: PersonalService,
    private sharedServices: SharedService,
    private translate: TranslateService,
    @Inject(DOCUMENT) private documentObj: Document,
    private activatedRoute: ActivatedRoute,
    private location: Location,
    private router: Router) {
    this.dataSource = new MatTableDataSource<any>([]);
    this.errDataSource = new MatTableDataSource<any>([]);
    this.errDataSource.paginator = this.paginator;
    this.errDataSource.sort = this.sort;
    this.errDataSource.sortingDataAccessor = (item, property) => {
      let sortString = property.split('.').reduce((o, i) => o[i], item);
      if (typeof sortString === 'string') {
        sortString = sortString.toLowerCase();
      }
      return sortString;
    }
  }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= (new Date().getFullYear() - 2020)); y++) {
      this.yearList.push(2020 + y);
    }
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.activatedRoute.queryParams.subscribe(params => {
      if (params["optionVal"]) {
        this.queryParams = JSON.parse(atob(params["optionVal"]))
      }
      this.multiColFilter.LoxySoftId = this.queryParams.loxySoftId != null ? this.queryParams.loxySoftId : '';
      this.multiColFilter.Prospect_id = this.queryParams.prospect_id != null ? this.queryParams.prospect_id : '';
      this.multiColFilter.first_name = this.queryParams.fName != null ? this.queryParams.fName : '';
      this.multiColFilter.last_name = this.queryParams.lName != null ? this.queryParams.lName : '';
      this.multiColFilter.sold_qty = this.queryParams.sold != null ? this.queryParams.sold : '';
      this.multiColFilter.Client_name = this.queryParams.cName != null ? this.queryParams.cName : '';
      this.multiColFilter.status = this.queryParams.stat != null ? this.queryParams.stat : '';
      this.multiColFilter.comments = this.queryParams.comment != null ? this.queryParams.comment : '';
      this.multiColFilter.Project_name = this.queryParams.projName != null ? this.queryParams.projName : '';
      this.multiColFilter.Product_name = this.queryParams.prodName != null ? this.queryParams.prodName : '';
      this.multiColFilter.WorkingDate = this.queryParams.wDate != null ? this.queryParams.wDate : '';
      this.multiColFilter.EmpProvisionIn = this.queryParams.in != null ? this.queryParams.in : '';
      this.multiColFilter.EmpProvisionOut = this.queryParams.out != null ? this.queryParams.out : '';
      this.monthSelected = this.queryParams.month != null ? this.queryParams.month : this.monthSelected;
      this.yearSelected = this.queryParams.year != null ? this.queryParams.year : this.yearSelected;
      this.sortActive = this.queryParams.active != null ? this.queryParams.active : this.sortActive;
      this.sortDirection = this.queryParams.direct != null ? this.queryParams.direct : this.sortDirection;
      this.currentPage = this.queryParams.page;

      this.addNoticer = this._formBuilder.group({
        statusSelected: '',
        statusFilterControls: '',
        empSelected: '',
        employeeFilterControls: '',
        clientSelected: '',
        clientFilterControls: '',
        ProductFilterControls: '',
        productSelected: ''
      });

      this.statusArr = [];
      this.statusArr.push(
        { label: 'Godkänd', value: 'Godkänd' },
        { label: 'Ånger', value: 'Ånger' },
        { label: 'Bortfall', value: 'Bortfall' },
        { label: 'Ånger tidigare period', value: 'Ånger tidigare period' },
        { label: 'Tidigare period', value: 'Tidigare period' }
      );
      this.statusFilteredOptions.next(this.statusArr.slice());

      this.loadImportOrder();
      this.loadClientList();
      this.getClientList();
      this.getProductList();
      this.getProjectList();
      this.loadEmployee();
      this.loadTotalOrder();
      this.getStatusList();
    });

    this.addNoticer = this._formBuilder.group({
      statusSelected: '',
      statusFilterControls: '',
      empSelected: '',
      employeeFilterControls: '',
      clientSelected: '',
      clientFilterControls: '',
      ProductFilterControls: '',
      productSelected: ''
    });

    this.modalFormGroup = this._formBuilder.group({
      name: ['', Validators.required],
      antalsalda: ['', Validators.required],
      client_name: ['', Validators.required],
      project_name: ['', Validators.required],
      product_name: ['', Validators.required],
      date: ['', Validators.required],
      LoxySoftId: [''],
      status: ['', Validators.required],
      comment: ['', Validators.required]
    });
    this.addNoticer.controls['statusFilterControls'].valueChanges
      .pipe(takeUntil(this._onDestroy)).subscribe(() => this._Empfilter());
  }

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  searchList() {
  }

  getClientList() {
    this.clientsArr = [];
    this.sharedServices.getClientList().subscribe(res => {
      res.forEach((obj) => {
        this.clientsArr.push({
          id: obj._id,
          name: obj.name
        });
      });
      this.clientsArr.sort(function (a, b) {
        if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
        if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
        return 0;
      });
      this._clientFilter();
    });
  }

  getProductList() {
    this.productsArr = [];
    this.sharedServices.getProductList().subscribe(res => {
      res.forEach((obj) => {
        this.productsArr.push({
          id: obj.Product_id,
          name: obj.Product_name
        });
      });
      this.productsArr.sort(function (a, b) {
        if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
        if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
        return 0;
      });
      this._ProductFilter();
    });
  }

  setIntialEmployeeSearch() {
    this.clientFilteredOptions.pipe(take(1), takeUntil(this._onClientDestroy))
      .subscribe(() => {
        this.clientSearchSelect.compareWith = (a: any, b: any) => a && b && ((a.id == b.id) || (a.id == b.id) || (a.id == b.id));
      });
  }

  setIntialProductSearch() {
    this.productFilteredOptions.pipe(take(1), takeUntil(this._onProductDestroy))
      .subscribe(() => {
        this.productSearchSelect.compareWith = (a: any, b: any) => a && b && ((a.id == b.id) || (a.id == b.id) || (a.id == b.id));
      });
  }

  getStatusList() {
    this.statusList = [
      { Status_id: "Godkänd", Status_name: "Godkänd" },
      { Status_id: "Ånger", Status_name: "Ånger" },
      { Status_id: "Bortfall", Status_name: "Bortfall" },
      { Status_id: "Ånger tidigare period", Status_name: "Ånger tidigare period" },
      { Status_id: "Tidigare period", Status_name: "Tidigare period" }
    ];
  }

  getProjectList() {
    this.sharedServices.getProjectList().subscribe((res: any) => {
      if (res) {
        this.projectsArr = res;
        this.projectsArr.sort(function (a, b) {
          if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
          if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
          return 0;
        });
      }
    });
  }

  AddImportOrder() {
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let form1 = this.modalFormGroup.getRawValue();
      let tosendImportOrder = {
        "WorkingDate": _moment(form1.date).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss'),
        "ClientId": form1.client_name._id,
        "ProjectId": form1.project_name.Project_id,
        "ProductId": form1.product_name.Product_id,
        "LoxySoftId": form1.LoxySoftId,
        "SoldQuantity": form1.antalsalda,
      }

      if (this.salesCreateOrupdate === 'create') {
        this.impOrderService.updateImportOrder(tosendImportOrder).subscribe(res => {
          if (res.message === 'Updated Successfully') {
            this.loadImportOrder();
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.deleteEmpModalRef.close('submitted');
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          setTimeout(() => {
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this._ref.detectChanges();
          }, 5000)
          this._ref.detectChanges();

        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
        this.spinner.active = false;
      } else if (this.salesCreateOrupdate === 'update') {

        let tosendTotalOrder: any = {
          regret_id: "", sales_id: "",
          status: this.modalFormGroup.value.status.Status_id, comments: this.modalFormGroup.value.comment
        }
        if (this.updateImportOrderData.regret_id) {
          tosendTotalOrder.regret_id = this.updateImportOrderData.regret_id
        }
        if (this.updateImportOrderData.sales_id) {
          tosendTotalOrder.sales_id = this.updateImportOrderData.sales_id
        }
        this.impOrderService.updateTotalOrder(tosendTotalOrder).subscribe(res => {
          if (res.message === 'Record updated successfully') {
            this.loadImportOrder();
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.deleteEmpModalRef.close('submitted');
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          setTimeout(() => {
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this._ref.detectChanges();
          }, 5000)
          this._ref.detectChanges();

        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
        this.spinner.active = false;
      }
      this.spinner.active = false;
    }
  }

  public fileChangeEvent(fileInput: any) {
    if (fileInput.target.files && fileInput.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(fileInput.target.files[0]);
    }
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }

  loadTotalOrder() {
    this.loaderTotal = true;
    if (!this.yearSelected) {
      this.yearSelected = new Date().getFullYear();
    }

    if (!this.monthSelected) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.totalOrderDataSource = new MatTableDataSource([]);
    let loadTotalData: any = {
      month: this.monthSelected,
      year: this.yearSelected
    }
    if (this.addNoticer.value.statusSelected && this.addNoticer.value.statusSelected != "") {
      loadTotalData.status = this.addNoticer.value.statusSelected
    }
    if (this.addNoticer.value.empSelected && this.addNoticer.value.empSelected != "") {
      loadTotalData.employee_id = this.addNoticer.value.empSelected
    }
    if (this.addNoticer.value.clientSelected && this.addNoticer.value.clientSelected != "") {
      loadTotalData.client_id = this.addNoticer.value.clientSelected
    }
    if (this.addNoticer.value.productSelected && this.addNoticer.value.productSelected != "") {
      loadTotalData.product_id = this.addNoticer.value.productSelected
    }
    this.impOrderService.getAllLoxysoftOverview(loadTotalData).subscribe(res => {
      this.totalOrderDataSource = new MatTableDataSource([]);
      if (res) {
        let totalresultarr = [];
        res.forEach((obj) => {
          let totaldatasourceObj: any = {};
          totaldatasourceObj.sales_count = obj.sales_count;
          totaldatasourceObj.regret_count = obj.regret_coun;
          totaldatasourceObj.total_count = obj.total_count;
          totalresultarr.push(totaldatasourceObj);
        });
        this.totalOrderList = totalresultarr;
        this.totalOrderDataSource = new MatTableDataSource(res);
        this.totalOrderDataSource.sort = this.sorttot;
        this.totalOrderDataSource.paginator = this.paginatortot;
        this.loaderTotal = false;
      }
      else {
        this.totalOrderDataSource = new MatTableDataSource([]);
        this.tTotRowNoRecord = true;
        this.loaderTotal = false;
      }
    }, err => {
      this.tTotRowErr = true;
      this.loaderTotal = false;
    });
  }

  getLastname(client) {
    return client && client.last_name ? client.last_name : '';
  }

  getWorkingDate(client) {
    return _moment(client.WorkingDate).format('YYYY-MM-DD');
  }

  getProvisionin(client) {
    return client.EmpProvisionIn ? client.EmpProvisionIn : '0';
  }

  getProvisionOut(client) {
    return client.EmpProvisionOut ? client.EmpProvisionOut : '0';
  }

  getFirstname(client) {
    return client && client.first_name ? client.first_name : '';
  }
  getComments(client) {
    return client && client.comments ? client.comments : '';
  }

  slideToggleChange(e) { }

  changeUrlParams(changepage?) {
    this.isQueryParams = false;
    if (this.queryParams.loxySoftId != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.fName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.lName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.sold != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.cName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.stat != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.comment != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.projName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.prodName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.wDate != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.in != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.out != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.month != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.year != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.page != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.active != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.direct != null) {
      this.isQueryParams = true;
    }
    if(this.queryParams.importId != null){
      this.isQueryParams =true;
    }
    if (changepage) {
      this.queryParams.page = this.currentPage;
    }
    this.optionVal = btoa(JSON.stringify(this.queryParams));
    this.location.go(this.router.createUrlTree([this.router.url.split('?')[0]],
      {
        queryParams: { optionVal: this.isQueryParams ? this.optionVal : null }
      }).toString());
  }

  loadImportOrder() {
    this.loader = true;
    this.tRowErr = false;
    this.tRowNoRecord = false;
    if (!this.yearSelected) {
      this.yearSelected = new Date().getFullYear();
    }
    if (!this.monthSelected) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.dataSource = new MatTableDataSource([]);

    let loadData: any = {
      month: this.monthSelected,
      year: this.yearSelected
    }
    if (this.addNoticer.value.statusSelected && this.addNoticer.value.statusSelected != "") {
      loadData.status = this.addNoticer.value.statusSelected
    }
    if (this.addNoticer.value.empSelected && this.addNoticer.value.empSelected != "") {
      loadData.employee_id = this.addNoticer.value.empSelected
    }
    if (this.addNoticer.value.clientSelected && this.addNoticer.value.clientSelected != "") {
      loadData.client_id = this.addNoticer.value.clientSelected
    }
    if (this.addNoticer.value.productSelected && this.addNoticer.value.productSelected != "") {
      loadData.product_id = this.addNoticer.value.productSelected
    }
    this.impOrderService.getImportOrderDataList(loadData).subscribe(res => {
      this.dataSource = new MatTableDataSource([]);
      if (res.length > 0) {
        let resultarr = [];
                res.forEach((obj) => {
          let datasourceObj: any = {};
          datasourceObj.LoxySoftId = obj.LoxySoftId;
          datasourceObj.Prospect_id = obj.Prospect_id
          datasourceObj.first_name = this.getFirstname(obj);
          datasourceObj.last_name = this.getLastname(obj);
          datasourceObj.sold_qty = obj.SoldQty;
          datasourceObj.Client_name = obj.Client_name;
          datasourceObj.Project_name = obj.Project_name;
          datasourceObj.Product_name = obj.Product_name;
          datasourceObj.EmpProvisionIn = obj.EmpProvisionIn;
          datasourceObj.EmpProvisionOut = obj.EmpProvisionOut;
          datasourceObj.status = obj.status ? obj.status : "";
          datasourceObj.ImportId = obj.Unique_id ? obj.Unique_id : "";
          datasourceObj.comments = obj.comments != undefined ? obj.comments : "";
          datasourceObj.WorkingDate = this.getWorkingDate(obj);
          resultarr.push(datasourceObj);
        });
        this.impOrderList = resultarr;
        this.dataSource = new MatTableDataSource(resultarr);

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;

        this.dataSource.paginator.pageIndex = this.currentPage;
        this.dataSource.sort.active = this.sortActive;
        this.dataSource.sort.direction = this.sortDirection;
        this.applyColumnFilter('');

        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.loader = false;
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.tRowNoRecord = true;
        this.loader = false;
      }
    }, err => {
      this.tRowErr = true;
      this.loader = false;
    })
  }

  loadClientList() {
    this.selection.clear();
    this.showHideCols();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.LoxySoftId + item.WorkingDate + item.Client_name + item.EmpProvisionIn + item.EmpProvisionOut + item.Project_name + item.Product_name + item.SoldQty + item.ImportId + this.getLastname(item) + this.getFirstname(item) + this.getWorkingDate(item) + item.comments;
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  private setExcelforTotal() {
    this.arrToPrint = [];
    this.arrToPrint.push(['Order', 'Ånger', 'Godkänd', '% Ånger']);
    if (this.totalOrderDataSource && this.totalOrderDataSource.data.length) {
      let newLine = [];
      this.totalOrderDataSource.filteredData.forEach((val: any) => {
        Object.entries(val).forEach(value => {
          newLine.push(value[1]);
        });
      });
      this.arrToPrint.push(newLine);
    }
    this.arrToPrint.push([]);
    this.arrToPrint.push([]);
  }

  private setExcelHeaders() {
    let nextIndex = this.arrToPrint.length;
    this.arrToPrint[nextIndex] = [];
    this.toggleColumns.forEach((obj) => {
      if (this.displayColumnToShow.indexOf(obj.label) > -1 && obj.label != 'actions') {
        this.arrToPrint[nextIndex].push(obj.column)
      }
    });
  }

  private setExcelValues() {
    if (this.dataSource && this.dataSource.data.length) {
      this.dataSource.filteredData.forEach((val: any) => {
        let newLine = [];
        this.displayColumnToShow.forEach((key, ind) => {
          if (key != 'actions') {
            let str = key.split('.').reduce((o, i) => { if (o && o[i]) { return o[i] } }, val);
            if (key == 'WorkingDate') {
              let toSetDate = {
                WorkingDate: str
              }
              str = this.getWorkingDate(toSetDate).toString();
            }
            newLine.push(str);
          }
        });
        this.arrToPrint.push(newLine);

      });
    }

  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols() {
    this.displayColumnToShow = [];
    this.filterDisplayColumnToShow = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        this.displayColumnToShow.push(obj.label);
        this.filterDisplayColumnToShow.push(this.filtertoggleColumns[ind].label);
        if (this.multiColFilter[obj.label] === undefined) {
          this.multiColFilter[obj.label] = '';
        }
      } else {
        if (this.multiColFilter[obj.label]) {
          this.multiColFilter[obj.label] = '';
          this.applyColumnFilter('');
        }
      }
    });

  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      /* generate worksheet */
      this.setExcelforTotal();
      this.setExcelHeaders();
      this.setExcelValues();
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Import_Order_List_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }


  openModal(content, contentAccessId, toClient?) {
    this.previousEmployee = null;
    if (content === 'create') {
      this.salesCreateOrupdate = 'create';
      this.modalFormGroup.reset();
      this.modalFormGroup.get('name').enable();
      this.modalFormGroup.get('product_name').enable();
      this.modalFormGroup.get('provisionin').disable();
      this.modalFormGroup.get('provisionut').disable();
      this.modalFormGroup.get('date').enable();
      this.modalFormGroup.get('project_name').enable();
      this.modalFormGroup.get('client_name').enable();
      this.updateErrMsg = false;
      this.clientTitle = "Lägg till fil";
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'update' || content === 'moveSales') {
      this.salesCreateOrupdate = 'update';
      this.updateImportOrderData = toClient;

      this.modalFormGroup.patchValue({
        client_name: toClient.Client_name,
        project_name: toClient.Project_name,
        product_name: toClient.Product_name,
        name: this._setEmployeeInEdit(toClient.Employee_id),
        antalsalda: "1",
        date: toClient.WorkingDate,
        LoxySoftId: toClient.LoxySoftId,
        status: { Status_id: toClient.status, Status_name: toClient.status },
        comment: toClient.comments
      });
      this.modalFormGroup.get('product_name').disable();
      this.modalFormGroup.get('date').disable();
      this.modalFormGroup.get('project_name').disable();
      this.modalFormGroup.get('client_name').disable();
      this.modalFormGroup.get('antalsalda').enable();

      this.updateErrMsg = false;
      if (content === 'moveSales') {
        this.clientTitle = "Flytta ordning";
        this.modalFormGroup.get('name').enable();
        this.previousEmployee = toClient.LoxySoftId;
      } else {
        this.clientTitle = "Uppdateringsorder";
        this.modalFormGroup.get('name').disable();
      }
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'delete') {
      this.deleteErrMsg = false;
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-delete-order', backdrop: "static" });
    }
    this.uploadOption = '0';
    this.delOrderData = toClient;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  deleteOrder() {
    this.spinner.active = true;
    let deleteData: any = { regret_id: "", sales_id: "" };
    if (this.delOrderData.regret_id) {
      deleteData.regret_id = this.delOrderData.regret_id
    }
    if (this.delOrderData.sales_id) {
      deleteData.sales_id = this.delOrderData.sales_id
    }
    this.impOrderService.deleteTotalOrder(this.delOrderData).subscribe(res => {
      if (res.message === 'Record deleted successfully') {
        this.loadImportOrder();
        this.resDeleteMessage.success = true;
        this.resDeleteMessage.error = false;
        this.deleteEmpModalRef.close('submitted');
      } else {
        this.spinner.active = false;
        this.deleteEmpModalRef.close('submitted');
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = true;
      }
      setTimeout(() => {
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = false;
        this._ref.detectChanges();
      }, 5000);
      this.spinner.active = false;
      this._ref.detectChanges();
    }, error => {
      if (error.error.message) {
        this.deleteErrMsg = true;
        this.spinner.active = false;
      }
    });
    this.spinner.active = false;
  }

  getProjectListByClient(clientId) {
    this.clientProjectsArr = [];
    this.clientsProductsArr = [];
    this.modalFormGroup.controls.project_name.reset();
    this.modalFormGroup.controls.product_name.reset();
    this.projectsArr.forEach((obj) => {
      if (obj.Client_id === clientId.id) {
        this.clientProjectsArr.push(obj);
      }
    });
    this._projectFilter();
  }

  getProductsListByProject(project) {
    this.clientsProductsArr = [];
    this.modalFormGroup.controls.product_name.reset();
    project.Products.forEach((prodData) => {
      this.clientsProductsArr.push({ Product_id: prodData.prod_id, Product_name: prodData.prod_name });
    });
    this._ProductFilter();
  }

  compareModalClient(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1._id === opt2._id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalProject(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.Project_id == opt2.Project_id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalProduct(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.Product_id == opt2.Product_id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalStatus(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.Status_id == opt2.Status_id && opt1.Status_name == opt2.Status_name) {
      return true;
    } else {
      return false;
    }
  }

  loadEmployee() {
    this.empArr = [];
    this.sharedServices.getAllEmployees().subscribe(res => {
      res.forEach((obj) => {
        this.empArr.push({
          id: obj.Employee_id,
          name: obj.first_name + " " + obj.last_name
        });
      });
      this.empArr.sort(function (a, b) {
        if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
        if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
        return 0;
      });
      this._Empfilter();
    });
  }

   _Empfilter(): any[] {
    if (this.empArr.length <= 0) {
      return;
    }
    if (this.addNoticer && this.addNoticer.controls['employeeFilterControls'].value && (typeof this.addNoticer.controls['employeeFilterControls'].value == 'string') && this.addNoticer.controls['employeeFilterControls'].value.trim() != '') {
      const empfilterValue = this.addNoticer.controls['employeeFilterControls'].value.toLowerCase();
      this.empFilteredOptions.next(
        this.empArr.filter(emp => (emp.name.toLowerCase().indexOf(empfilterValue) > -1))
      );
    } else {
      this.empFilteredOptions.next(this.empArr.slice());
      return;
    }
  }

   _clientFilter(): any[] {
    if (this.clientsArr.length <= 0) {
      return;
    }
    if (this.addNoticer && this.addNoticer.controls['clientFilterControls'].value && (typeof this.addNoticer.controls['clientFilterControls'].value == 'string') && this.addNoticer.controls['clientFilterControls'].value.trim() != '') {
      const depfilterValue = this.addNoticer.controls['clientFilterControls'].value.toLowerCase();
      this.clientFilteredOptions.next(
        this.clientsArr.filter(dep => (dep.name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.clientFilteredOptions.next(this.clientsArr.slice());
      return;
    }
  }
   _ProductFilter(): any[] {
    if (this.productsArr.length <= 0) {
      return;
    }
    if (this.addNoticer && this.addNoticer.controls['ProductFilterControls'].value && (typeof this.addNoticer.controls['ProductFilterControls'].value == 'string') && this.addNoticer.controls['ProductFilterControls'].value.trim() != '') {
      const depfilterValue = this.addNoticer.controls['ProductFilterControls'].value.toLowerCase();
      this.productFilteredOptions.next(
        this.productsArr.filter(dep => (dep.name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.productFilteredOptions.next(this.productsArr.slice());
      return;
    }
  }

  displayFn(user?: any): string | undefined {
    return user ? user.name : '';
  }

  onAddEmployeeFromClick(event) {
    if (event.option.value) {
      this.projectService.getEmployee(event.option.value.id).subscribe(res => {
        if (res) {
          this.modalFormGroup.patchValue({
            LoxySoftId: res.loxysoft_id
          });
        }
      });
    }
  }

  private _filter(value: string): string[] {
    let filterValue = '';
    if (typeof value === 'string') {
      filterValue = value.toLowerCase();
    }
    return this.empArr.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  private _setEmployeeInEdit(empId: any) {
    return this.empArr.find((employee) => employee.id === empId);
  }

  applyColumnFilter(searchkey) {
    switch (searchkey) {
      case "loxySoftId": {
        this.queryParams.loxySoftId = this.multiColFilter.LoxySoftId == "" ? null : this.multiColFilter.LoxySoftId;
        this.changeUrlParams();
        break;
      }  case "prospect_id": {
        this.queryParams.prospect_id = this.multiColFilter.Prospect_id == "" ? null : this.multiColFilter.Prospect_id;
        this.changeUrlParams();
        break;
      }
      case "fName": {
        this.queryParams.fName = this.multiColFilter.first_name == "" ? null : this.multiColFilter.first_name;
        this.changeUrlParams();
        break;
      }
      case "lName": {
        this.queryParams.lName = this.multiColFilter.last_name == "" ? null : this.multiColFilter.last_name;
        this.changeUrlParams();
        break;
      }
      case "sold": {
        this.queryParams.sold = this.multiColFilter.sold_qty == "" ? null : this.multiColFilter.sold_qty;
        this.changeUrlParams();
        break;
      }
      case "cName": {
        this.queryParams.cName = this.multiColFilter.Client_name == "" ? null : this.multiColFilter.Client_name;
        this.changeUrlParams();
        break;
      }
      case "stat": {
        this.queryParams.stat = this.multiColFilter.status == "" ? null : this.multiColFilter.status;
        this.changeUrlParams();
        break;
      }
      case "projName": {
        this.queryParams.projName = this.multiColFilter.Project_name == "" ? null : this.multiColFilter.Project_name;
        this.changeUrlParams();
        break;
      }
      case "prodName": {
        this.queryParams.prodName = this.multiColFilter.Product_name == "" ? null : this.multiColFilter.Product_name;
        this.changeUrlParams();
        break;
      }
      case "comment": {
        this.queryParams.comment = this.multiColFilter.comments == "" ? null : this.multiColFilter.comments;
        this.changeUrlParams();
        break;
      }
      case "wDate": {
        this.queryParams.wDate = this.multiColFilter.WorkingDate == "" ? null : this.multiColFilter.WorkingDate;
        this.changeUrlParams();
        break;
      }
      case "in": {
        this.queryParams.in = this.multiColFilter.EmpProvisionIn == "" ? null : this.multiColFilter.EmpProvisionIn;
        this.changeUrlParams();
        break;
      }
      case "out": {
        this.queryParams.out = this.multiColFilter.EmpProvisionOut == "" ? null : this.multiColFilter.EmpProvisionOut;
        this.changeUrlParams();
        break;
      }
      case "importId":{
        this.queryParams.importId = this.multiColFilter.ImportId == "" ? null : this.multiColFilter.ImportId;
        this.changeUrlParams();
        break;
      }

      default: {
        break;
      }
    }
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.currentPage > 0 && searchkey == '') {
      this.dataSource.paginator.pageIndex = this.currentPage;
    }
    else {
      this.dataSource.paginator.firstPage();
    }
  }

  public handlePage(e: any) {
    this.currentPage = e.pageIndex;
    this.queryParams.page = this.currentPage;
    this.changeUrlParams();
  }

  sortData(event) {
    this.queryParams.active = event.active;
    this.queryParams.direct = event.direction;
    this.changeUrlParams();
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(item).forEach((key) => {
        if ((item[key] && filterString[key]) || ((item[key] >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (typeof item[key] != 'string') {
            itemString = item[key].toString();
          } else {
            if (key === 'WorkingDate') {
              itemString = this.getWorkingDate(item).toString();
            } else {
              itemString = item[key];
            }
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!item[key] || (item[key] <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  deleteByImportId() {
    if (this.deleteImportId.valid) {
      this.spinner.active = true;
      this.impOrderService.deleteByImportId(this.deleteImportId.value, 'Sales').subscribe(res => {
        if (res.message === 'Record deleted successfully') {
          this.loadImportOrder();
          this.resDeleteMessage.success = true;
          this.resDeleteMessage.error = false;
          this.deleteEmpModalRef.close('submitted');
        } else {
          this.spinner.active = false;
          this.deleteEmpModalRef.close('submitted');
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = true;
        }
        setTimeout(() => {
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = false;
          this._ref.detectChanges();
        }, 5000);
        this.spinner.active = false;
        this._ref.detectChanges();
      }, error => {
        if (error.error.message) {
          if (error.error.message === 'Wrong import id') {
            this.deleteImportIdErrMsg = this.translate.instant('COMMON.ERROR') + "!Felaktigt import-ID!";
          } else {
            this.deleteImportIdErrMsg = this.translate.instant('COMMON.ERROR') + "!Ser ut som något gick fel!";
          }
          this.showDeleteImportIdErrMsg = true;
          setTimeout(() => {
            this.showDeleteImportIdErrMsg = false;
            this._ref.detectChanges();
          }, 5000);
        }
        this.spinner.active = false;
        this._ref.detectChanges();
      });
    }
  }

  moveSalesData() {
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let form1 = this.modalFormGroup.getRawValue();
      let tosendImportOrder = {
        "WorkingDate": form1.date,
        "ClientId": form1.client_name._id,
        "ProjectId": form1.project_name.Project_id,
        "ProductId": form1.product_name.Product_id,
        "LoxySoftId": this.previousEmployee,
        "SoldQuantity": form1.antalsalda,
        "ToLoxySoftId": form1.LoxySoftId,
        "MovedBy": this.userData.id
      };

      if (this.salesCreateOrupdate === 'update') {
        this.impOrderService.moveSalesDetails(tosendImportOrder).subscribe(res => {
          if (res.message === 'Data moved Successfully') {
            this.loadImportOrder();
            this.resUpdateeMessage.success = true;
            this.resUpdateeMessage.error = false;
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.deleteEmpModalRef.close('submitted');
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = true;
          }
          setTimeout(() => {
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = false;
            this._ref.detectChanges();
          }, 5000);
          this.spinner.active = false;
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      }
      this.spinner.active = false;
    }
  }

  isMoveOrUpdate() {
    if (!this.previousEmployee) {
      this.AddImportOrder();
    } else {
      this.moveSalesData();
    }
  }

  updateStatus() {
    if (this.modalFormGroup.valid) {
      let data = {
        Client_id: this.updateImportOrderData.Client_id,
        Client_name: this.updateImportOrderData.Client_name,
        EmpProvisionIn: this.updateImportOrderData.EmpProvisionIn,
        EmpProvisionOut: this.updateImportOrderData.EmpProvisionOut,
        Employee_id: this.updateImportOrderData.Employee_id,
        LoxySoftId: this.updateImportOrderData.LoxySoftId,
        Product_id: this.updateImportOrderData.Product_id,
        Product_name: this.updateImportOrderData.Product_name,
        Project_id: this.updateImportOrderData.Project_id,
        Project_name: this.updateImportOrderData.Project_name,
        WorkingDate: this.updateImportOrderData.WorkingDate,
        first_name: this.updateImportOrderData.first_name,
        last_name: this.updateImportOrderData.last_name,
        salescount: this.updateImportOrderData.salescount,
        comment: this.modalFormGroup.controls['comment'].value,
        Status_id: this.modalFormGroup.controls['status'].value.Status_id,
        Status_name: this.modalFormGroup.controls['status'].value.Status_name
      }

      this.impOrderService.updateImportOrderData(data, this.delOrderData.id).subscribe(res => {
        if (res) {
          this.loadImportOrder();
          this.resUpdateStatusMessage.success = true;
          this.resUpdateStatusMessage.error = false;
          this.deleteEmpModalRef.close('submitted');
        } else {
          this.deleteEmpModalRef.close('submitted');
          this.resUpdateStatusMessage.success = false;
          this.resUpdateStatusMessage.error = true;
        }
        setTimeout(() => {
          this.resUpdateStatusMessage.success = false;
          this.resUpdateStatusMessage.error = false;
          this._ref.detectChanges();
        }, 5000)
        this._ref.detectChanges();

      }, error => {
        if (error.error.message) {
          this.updateStatusErrMsg = true;
        }
      });
      this.spinner.active = false;
    }
  }

  getSelectedYear(year?: any) {
    if (year) {
      this.yearSelected = year;
    } else {
      this.yearSelected = new Date().getFullYear();
    }
    this.monthSelected = null;
    this.queryParams.month = this.monthSelected;
    this.queryParams.year = this.yearSelected;
    this.changeUrlParams();
  }

  getSelectedMonth(monthObj?: any) {
    if (monthObj && monthObj.value) {
      this.monthSelected = monthObj.value;
    }
    this.loadImportOrder();
    this.loadTotalOrder();
  }

  protected _projectFilter(): any[] {
    if (this.clientProjectsArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['projectNameFilter'].value && (typeof this.modalFormGroup.controls['projectNameFilter'].value == 'string') && this.modalFormGroup.controls['projectNameFilter'].value.trim() != '') {
      const depfilterValue = this.modalFormGroup.controls['projectNameFilter'].value.toLowerCase();
      this.projectFilteredOptions.next(
        this.clientProjectsArr.filter(dep => (dep.Project_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.projectFilteredOptions.next(this.clientProjectsArr.slice());
      return;
    }
  }

  protected _productFilter(): any[] {
    if (this.clientsProductsArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['productNameFilter'].value && (typeof this.modalFormGroup.controls['productNameFilter'].value == 'string') && this.modalFormGroup.controls['productNameFilter'].value.trim() != '') {
      const depfilterValue = this.modalFormGroup.controls['productNameFilter'].value.toLowerCase();
      this.productFilteredOptions.next(
        this.clientsProductsArr.filter(dep => (dep.Product_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.productFilteredOptions.next(this.clientsProductsArr.slice());
      return;
    }
  }
}
