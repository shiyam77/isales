import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalRegretComponent } from './total-regret.component';

describe('TotalRegretComponent', () => {
  let component: TotalRegretComponent;
  let fixture: ComponentFixture<TotalRegretComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotalRegretComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TotalRegretComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
