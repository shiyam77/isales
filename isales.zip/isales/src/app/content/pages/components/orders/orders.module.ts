import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyOrderComponent } from './my-order/my-order.component';
import { TotalOrderComponent } from './total-order/total-order.component';

import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { CoreModule } from '../../../../core/core.module';
import { PartialsModule } from '../../../partials/partials.module';
import { NgbModule, NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { CodePreviewModule } from '../../../partials/content/general/code-preview/code-preview.module';
import { MaterialPreviewModule } from '../../../partials/content/general/material-preview/material-preivew.module';
import {
	MatIconRegistry,
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatSliderModule,
	MatListModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatSlideToggleModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatSidenavModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatSnackBarModule,
	MatGridListModule,
	MatTableModule,
	MatExpansionModule,
	MatToolbarModule,
	MatSortModule,
	MatDividerModule,
	MatStepperModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	MatRadioModule,
	DateAdapter,
	MAT_DATE_LOCALE,
	MAT_DATE_FORMATS,
	MatPaginatorIntl,	
} from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { QRCodeModule } from 'angularx-qrcode';
import { NgxPermissionsGuard, NgxPermissionsModule } from 'ngx-permissions';
import { FullCalendarModule } from 'ng-fullcalendar';
import { FileUploadModule } from 'ng2-file-upload';
import { ImageCropperModule } from 'ngx-image-cropper';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { ChartsModule } from 'ng2-charts';
import { MglTimelineModule } from 'angular-mgl-timeline';
import { PersonalService } from '../personal/_core/services/personal.service';
import { ImportordertimeService } from '../importordertime/_core/services/importordertime.service';
import { MyRegretComponent } from './my-order/my-regret/my-regret.component';
import { TotalRegretComponent } from './total-regret/total-regret.component';

const MY_FORMATS = {
	parse: {
	  dateInput: 'LL',
	},
	display: {
	  dateInput: 'YYYY-MM-DD',
	  monthYearLabel: 'YYYY',
	  dateA11yLabel: 'LL',
	  monthYearA11yLabel: 'YYYY',
	},
};

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
};

function getSwedishPaginatorIntl() {
	const paginatorIntl = new MatPaginatorIntl();
	paginatorIntl.itemsPerPageLabel = 'Objekt per sida:';
	paginatorIntl.getRangeLabel = swedishRangeLabel;
	return paginatorIntl;
  }
  const swedishRangeLabel = (page: number, pageSize: number, length: number) => {
    if (length == 0 || pageSize == 0) { return `0 av ${length}`; }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    // If the start index exceeds the list length, do not try and fix the end index to the end.
    const endIndex = startIndex < length ?
      Math.min(startIndex + pageSize, length) :
      startIndex + pageSize;
    return `${startIndex + 1} - ${endIndex} av ${length}`;
    }

const routes: Routes = [
	{
		path: '',
		canActivateChild:[NgxPermissionsGuard],
		children: [
			{
				path:'',
				redirectTo:'myorder',
				pathMatch:'full'
			},
			{
				path:'myorder',
        component:MyOrderComponent,
        pathMatch:'full'
      },
      {
				path:'myregret',
        component:MyRegretComponent,
        pathMatch:'full'
      },
      {
				path:'totalorder',
				component:TotalOrderComponent,
			},
      {
				path:'totalregret',
				component:TotalRegretComponent,
			}
		]
	}
];


@NgModule({
  imports: [
    CommonModule,
    PartialsModule,
    NgbModule,
    CodePreviewModule,
    CoreModule,
    MaterialPreviewModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,	
    PerfectScrollbarModule,	
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatSliderModule,
    MatListModule,
    MatCardModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    MatMenuModule,
    MatTabsModule,
    MatTooltipModule,
    MatSidenavModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatGridListModule,
    MatTableModule,
    MatExpansionModule,
    MatToolbarModule,
    MatSortModule,
    MatDividerModule,
    MatStepperModule,
    MatChipsModule,
    MatPaginatorModule,
    MatDialogModule,
    MatRadioModule,
    TranslateModule,
    QRCodeModule,
    WidgetChartsModule,
    NgxPermissionsModule.forChild(),
    FullCalendarModule,
    FileUploadModule,
    ImageCropperModule,
    NgxMatSelectSearchModule,
    ChartsModule,
    MglTimelineModule, 
  ],
  declarations: [MyOrderComponent, TotalOrderComponent, MyRegretComponent, TotalRegretComponent],
  providers: [
    NgbAlertConfig, {
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    MatIconRegistry,
    PersonalService,
    ImportordertimeService,
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    { provide: MatPaginatorIntl, useValue: getSwedishPaginatorIntl() }
    ]
})
export class OrdersModule { }
