import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, SortDirection } from '@angular/material';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, ReplaySubject } from 'rxjs';
import { ProjectService } from '../../../project/_core/services/project.service';
import { Location } from '@angular/common';
import * as _moment from 'moment';
import { ImportordertimeService } from '../../../importordertime/_core/services/importordertime.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as Xlsx from 'xlsx';
type AOA = any[][];
@Component({
  selector: 'm-my-regret',
  templateUrl: './my-regret.component.html',
  styleUrls: ['./my-regret.component.scss']
})
export class MyRegretComponent implements OnInit {
  impOrderList: any[] = [];
  arrToPrint: AOA = [];
  loader: boolean = false;
  loaderTotal: boolean = false;
  displayColumnToShow = ['LoxySoftId', 'salescount', 'Client_name', 'Project_name', 'Product_name', 'WorkingDate', 'Status_name', 'comment'];
  filterDisplayColumnToShow = ['loxySoftId', 'sales_count', 'client_name', 'project_name', 'product_name', 'workingDate', 'status_name', 'Comment'];

  toggleColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'LoxySoftId' },
    { arrIndex: 2, column: 'Fornamn', checked: true, label: 'first_name' },
    { arrIndex: 3, column: 'Efternamn', checked: true, label: 'last_name' },
    { arrIndex: 4, column: 'Antal saida', checked: true, label: 'salescount' },
    { arrIndex: 5, column: 'KUND', checked: true, label: 'Client_name' },
    { arrIndex: 6, column: 'PROJEKT', checked: true, label: 'Project_name' },
    { arrIndex: 7, column: 'PRODUKT', checked: true, label: 'Product_name' },
    { arrIndex: 8, column: 'DATUM', checked: true, label: 'WorkingDate' },
    { arrIndex: 9, column: 'Status', checked: true, label: 'Status_name' },
    { arrIndex: 10, column: 'Comment', checked: true, label: 'comment' },
    { arrIndex: 11, column: 'ACTIONS', checked: true, label: 'actions' }
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  empArr: Array<any> = [];
  empFilterArr: Observable<any[]>;
  uploadOption: any = '0';
  multiColFilter = {
    LoxySoftId: '',
    first_name: '',
    last_name: '',
    salescount: '',
    Client_name: '',
    Status_name: '',
    comment: '',
    Project_name: '',
    Product_name: '',
    WorkingDate: '',
  };

  errMultiColFilter = {
    Lineno: '',
    LoxySoftId: '',
    SoldQty: '',
    Client_name: '',
    Status_name: '',
    comment: '',
    Project_name: '',
    Product_name: '',
    Status: '',
    Reason: '',
    WorkingDate: '',
  };

  monthList = [
    { label: "Jan", value: 1 },
    { label: "Feb", value: 2 },
    { label: "Mar", value: 3 },
    { label: "Apr", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Jun", value: 6 },
    { label: "Jul", value: 7 },
    { label: "Aug", value: 8 },
    { label: "Sep", value: 9 },
    { label: "Okt", value: 10 },
    { label: "Nov", value: 11 },
    { label: "Dec", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  unchangedSelectedMonth = null;
  unchangedSelectedYear = null;
  importOrders$: Observable<any[]>;
  dataSource: any = new MatTableDataSource();
  totalOrderDataSource: any = new MatTableDataSource();
  errDataSource: any;
  filtertoggleColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'loxySoftId' },
    { arrIndex: 2, column: 'Fornamn', checked: true, label: 'firstname' },
    { arrIndex: 3, column: 'Efternamn', checked: true, label: 'lastname' },
    { arrIndex: 4, column: 'Antal saida', checked: true, label: 'sales_count' },
    { arrIndex: 5, column: 'KUND', checked: true, label: 'client_name' },
    { arrIndex: 6, column: 'Status', checked: true, label: 'status_name' },
    { arrIndex: 7, column: 'Kommentar', checked: true, label: 'Comment' },
    { arrIndex: 8, column: 'PROJEKT', checked: true, label: 'project_name' },
    { arrIndex: 9, column: 'PRODUKT', checked: true, label: 'product_name' },
    { arrIndex: 10, column: 'PROVISIONIN', checked: true, label: 'provisionIn' },
    { arrIndex: 11, column: 'PROVISIONUT', checked: true, label: 'provisionOut' },
    { arrIndex: 12, column: 'DATUM', checked: true, label: 'workingDate' },
    { arrIndex: 13, column: 'ACTIONS', checked: true, label: 'Actions' }
  ];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('TableTwoPaginator') paginatortot: MatPaginator;
  @ViewChild('TableTwoSort') sorttot: MatSort;
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tTotRowErr: boolean = false;
  tTotRowNoRecord: boolean = false;

  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };

  queryParams = {
    loxySoftId: null,
    fName: null,
    lName: null,
    count: null,
    cName: null,
    status: null,
    comment: null,
    projName: null,
    prodName: null,
    in: null,
    out: null,
    wDate: null,
    importId: null,
    active: null,
    direct: null,
    page: null,
    month: null,
    year: null
  };

  sortActive = "WorkingDate";
  sortDirection: SortDirection = "desc"
  currentPage = 0;
  optionVal = "";
  isQueryParams = false;
  displayColumnToShowTotal = ['order', 'regret', 'total_order', 'regret_per'];
  xpandStatus: boolean;
  pageEvent: any;
  searchInput: any;
  addNoticer: FormGroup;
  statusFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  statusArr: Array<any> = [];

  constructor(
    private projectService: ProjectService,
    private impOrderService: ImportordertimeService,
    private activatedRoute: ActivatedRoute,
    private _formBuilder: FormBuilder,
    private location: Location,
    private router: Router) {
    this.dataSource = new MatTableDataSource<any>([]);
  }

  ngOnInit() {
    this.totalOrderDataSource = new MatTableDataSource([]);
    this.yearList = [];
    for (let y = 0; (y <= (new Date().getFullYear() - 2020)); y++) {
      this.yearList.push(2020 + y);
    }
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.activatedRoute.queryParams.subscribe(params => {
      if (params["optionVal"]) {
        this.queryParams = JSON.parse(atob(params["optionVal"]))
      }
      this.multiColFilter.LoxySoftId = this.queryParams.loxySoftId != null ? this.queryParams.loxySoftId : '';
      this.multiColFilter.first_name = this.queryParams.fName != null ? this.queryParams.fName : '';
      this.multiColFilter.last_name = this.queryParams.lName != null ? this.queryParams.lName : '';
      this.multiColFilter.salescount = this.queryParams.count != null ? this.queryParams.count : '';
      this.multiColFilter.Client_name = this.queryParams.cName != null ? this.queryParams.cName : '';
      this.multiColFilter.Project_name = this.queryParams.projName != null ? this.queryParams.projName : '';
      this.multiColFilter.Product_name = this.queryParams.prodName != null ? this.queryParams.prodName : '';
      this.multiColFilter.WorkingDate = this.queryParams.wDate != null ? this.queryParams.wDate : '';
      this.monthSelected = this.queryParams.month != null ? this.queryParams.month : this.monthSelected;
      this.yearSelected = this.queryParams.year != null ? this.queryParams.year : this.yearSelected;
      this.sortActive = this.queryParams.active != null ? this.queryParams.active : this.sortActive;
      this.sortDirection = this.queryParams.direct != null ? this.queryParams.direct : this.sortDirection;
      this.currentPage = this.queryParams.page;

      this.addNoticer = this._formBuilder.group({
        statusSelected: '',
        statusFilterControls: '',
        empSelected: '',
        employeeFilterControls: '',
      });
      this.statusArr = [];
      this.statusArr.push(
        { label: 'Godkänd', value: 'Godkänd' },
        { label: 'Ånger', value: 'Ånger' },
        { label: 'Bortfall', value: 'Bortfall' },
        { label: 'Ånger tidigare period', value: 'Ånger tidigare period' },
        { label: 'Tidigare period', value: 'Tidigare period' }
      );
      this.statusFilteredOptions.next(this.statusArr.slice());
      this.loadImportOrder();
      this.loadTotalOrder();
    });
    this.addNoticer = this._formBuilder.group({
      statusSelected: '',
      statusFilterControls: '',
    });
  }

  generateAndDownloadDoc() {
    // if(this.userData.role === 'admin' || this.userData.role === 'superadmin'){
    /* generate worksheet */
    // this.setExcelforTotal();
    this.setExcelHeaders();
    this.setExcelValues();
    const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
    /* generate workbook and add the worksheet */
    const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
    Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
    /* save to file */
    Xlsx.writeFile(wb, 'My_Regret_List_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    // }    
  }

  private setExcelHeaders() {
    let nextIndex = this.arrToPrint.length;
    this.arrToPrint[nextIndex] = [];
    this.toggleColumns.forEach((obj) => {
      if (this.displayColumnToShow.indexOf(obj.label) > -1 && obj.label != 'actions') {
        this.arrToPrint[nextIndex].push(obj.column)
      }
    });
  }

  private setExcelValues() {
    if (this.dataSource && this.dataSource.data.length) {
      this.dataSource.filteredData.forEach((val: any) => {
        let newLine = [];
        this.displayColumnToShow.forEach((key, ind) => {
          if (key != 'actions') {
            let str = key.split('.').reduce((o, i) => { if (o && o[i]) { return o[i] } }, val);
            if (key == 'WorkingDate') {
              let toSetDate = {
                WorkingDate: str
              }
              str = this.getWorkingDate(toSetDate).toString();
            }
            newLine.push(str);
          }
        });
        this.arrToPrint.push(newLine);
      });
    }

  }

  getSelectedYear(year?: any) {
    if (year) {
      this.yearSelected = year;
    } else {
      this.yearSelected = new Date().getFullYear();
    }
    this.monthSelected = null;
    this.queryParams.month = this.monthSelected;
    this.queryParams.year = this.yearSelected;
    this.changeUrlParams();
  }

  getSelectedMonth(monthObj?: any) {
    if (monthObj && monthObj.value) {
      this.monthSelected = monthObj.value;
    } else {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.queryParams.month = this.monthSelected;
    this.changeUrlParams();
    if (!((this.monthSelected == this.unchangedSelectedMonth) && (this.yearSelected == this.unchangedSelectedYear))) {
      this.unchangedSelectedMonth = this.monthSelected;
      this.unchangedSelectedYear = this.yearSelected;
      this.loadImportOrder();
      this.loadTotalOrder();
    }
  }

  loadTotalOrder() {
    this.loaderTotal = true;
    if (!this.yearSelected) {
      this.yearSelected = new Date().getFullYear();
    }

    if (!this.monthSelected) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    let loadOrderData: any = {
      month: this.monthSelected,
      year: this.yearSelected
    }
    if (this.addNoticer.value.statusSelected && this.addNoticer.value.statusSelected != "") {
      loadOrderData.status = this.addNoticer.value.statusSelected
    }
    this.impOrderService.getEmployeeLoxysoftOverview(loadOrderData).subscribe(res => {
      if (res.length > 0) {
        this.totalOrderDataSource = new MatTableDataSource(res);
        this.totalOrderDataSource.sort = this.sorttot;
        this.totalOrderDataSource.paginator = this.paginatortot;
        this.loaderTotal = false;
      }
      else {
        this.totalOrderDataSource = new MatTableDataSource([]);
        this.tTotRowNoRecord = true;
        this.loaderTotal = false;
      }
    }, err => {
      this.tTotRowErr = true;
      this.loaderTotal = false;
    });
  }

  loadImportOrder() {
    this.loader = true;

    this.tRowErr = false;
    this.tRowNoRecord = false;

    if (!this.yearSelected) {
      this.yearSelected = new Date().getFullYear();
    }

    if (!this.monthSelected) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.dataSource = new MatTableDataSource([]);
    let loadData: any = {
      month: this.monthSelected,
      year: this.yearSelected
    }

    if (this.addNoticer.value.statusSelected && this.addNoticer.value.statusSelected != "") {
      loadData.status = this.addNoticer.value.statusSelected
    }

    this.impOrderService.getEmployeeRegretDetails(loadData).subscribe(res => {
      this.dataSource = new MatTableDataSource([]);
      if (res.length > 0) {
        let resultarr = [];
        res.forEach((obj) => {
          let datasourceObj: any = {};
          datasourceObj.LoxySoftId = obj.LoxySoftId;
          datasourceObj.first_name = this.getFirstname(obj);
          datasourceObj.last_name = this.getLastname(obj);
          datasourceObj.salescount = obj.salescount;
          datasourceObj.Client_name = obj.Client_name;
          datasourceObj.Project_name = obj.Project_name;
          datasourceObj.Product_name = obj.Product_name;
          datasourceObj.WorkingDate = this.getWorkingDate(obj);
          datasourceObj.ImportId = undefined;
          resultarr.push(datasourceObj);
        });
        this.impOrderList = resultarr;
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;

        this.dataSource.paginator.pageIndex = this.currentPage;
        this.dataSource.sort.active = this.sortActive;
        this.dataSource.sort.direction = this.sortDirection;
        this.applyColumnFilter('');

        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.loader = false;
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.tRowNoRecord = true;
        this.loader = false;
      }
    }, err => {
      this.tRowErr = true;
      this.loader = false;
    })
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.LoxySoftId + item.WorkingDate + item.Client_name + item.Project_name + item.Product_name + item.ImportId + item.salescount + this.getLastname(item) + this.getFirstname(item) + this.getWorkingDate(item);
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  getFirstname(client) {
    return client && client.first_name ? client.first_name : '';
  }

  getLastname(client) {
    return client && client.last_name ? client.last_name : '';
  }

  getWorkingDate(client) {
    return _moment(client.WorkingDate).format('YYYY-MM-DD');
  }

  applyColumnFilter(searchkey) {
    switch (searchkey) {
      case "loxySoftId": {
        this.queryParams.loxySoftId = this.multiColFilter.LoxySoftId == "" ? null : this.multiColFilter.LoxySoftId;
        this.changeUrlParams();
        break;
      }
      case "fName": {
        this.queryParams.fName = this.multiColFilter.first_name == "" ? null : this.multiColFilter.first_name;
        this.changeUrlParams();
        break;
      }
      case "lName": {
        this.queryParams.lName = this.multiColFilter.last_name == "" ? null : this.multiColFilter.last_name;
        this.changeUrlParams();
        break;
      }
      case "count": {
        this.queryParams.count = this.multiColFilter.salescount == "" ? null : this.multiColFilter.salescount;
        this.changeUrlParams();
        break;
      }
      case "cName": {
        this.queryParams.cName = this.multiColFilter.Client_name == "" ? null : this.multiColFilter.Client_name;
        this.changeUrlParams();
        break;
      }
      case "projName": {
        this.queryParams.projName = this.multiColFilter.Project_name == "" ? null : this.multiColFilter.Project_name;
        this.changeUrlParams();
        break;
      }
      case "prodName": {
        this.queryParams.prodName = this.multiColFilter.Product_name == "" ? null : this.multiColFilter.Product_name;
        this.changeUrlParams();
        break;
      }
      case "wDate": {
        this.queryParams.wDate = this.multiColFilter.WorkingDate == "" ? null : this.multiColFilter.WorkingDate;
        this.changeUrlParams();
        break;
      }
      default: {
        break;
      }
    }

    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.currentPage > 0 && searchkey == '') {
      this.dataSource.paginator.pageIndex = this.currentPage;
    }
    else {
      this.dataSource.paginator.firstPage();
    }
  }

  public handlePage(e: any) {
    this.currentPage = e.pageIndex;
    this.queryParams.page = this.currentPage;
    this.changeUrlParams();
  }

  sortData(event) {
    this.queryParams.active = event.active;
    this.queryParams.direct = event.direction;
    this.changeUrlParams();
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(item).forEach((key) => {
        if ((item[key] && filterString[key]) || ((item[key] >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (typeof item[key] != 'string') {
            itemString = item[key].toString();
          } else {
            if (key === 'WorkingDate') {
              itemString = this.getWorkingDate(item).toString();
            } else {
              itemString = item[key];
            }
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!item[key] || (item[key] <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  changeUrlParams(changepage?) {
    this.isQueryParams = false;
    if (this.queryParams.loxySoftId != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.fName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.lName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.count != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.cName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.projName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.prodName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.wDate != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.importId != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.in != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.out != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.month != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.year != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.page != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.active != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.direct != null) {
      this.isQueryParams = true;
    }
    if (changepage) {
      this.queryParams.page = this.currentPage;
    }
    this.optionVal = btoa(JSON.stringify(this.queryParams));
    this.location.go(this.router.createUrlTree([this.router.url.split('?')[0]],
      {
        queryParams: { optionVal: this.isQueryParams ? this.optionVal : null }
      }).toString());
  }
}
