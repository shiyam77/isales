import { Component, OnInit, ViewChild, ChangeDetectorRef, Inject } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource, MatSelect, SortDirection } from '@angular/material';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ClientList } from '../../project/_core/models/client-list.model';
import { ProjectService } from '../../project/_core/services/project.service';
import { ImportordertimeService } from '../../importordertime/_core/services/importordertime.service';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { Observable, Subject, ReplaySubject } from 'rxjs';
import { startWith, map, takeUntil } from 'rxjs/operators';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { TranslateService } from '@ngx-translate/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Update } from '@ngrx/entity';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

const URL = 'https://viafoneerp.azurewebsites.net/api/File/SalesFileUpload ';

type AOA = any[][];


@Component({
  selector: 'm-total-regret',
  templateUrl: './total-regret.component.html',
  styleUrls: ['./total-regret.component.scss']
})
export class TotalRegretComponent implements OnInit {


  // public uploader:FileUploader = new FileUploader({url: URL, allowedMimeType: ['text/csv','application/vnd.ms-excel']});
  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;
  filedata: any = new Array<string>();
  uspFile: any = new Array<string>();

  clientsArr: Array<any> = [];
  projectsArr: Array<any> = [];
  productsArr: Array<any> = [];

  statusList: Array<any> = [];



  impOrderList: any[] = [];
  totalOrderList: any[] = [];

  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tTotRowErr: boolean = false;
  tTotRowNoRecord: boolean = false;


  salesCreateOrupdate: string;

  clientProjectsArr: Array<any> = [];
  clientsProductsArr: Array<any> = [];

  addNoticer: FormGroup;
  empFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  statusFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  statusArr: Array<any> = [];


  modalFormGroup: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('TableTwoPaginator') paginatortot: MatPaginator;
  @ViewChild('TableTwoSort') sorttot: MatSort;

  arrToPrint: AOA = [];
  selection = new SelectionModel<ClientList>(true, []);
  //dataSource:MatTableDataSource<ClientList>;
  dataSource: any = new MatTableDataSource();
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  loaderTotal: boolean = false;
  displayColumnToShow = ['LoxySoftId', 'first_name', 'last_name', 'salescount', 'Client_name', 'Status_name', 'comment', 'Project_name', 'Product_name', 'EmpProvisionIn', 'EmpProvisionOut', 'WorkingDate'];
  filterDisplayColumnToShow = ['loxySoftId', 'firstname', 'lastname', 'sales_count', 'client_name', 'status_name', 'Comment', 'project_name', 'product_name', 'provisionIn', 'provisionOut', 'workingDate'];
  // errDisplayColumnToShow = ['Lineno','Reason','LoxySoftId','Client_name','Project_name','Product_name','SoldQty','WorkingDate','ImportId'];
  // errFilterDisplayColumnToShow = ['lineno','reason','loxySoftId','client_name','project_name','product_name','soldQty','workingDate','importId'];
  allClientList: ClientList[] = [];
  xpandStatus: boolean = false;
  searchInput: string = '';

  deleteEmpModalRef: any;
  closeResult: string;
  clientTitle: string;
  delOrderData: any;
  updateClientID: any;

  deleteErrMsg: boolean = false;
  updateErrMsg: boolean = false;

  deleteStatusErrMsg: boolean = false;
  updateStatusErrMsg: boolean = false;

  // updateUspFileErrMsg: boolean = false;

  resDeleteMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateStatusMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };



  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };

  toggleColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'LoxySoftId' },
    { arrIndex: 2, column: 'Fornamn', checked: true, label: 'first_name' },
    { arrIndex: 3, column: 'Efternamn', checked: true, label: 'last_name' },
    { arrIndex: 4, column: 'Antal saida', checked: true, label: 'salescount' },
    { arrIndex: 5, column: 'KUND', checked: true, label: 'Client_name' },
    { arrIndex: 6, column: 'Status', checked: true, label: 'Status_name' },
    { arrIndex: 7, column: 'Comment', checked: true, label: 'comment' },
    { arrIndex: 8, column: 'PROJEKT', checked: true, label: 'Project_name' },
    { arrIndex: 9, column: 'PRODUKT', checked: true, label: 'Product_name' },
    { arrIndex: 10, column: 'PROVISIONIN', checked: true, label: 'EmpProvisionIn' },
    { arrIndex: 11, column: 'PROVISIONUT', checked: true, label: 'EmpProvisionOut' },
    { arrIndex: 12, column: 'DATUM', checked: true, label: 'WorkingDate' },
    // {arrIndex:13,column:'IMPORTID',checked:true,label:'ImportId'},
    { arrIndex: 13, column: 'ACTIONS', checked: true, label: 'actions' }
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  empArr: Array<any> = [];
  empFilterArr: Observable<any[]>;
  uploadOption: any = '0';
  multiColFilter = {
    LoxySoftId: '',
    first_name: '',
    last_name: '',
    salescount: '',
    Client_name: '',
    Status_name: '',
    comment: '',
    Project_name: '',
    Product_name: '',
    EmpProvisionIn: '',
    EmpProvisionOut: '',
    WorkingDate: '',
    // ImportId:''
  };

  errMultiColFilter = {
    Lineno: '',
    LoxySoftId: '',
    SoldQty: '',
    Client_name: '',
    Status_name: '',
    comment: '',
    Project_name: '',
    Product_name: '',
    Status: '',
    Reason: '',
    WorkingDate: '',
    // ImportId:''
  };

  deleteImportId: FormControl = new FormControl(null, Validators.required);
  showDeleteImportIdErrMsg: boolean = false;
  deleteImportIdErrMsg: string = '';
  previousEmployee: any;
  errDataSource: any;
  isImportError: boolean = false;
  monthList = [
    { label: "Jan", value: 1 },
    { label: "Feb", value: 2 },
    { label: "Mar", value: 3 },
    { label: "Apr", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Jun", value: 6 },
    { label: "Jul", value: 7 },
    { label: "Aug", value: 8 },
    { label: "Sep", value: 9 },
    { label: "Okt", value: 10 },
    { label: "Nov", value: 11 },
    { label: "Dec", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  unchangedSelectedYear = null;
  unchangedSelectedMonth = null;
  errImportArr: any[] = [];
  errImportArrLength: any = 0;
  errPageSize: any = 20;
  errPageIndex: any = 0;

  // ['loxySoftId','firstname','lastname','sales_count','client_name','project_name','product_name','provisionIn','provisionOut','workingDate','importId'];

  filtertoggleColumns = [
    { arrIndex: 1, column: 'LoxySoftId', checked: true, label: 'loxySoftId' },
    { arrIndex: 2, column: 'Fornamn', checked: true, label: 'firstname' },
    { arrIndex: 3, column: 'Efternamn', checked: true, label: 'lastname' },
    { arrIndex: 4, column: 'Antal saida', checked: true, label: 'sales_count' },
    { arrIndex: 5, column: 'KUND', checked: true, label: 'client_name' },
    { arrIndex: 6, column: 'Status', checked: true, label: 'status_name' },
    { arrIndex: 7, column: 'Kommentar', checked: true, label: 'Comment' },
    { arrIndex: 8, column: 'PROJEKT', checked: true, label: 'project_name' },
    { arrIndex: 9, column: 'PRODUKT', checked: true, label: 'product_name' },
    { arrIndex: 10, column: 'PROVISIONIN', checked: true, label: 'provisionIn' },
    { arrIndex: 11, column: 'PROVISIONUT', checked: true, label: 'provisionOut' },
    { arrIndex: 12, column: 'DATUM', checked: true, label: 'workingDate' },
    // {arrIndex:13,column:'IMPORTID',checked:true,label:'importId'},
    { arrIndex: 13, column: 'ACTIONS', checked: true, label: 'Actions' }
  ];

  @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
  protected _onClientDestroy = new Subject<void>();
  clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  @ViewChild('projectSearchSelect') projectSearchSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  projectFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  @ViewChild('productSearchSelect') productSearchSelect: MatSelect;
  protected _onProductDestroy = new Subject<void>();
  productFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  importOrders$: Observable<any[]>;
  updateImportOrderData: any;

  queryParams = {
    loxySoftId: null,
    fName: null,
    lName: null,
    count: null,
    cName: null,
    projName: null,
    status: null,
    comment: null,
    prodName: null,
    in: null,
    out: null,
    wDate: null,
    // importId: null,
    active: null,
    direct: null,
    page: null,
    month: null,
    year: null
  };

  sortActive = "WorkingDate";
  sortDirection: SortDirection = "desc"
  currentPage = 0;
  optionVal = "";
  isQueryParams = false;

  totalOrderDataSource: any = new MatTableDataSource();
  displayColumnToShowTotal = ['order', 'regret', 'total_order', 'regret_per'];

  pageEvent: any;
  constructor(
    private projectService: ProjectService,
    private impOrderService: ImportordertimeService,
    private modalService: NgbModal,
    private _formBuilder: FormBuilder,
    private _ref: ChangeDetectorRef,
    private sharedServices: SharedService,
    private translate: TranslateService,
    private activatedRoute: ActivatedRoute,
    private location: Location,
    private router: Router) {
    this.dataSource = new MatTableDataSource<any>([]);
    this.errDataSource = new MatTableDataSource<any>([]);
    this.errDataSource.paginator = this.paginator;
    this.errDataSource.sort = this.sort;
    this.errDataSource.sortingDataAccessor = (item, property) => {
      let sortString = property.split('.').reduce((o, i) => o[i], item);
      if (typeof sortString === 'string') {
        sortString = sortString.toLowerCase();
      }
      return sortString;
    }
  }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= (new Date().getFullYear() - 2020)); y++) {
      this.yearList.push(2020 + y);
    }
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.activatedRoute.queryParams.subscribe(params => {
      if (params["optionVal"]) {
        this.queryParams = JSON.parse(atob(params["optionVal"]))
      }
      this.multiColFilter.LoxySoftId = this.queryParams.loxySoftId != null ? this.queryParams.loxySoftId : '';
      this.multiColFilter.first_name = this.queryParams.fName != null ? this.queryParams.fName : '';
      this.multiColFilter.last_name = this.queryParams.lName != null ? this.queryParams.lName : '';
      this.multiColFilter.salescount = this.queryParams.count != null ? this.queryParams.count : '';
      this.multiColFilter.Client_name = this.queryParams.cName != null ? this.queryParams.cName : '';
      this.multiColFilter.Status_name = this.queryParams.status != null ? this.queryParams.status : '';
      this.multiColFilter.comment = this.queryParams.comment != null ? this.queryParams.comment : '';
      this.multiColFilter.Project_name = this.queryParams.projName != null ? this.queryParams.projName : '';
      this.multiColFilter.Product_name = this.queryParams.prodName != null ? this.queryParams.prodName : '';
      this.multiColFilter.WorkingDate = this.queryParams.wDate != null ? this.queryParams.wDate : '';
      this.multiColFilter.EmpProvisionIn = this.queryParams.in != null ? this.queryParams.in : '';
      this.multiColFilter.EmpProvisionOut = this.queryParams.out != null ? this.queryParams.out : '';
      this.monthSelected = this.queryParams.month != null ? this.queryParams.month : this.monthSelected;
      this.yearSelected = this.queryParams.year != null ? this.queryParams.year : this.yearSelected;
      this.sortActive = this.queryParams.active != null ? this.queryParams.active : this.sortActive;
      this.sortDirection = this.queryParams.direct != null ? this.queryParams.direct : this.sortDirection;
      this.currentPage = this.queryParams.page;
      this.addNoticer = this._formBuilder.group({
        statusSelected: '',
        statusFilterControls: '',
        empSelected: '',
        employeeFilterControls: '',
      });
      this.statusArr = [];
      this.statusArr.push(
        { label: 'Godkänd', value: 'Godkänd' },
        { label: 'Ånger', value: 'Ånger' },
        { label: 'Bortfall', value: 'Bortfall' },
        { label: 'Ånger tidigare period', value: 'Ånger tidigare period' },
        { label: 'Tidigare period', value: 'Tidigare period' }
      );
      this.statusFilteredOptions.next(this.statusArr.slice());
      this.loadImportOrder();
      this.loadClientList();
      this.getClientList();
      this.getProductList();
      this.getProjectList();
      this.loadEmployee();
      this.loadTotalOrder();
      this.getStatusList();
    });
    this.addNoticer = this._formBuilder.group({
      statusSelected: '',
      statusFilterControls: '',
      empSelected: '',
      employeeFilterControls: '',
    });
    this.modalFormGroup = this._formBuilder.group({
      name: ['', Validators.required],
      antalsalda: ['', Validators.required],
      client_name: ['', Validators.required],
      clientNameFilter: [''],
      project_name: ['', Validators.required],
      projectNameFilter: [''],
      product_name: ['', Validators.required],
      productNameFilter: [''],
      provisionin: ['', Validators.required],
      provisionut: ['', Validators.required],
      date: ['', Validators.required],
      LoxySoftId: [''],
      status: ['', Validators.required],
      comment: ['', Validators.required]
    });
    this.empFilterArr = this.modalFormGroup.controls['name'].valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
    this.modalFormGroup.controls['clientNameFilter'].valueChanges
      .pipe(takeUntil(this._onClientDestroy)).subscribe(() => this._clientFilter());
    this.modalFormGroup.controls['projectNameFilter'].valueChanges
      .pipe(takeUntil(this._onDestroy)).subscribe(() => this._projectFilter());
    this.modalFormGroup.controls['productNameFilter'].valueChanges
      .pipe(takeUntil(this._onProductDestroy)).subscribe(() => this._productFilter());
  }

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  searchList() {
  }

  getClientList() {
    this.sharedServices.getClientList().subscribe((res: any) => {
      if (res) {
        this.clientsArr = res;
        this.clientsArr.sort(function (a, b) {
          if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
          if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
          return 0;
        });
      }
    });
  }


  getProductList() {
    this.sharedServices.getProductList().subscribe((res: any) => {
      if (res) {
        this.productsArr = res;
        this.productsArr.sort(function (a, b) {
          if (a.Product_name.toLowerCase() < b.Product_name.toLowerCase()) { return -1; }
          if (a.Product_name.toLowerCase() > b.Product_name.toLowerCase()) { return 1; }
          return 0;
        });
      }
    });
  }

  getStatusList() {
    this.statusList = [
      { Status_id: 1, Status_name: "Godkänd" },
      { Status_id: 2, Status_name: "Ånger" },
      { Status_id: 3, Status_name: "Bortfall" },
      { Status_id: 4, Status_name: "Ånger tidigare period" },
      { Status_id: 5, Status_name: "Tidigare period" }
    ];
  }

  getProjectList() {
    this.sharedServices.getProjectList().subscribe((res: any) => {
      if (res) {
        this.projectsArr = res;
        this.projectsArr.sort(function (a, b) {
          if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
          if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
          return 0;
        });
      }
    });
  }

  AddImportOrder() {
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let form1 = this.modalFormGroup.getRawValue();
      let tosendImportOrder = {
        "WorkingDate": _moment(form1.date).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss'),
        "ClientId": form1.client_name._id,
        "ProjectId": form1.project_name.Project_id,
        "ProductId": form1.product_name.Product_id,
        "LoxySoftId": form1.LoxySoftId,
        "SoldQuantity": form1.antalsalda,
      }

      if (this.salesCreateOrupdate === 'create') {
        this.impOrderService.updateImportOrder(tosendImportOrder).subscribe(res => {
          if (res.message === 'Updated Successfully') {
            this.loadImportOrder();
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.deleteEmpModalRef.close('submitted');
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          setTimeout(() => {
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this._ref.detectChanges();
          }, 5000)
          this._ref.detectChanges();

        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
        this.spinner.active = false;
      } else if (this.salesCreateOrupdate === 'update') {
        const editSubmission: Update<any> = {
          id: tosendImportOrder.LoxySoftId,
          changes: {
            Client_id: tosendImportOrder.ClientId,
            Client_name: form1.client_name.name,
            Employee_id: this.updateImportOrderData.Employee_id,
            LoxySoftId: tosendImportOrder.LoxySoftId,
            Product_id: tosendImportOrder.ProductId,
            Product_name: form1.product_name.Product_name,
            Project_id: form1.project_name.Project_id,
            Project_name: form1.project_name.Project_name,
            WorkingDate: form1.date,
            first_name: this.updateImportOrderData.first_name,
            last_name: this.updateImportOrderData.last_name,
            salescount: form1.antalsalda,
          }
        };
        this.resUpdateeMessage.success = true;
        this.resUpdateeMessage.error = false;
        this.deleteEmpModalRef.close('submitted');
        setTimeout(() => {
          this.resUpdateeMessage.success = false;
          this.resUpdateeMessage.error = false;
          this._ref.detectChanges();
        }, 5000)
        this._ref.detectChanges();
      }
      this.spinner.active = false;
    }
  }

  public fileChangeEvent(fileInput: any) {
    if (fileInput.target.files && fileInput.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(fileInput.target.files[0]);
    }
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }

  loadTotalOrder() {
    this.loaderTotal = true;
    if (!this.yearSelected) {
      this.yearSelected = new Date().getFullYear();
    }
    if (!this.monthSelected) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.totalOrderDataSource = new MatTableDataSource([]);

    let loadTotalData: any = {
      month: this.monthSelected,
      year: this.yearSelected
    }
    if (this.addNoticer.value.statusSelected && this.addNoticer.value.statusSelected != "") {
      loadTotalData.status = this.addNoticer.value.statusSelected
    }
    if (this.addNoticer.value.empSelected && this.addNoticer.value.empSelected != "") {
      loadTotalData.employee_id = this.addNoticer.value.empSelected
    }
    this.impOrderService.getAllLoxysoftOverview(loadTotalData).subscribe(res => {
      this.totalOrderDataSource = new MatTableDataSource([]);
      if (res) {
        let totalresultarr = [];
        res.forEach((obj) => {
          let totaldatasourceObj: any = {};
          totaldatasourceObj.sales_count = obj.sales_count;
          totaldatasourceObj.regret_count = obj.regret_coun;
          totaldatasourceObj.total_count = obj.total_count;
          totalresultarr.push(totaldatasourceObj);
        });
        this.totalOrderList = totalresultarr;
        this.totalOrderDataSource = new MatTableDataSource(res);
        this.totalOrderDataSource.sort = this.sorttot;
        this.totalOrderDataSource.paginator = this.paginatortot;
        this.loaderTotal = false;
      }
      else {
        this.totalOrderDataSource = new MatTableDataSource([]);
        this.tTotRowNoRecord = true;
        this.loaderTotal = false;
      }
    }, err => {
      this.tTotRowErr = true;
      this.loaderTotal = false;
    });
  }

  getLastname(client) {
    return client && client.last_name ? client.last_name : '';
  }

  getWorkingDate(client) {
    return _moment(client.WorkingDate).format('YYYY-MM-DD');
  }

  getProvisionin(client) {
    return client.EmpProvisionIn ? client.EmpProvisionIn : '0';
  }

  getProvisionOut(client) {
    return client.EmpProvisionOut ? client.EmpProvisionOut : '0';
  }

  getFirstname(client) {
    return client && client.first_name ? client.first_name : '';
  }

  slideToggleChange(e) { }

  changeUrlParams(changepage?) {
    this.isQueryParams = false;
    if (this.queryParams.loxySoftId != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.fName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.lName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.count != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.cName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.status != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.comment != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.projName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.prodName != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.wDate != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.in != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.out != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.month != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.year != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.page != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.active != null) {
      this.isQueryParams = true;
    }
    if (this.queryParams.direct != null) {
      this.isQueryParams = true;
    }
    if (changepage) {
      this.queryParams.page = this.currentPage;
    }
    this.optionVal = btoa(JSON.stringify(this.queryParams));
    this.location.go(this.router.createUrlTree([this.router.url.split('?')[0]],
      {
        queryParams: { optionVal: this.isQueryParams ? this.optionVal : null }
      }).toString());
  }

  loadImportOrder() {
    this.loader = true;
    this.tRowErr = false;
    this.tRowNoRecord = false;
    if (!this.yearSelected) {
      this.yearSelected = new Date().getFullYear();
    }
    if (!this.monthSelected) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.dataSource = new MatTableDataSource([]);
    let loadData: any = {
      month: this.monthSelected,
      year: this.yearSelected
    }
    if (this.addNoticer.value.statusSelected && this.addNoticer.value.statusSelected != "") {
      loadData.status = this.addNoticer.value.statusSelected
    }
    if (this.addNoticer.value.empSelected && this.addNoticer.value.empSelected != "") {
      loadData.employee_id = this.addNoticer.value.empSelected
    }
    this.impOrderService.getImportRegretDataList(loadData).subscribe(res => {
      this.dataSource = new MatTableDataSource([]);
      if (res) {
        //for download
        let resultarr = [];
        res.forEach((obj) => {
          let datasourceObj: any = {};
          datasourceObj.LoxySoftId = obj.LoxySoftId;
          datasourceObj.first_name = this.getFirstname(obj);
          datasourceObj.last_name = this.getLastname(obj);
          datasourceObj.salescount = obj.salescount;
          datasourceObj.Client_name = obj.Client_name;
          datasourceObj.Project_name = obj.Project_name;
          datasourceObj.Product_name = obj.Product_name;
          datasourceObj.EmpProvisionIn = undefined;
          datasourceObj.EmpProvisionOut = undefined;
          datasourceObj.WorkingDate = this.getWorkingDate(obj);
          resultarr.push(datasourceObj);
        });
        this.impOrderList = resultarr;
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator.pageIndex = this.currentPage;
        this.dataSource.sort.active = this.sortActive;
        this.dataSource.sort.direction = this.sortDirection;
        this.applyColumnFilter('');

        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.loader = false;
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.tRowNoRecord = true;
        this.loader = false;
      }
    }, err => {
      this.tRowErr = true;
      this.loader = false;
    })
  }

  loadClientList() {
    this.selection.clear();
    this.showHideCols();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.LoxySoftId + item.WorkingDate + item.Client_name + item.EmpProvisionIn + item.EmpProvisionOut + item.Project_name + item.Product_name + item.salescount + this.getLastname(item) + this.getFirstname(item) + this.getWorkingDate(item);
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  private setExcelHeaders() {
    this.arrToPrint = [];
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      if (this.displayColumnToShow.indexOf(obj.label) > -1 && obj.label != 'actions') {
        this.arrToPrint[0].push(obj.column)
      }
    });
  }

  private setExcelValues() {
    if (this.dataSource && this.dataSource.data.length) {
      this.dataSource.filteredData.forEach((val: any) => {
        let newLine = [];
        this.displayColumnToShow.forEach((key, ind) => {
          if (key != 'actions') {
            let str = key.split('.').reduce((o, i) => { if (o && o[i]) { return o[i] } }, val);
            if (key == 'WorkingDate') {
              let toSetDate = {
                WorkingDate: str
              }
              str = this.getWorkingDate(toSetDate).toString();
            }
            newLine.push(str);
          }
        });
        this.arrToPrint.push(newLine);
      });
    }
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols() {
    this.displayColumnToShow = [];
    this.filterDisplayColumnToShow = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        this.displayColumnToShow.push(obj.label);
        this.filterDisplayColumnToShow.push(this.filtertoggleColumns[ind].label);
        if (this.multiColFilter[obj.label] === undefined) {
          this.multiColFilter[obj.label] = '';
        }
      } else {
        if (this.multiColFilter[obj.label]) {
          this.multiColFilter[obj.label] = '';
          this.applyColumnFilter('');
        }
      }
    });
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      /* generate worksheet */
      this.setExcelHeaders();
      this.setExcelValues();
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Import_Order_List_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }

  openModal(content, contentAccessId, toClient?) {
    this.previousEmployee = null;
    if (content === 'create') {
      this.salesCreateOrupdate = 'create';
      this.modalFormGroup.reset();
      this.modalFormGroup.get('name').enable();
      this.modalFormGroup.get('product_name').enable();
      this.modalFormGroup.get('provisionin').disable();
      this.modalFormGroup.get('provisionut').disable();
      this.modalFormGroup.get('date').enable();
      this.modalFormGroup.get('project_name').enable();
      this.modalFormGroup.get('client_name').enable();
      this.updateErrMsg = false;
      this.clientTitle = "Lägg till fil";
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'update' || content === 'moveSales') {
      this.salesCreateOrupdate = 'update';
      this.updateImportOrderData = toClient;
      this.modalFormGroup.patchValue({
        client_name: { _id: toClient.Client_id, name: toClient.Client_name },
      });
      this.getProjectListByClient(this.modalFormGroup.controls.client_name.value);
      this.modalFormGroup.patchValue({
        project_name: { Project_id: toClient.Project_id, Project_name: toClient.Project_name },
      });
      this.clientProjectsArr.forEach((obj) => {
        if (this.modalFormGroup.controls.project_name.value && this.modalFormGroup.controls.project_name.value['Project_id'] === obj.Project_id) {
          this.getProductsListByProject(obj);
        }
      });
      this.modalFormGroup.patchValue({
        product_name: { Product_id: toClient.Product_id, Product_name: toClient.Product_name },
        name: this._setEmployeeInEdit(toClient.Employee_id),
        antalsalda: toClient.salescount,
        provisionin: toClient.EmpProvisionIn,
        provisionut: toClient.EmpProvisionOut,
        date: toClient.WorkingDate,
        LoxySoftId: toClient.LoxySoftId,
        status: { Status_id: toClient.Status_id, Status_name: toClient.Status_name },
        comment: toClient.comment
      });
      this.modalFormGroup.get('product_name').disable();
      this.modalFormGroup.get('provisionin').disable();
      this.modalFormGroup.get('provisionut').disable();
      this.modalFormGroup.get('date').disable();
      this.modalFormGroup.get('project_name').disable();
      this.modalFormGroup.get('client_name').disable();
      this.modalFormGroup.get('antalsalda').enable();
      this.updateErrMsg = false;
      if (content === 'moveSales') {
        this.clientTitle = "Flytta ordning";
        this.modalFormGroup.get('name').enable();
        this.previousEmployee = toClient.LoxySoftId;
      } else {
        this.clientTitle = "Uppdateringsorder";
        this.modalFormGroup.get('name').disable();
      }

      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', backdrop: "static" });
    } else if (content === 'delete') {
      this.deleteErrMsg = false;
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-delete-order', backdrop: "static" });
    }
    this.uploadOption = '0';
    this.delOrderData = toClient;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  deleteOrder() {
    this.spinner.active = true;
    this.impOrderService.deleteOrder(this.delOrderData).subscribe(res => {
      if (res.message === 'Record deleted successfully') {
        this.loadImportOrder();
        this.resDeleteMessage.success = true;
        this.resDeleteMessage.error = false;
        this.deleteEmpModalRef.close('submitted');
      } else {
        this.spinner.active = false;
        this.deleteEmpModalRef.close('submitted');
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = true;
      }
      setTimeout(() => {
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = false;
        this._ref.detectChanges();
      }, 5000);
      this.spinner.active = false;
      this._ref.detectChanges();
    }, error => {
      if (error.error.message) {
        this.deleteErrMsg = true;
        this.spinner.active = false;
      }
    });
    this.spinner.active = false;
  }

  getProjectListByClient(clientId) {
    this.clientProjectsArr = [];
    this.clientsProductsArr = [];
    this.modalFormGroup.controls.project_name.reset();
    this.modalFormGroup.controls.product_name.reset();
    this.projectsArr.forEach((obj) => {
      if (obj.Client_id === clientId._id) {
        this.clientProjectsArr.push(obj);
      }
    });
    this._projectFilter();
  }

  getProductsListByProject(project) {
    this.clientsProductsArr = [];
    this.modalFormGroup.controls.product_name.reset();
    project.Products.forEach((prodData) => {
      this.clientsProductsArr.push({ Product_id: prodData.prod_id, Product_name: prodData.prod_name });
    });
    this._productFilter();
  }

  compareModalClient(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1._id === opt2._id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalProject(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.Project_id == opt2.Project_id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalProduct(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.Product_id == opt2.Product_id) {
      return true;
    } else {
      return false;
    }
  }

  compareModalStatus(opt1: any, opt2: any) {
    if (opt1 && opt2 && opt1.Status_id == opt2.Status_id && opt1.Status_name == opt2.Status_name) {
      return true;
    } else {
      return false;
    }
  }

  loadEmployee() {
    this.empArr = [];
    this.sharedServices.getAllEmployees().subscribe(res => {
      res.forEach((obj) => {
        this.empArr.push({
          id: obj.Employee_id,
          name: obj.first_name + " " + obj.last_name
        });
      });
      this.empArr.sort(function (a, b) {
        if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
        if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
        return 0;
      });
      this._Empfilter();
    });
  }

  protected _Empfilter(): any[] {
    if (this.empArr.length <= 0) {
      return;
    }
    if (this.addNoticer && this.addNoticer.controls['employeeFilterControls'].value && (typeof this.addNoticer.controls['employeeFilterControls'].value == 'string') && this.addNoticer.controls['employeeFilterControls'].value.trim() != '') {
      const empfilterValue = this.addNoticer.controls['employeeFilterControls'].value.toLowerCase();
      this.empFilteredOptions.next(
        this.empArr.filter(emp => (emp.name.toLowerCase().indexOf(empfilterValue) > -1))
      );
    } else {
      this.empFilteredOptions.next(this.empArr.slice());
      return;
    }
  }

  displayFn(user?: any): string | undefined {
    return user ? user.name : '';
  }

  onAddEmployeeFromClick(event) {
    if (event.option.value) {
      this.projectService.getEmployee(event.option.value.id).subscribe(res => {
        if (res) {
          this.modalFormGroup.patchValue({
            LoxySoftId: res.loxysoft_id
          });
        }
      });
    }
  }

  private _filter(value: string): string[] {
    let filterValue = '';
    if (typeof value === 'string') {
      filterValue = value.toLowerCase();
    }
    return this.empArr.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  private _setEmployeeInEdit(empId: any) {
    return this.empArr.find((employee) => employee.id === empId);
  }

  applyColumnFilter(searchkey) {
    switch (searchkey) {
      case "loxySoftId": {
        this.queryParams.loxySoftId = this.multiColFilter.LoxySoftId == "" ? null : this.multiColFilter.LoxySoftId;
        this.changeUrlParams();
        break;
      }
      case "fName": {
        this.queryParams.fName = this.multiColFilter.first_name == "" ? null : this.multiColFilter.first_name;
        this.changeUrlParams();
        break;
      }
      case "lName": {
        this.queryParams.lName = this.multiColFilter.last_name == "" ? null : this.multiColFilter.last_name;
        this.changeUrlParams();
        break;
      }
      case "count": {
        this.queryParams.count = this.multiColFilter.salescount == "" ? null : this.multiColFilter.salescount;
        this.changeUrlParams();
        break;
      }
      case "cName": {
        this.queryParams.cName = this.multiColFilter.Client_name == "" ? null : this.multiColFilter.Client_name;
        this.changeUrlParams();
        break;
      }
      case "projName": {
        this.queryParams.projName = this.multiColFilter.Project_name == "" ? null : this.multiColFilter.Project_name;
        this.changeUrlParams();
        break;
      }
      case "prodName": {
        this.queryParams.prodName = this.multiColFilter.Product_name == "" ? null : this.multiColFilter.Product_name;
        this.changeUrlParams();
        break;
      }
      case "wDate": {
        this.queryParams.wDate = this.multiColFilter.WorkingDate == "" ? null : this.multiColFilter.WorkingDate;
        this.changeUrlParams();
        break;
      }
      case "in": {
        this.queryParams.in = this.multiColFilter.EmpProvisionIn == "" ? null : this.multiColFilter.EmpProvisionIn;
        this.changeUrlParams();
        break;
      }
      case "out": {
        this.queryParams.out = this.multiColFilter.EmpProvisionOut == "" ? null : this.multiColFilter.EmpProvisionOut;
        this.changeUrlParams();
        break;
      }
      default: {
        break;
      }
    }
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.currentPage > 0 && searchkey == '') {
      this.dataSource.paginator.pageIndex = this.currentPage;
    }
    else {
      this.dataSource.paginator.firstPage();
    }
  }

  public handlePage(e: any) {
    this.currentPage = e.pageIndex;
    this.queryParams.page = this.currentPage;
    this.changeUrlParams();
  }

  sortData(event) {
    this.queryParams.active = event.active;
    this.queryParams.direct = event.direction;
    this.changeUrlParams();
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(item).forEach((key) => {
        if ((item[key] && filterString[key]) || ((item[key] >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (typeof item[key] != 'string') {
            itemString = item[key].toString();
          } else {
            if (key === 'WorkingDate') {
              itemString = this.getWorkingDate(item).toString();
            } else {
              itemString = item[key];
            }
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!item[key] || (item[key] <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  deleteByImportId() {
    if (this.deleteImportId.valid) {
      this.spinner.active = true;
      this.impOrderService.deleteByImportId(this.deleteImportId.value, 'Sales').subscribe(res => {
        if (res.message === 'Record deleted successfully') {
          this.loadImportOrder();
          this.resDeleteMessage.success = true;
          this.resDeleteMessage.error = false;
          this.deleteEmpModalRef.close('submitted');
        } else {
          this.spinner.active = false;
          this.deleteEmpModalRef.close('submitted');
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = true;
        }
        setTimeout(() => {
          this.resDeleteMessage.success = false;
          this.resDeleteMessage.error = false;
          this._ref.detectChanges();
        }, 5000);
        this.spinner.active = false;
        this._ref.detectChanges();
      }, error => {
        if (error.error.message) {
          if (error.error.message === 'Wrong import id') {
            this.deleteImportIdErrMsg = this.translate.instant('COMMON.ERROR') + "!Felaktigt import-ID!";
          } else {
            this.deleteImportIdErrMsg = this.translate.instant('COMMON.ERROR') + "!Ser ut som något gick fel!";
          }
          this.showDeleteImportIdErrMsg = true;
          setTimeout(() => {
            this.showDeleteImportIdErrMsg = false;
            this._ref.detectChanges();
          }, 5000);
        }
        this.spinner.active = false;
        this._ref.detectChanges();
      });
    }
  }

  moveSalesData() {
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let form1 = this.modalFormGroup.getRawValue();
      let tosendImportOrder = {
        "WorkingDate": form1.date,
        "ClientId": form1.client_name._id,
        "ProjectId": form1.project_name.Project_id,
        "ProductId": form1.product_name.Product_id,
        "LoxySoftId": this.previousEmployee,
        "SoldQuantity": form1.antalsalda,
        "ToLoxySoftId": form1.LoxySoftId,
        "MovedBy": this.userData.id
      };

      if (this.salesCreateOrupdate === 'update') {
        this.impOrderService.moveSalesDetails(tosendImportOrder).subscribe(res => {
          if (res.message === 'Data moved Successfully') {
            this.loadImportOrder();
            this.resUpdateeMessage.success = true;
            this.resUpdateeMessage.error = false;
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.deleteEmpModalRef.close('submitted');
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = true;
          }
          setTimeout(() => {
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = false;
            this._ref.detectChanges();
          }, 5000);
          this.spinner.active = false;
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      }
      this.spinner.active = false;
    }
  }

  isMoveOrUpdate() {
    if (!this.previousEmployee) {
      this.AddImportOrder();
    } else {
      this.moveSalesData();
    }
  }

  updateStatus() {
    if (this.modalFormGroup.valid) {
      let data = {
        Client_id: this.updateImportOrderData.Client_id,
        Client_name: this.updateImportOrderData.Client_name,
        EmpProvisionIn: this.updateImportOrderData.EmpProvisionIn,
        EmpProvisionOut: this.updateImportOrderData.EmpProvisionOut,
        Employee_id: this.updateImportOrderData.Employee_id,
        LoxySoftId: this.updateImportOrderData.LoxySoftId,
        Product_id: this.updateImportOrderData.Product_id,
        Product_name: this.updateImportOrderData.Product_name,
        Project_id: this.updateImportOrderData.Project_id,
        Project_name: this.updateImportOrderData.Project_name,
        WorkingDate: this.updateImportOrderData.WorkingDate,
        first_name: this.updateImportOrderData.first_name,
        last_name: this.updateImportOrderData.last_name,
        salescount: this.updateImportOrderData.salescount,
        comment: this.modalFormGroup.controls['comment'].value,
        Status_id: this.modalFormGroup.controls['status'].value.Status_id,
        Status_name: this.modalFormGroup.controls['status'].value.Status_name
      }

      this.impOrderService.updateImportOrderData(data, this.delOrderData.id).subscribe(res => {
        if (res) {
          this.loadImportOrder();
          this.resUpdateStatusMessage.success = true;
          this.resUpdateStatusMessage.error = false;
          this.deleteEmpModalRef.close('submitted');
        } else {
          this.deleteEmpModalRef.close('submitted');
          this.resUpdateStatusMessage.success = false;
          this.resUpdateStatusMessage.error = true;
        }
        setTimeout(() => {
          this.resUpdateStatusMessage.success = false;
          this.resUpdateStatusMessage.error = false;
          this._ref.detectChanges();
        }, 5000)
        this._ref.detectChanges();

      }, error => {
        if (error.error.message) {
          this.updateStatusErrMsg = true;
        }
      });
      this.spinner.active = false;
    }
  }

  getSelectedYear(year?: any) {
    if (year) {
      this.yearSelected = year;
    } else {
      this.yearSelected = new Date().getFullYear();
    }
    this.monthSelected = null;
    this.queryParams.month = this.monthSelected;
    this.queryParams.year = this.yearSelected;
    this.changeUrlParams();
  }

  getSelectedMonth(monthObj?: any) {
    if (monthObj && monthObj.value) {
      this.monthSelected = monthObj.value;
    } else {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.queryParams.month = this.monthSelected;
    this.changeUrlParams();
    if (!((this.monthSelected == this.unchangedSelectedMonth) && (this.yearSelected == this.unchangedSelectedYear))) {
      this.unchangedSelectedMonth = this.monthSelected;
      this.unchangedSelectedYear = this.yearSelected;
      this.loadImportOrder();
      this.loadTotalOrder();
    }
  }

  protected _projectFilter(): any[] {
    if (this.clientProjectsArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['projectNameFilter'].value && (typeof this.modalFormGroup.controls['projectNameFilter'].value == 'string') && this.modalFormGroup.controls['projectNameFilter'].value.trim() != '') {
      const depfilterValue = this.modalFormGroup.controls['projectNameFilter'].value.toLowerCase();
      this.projectFilteredOptions.next(
        this.clientProjectsArr.filter(dep => (dep.Project_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.projectFilteredOptions.next(this.clientProjectsArr.slice());
      return;
    }
  }

  protected _clientFilter(): any[] {
    if (this.clientsArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['clientNameFilter'].value && (typeof this.modalFormGroup.controls['clientNameFilter'].value == 'string') && this.modalFormGroup.controls['clientNameFilter'].value.trim() != '') {
      const depfilterValue = this.modalFormGroup.controls['clientNameFilter'].value.toLowerCase();
      this.clientFilteredOptions.next(
        this.clientsArr.filter(dep => (dep.name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.clientFilteredOptions.next(this.clientsArr.slice());
      return;
    }
  }

  protected _productFilter(): any[] {
    if (this.clientsProductsArr.length <= 0) {
      return;
    }
    if (this.modalFormGroup && this.modalFormGroup.controls['productNameFilter'].value && (typeof this.modalFormGroup.controls['productNameFilter'].value == 'string') && this.modalFormGroup.controls['productNameFilter'].value.trim() != '') {
      const depfilterValue = this.modalFormGroup.controls['productNameFilter'].value.toLowerCase();
      this.productFilteredOptions.next(
        this.clientsProductsArr.filter(dep => (dep.Product_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.productFilteredOptions.next(this.clientsProductsArr.slice());
      return;
    }
  }
}
