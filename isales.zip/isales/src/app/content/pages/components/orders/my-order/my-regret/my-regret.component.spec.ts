import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyRegretComponent } from './my-regret.component';

describe('MyRegretComponent', () => {
  let component: MyRegretComponent;
  let fixture: ComponentFixture<MyRegretComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyRegretComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyRegretComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
