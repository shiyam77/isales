import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
	selector: 'm-material',
	templateUrl: './material.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class MaterialComponent { }


