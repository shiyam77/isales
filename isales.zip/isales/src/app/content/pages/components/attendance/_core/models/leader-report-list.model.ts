export class LeaderReportList {
    first_name:string;
    last_name:string;
    mobile: number;
    landline: number;
    In_time: number;
    Out_time: number;
    Lunch: number;
}