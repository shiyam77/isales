import { Component, OnInit, ViewChild, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { SelectionModel, DataSource, CollectionViewer } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import * as _moment from 'moment';
import * as Moment from "moment";
import * as Xlsx from 'xlsx';
import { TranslateService } from '@ngx-translate/core';
import { ProjectService } from '../../project/_core/services/project.service';
type AOA = any[][];
import { AttendanceService } from '../_core/services/attendance.service';
import { AttendanceList } from '../_core/models/attendance-list.model';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

@Component({
  selector: 'm-leader-view',
  templateUrl: './leader-view.component.html',
  styleUrls: ['./leader-view.component.scss']
})

export class LeaderViewComponent implements OnInit {

  totalTime: any;
  totalQty: any;
  attID: any;
  empID: any;
  spinners = false;
  modalTitle: string = 'Lägg till ny Tidsrapportering Ledare';
  attendanceProjectList: any = [];
  attendanceEmployeeList: any = [];
  completeAttendanceList: any = [];
  projects: any = [];
  dataSource: any;
  tempDataSource: any;
  isExtendedRow = (index, item) => item.extend;
  statusArr: Array<any> = [];
  totalDeptReportArray: Array<any> = [];
  modalFormGroup: FormGroup;
  dateFormGroup: FormGroup;
  modalInOutError: boolean = false;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  arrToPrint: AOA = [];
  selection = new SelectionModel<AttendanceList>(true, []);
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  displayColumnToShow = ['firstname', 'surname'];
  allAttendanceList: AttendanceList[] = [];
  xpandStatus: boolean = false;
  searchInput: string = '';
  deleteEmpModalRef: any;
  closeResult: string;
  TotalpresenceHours: any;
  toggleColumns = [
    { arrIndex: 1, column: 'Employee_id', checked: true, label: 'Employee_id' },
    { arrIndex: 2, column: 'first_name', checked: true, label: 'first_name' },
    { arrIndex: 3, column: 'last_name', checked: true, label: 'last_name' },
    { arrIndex: 4, column: 'mobile', checked: true, label: 'mobile' },
    { arrIndex: 5, column: 'In_time', checked: true, label: 'In_time' },
    { arrIndex: 6, column: 'Out_time', checked: true, label: 'Out_time' },
    { arrIndex: 7, column: 'Status', checked: true, label: 'Status' },
    { arrIndex: 8, column: 'Actions', checked: true, label: 'Actions' }
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };

  resDeleteMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  nextDateToDisplay: string;
  previousDateToDisplay: string;
  multiColFilter = {
    Employee_id: '',
    first_name: '',
    last_name: '',
    department: '',
    mobile: '',
    Status: '',
    Note: ''
  };

  constructor(private projectService: ProjectService,
    private modalService: NgbModal,
    private attendanceService: AttendanceService,
    private _formBuilder: FormBuilder,
    private _ref: ChangeDetectorRef) { }

  ngOnInit() {
    this.setExcelHeaders();
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.dateFormGroup = this._formBuilder.group({
      attendancedate: [this.getSearchDate()],
    });
    this.tempDataSource = new MyDataSource(this.attendanceService);
    this.dataSource = new MatTableDataSource([]);
    this.loadAttendanceDatewise();
    this.modalFormGroup = this._formBuilder.group({
      personal: ['', Validators.required],
      fromdate: ['', Validators.required],
      starttime: [{ hour: 10, minute: 0 }],
      finaltime: [{ hour: 19, minute: 0 }],
      lunchtime: [{ hour: 1, minute: 0 }],
      statusid: ['', Validators.required],
      project: [''],
      department: [''],
      notes: [''],
      godkand: [''],
    });
    this.statusArr.push({ id: 0, name: 'Närvaro' },
      { id: 1, name: 'Närvaro sen' },
      { id: 11, name: 'Närvaro godkänd sen' },
      { id: 2, name: 'Sjuk' },
      { id: 3, name: 'Ogiltig frånvaro' },
      { id: 4, name: 'Ledighet' },
      { id: 5, name: 'Utbildning' },
      { id: 6, name: 'Sjuk Vab' },
      { id: 7, name: 'Ej Schemalagd' }
    );
  }

  getSearchDate() {
    var d = new Date(),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [month, day, year].join('-');
  }

  getTime(value) {
    let ts = '';
    if (value) {
      ts = Moment(value).format('HH:mm:ss');
    }
    return ts;
  }

  getStatus(status) {
    switch (status) {
      case 0:
        return 'Närvaro';
      case 1:
        return 'Närvaro sen';
      case 2:
        return 'Sjuk';
      case 3:
        return 'Ogiltig frånvaro';
      case 4:
        return 'Ledighet';
      case 5:
        return 'Utbildning';
      case 6:
        return 'Sjuk Vab';
      case 7:
        return 'Ej Schemalagd';
      case 11:
        return 'Närvaro godkänd sen';
      default:
        return '';
    }
  }

  attendanceDateChange(value: any) {
    this.loadAttendanceDatewise();
  }

  setNextAndPreviousDay() {
    var currentdate = new Date(this.dateFormGroup.value.attendancedate);
    var nextDate = new Date(currentdate.getTime() + (1000 * 60 * 60 * 24));
    this.nextDateToDisplay = Moment(nextDate).format('YYYY-MM-DD');
    var previousDate = new Date(currentdate.getTime() - (1000 * 60 * 60 * 24));
    this.previousDateToDisplay = Moment(previousDate).format('YYYY-MM-DD');
  }

  getTotalTime(time) {
    if (time) {
      let tims = time.split(':');
      return tims[0] + ':' + tims[1];
    } else {
      return '';
    }
  }

  loadDepartmentwiseTotal() {
    this.totalTime = {};
    this.totalQty = {};
    let searchDate = Moment(this.dateFormGroup.controls.attendancedate.value).format('YYYY-MM-DD');
    this.attendanceService.getDepartmentwiseTotalhours(searchDate).subscribe(res => {
      if (res) {
        this.totalTime.totalpresenceQty = 0;
        this.totalTime.totalpresenceLateQty = 0;
        this.totalTime.totalpresenceApprovedQty = 0;
        this.totalTime.totalsickQty = 0;
        this.totalTime.totalinvalidAbsenceQty = 0;
        this.totalTime.totalapprovedAbsenceQty = 0;
        this.totalTime.totalpresenceEduQty = 0;
        this.totalTime.totalsickVabQty = 0;
        this.totalTime.TotaltotalQty = 0;
        this.totalQty.TotalpresenceHours = 0;
        this.totalQty.TotalpresenceLateHours = 0;
        this.totalQty.TotalpresenceApprovedHours = 0;
        this.totalQty.TotalsickHours = 0;
        this.totalQty.TotalinvalidAbsenceHours = 0;
        this.totalQty.TotalapprovedAbsenceHours = 0;
        this.totalQty.TotalpresenceEduHours = 0;
        this.totalQty.TotalsickVabHours = 0;
        this.totalQty.Totaltotaltime = 0;
        if (res.Grandtotal) {
          this.totalQty.Totaltotaltime = this.getTotalTime(res.Grandtotal);
          this.totalTime.TotaltotalQty = res.TotalMandays;
        }
        this.totalDeptReportArray = [];
        res.Department_wise_Report.forEach((obj) => {
          let tempObj: any = {
            department: obj.Department,
          };
          if (obj.Row_wise_Total) {
            obj.Row_wise_Total.forEach((rObj) => {
              rObj.StatuswiseReport.forEach((sObj) => {
                tempObj.totalqty = rObj.TotalMandays;
                tempObj.totaltime = this.getTotalTime(rObj.Totalhours);
                let time = this.getTotalTime(sObj.Hours);
                switch (sObj.Status) {
                  case 0: {
                    tempObj.presenceHours = time;
                    tempObj.presenceQty = sObj.Mandays;
                    this.totalTime.totalpresenceQty += sObj.Mandays;
                  };
                    break;
                  case 1: {
                    tempObj.presenceLateHours = time;
                    tempObj.presenceLateQty = sObj.Mandays;
                    this.totalTime.totalpresenceLateQty = + sObj.Mandays;
                  };
                    break;
                  case 2: {
                    tempObj.sickHours = time;
                    tempObj.sickQty = sObj.Mandays;
                    this.totalTime.totalsickQty = + sObj.Mandays;
                  };
                    break;
                  case 3: {
                    tempObj.invalidAbsenceHours = time;
                    tempObj.invalidAbsenceQty = sObj.Mandays;
                    this.totalTime.totalinvalidAbsenceQty = + sObj.Mandays;
                  };
                    break;
                  case 4: {
                    tempObj.approvedAbsenceHours = time;
                    tempObj.approvedAbsenceQty = sObj.Mandays;
                    this.totalTime.totalapprovedAbsenceQty = + sObj.Mandays;
                  };
                    break;
                  case 5: {
                    tempObj.presenceEduHours = time;
                    tempObj.presenceEduQty = sObj.Mandays;
                    this.totalTime.totalpresenceEduQty = + sObj.Mandays;
                  };
                    break;
                  case 6: {
                    tempObj.sickVabHours = time;
                    tempObj.sickVabQty = sObj.Mandays;
                    this.totalTime.totalsickVabQty = + sObj.Mandays;
                  };
                    break;
                  case 11: {
                    tempObj.presenceApprovedHours = time;
                    tempObj.presenceApprovedQty = sObj.Mandays;
                    this.totalTime.totalpresenceApprovedQty = + sObj.Mandays;
                  };
                    break;                    
                  default: {
                    tempObj.notScheduledHours = '';
                    tempObj.notScheduledQty = '';
                  };
                    break;
                }
              });
            });
          }
          this.totalDeptReportArray.push(tempObj);
        });
        if (res.Column_wise_Total) {
          res.Column_wise_Total.forEach((cObj) => {
            switch (cObj.Status) {
              case 0: {
                this.totalQty.TotalpresenceHours = this.getTotalTime(cObj.Hours);
                this.totalTime.totalpresenceQty = cObj.Mandays;
              };
                break;
              case 1: {
                this.totalTime.totalpresenceLateQty = cObj.Mandays;
                this.totalQty.TotalpresenceLateHours = this.getTotalTime(cObj.Hours);
              };
                break;
              case 2: {
                this.totalTime.totalsickQty = cObj.Mandays;
                this.totalQty.TotalsickHours = this.getTotalTime(cObj.Hours);
              };
                break;
              case 3: {
                this.totalTime.totalinvalidAbsenceQty = cObj.Mandays;
                this.totalQty.TotalinvalidAbsenceHours = this.getTotalTime(cObj.Hours);
              };
                break;
              case 4: {
                this.totalTime.totalapprovedAbsenceQty = cObj.Mandays;
                this.totalQty.TotalapprovedAbsenceHours = this.getTotalTime(cObj.Hours);
              };
                break;
              case 5: {
                this.totalTime.totalpresenceEduQty = cObj.Mandays;
                this.totalQty.TotalpresenceEduHours = this.getTotalTime(cObj.Hours);
              };
                break;
              case 6: {
                this.totalTime.totalsickVabQty = cObj.Mandays;
                this.totalQty.TotalsickVabHours = this.getTotalTime(cObj.Hours);
              };
                break;
              case 11: {
                this.totalTime.totalpresenceApprovedQty = cObj.Mandays;
                this.totalQty.TotalpresenceApprovedHours = this.getTotalTime(cObj.Hours);
              };
                break;                
              default: {

              };
                break;
            }
          });
        }
      }
      this._ref.detectChanges();
    }, err => {
      this.totalDeptReportArray = [];
      this.totalTime = {};
      this.totalQty = {};
      this._ref.detectChanges();
    })
  }

  loadAttendanceDatewise() {
    this.loadDepartmentwiseTotal();
    let searchDate = Moment(this.dateFormGroup.controls.attendancedate.value).format('YYYY-MM-DD');
    this.setNextAndPreviousDay();
    this.loader = true;
    this.dataSource = new MatTableDataSource([]);
    this.selection.clear();
    this.attendanceProjectList = [];
    this.attendanceEmployeeList = [];
    this.completeAttendanceList = [];
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin' || this.userData.role == 'teamleader') {
      this.tempDataSource.loadAttendanceDatewise(searchDate);
      this.selection.clear();
      this.showHideCols();
    }
    this.selection.clear();
    this.showHideCols();
  }

  openModal(content, contentAccessId, totimersattning?) {
    this.projects = [];
    if (content === 'create') {
      this.modalTitle = 'Lägg till ny Tidsrapportering Ledare';
      this.modalFormGroup.reset();
      if (totimersattning) {
        this.modalFormGroup.patchValue({
          personal: totimersattning.first_name,
          fromdate: totimersattning.Date,
          start: totimersattning.In_time,
          final: totimersattning.Out_time,
          statusid: totimersattning.Status,
          lunch: totimersattning.Lunch,
          department: totimersattning.department
        });
      }
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal' });
    } else if (content === 'update') {
      this.attID = totimersattning.ID;
      this.empID = totimersattning.Employee_id;
      this.projectService.getEmployee(totimersattning.Employee_id).subscribe(res => {
        if (res) {
          if (res.Projects && res.Projects.length) {
            this.projects.push(res.Projects[res.Projects.length - 1].Project_name);
          }
        }
      });
      this.modalTitle = 'Andra Tidsrapportering Ledare';
      this.modalFormGroup.patchValue({
        personal: totimersattning.first_name + '  ' + totimersattning.last_name,
        fromdate: totimersattning.Date,
        starttime: { hour: this.getHour(totimersattning.In_time), minute: this.getMinute(totimersattning.In_time) },
        lunchtime: { hour: this.getHour(totimersattning.Lunch), minute: this.getMinute(totimersattning.Lunch) },
        finaltime: { hour: this.getHour(totimersattning.Out_time), minute: this.getMinute(totimersattning.Out_time) },
        statusid: totimersattning.Status,
        project: totimersattning.project,
        department: totimersattning.department,
        notes: totimersattning.notes,
        godkand: totimersattning.godkand,
      });
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal' });
    } else if (content === 'delete') {
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'delete-timersattning-modal' });
    }
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  applyFilter(filterValue: string) {
    this.tempDataSource.attendanceFilteredList(filterValue);
  }
  private setExcelHeaders() {
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      this.arrToPrint[0].push(obj.column);
    });
  }

  private setExcelValues() {
    this.allAttendanceList.forEach((val) => {
      let newLine = [];
      this.toggleColumns.forEach((obj) => {
        if (obj.arrIndex !== 11) {
          if (obj.arrIndex === 18
            || obj.arrIndex === 20 || obj.arrIndex === 21
            || obj.arrIndex === 22 || obj.arrIndex === 23) {
            if (obj.arrIndex === 18) {
              newLine.push('True');
            } else {
              newLine.push('False');
            }
          } else {
            let str = obj.label.split('.').reduce((o, i) => o[i], val);
            newLine.push(str);
          }
        }
      });
      this.arrToPrint.push(newLine);
    });
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols() {
    this.displayColumnToShow = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        if (this.userData.role === 'admin' || this.userData.role === 'superadmin' || this.userData.role == 'teamleader') {
          if (this.userData.role != 'teamleader') {
            this.displayColumnToShow.push(obj.label);
          } else {
            if (obj.label != 'Actions') {
              this.displayColumnToShow.push(obj.label);
            }
          }
        }
      }
    });
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin' || this.userData.role === 'superadmin' || this.userData.role == 'teamleader') {
      /* generate worksheet */
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Employee_List_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }

  nextDay() {
    var date = new Date(this.dateFormGroup.value.attendancedate);
    var nextDate = new Date(date.getTime() + (1000 * 60 * 60 * 24));
    this.dateFormGroup.controls['attendancedate'].setValue(Moment(nextDate).format('YYYY-MM-DD'));
    this.loadAttendanceDatewise();
  }

  previousDay() {
    var date = new Date(this.dateFormGroup.value.attendancedate);
    var previousDate = new Date(date.getTime() - (1000 * 60 * 60 * 24));
    this.dateFormGroup.controls['attendancedate'].setValue(Moment(previousDate).format('YYYY-MM-DD'));
    this.loadAttendanceDatewise();
  }

  getHour(time) {
    if (time.includes("T")) {
      return Moment(time.substring(time.indexOf("T") + 1), 'HH:mm:ss').hour();
    } else {
      return Moment(time, 'HH:mm:ss').hour();
    }
  }

  getMinute(time) {
    if (time.includes("T")) {
      return Moment(time.substring(time.indexOf("T") + 1), 'HH:mm:ss').minute();
    } else {
      return Moment(time, 'HH:mm:ss').minute();
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  checkInOutInterval() {
    let formData: any = {};
    if ((this.modalFormGroup.value.starttime.hour >= 0) && (this.modalFormGroup.value.starttime.minute >= 0) && (this.modalFormGroup.value.finaltime.hour >= 0) && (this.modalFormGroup.value.finaltime.hour >= 0)) {
      if (this.modalFormGroup.value.Date) {
        formData.In_time = Moment(this.modalFormGroup.value.Date).set({ hour: this.modalFormGroup.value.starttime.hour, minute: this.modalFormGroup.value.starttime.minute }).valueOf();
        formData.Out_time = Moment(this.modalFormGroup.value.Date).set({ hour: this.modalFormGroup.value.finaltime.hour, minute: this.modalFormGroup.value.finaltime.minute }).valueOf();
      } else {
        formData.In_time = Moment().set({ hour: this.modalFormGroup.value.starttime.hour, minute: this.modalFormGroup.value.starttime.minute }).valueOf();
        formData.Out_time = Moment().set({ hour: this.modalFormGroup.value.finaltime.hour, minute: this.modalFormGroup.value.finaltime.minute }).valueOf();
      }
      if (formData.Out_time >= formData.In_time) {
        this.modalInOutError = false;
        return true;
      } else {
        this.modalInOutError = true;
        return false;
      }
    }
  }

  createSales() {
    if (this.modalTitle == 'Andra Tidsrapportering Ledare') {
      if (this.modalFormGroup.valid && this.checkInOutInterval()) {
        this.spinner.active = true;
        let form1 = this.modalFormGroup.value;
        if (!form1.notes) {
          form1.notes = "";
        }
        let timerSattningData: any = {
          "Employee_id": this.empID,
          "Date": Moment(form1.fromdate).format('YYYY-MM-DD'),
          "Lunch": Moment().set({ hours: form1.lunchtime.hour, minute: form1.lunchtime.minute, second: form1.lunchtime.second }).format('HH:mm:ss'),
          "Status": form1.statusid,
          "Note": form1.notes
        }
        timerSattningData.In_time = Moment(timerSattningData.Date).set({ hour: form1.starttime.hour, minute: form1.starttime.minute, second: form1.starttime.second }).format('YYYY-MM-DDTHH:mm:ss');
        timerSattningData.In_time = timerSattningData.In_time + 'Z';
        timerSattningData.Out_time = Moment(timerSattningData.Date).set({ hour: form1.finaltime.hour, minute: form1.finaltime.minute, second: form1.finaltime.second }).format('YYYY-MM-DDTHH:mm:ss');
        timerSattningData.Out_time = timerSattningData.Out_time + 'Z';
        this.attendanceService.updateSalesAttendance(timerSattningData, this.attID).subscribe(res => {
          if (res.message === 'Edited Successfully') {
            this.loadAttendanceDatewise();
            this.resUpdateeMessage.success = true;
            this.resUpdateeMessage.error = false;
            this._ref.detectChanges();
            this.deleteEmpModalRef.close('submitted');
          } else {
            this.spinner.active = false;
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = true;
            this._ref.detectChanges();
          }
          setTimeout(() => {
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = false;
            this._ref.detectChanges();
          }, 5000);
        });
      }
    }
  }

  applyColumnFilter() {
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(filterString).forEach((key) => {
        let keyNodeValue = key.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
        if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (typeof keyNodeValue != 'string') {
            itemString = keyNodeValue.toString();
          } else {
            itemString = keyNodeValue;
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }
}

class MyDataSource implements DataSource<any>, OnDestroy {
  private attendanceSubject = new BehaviorSubject<any[]>([]);
  private attendanceDataList: any = [];
  public loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  public paginator: MatPaginator;
  data = new BehaviorSubject<any>([]);
  attendancePageSizeSubject = new BehaviorSubject<number>(50);
  public attendancePageSize$ = this.attendancePageSizeSubject.asObservable();
  attendanceArrLengthSubject = new BehaviorSubject<number>(0);
  public attendanceArrLength$ = this.attendanceArrLengthSubject.asObservable();
  attendancePageIndexSubject = new BehaviorSubject<number>(0);
  public attendancePageIndex$ = this.attendancePageIndexSubject.asObservable();
  private pageIndexRef: number = 0;
  private pageSizeRef: number = 50;
  private arrLengthRef: number = 0;
  filteredAttendancDataList: any = [];
  pageIndexSubRef: any;
  pageSizeSubRef: any;

  constructor(private attendanceService: AttendanceService) {
    this.pageIndexSubRef = this.attendancePageIndex$.subscribe((index) => {
      this.pageIndexRef = index;
    });
    this.pageSizeSubRef = this.attendancePageSize$.subscribe((size) => {
      this.pageSizeRef = size;
    });
  }

  ngOnDestroy() {
    this.pageIndexSubRef.unsubscribe();
    this.pageSizeSubRef.unsubscribe();
  }

  connect(collectionViewer: CollectionViewer): Observable<any[]> {
    return this.attendanceSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.attendanceSubject.complete();
    this.loadingSubject.complete();
  }

  getTime(value) {
    let ts = '';
    if (value) {
      ts = Moment(value).format('HH:mm:ss');
    }
    return ts;
  }

  getStatus(status) {
    switch (status) {
      case 0:
        return 'Närvaro';
      case 1:
        return 'Närvaro sen';
      case 2:
        return 'Sjuk';
      case 3:
        return 'Ogiltig frånvaro';
      case 4:
        return 'Ledighet';
      case 5:
        return 'Utbildning';
      case 6:
        return 'Sjuk Vab';
      case 7:
        return 'Ej Schemalagd';
      case 11:
        return 'Narvaro godkänd sen';
      default:
        return '';
    }
  }

  loadAttendanceDatewise(searchDate) {
    this.loadingSubject.next(true);
    this.attendanceService.getAttendanceDepartmentwiseForLeaderView(searchDate).pipe(
      catchError(() => of([])),
      finalize(() => this.loadingSubject.next(false))).subscribe(res => {
        let completeAttendanceList = [];
        this.attendanceDataList = [];
        this.attendanceSubject.next([]);
        res.forEach((obj) => {
          if (obj.data && obj.data.length > 0) {
            obj.data.forEach((aObj) => {
              let toStoreAtt = aObj;
              toStoreAtt.department_name = obj.department_name;
              toStoreAtt.Status_id = this.getStatus(toStoreAtt.Status);
              toStoreAtt.In_time = this.getTime(toStoreAtt.In_time);
              toStoreAtt.Out_time = this.getTime(toStoreAtt.Out_time);
              toStoreAtt.user_count = obj.data.length;
              completeAttendanceList.push(toStoreAtt);
              this.attendanceDataList.push(toStoreAtt);
            });
          }
          this.filteredAttendancDataList = this.attendanceDataList;
          this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
          this.handleAttendancePaging();
        });
      });
  }

  attendancePageFilter(toFilterArr) {
    let tempObj: any = {};
    let toRetArr = [];
    toFilterArr.forEach((listObj) => {
      if (listObj.department_name != tempObj.department_name) {
        toRetArr.push({ department_name: listObj.department_name + ' (' + listObj.user_count + ')', extend: true });
        tempObj.department_name = listObj.department_name;
      }
      toRetArr.push(listObj);
    });
    return toRetArr;
  }

  attendanceArrPageIterator() {
    let start = this.pageIndexRef * this.pageSizeRef;
    let end = (this.pageIndexRef + 1) * this.pageSizeRef;
    let tempAttendanceArr = this.filteredAttendancDataList.slice(start, end);
    let toRetAttendanceArr = this.attendancePageFilter(tempAttendanceArr);
    this.attendanceSubject.next(toRetAttendanceArr);
  }

  handleAttendancePaging(event?) {
    if (event) {
      this.attendancePageIndexSubject.next(event.pageIndex);
      this.attendancePageSizeSubject.next(event.pageSize);
    } else {
      this.attendancePageIndexSubject.next(0);
      this.attendancePageSizeSubject.next(50);
    }
    this.attendancePageIndex$.subscribe((index) => {
      this.pageIndexRef = index;
    });
    this.attendancePageSize$.subscribe((size) => {
      this.pageSizeRef = size;
    });
    this.attendanceArrPageIterator();
  }

  attendanceFilteredList(filterData) {
    let toRetAttendanceArr: any = this.filterList(filterData);
    this.filteredAttendancDataList = toRetAttendanceArr;
    this.attendanceSubject.next(toRetAttendanceArr);
    this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
    this.attendancePageIndexSubject.next(0);
    this.attendancePageSizeSubject.next(this.pageSizeRef);
    this.handleAttendancePaging({ pageIndex: 0, pageSize: this.pageSizeRef });
  }

  filterList(filterValue) {
    let filteredArr = this.attendanceDataList.filter((item) => {
      let filterString = item.Employee_id + item.first_name + item.last_name + item.project + item.landline + item.mobile + item.In_time + item.Out_time + item.Lunch;
      filterString = filterString.trim().toLowerCase();
      filterValue = filterValue.toLowerCase();
      return filterString.indexOf(filterValue) != -1;
    });
    return filteredArr;
  }
}