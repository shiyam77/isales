import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ApiEndpointConstants } from '../../../../../../core/models/api-endpoint-constants';
import { TokenStorage } from '../../../../../../core/auth/token-storage.service';
import * as _moment from 'moment';


@Injectable()
export class AttendanceService {

  private Dept_Report_Lead_View = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.DEPARTMENT_REPORT_LEADER_VIEW;
  private Dept_Report_Lead_Report = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.DEPARTMENT_REPORT_LEADER_REPORT;
  private Attendance_Datewise_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE;
  private Attendance_Report_Datewise_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_SALES_REPORT;
  private Department_Report_Datewise_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.DEPARTMENT_REPORT;
  private Department_Total_Hour_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.DEPARTMENT_TOTAL_HOURS
  private Project_Statistics_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.PROJECT_STATISTICS_ATTENDANCE;
  private Attendance_Statistics_Report_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_STATISTICS_REPORT;
  private Attendance_Statistics_Total_Report_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_STATISTICS_TOTAL_REPORT;
  private Attendance_Statistics_TotalHours_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_STATISTICS_TOTALHOURS;
  private update_attendance_sales_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE;
  private Attendance_Clientwise_Report_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_SALES_REPORT_CLIENTWISE;
  private Attendance_Clientwise_View_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_SALES_VIEW_CLIENTWISE;
  private Attendance_Departmentwise_Report_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_LEADER_REPORT_DEPARTMENTWISE;
  private Attendance_Departmentwise_View_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_LEADER_VIEW_DEPARTMENTWISE;
  private Attendance_Datewise_Details_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.USER_ATTENDANCE_DETAILS;
  private Lock_Attendance_By_Date_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.LOCK_ATTENDANCE_BY_DATE;
  private Change_Attendance_Status_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.CHANGE_ATTENDANCE_STATUS;
  private Attendance_Overview_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_OVERVIEW;
  private Attendance_Overview_Summary_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_OVERVIEW_SUMMARY;
  private Attendance_Overview_Details_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.ATTENDANCE_OVERVIEW_SUMMARY_DETAILS;
  private Attendance_Checkin_url = ApiEndpointConstants.api_url + ApiEndpointConstants.ROUTES.EMPLOYEE_ATTENDANCE_CHECKIN;

  constructor(private http: HttpClient, private tokenStorage: TokenStorage) { }

  getRoleAndId(): Observable<any> {
    let userData: any = {};
    userData.role = this.tokenStorage.getUserRoles().pipe(role => role);
    userData.userId = this.tokenStorage.getUserId().pipe(id => id);
    return userData;
  }

  getAllAttendanceByDate(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Attendance_Datewise_url}/${date}`).pipe(map((res: any) => res));
  }

  getDepartmentwiseReportForLeaderView(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Dept_Report_Lead_View}/${date}`).pipe(map((res: any) => res));
  }

  getDeptwiseLeaderReport(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Dept_Report_Lead_Report}/${date}`).pipe(map((res: any) => res));
  }

  getAllAttendanceReportByDate(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Attendance_Report_Datewise_url}/${date}`).pipe(map((res: any) => res));
  }

  getDepartmentwiseTotalhours(date: string): Observable<any> {
    return this.http.get(`${this.Department_Total_Hour_url}/${date}`).pipe(map((res: any) => res));
  }

  getStatisticsDepartmentWiseReportByDateRangeTotalHours(date: any): Observable<Array<any>> {
    let dateRangeHeader: any = {
      fromdate: _moment(date.startDate).format('YYYY-MM-DD'),
      todate: _moment(date.endDate).format('YYYY-MM-DD')
    };
    return this.http.get(`${this.Attendance_Statistics_Total_Report_url}`, { headers: dateRangeHeader }).pipe(map((res: any) => res));
  }

  getProjectwiseStatistics(date: string): Observable<any> {
    return this.http.get(`${this.Project_Statistics_url}/${date}`).pipe(map((res: any) => res));
  }

  getAllDepartmentWiseReportByDate(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Department_Report_Datewise_url}/${date}`).pipe(map((res: any) => res));
  }

  addSalesAttendance(attendanceData: any): Observable<any> {
    return this.http.post(`${this.update_attendance_sales_url}`, attendanceData).pipe(map((res: any) => res));
  }

  updateSalesAttendance(attendanceData: any, id: number): Observable<any> {
    return this.http.put(`${this.update_attendance_sales_url}/${id}`, attendanceData).pipe(map((res: any) => res));
  }

  getStatisticsDepartmentWiseReportByDateRange(date: any): Observable<Array<any>> {
    let dateRangeHeader: any = {
      fromdate: _moment(date.startDate).format('YYYY-MM-DD'),
      todate: _moment(date.endDate).format('YYYY-MM-DD')
    };
    return this.http.get(`${this.Attendance_Statistics_Report_url}`, { headers: dateRangeHeader }).pipe(map((res: any) => res));
  }

  getStatisticsDepartmentWiseTotalHoursByDateRange(date: any): Observable<any> {
    let dateRangeHeader: any = {
      fromdate: _moment(date.startDate).format('YYYY-MM-DD'),
      todate: _moment(date.endDate).format('YYYY-MM-DD')
    };
    return this.http.get(`${this.Attendance_Statistics_TotalHours_url}`, { headers: dateRangeHeader }).pipe(map((res: any) => res));
  }

  getAllAttendanceClientwiseReportByDate(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Attendance_Clientwise_Report_url}/${date}`).pipe(map((res: any) => res));
  }

  getAllAttendanceClientwiseViewByDate(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Attendance_Clientwise_View_url}/${date}`).pipe(map((res: any) => res));
  }

  getAttendanceDepartmentwiseForLeaderView(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Attendance_Departmentwise_View_url}/${date}`).pipe(map((res: any) => res));
  }

  getAttendanceDeptwiseForLeaderReport(date: string): Observable<Array<any>> {
    return this.http.get(`${this.Attendance_Departmentwise_Report_url}/${date}`).pipe(map((res: any) => res));
  }

  getAttendanceListForUserByDate(attendanceReq): Observable<any> {
    return this.http.post(this.Attendance_Datewise_Details_url, attendanceReq).pipe(map((res: any) => res));
  }

  lockAttendanceByDate(lockReq): Observable<any> {
    return this.http.post(this.Lock_Attendance_By_Date_url, lockReq).pipe(map((res: any) => res));
  }

  changeAttendanceStatus(attendanceReq): Observable<any> {
    return this.http.post(this.Change_Attendance_Status_url, attendanceReq).pipe(map((res: any) => res));
  }

  getAttendanceOverview(attendanceOverViewReq): Observable<any> {
    return this.http.post(this.Attendance_Overview_url, attendanceOverViewReq).pipe(map((res: any) => res));
  }

  saveAttendanceApprovalStatus(attendanceApprovalDetails): Observable<any> {
    return this.http.post(`${this.Attendance_Datewise_url}/approvalstatus`, attendanceApprovalDetails).pipe(map((res: any) => res));
  }

  overviewSummary(data: any): Observable<any> {
    return this.http.post(`${this.Attendance_Overview_Summary_url}`, data).pipe(map((res: any) => res));
  }

  overviewSummaryDetails(data: any): Observable<any> {
    return this.http.post(`${this.Attendance_Overview_Details_url}`, data).pipe(map((res: any) => res));
  }

  employeeCheckin(data) {
    return this.http.post(`${this.Attendance_Checkin_url}`, data).pipe(map((res: any) => res));
  }
}
