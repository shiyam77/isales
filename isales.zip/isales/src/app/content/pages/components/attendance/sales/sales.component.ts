import { Component, OnInit, ViewChild, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { SelectionModel, DataSource, CollectionViewer } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatTableDataSource, MatSelect } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import * as _moment from 'moment';
import * as Moment from "moment";
import * as Xlsx from 'xlsx';
import { ProjectService } from '../../project/_core/services/project.service';
type AOA = any[][];
import { AttendanceService } from '../_core/services/attendance.service';
import { AttendanceList } from '../_core/models/attendance-list.model';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { catchError, finalize, takeUntil, take } from 'rxjs/operators';
import { of, BehaviorSubject, Observable, Subject, ReplaySubject } from 'rxjs';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Workbook } from 'exceljs/dist/exceljs.min.js';
import * as fs from 'file-saver';

@Component({
    selector: 'm-sales',
    templateUrl: './sales.component.html',
    styleUrls: ['./sales.component.scss']
})

export class SalesComponent implements OnInit, OnDestroy {
    displayedColumns: any = ["project_name",
        "narvaro",
        "narvaro_sen",
        "sjuk",
        "ogiltig_franvaro",
        "ledighet",
        "utbildning",
        "sjuk_vab",
        "ej_schemalagd",
        "narvaro_avvikelse",
        "total_count"];
    datasSource: any = [];
    isLoading = true;
    empArr: Array<any> = [];
    options: any = [];
    attID: any;
    inTime: any;
    OutTime: any;
    Lunch: any;
    history: any = [];
    enteredDate: any = '';
    spinners = false;
    modalTitle: string = 'Lägg till ny tidsrapportering Säljare';
    attendanceProjectList: any = [];
    attendanceEmployeeList: any = [];
    completeAttendanceList: any = [];
    projects: any = [];
    dataSource: any;
    tempDataSource: MyDataSource;
    isExtendedRow = (index, item) => item.extend;
    statusArr: Array<any> = [];
    modalFormGroup: FormGroup;
    dateFormGroup: FormGroup;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    arrToPrint: AOA = [];
    selection = new SelectionModel<AttendanceList>(true, []);
    getuserData: any;
    userData: any = {
        role: '',
        id: null
    };
    loader: boolean = false;
    displayColumnToShow = ['first_name', 'surname'];
    allAttendanceList: AttendanceList[] = [];
    xpandStatus: boolean = false;
    searchInput: string = '';
    deleteEmpModalRef: any;
    closeResult: string;
    leaveHistory: any = [];
    toggleColumns = [
        { arrIndex: 1, column: 'first_name', checked: true, label: 'first_name' },
        { arrIndex: 2, column: 'last_name', checked: true, label: 'last_name' },
        { arrIndex: 3, column: 'mobile', checked: true, label: 'mobile' },
        { arrIndex: 4, column: 'In_time', checked: true, label: 'In_time' },
        { arrIndex: 5, column: 'Out_time', checked: true, label: 'Out_time' },
        { arrIndex: 6, column: 'Lunch', checked: true, label: 'Lunch' },
        { arrIndex: 7, column: 'Total', checked: true, label: 'Total' },
        { arrIndex: 8, column: 'checkin', checked: true, label: 'checkin' },
        { arrIndex: 9, column: 'checkout', checked: true, label: 'checkout' },
        { arrIndex: 10, column: 'totalhours', checked: true, label: 'totalhours' },
        { arrIndex: 11, column: 'attendancestatus', checked: true, label: 'attendancestatus' },
        { arrIndex: 12, column: 'loxyin', checked: false, label: 'loxyin' },
        { arrIndex: 13, column: 'loxyout', checked: false, label: 'loxyout' },
        { arrIndex: 14, column: 'loxytotalhours', checked: false, label: 'loxytotalhours' },
        { arrIndex: 15, column: 'confirmationstatus', checked: false, label: 'confirmationstatus' },
        { arrIndex: 16, column: 'actions', checked: true, label: 'actions' },
    ];
    primaryHeaders = ['personalinfo', 'schedule', 'checkindetails', 'loysoftdetails', 'approvalstatus'];
    itemsPerPage: number = 50;
    itemsInPageList: Array<number> = [50, 100, 500];
    spinner: SpinnerButtonOptions = {
        active: false,
        spinnerSize: 18,
        raised: true,
        buttonColor: 'primary',
        spinnerColor: 'accent',
        fullWidth: false
    };
    resDeleteMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    resCreateMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    resUpdateeMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    nextDateToDisplay: string;
    previousDateToDisplay: string;
    modalInOutError: boolean = false;
    multiColFilter = {
        Employee_id: '',
        first_name: '',
        last_name: '',
        'project.0': '',
        mobile: '',
        landline: '',
        In_time: '',
        Out_time: '',
        Lunch: ''
    };
    attendancePageSize: any;
    attendanceArrLength: any;
    attendancePageIndex: any;
    yearList = [new Date().getFullYear()];
    yearSelected = new Date().getFullYear();
    KlaraxpandStatus: string = '';
    attendanceListRequestData: any = {
        "emp_type": "Säljare",
        "date": new Date(),
        "approved_status": "Ejklara"
    };
    approvalColSpan: any = 1;
    attendanceId: any = null;
    approverName: string = '';
    dateLibVar = _moment;
    tRowErr: boolean = false;
    tRowNoRecord: boolean = false;
    tid: any;
    qty: any;
    permissionHistory: any = [];
    hasEmployeeRequestForPermission: boolean = false;
    sortFilterOptions: any = {};
    inputAttendanceDatePicker: any = {
        isOpen: false
    };
    searchGroup: FormGroup;
    clientsArr: Array<any> = [];
    modalStartTime: any = {};
    modalEndTime: any = {};
    @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
    protected _onClientDestroy = new Subject<void>();
    clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    toggleCheckinBtn: boolean = false;
    pageIndexNumber: number = 0;
    pageChanged: boolean = false;

    constructor(private projectService: ProjectService,
        private _ref: ChangeDetectorRef,
        private personalService: PersonalService,
        private attendanceService: AttendanceService,
        private modalService: NgbModal,
        private _formBuilder: FormBuilder,
        private sharedService: SharedService,
        private router: Router,
        private activeRoute: ActivatedRoute) { }

    ngOnInit() {
        this.KlaraxpandStatus = 'not done';
        this.yearList = [];
        for (let y = 0; (y <= 5); y++) {
            this.yearList.push(2020 + y);
        }
        this.getuserData = this.projectService.getRoleAndId();
        this.getuserData.role.subscribe(role => {
            this.userData.role = role.toString();
        });
        this.getuserData.userId.subscribe(id => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.sharedService.getUserDetails().subscribe((uData: any) => {
            if (uData) {
                this.userData.data = uData;
            }
        });
        let asdada = this.getSearchDate();
        this.dateFormGroup = this._formBuilder.group({
            attendancedate: [this.getSearchDate()],
        });
        this.searchGroup = this._formBuilder.group({
            selectedClient: [[]],
            clientFilterControls: ['']
        });
        this.tempDataSource = new MyDataSource(this.attendanceService);
        this.dataSource = new MatTableDataSource();
        this.datasSource = [];
        this.modalFormGroup = this._formBuilder.group({
            personal: ['', Validators.required],
            employee_id: [''],
            fromdate: ['', Validators.required],
            starttime: [{ hour: 10, minute: 0, second: 0 }],
            finaltime: [{ hour: 19, minute: 0, second: 0 }],
            lunchtime: [{ hour: 1, minute: 0, second: 0 }],
            statusid: ['', Validators.required],
            project: [''],
            notes: [''],
            godkand: [''],
        });
        this.statusArr = [];
        if (this.userData.role === 'superadmin') {
            this.statusArr.push(
                { id: 0, name: 'Närvaro' },
                { id: 1, name: 'Närvaro sen' },
                { id: 11, name: 'Närvaro godkänd sen' },
                { id: 2, name: 'Sjuk' },
                { id: 3, name: 'Ogiltig frånvaro' },
                { id: 4, name: 'Ledighet' },
                { id: 5, name: 'Utbildning' },
                { id: 6, name: 'Sjuk Vab' },
                { id: 7, name: 'Ej Schemalagd' },
                { id: 9, name: 'Ledighet - påverkar timmarna'},
                { id: 10, name: 'Ledighet - påverkar inte timmarna'},
            );
        } else {
            this.statusArr.push(
                { id: 2, name: 'Sjuk' },
                { id: 3, name: 'Ogiltig frånvaro' },
                { id: 4, name: 'Ledighet' },
                { id: 6, name: 'Sjuk Vab' },
                { id: 7, name: 'Ej Schemalagd' },
                { id: 9, name: 'Ledighet - påverkar timmarna'},
                { id: 10, name: 'Ledighet - påverkar inte timmarna'}
            );
        }
        this.getEmployeeClientSelectionList();
        this.searchGroup.controls['clientFilterControls'].valueChanges
            .pipe(takeUntil(this._onClientDestroy)).subscribe(() => this._ClientFilter());

        this.loadEmployee();
        this.activeRoute.queryParams.subscribe((params) => {
            this.yearSelected = this.converToInteger(params['sa']) ? this.converToInteger(params.sa) : (new Date().getFullYear());
            this.KlaraxpandStatus = params['kes'] == '3' ? 'checkin problem' : ((params['kes'] == '2') ? 'done' : 'not done');
            this.pageIndexNumber = params['pin'] ? params['pin'] : 0;
            this.itemsPerPage = params['ipp'] ? params['ipp'] : this.itemsPerPage;
            this.pageChanged = params['pac'] == 'false' ? false : true;
            this.searchInput = params['si'];
            this.sortFilterOptions = {
                active: params['ac'],
                toggleSort: params['ts'] == 'true' ? true : false
            }
            this.showHideCols();
            this.setExcelHeaders();
            if ((!params['fic'] || params['fic'] == 'false') || (this.dataSource.data.length == 0)) {
                this.loadAttendanceDatewise(false, this.searchInput);
                this.getOverviewSummary();
            } else {
                this.tempDataSource.attendanceFilteredList(this.searchInput, { pageIndex: this.pageIndexNumber, pageSize: this.itemsPerPage });
            }
        });
    }

    ngOnDestroy() {
        this._onClientDestroy.next();
        this._onClientDestroy.complete();
    }

    addSalesAttendance(att) {
        this.spinner.active = true;
        let form1 = att;
        let attId = att.ID;
        let timerSattningData = {
            Employee_id: form1.Employee_id,
            "Date": Moment(this.dateFormGroup.controls['attendancedate'].value).format('YYYY-MM-DD'),
            "In_time": form1.In_time,
            "Out_time": form1.Out_time,
            "Lunch": form1.Lunch,
            "Status": 0,
            "Note": ""
        }
        this.attendanceService.updateSalesAttendance(timerSattningData, attId).subscribe(res => {
            if (res.message === 'Edited Successfully') {
                this.loadAttendanceDatewise();
                this.resUpdateeMessage.success = true;
                this.resUpdateeMessage.error = false;
                this._ref.detectChanges();
            } else {
                this.spinner.active = false;
                this.resUpdateeMessage.success = false;
                this.resUpdateeMessage.error = true;
                this._ref.detectChanges();
            }
            setTimeout(() => {
                this.resUpdateeMessage.success = false;
                this.resUpdateeMessage.error = false;
                this._ref.detectChanges();
            }, 10000);
        });
    }

    loadEmployee() {
        this.sharedService.getAllEmployees().subscribe(res => {
            res.forEach((obj) => {
                if (obj.role == 'sales') {
                    this.empArr.push({
                        id: obj.Employee_id,
                        name: obj.first_name + "" + obj.last_name
                    });
                }
            })
        });
    }

    displayFn(user?: any): string | undefined {
        return user ? user.name : '';
    }

    onAddProductsFromClick(event) {
        if (event.option.value) {
            this.projectService.getEmployee(event.option.value.id).subscribe(res => {
                if (res) {
                    this.modalFormGroup.patchValue({
                        employee_id: event.option.value.id
                    });
                    this.projects = [];
                    if (res.Projects && res.Projects.length) {
                        this.projects.push(res.Projects[res.Projects.length - 1].Project_name);
                    }
                }
            });
        }
    }

    getSearchDate() {
        var d = new Date(),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return [year, month, day].join('-');
    }

    getTime(value) {
        let ts = Moment(value).format('HH:mm:ss');
        return ts;
    }

    attendanceDateChange(value: any, action) {
        if (action == 'previous') {
            this.previousDay(value);
        } else if (action == 'next') {
            this.nextDay();
        } else {
            this.setPageParams(!!this.searchInput);
        }
    }

    setNextAndPreviousDay() {
        let currentdate = new Date(this.dateFormGroup.value.attendancedate);
        let nextDate = new Date(currentdate.getTime() + (1000 * 60 * 60 * 24));
        this.nextDateToDisplay = Moment(nextDate).format('YYYY-MM-DD');
        let previousDate = new Date(currentdate.getTime() - (1000 * 60 * 60 * 24));
        this.previousDateToDisplay = Moment(previousDate).format('YYYY-MM-DD');
    }

    loadAttendanceDatewise(filterChange?: boolean, filterValue?: any) {
        let searchDate = Moment(this.dateFormGroup.controls.attendancedate.value).format('YYYY-MM-DD');
        this.setNextAndPreviousDay();
        this.isLoading = true;
        this.selection.clear();
        this.attendanceProjectList = [];
        this.attendanceEmployeeList = [];
        this.completeAttendanceList = [];
        let resultarr = [];
        this.loadProjectwiseTotal();
        this.showHideCols();
        let toApproveStatus = 'Ejklara';
        this.primaryHeaders = ['personalinfo', 'schedule', 'checkindetails', 'loysoftdetails', 'approvalstatus'];
        this.approvalColSpan = 2;
        if (this.KlaraxpandStatus == 'done') {
            toApproveStatus = 'Klara';
            this.primaryHeaders = ['personalinfo', 'schedule', 'checkindetails', 'loysoftdetails', 'approvalstatus'];
            this.approvalColSpan = 2;
        } else if (this.KlaraxpandStatus == 'checkin problem') {
            toApproveStatus = 'E-checkin problem';
            this.primaryHeaders = ['personalinfo', 'schedule', 'checkindetails', 'loysoftdetails', 'approvalstatus'];
            this.approvalColSpan = 2;
        }
        let attendancReqForSales: any = {
            emp_type: "Säljare",
            date: searchDate,
            approved_status: toApproveStatus
        };
        if (this.sortFilterOptions.toggleSort) {
            attendancReqForSales.echeck = this.sortFilterOptions.active;
        }
        this.tempDataSource.loadAttendanceDatewise(attendancReqForSales, { pageIndex: this.pageIndexNumber, pageSize: this.itemsPerPage }, filterChange, filterValue);
        this.selection.clear();
    }

    applyFilter(filterValue: string) {
        this.tempDataSource.attendanceFilteredList(filterValue, { pageIndex: this.pageIndexNumber, pageSize: this.itemsPerPage });
    }

    private setExcelHeaders() {
        this.arrToPrint[0] = [];
        this.toggleColumns.forEach((obj) => {
            this.arrToPrint[0].push(obj.column);
        });
    }

    private setExcelValues() {
        this.allAttendanceList.forEach((val) => {
            let newLine = [];
            this.toggleColumns.forEach((obj) => {
                if (obj.arrIndex !== 11) {
                    if (obj.arrIndex === 18
                        || obj.arrIndex === 20 || obj.arrIndex === 21
                        || obj.arrIndex === 22 || obj.arrIndex === 23) {
                        if (obj.arrIndex === 18) {
                            newLine.push('True');
                        } else {
                            newLine.push('False');
                        }
                    } else {
                        let str = obj.label.split('.').reduce((o, i) => o[i], val);
                        newLine.push(str);
                    }
                }
            });
            this.arrToPrint.push(newLine);
        });
    }

    expandSearch(e, searchText) {
        if (e.type == "blur") {
            if (e.target.value) {
                (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
            } else {
                (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
            }
            
            
        } else if (e.type == "click") {
            if (!searchText) {
                (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
            }
        }
        
    }

    showHideCols() {
        this.displayColumnToShow = [];
        this.toggleColumns.forEach((obj, ind) => {
            obj.checked = true;
            if (obj.checked) {
                this.displayColumnToShow.push(obj.label);
            }
        });
    }

    generateAndDownloadDoc() {
        if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
            /* generate worksheet */
            const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
            /* generate workbook and add the worksheet */
            const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
            Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
            /* save to file */
            Xlsx.writeFile(wb, 'Employee_List_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
        }
    }

    nextDay() {
        let date = new Date(this.dateFormGroup.value.attendancedate);
        let nextDate = new Date(date.getTime() + (1000 * 60 * 60 * 24));
        this.dateFormGroup.controls['attendancedate'].setValue(Moment(nextDate).format('YYYY-MM-DD'));
        if(this.searchInput){
            this.setPageParams(!this.searchInput);
        }else{
            this.setPageParams(!!this.searchInput);
        }
    }

    previousDay(someVal?: any) {
        this.enteredDate = someVal
        let date = new Date(this.dateFormGroup.value.attendancedate);
        let previousDate = new Date(date.getTime() - (1000 * 60 * 60 * 24));
        this.dateFormGroup.controls['attendancedate'].setValue(Moment(previousDate).format('YYYY-MM-DD'));
        if(this.searchInput){
            this.setPageParams(!this.searchInput);
        }else{
            this.setPageParams(!!this.searchInput);
        }
        
    }

    openModal(content, contentAccessId, totimersattning?, selectedDate?) {
        this.projects = [];
        this.approverName = '';
        this.statusArr = [];
        if (content === 'create') {
            this.modalTitle = 'Lägg till ny tidsrapportering Säljare';
            this.modalFormGroup.reset();
            if (totimersattning) {
                this.modalFormGroup.patchValue({
                    personal: totimersattning.first_name,
                    fromdate: _moment(this.dateFormGroup.controls['attendancedate'].value).toISOString(),
                    start: totimersattning.In_time,
                    final: totimersattning.Out_time,
                    statusid: totimersattning.Status,
                    lunch: totimersattning.Lunch,
                    notes: totimersattning.notes
                });
            }
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content === 'update') {
            this.modalInOutError = false;
            this.modalFormGroup.enable();
            if (this.userData.role === 'superadmin') {
                this.statusArr.push(
                    { id: 0, name: 'Närvaro' },
                    { id: 1, name: 'Närvaro sen' },
                    { id: 11, name: 'Närvaro godkänd sen' },
                    { id: 2, name: 'Sjuk' },
                    { id: 3, name: 'Ogiltig frånvaro' },
                    { id: 4, name: 'Ledighet' },
                    { id: 5, name: 'Utbildning' },
                    { id: 6, name: 'Sjuk Vab' },
                    { id: 7, name: 'Ej Schemalagd' },
                    { id: 9, name: 'Ledighet - påverkar timmarna'},
                    { id: 10, name: 'Ledighet - påverkar inte timmarna'}
                );
            } else {
                this.statusArr.push(
                    { id: 2, name: 'Sjuk' },
                    { id: 3, name: 'Ogiltig frånvaro' },
                    { id: 4, name: 'Ledighet' },
                    { id: 6, name: 'Sjuk Vab' },
                    { id: 7, name: 'Ej Schemalagd' },
                    { id: 9, name: 'Ledighet - påverkar timmarna'},
                    { id: 10, name: 'Ledighet - påverkar inte timmarna'}
                );
            }
            this.projectService.getEmployee(totimersattning.employee_id).subscribe(res => {
                if (res) {
                    if (res.EmployeeClients && res.EmployeeClients.length) {
                        this.projects.push(res.EmployeeClients[res.EmployeeClients.length - 1].Client_name);
                    }
                }
            });
            this.modalTitle = 'Ändra tidsrapportering säljare';
            this.attID = totimersattning.ID;
            this.inTime = totimersattning.In_time;
            this.OutTime = totimersattning.Out_time;
            this.Lunch = totimersattning.department_lunch;
            this.modalFormGroup.patchValue({
                personal: { id: totimersattning.employee_id, name: totimersattning.first_name + '  ' + totimersattning.last_name },
                employee_id: totimersattning.employee_id,
                fromdate: _moment(this.dateFormGroup.controls['attendancedate'].value).toISOString(),
                starttime: { hour: this.getHour(totimersattning.In_time), minute: this.getMinute(totimersattning.In_time), second: this.getSeconds(totimersattning.In_time) },
                lunchtime: { hour: this.getHour(totimersattning.department_lunch), minute: this.getMinute(totimersattning.department_lunch), second: 0 },
                finaltime: { hour: this.getHour(totimersattning.Out_time), minute: this.getMinute(totimersattning.Out_time), second: this.getSeconds(totimersattning.Out_time) },
                statusid: totimersattning.attendance_status_id,
                project: totimersattning.project_id,
                notes: totimersattning.notes,
                godkand: totimersattning.godkand,
            });
            this.modalStartTime = this.modalFormGroup.value.starttime;
            this.modalEndTime = this.modalFormGroup.value.finaltime;
            this.modalFormGroup.disable();
            this.modalFormGroup.controls['statusid'].enable();
            this.modalFormGroup.controls['notes'].enable();
            this.modalFormGroup.controls['starttime'].enable();
            this.modalFormGroup.controls['finaltime'].enable();
            this.modalFormGroup.controls['godkand'].enable();
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content === 'delete') {
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'delete-timersattning-modal', backdrop: "static" });
        } else if (content == 'lock') {
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'unlock') {
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'notes') {
            this.modalFormGroup.patchValue({
                notes: totimersattning.notes
            });
            this.attendanceId = totimersattning.attendance_id;
            this.approverName = this.userData.data.FullName;
            this.modalFormGroup.enable();
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'history') {
            this.history = totimersattning.attendance_history;
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'history', backdrop: "static" });
        } else if (content == 'approval_notes') {
            this.modalFormGroup.patchValue({
                notes: totimersattning.notes
            });
            this.attendanceId = totimersattning.attendance_id;
            // this.approverName = totimersattning.approver_name ? totimersattning.approver_name : this.userData.data.FullName;
            this.approverName = totimersattning.approver_name ? totimersattning.approver_name : '' ;
            this.modalFormGroup.disable();
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'leave') {
            this.leaveHistory = [];
            this.leaveHistory = (totimersattning.leave_details.length > 0) ? totimersattning.leave_details : [];
            this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'leave', size: 'lg', backdrop: "static" });
        }

        this.deleteEmpModalRef.result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }

    createTimerSattning() {
        if (this.modalTitle == 'Ändra tidsrapportering säljare') {
            if (this.modalFormGroup.valid && this.checkInOutInterval()) {
                if (this.modalFormGroup.valid) {
                    this.spinner.active = true;
                    let form1: any = this.modalFormGroup.controls;
                    if (!form1.notes.value) {
                        form1.notes.value = "";
                    }
                    let toSendAttendanceData: any = {
                        "date": Moment(form1.fromdate.value).format('YYYY-MM-DD'),
                        "approver_id": this.userData.id,
                        "employee_id": form1.personal.value.id,
                        "status": form1.statusid.value,
                        'approved_status': form1.godkand.value ? 1 : 0,
                        'notes': form1.notes.value
                    };
                    let toSetStartTime = Moment().set({ hour: form1.starttime.value.hour, minute: form1.starttime.value.minute, second: form1.starttime.value.second ? form1.starttime.value.second : 0 }).format('HH:mm:ss');
                    if (!((this.modalStartTime.hour == form1.starttime.value.hour) && (this.modalStartTime.minute == form1.starttime.value.minute) && (this.modalStartTime.second == form1.starttime.value.second))) {
                        toSetStartTime = Moment().set({ hour: form1.starttime.value.hour, minute: form1.starttime.value.minute, second: 0 }).format('HH:mm:ss');
                    }
                    let statusList = [2, 3, 4, 6, 7];
                    if (!statusList.includes(form1.statusid.value) && (toSetStartTime != '00:00:00')) {
                        toSendAttendanceData.start_time = toSetStartTime;
                    }
                    if (form1.finaltime.value) {
                        let toSetEndTime = Moment().set({ hour: form1.finaltime.value.hour, minute: form1.finaltime.value.minute, second: form1.finaltime.value.second ? form1.finaltime.value.second : 0 }).format('HH:mm:ss');
                        if (!((this.modalEndTime.hour == form1.finaltime.value.hour) && (this.modalEndTime.minute == form1.finaltime.value.minute) && (this.modalEndTime.second == form1.finaltime.value.second))) {
                            toSetEndTime = Moment().set({ hour: form1.finaltime.value.hour, minute: form1.finaltime.value.minute, second: 0 }).format('HH:mm:ss');
                        }
                        if (!(statusList.includes(form1.statusid.value)) && (toSetEndTime != '00:00:00')) {
                            toSendAttendanceData.end_time = toSetEndTime;
                        }
                    }
                    this.attendanceService.changeAttendanceStatus(toSendAttendanceData).subscribe((res: any) => {
                        if (res) {
                            this.loadAttendanceDatewise(!!this.searchInput, this.searchInput);
                            this.resUpdateeMessage.success = true;
                            this.resUpdateeMessage.error = false;
                            this._ref.detectChanges();
                            this.deleteEmpModalRef.close('submitted');
                            this.spinner.active = false;
                        } else {
                            this.spinner.active = false;
                            this.resUpdateeMessage.success = false;
                            this.resUpdateeMessage.error = true;
                            this._ref.detectChanges();
                        }
                        setTimeout(() => {
                            this.resUpdateeMessage.success = false;
                            this.resUpdateeMessage.error = false;
                            this._ref.detectChanges();
                        }, 10000);
                    });
                }
            }
        } else {
            if (this.modalFormGroup.valid && this.checkInOutInterval()) {
                this.spinner.active = true;
                let form1 = this.modalFormGroup.value;

                if (!form1.notes) {
                    form1.notes = "";
                }
                let timerSattningData: any = {
                    Employee_id: form1.employee_id,
                    "Date": Moment(form1.fromdate).format('YYYY-MM-DD'),
                    "In_time": form1.starttime.hour + ':' + form1.starttime.minute + ':' + form1.starttime.second,
                    "Out_time": form1.lunchtime.hour + ':' + form1.finaltime.minute + ':' + form1.finaltime.second,
                    "Lunch": Moment().set({ hours: form1.lunchtime.hour, minute: form1.lunchtime.minute, second: form1.lunchtime.second }).format('HH:mm:ss'),
                    "Status": form1.statusid,
                    "Note": form1.notes
                };
                timerSattningData.In_time = Moment(timerSattningData.Date).set({ hour: form1.starttime.hour, minute: form1.starttime.minute, second: form1.starttime.second }).format('YYYY-MM-DDTHH:mm:ss');
                timerSattningData.In_time = timerSattningData.In_time + 'Z';
                timerSattningData.Out_time = Moment(timerSattningData.Date).set({ hour: form1.finaltime.hour, minute: form1.finaltime.minute, second: form1.finaltime.second }).format('YYYY-MM-DDTHH:mm:ss');
                timerSattningData.Out_time = timerSattningData.Out_time + 'Z';
                this.attendanceService.addSalesAttendance(timerSattningData).subscribe(res => {
                    if (res.message === 'Added Successfully') {
                        this.loadAttendanceDatewise(!!this.searchInput, this.searchInput);
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                        this.deleteEmpModalRef.close('submitted');
                    } else {
                        this.spinner.active = false;
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                        this._ref.detectChanges();
                    }
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 10000);
                }, err => {
                });
            }
        }
    }

    getHour(time) {
        if (time && time.includes("T") && time.substring(time.indexOf("T") + 1) != '00:00:00') {
            return Moment(time.substring(time.indexOf("T") + 1), 'HH:mm:ss').hour();
        } else {
            if (time != '00:00:00' && time != '0:0:0' && time != '00:00' && time != '0:0') {
                return Moment(time, 'HH:mm:ss').hour();
            } else {
                return '';
            }
        }
    }

    getMinute(time) {
        if (time && time.includes("T") && time.substring(time.indexOf("T") + 1) != '00:00:00') {
            return Moment(time.substring(time.indexOf("T") + 1), 'HH:mm:ss').minute();
        } else {
            if (time != '00:00:00' && time != '0:0:0' && time != '00:00' && time != '0:0') {
                return Moment(time, 'HH:mm:ss').minute();
            } else {
                return '';
            }
        }
    }

    getSeconds(time) {
        if (time && time.includes("T") && time.substring(time.indexOf("T") + 1) != '00:00:00') {
            return Moment(time.substring(time.indexOf("T") + 1), 'HH:mm:ss').second();
        } else {
            if (time != '00:00:00' && time != '0:0:0' && time != '00:00' && time != '0:0') {
                return Moment(time, 'HH:mm:ss').second();
            } else {
                return '';
            }
        }
    }

    checkInOutInterval() {
        let formData: any = this.modalFormGroup.controls;
        let toSendFormData: any = {};
        if ((formData.starttime.value.hour >= 0) && (formData.starttime.value.minute >= 0) && (formData.finaltime.value && !((formData.finaltime.value.hour == 0) && (formData.finaltime.value.minute == 0)))) {
            if (formData.fromdate.value) {
                toSendFormData.In_time = Moment(formData.fromdate.value).set({ hour: formData.starttime.value.hour, minute: formData.starttime.value.minute }).valueOf();
                toSendFormData.Out_time = Moment(formData.fromdate.value).set({ hour: formData.finaltime.value.hour, minute: formData.finaltime.value.minute }).valueOf();
            } else {
                toSendFormData.In_time = Moment().set({ hour: formData.starttime.value.hour, minute: formData.starttime.value.minute }).valueOf();
                toSendFormData.Out_time = Moment().set({ hour: formData.finaltime.value.hour, minute: formData.finaltime.value.minute }).valueOf();
            }
            let statusList = [2, 3, 4, 6, 7, 9, 10];
            if ((formData.starttime.value.hour == 0) && (formData.starttime.value.minute == 0) && !statusList.includes(formData.statusid.value)) {
                this.modalInOutError = true;
                return false;
            }
            if (((toSendFormData.Out_time > toSendFormData.In_time) && (!statusList.includes(formData.statusid.value))) ||
                ((toSendFormData.Out_time >= toSendFormData.In_time) && (statusList.includes(formData.statusid.value)))) {
                this.modalInOutError = false;
                return true;
            } else {
                this.modalInOutError = true;
                return false;
            }
        } else {
            let statusList = [2, 3, 4, 6, 7, 9, 10];
            if ((formData.starttime.value.hour == 0) && (formData.starttime.value.minute == 0) && !statusList.includes(formData.statusid.value)) {
                this.modalInOutError = true;
                return false;
            } else {
                this.modalInOutError = false;
                return true;
            }
        }
    }

    applyColumnFilter() {
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.filter = JSON.stringify(this.multiColFilter);
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    }

    private columnwiseFilter() {
        let filterPred = (item, filter) => {
            let filterString = JSON.parse(filter);
            let isRowSet: boolean = true;
            Object.keys(filterString).forEach((key) => {
                let keyNodeValue = key.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
                if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
                    let itemString = '';
                    if (typeof keyNodeValue != 'string') {
                        itemString = keyNodeValue.toString();
                    } else {
                        itemString = keyNodeValue;
                    }
                    if (key === 'In_time' || key === 'Out_time') {
                        itemString = this.getTime(itemString);
                    }
                    if (filterString[key]) {
                        isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
                    } else {
                        isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
                    }
                }

            });
            return isRowSet;
        }
        return filterPred;
    }

    getAttendanceByYear() {
        let selectedDateData = this.dateFormGroup.value.attendancedate ? new Date(this.dateFormGroup.value.attendancedate) : new Date();
        let toSetAttendanceDate: any = selectedDateData.getDate() + '-' + (selectedDateData.getMonth() + 1) + '-';
        this.dateFormGroup.patchValue({
            attendancedate: toSetAttendanceDate + this.yearSelected
        });
        this.setPageParams(!!this.searchInput);
    }

    getAttendanceData(selectedTab?: any) {
        this.KlaraxpandStatus = selectedTab;
        this.setPageParams(!this.searchInput);
        this.getOverviewSummary();
        this.loadAttendanceDatewise();
    }

    lockSelectedDate() {
        this.spinner.active = true;
        let selectedDate = Moment(this.dateFormGroup.controls.attendancedate.value).format('YYYY-MM-DD');
        let toLockDayData: any = {
            date: selectedDate,
            approver_id: this.userData.id,
            lock_status: 1
        };
        this.attendanceService.lockAttendanceByDate(toLockDayData).subscribe((lockRes) => {
            if (lockRes) {
                this.tempDataSource.setAllowLock(false);
                this.spinner.active = false;
                this.deleteEmpModalRef.close('submitted');
                this.loadAttendanceDatewise(!!this.searchInput, this.searchInput);
            } else {
                this.spinner.active = false;
            }
        });
    }

    unlockSelectedDate() {
        this.spinner.active = true;
        let selectedDate = Moment(this.dateFormGroup.controls.attendancedate.value).format('YYYY-MM-DD');
        let toLockDayData: any = {
            date: selectedDate,
            approver_id: this.userData.id,
            lock_status: 0
        };
        this.attendanceService.lockAttendanceByDate(toLockDayData).subscribe((lockRes) => {
            if (lockRes) {
                this.tempDataSource.setAllowLock(true);
                this.spinner.active = false;
                this.deleteEmpModalRef.close('submitted');
                this.loadAttendanceDatewise(!!this.searchInput, this.searchInput);
            } else {
                this.spinner.active = false;
            }
        });
    }

    saveApprovalNotes() {
        this.spinner.active = true;
        let datas = { "approver_id": this.userData.id, "approval_status": 1, attendance_id: this.attendanceId, 'notes': this.modalFormGroup.controls['notes'].value };
        this.attendanceService.saveAttendanceApprovalStatus(datas).subscribe((res: any) => {
            this.spinner.active = false;
            if (res[0].data) {
                this.resUpdateeMessage.success = true;
                this.resUpdateeMessage.error = false;
                this._ref.detectChanges();
                this.deleteEmpModalRef.close('submitted');
                this.loadAttendanceDatewise(!!this.searchInput, this.searchInput);
            } else {
                this.spinner.active = false;
                this.resUpdateeMessage.success = false;
                this.resUpdateeMessage.error = true;
                this._ref.detectChanges();
            }
            setTimeout(() => {
                this.resUpdateeMessage.success = false;
                this.resUpdateeMessage.error = false;
                this._ref.detectChanges();
            }, 10000);
        }, err => {
            this.spinner.active = false;
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = true;
            this._ref.detectChanges();
        });
    }

    loadProjectwiseTotal() {
        this.tid = {};
        this.qty = {};
        let searchDate = Moment(this.dateFormGroup.controls.attendancedate.value).format('YYYY-MM-DD');
        this.attendanceService.getProjectwiseStatistics(searchDate).subscribe(res => {
            if (res) {
                this.qty.presenceQty = 0;
                this.qty.presenceLateQty = 0;
                this.qty.sickQty = 0;
                this.qty.invalidAbsenceQty = 0;
                this.qty.approvedAbsenceQty = 0;
                this.qty.presenceEduQty = 0;
                this.qty.sickVabQty = 0;
                this.qty.totalQty = 0;

                this.tid.presenceHours = 0;
                this.tid.presenceLateHours = 0;
                this.tid.sickHours = 0;
                this.tid.invalidAbsenceHours = 0;
                this.tid.approvedAbsenceHours = 0;
                this.tid.presenceEduHours = 0;
                this.tid.sickVabHours = 0;
                this.tid.totaltime = 0;

                if (res.Grandtotal) {
                    this.tid.totaltime = this.getTotalTime(res.Grandtotal);
                    this.qty.totalQty = res.TotalMandays;
                }
                res.StatuswiseReport.forEach((obj) => {
                    switch (obj.Status) {
                        case 0: {
                            this.qty.presenceQty = obj.Mandays;
                            this.tid.presenceHours = this.getTotalTime(obj.Hours);
                        };
                            break;
                        case 1: {
                            this.qty.presenceLateQty = obj.Mandays;
                            this.tid.presenceLateHours = this.getTotalTime(obj.Hours);
                        };
                            break;
                        case 2: {
                            this.qty.sickQty = obj.Mandays;
                            this.tid.sickHours = this.getTotalTime(obj.Hours);
                        };
                            break;
                        case 3: {
                            this.qty.invalidAbsenceQty = obj.Mandays;
                            this.tid.invalidAbsenceHours = this.getTotalTime(obj.Hours);
                        };
                            break;
                        case 4: {
                            this.qty.approvedAbsenceQty = obj.Mandays;
                            this.tid.approvedAbsenceHours = this.getTotalTime(obj.Hours);
                        };
                            break;
                        case 5: {
                            this.qty.presenceEduQty = obj.Mandays;
                            this.tid.presenceEduHours = this.getTotalTime(obj.Hours);
                        };
                            break;
                        case 6: {
                            this.qty.sickVabQty = obj.Mandays;
                            this.tid.sickVabHours = this.getTotalTime(obj.Hours);
                        };
                            break;
                        default: {
                        };
                            break;
                    }
                });
            }
            this._ref.detectChanges();
        }, err => {
            this.tid = {};
            this.qty = {};
            this._ref.detectChanges();
        });
    }

    getTotalTime(time) {
        if (time) {
            let tims = time.split(':');
            return tims[0] + ':' + tims[1];
        } else {
            return '';
        }
    }
    getOverviewSummary() {
        this.isLoading = true;
        this.selection.clear();
        let resultarr = [];
        let toApproveStatus = 'Ejklara';
        if (this.KlaraxpandStatus == 'done') {
            toApproveStatus = 'Klara';
        } else if (this.KlaraxpandStatus == 'checkin problem') {
            toApproveStatus = 'E-checkin problem';
        }
        let overviewData = {
            emp_type: "Säljare",
            "date": Moment(this.dateFormGroup.controls['attendancedate'].value).format('YYYY-MM-DD'),
            "approved_status": toApproveStatus
        };

        this.attendanceService.overviewSummaryDetails(overviewData).subscribe(res => {
            res.forEach((obj) => {
                let datasourceObj: any = {};
                if (obj.data && obj.data.length > 0) {
                    obj.data.forEach((projObj) => {

                        resultarr.push(projObj);
                    });
                }
                if (obj.total_summary && obj.total_summary.length > 0) {
                    obj.total_summary[0].project_name = 'Total';
                    resultarr.push(obj.total_summary[0]);
                }
            });
            this.datasSource = resultarr;
            this.dataSource = new MatTableDataSource(resultarr);
            this._ref.detectChanges();
            this.loader = false;
        }, err => {
            this.dataSource = [];
            this.loader = false;
            this._ref.detectChanges();
        });
    }

    getSortFilterValues(sortOptions) {
        if (sortOptions && (sortOptions.active == 'checkin' || sortOptions.active == 'checkout')) {
            const isAsc = (sortOptions.direction === 'asc') ? true : false;
            this.sortFilterOptions = {
                active: sortOptions.active,
                toggleSort: isAsc
            };
            this.setPageParams(!!this.searchInput);
        }
    }

    showAttendanceDatePicker(evt?: any) {
        this.inputAttendanceDatePicker.isOpen = true;
    }

    hideAttendanceDatePicker(evt?: any) {
        if (!evt.relatedTarget) {
            this.inputAttendanceDatePicker.isOpen = false;
        }
    }

    protected _ClientFilter(): any[] {
        if (this.clientsArr.length <= 0) {
            return;
        }
        if (this.searchGroup && this.searchGroup.controls['clientFilterControls'].value && (typeof this.searchGroup.controls['clientFilterControls'].value == 'string') && this.searchGroup.controls['clientFilterControls'].value.trim() != '') {
            const clientValue = this.searchGroup.controls['clientFilterControls'].value.toLowerCase();
            this.clientFilteredOptions.next(
                this.clientsArr.filter(client => (client.name.toLowerCase().indexOf(clientValue) > -1))
            );
        } else {
            this.clientFilteredOptions.next(this.clientsArr.slice());
            return;
        }
    }

    toggleClientSelectAll(selectAllValue: boolean) {
        let toSetArr = [];
        this.clientFilteredOptions.pipe(take(1), takeUntil(this._onClientDestroy))
            .subscribe((val: any) => {
                if (selectAllValue) {
                    val.forEach((valObj: any) => {
                        toSetArr.push(valObj._id);
                    });
                    this.searchGroup.controls['selectedClient'].patchValue(toSetArr);
                } else {
                    this.searchGroup.controls['selectedClient'].patchValue([]);
                }
            });
    }

    getEmployeeClientSelectionList() {
        this.personalService.employeeClientList().subscribe((clientNewArr: any) => {
            if (clientNewArr && clientNewArr.length > 0) {
                this.clientsArr = clientNewArr;
                this.clientFilteredOptions.next(this.clientsArr.slice());
            }
        });
    }

    employeeCheckin(attendanceData) {
        let selectedDate = this.dateFormGroup.value;
        let toSendCheckInData: any = {
            date: selectedDate.attendancedate,
            employee_id: attendanceData.employee_id,
            approver_id: this.userData.id
        };
        this.toggleCheckinBtn = true;
        this.attendanceService.employeeCheckin(toSendCheckInData).subscribe((checkinRes) => {
            if (checkinRes) {
                this.loadAttendanceDatewise(!!this.searchInput, this.searchInput);
                this.resUpdateeMessage.success = true;
                this.resUpdateeMessage.error = false;
                this._ref.detectChanges();
            }
            this.toggleCheckinBtn = false;
        }, (err: any) => {
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = true;
            this._ref.detectChanges();
            this.toggleCheckinBtn = false;
        });
    }

    converToNumber(val) {
        if (typeof val != 'number') {
            return parseFloat(val);
        } else {
            return val;
        }
    }

    converToInteger(val) {
        if (typeof val != 'number') {
            return parseInt(val);
        } else {
            return null;
        }
    }

    setPageParams(filterChanged: boolean, pageEvent?: any) {
        if (pageEvent) {
            this.pageIndexNumber = pageEvent.pageIndex;
            this.itemsPerPage = pageEvent.pageSize;
            this.pageChanged = true;
        } else {
            this.pageChanged = false;
        }
        let toSetQueryParams: any = {
            kes: this.KlaraxpandStatus == 'checkin problem' ? 3 : ((this.KlaraxpandStatus == 'done') ? 2 : 1),
            pin: this.pageIndexNumber,
            ipp: this.itemsPerPage,
            fic: filterChanged,
            pac: this.pageChanged,
            ad: this.dateFormGroup.controls.attendancedate.value ? this.dateFormGroup.controls.attendancedate.value : '',
            si: this.searchInput,
            ac: this.sortFilterOptions.active,
            ts: this.sortFilterOptions.toggleSort
        };
        this.router.navigate([],
            {
                queryParams: toSetQueryParams,
            });
    }

    generateAndDownloadDoc2() {

        let workbook = new Workbook();
        let worksheet = workbook.addWorksheet('Säljare_Report' + _moment.now());  // Add Xlsx File Name

        let headerarr = [];
        this.primaryHeaders.forEach((obj) => {
            let value = "";
            if (obj == 'personalinfo') {
                value = "Personal Info".toUpperCase();
                headerarr.push(value);
                headerarr.push("");
                headerarr.push("");
            }
            else if (obj == 'schedule') {
                value = "SCHEMALAGD".toUpperCase();
                headerarr.push(value);
                headerarr.push("");
                headerarr.push("");
                headerarr.push("");
            }
            else if (obj == 'checkindetails') {
                value = "E-check".toUpperCase();
                headerarr.push(value);
                headerarr.push("");
                headerarr.push("");
                headerarr.push("");
            }
            else if (obj == 'loysoftdetails') {
                value = "Loxysoft".toUpperCase();
                headerarr.push(value);
                headerarr.push("");
                headerarr.push("");
            }
            else if (obj == 'extra') {
                headerarr.push("");
            }
            else if (obj == 'approvalstatus') {
                value = "Status".toUpperCase();
                headerarr.push(value);
            }
        });

        let headerRow = worksheet.addRow(headerarr); // Add Header
        worksheet.mergeCells('A1:C1'); // Merge Header
        worksheet.mergeCells('D1:G1');
        worksheet.mergeCells('H1:K1');
        worksheet.mergeCells('L1:N1');

        headerRow.eachCell((cell, number) => {
            let color = 'e0e0eb'; // Default Background Color
            if (number >= 1 && number < 4) {   // First Set of Header Set Background Color for First 3 Column
                color = 'ffd9cc';
            }
            else if (number >= 4 && number < 8) { // Second Set Of Header Set Background Color for from 4 to 7 Column
                color = '99ccff';
            }
            else if (number >= 8 && number < 12) { // Third Set Of Header Set Background Color for from 8 to 11 Column
                color = '8cd98c';
            }
            else if (number >= 12 && number < 15) { // Fourth Set Of Header Set Background Color for from 12 to 14 Column
                color = 'ffff80';
            }
            cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: color },
                bgColor: { argb: 'FF0000FF' }
            },
                cell.alignment = {
                    vertical: 'middle',
                    horizontal: 'center'
                }
        });

        headerarr = [];
        this.toggleColumns.forEach((obj) => {
            let value = this.setExcelHeaders2(obj);
            if (obj.column != "actions") {
                headerarr.push(value.toUpperCase());
            }
        });
        let subHeaderRow = worksheet.addRow(headerarr); // Add Sub Header

        subHeaderRow.eachCell((cell, number) => {
            let color = 'e0e0eb'; // Default Background Color
            if (number >= 0 && number < 4) { // First Set of SubHeader Set Background Color for First 3 Column
                color = 'ffd9cc';
            }
            else if (number >= 4 && number < 8) { // Second Set Of SubHeader Set Background Color for from 4 to 7 Column
                color = '99ccff';
            }
            else if (number >= 8 && number < 12) { // Third Set Of SubHeader Set Background Color for from 8 to 11 Column
                color = '8cd98c';
            }
            else if (number >= 12 && number < 15) { // Fourth Set Of SubHeader Set Background Color for from 12 to 14 Column
                color = 'ffff80';
            }
            cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: color },
                bgColor: { argb: 'FF0000FF' }
            },
                cell.alignment = {
                    vertical: 'middle',
                    horizontal: 'center'
                }
        });
        // Set Cell width - Based On Sub Header (Max Length)
        worksheet.columns.forEach(function (column, i) {
            var maxLength = 0;
            column["eachCell"]({ includeEmpty: true }, function (cell) {
                var columnLength = cell.value ? cell.value.toString().length : 10;
                if (columnLength > maxLength) {
                    maxLength = columnLength;
                }
            });
            column.width = maxLength < 15 ? 15 : maxLength;
        });
        let projectName = "";
        this.tempDataSource.filteredAttendancDataList.forEach(val => {
            let newLine = [];
            if (val.project_name != projectName) {
                if (val.project_name) {
                    let noOfRecords = this.tempDataSource.filteredAttendancDataList.filter(
                        attendance => attendance.project_name === val.project_name);

                    newLine.push(`${val.project_name}(${noOfRecords.length})`);
                    let projectNameHeader = worksheet.addRow(newLine); // Add Project Name as Sub title
                    projectNameHeader.eachCell((cell, number) => {
                        worksheet.mergeCells(`${cell._address}:O${cell._address.substring(1, 10)}`); // Find row and merge cells
                        cell.fill = {  // Set Cell Background Color 
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: { argb: 'fff2e6' },
                            bgColor: { argb: 'fff2e6' }
                        };
                        const row = worksheet.getRow(cell._address.substring(1, 10));
                        row.getCell(number).font = { color: { argb: "ff884d" } }; // Set Font Color 
                    });
                }
                projectName = val.project_name;
                newLine = [];
            }
            this.toggleColumns.forEach((key, ind) => {
                if (key.column != 'actions') {
                    newLine.push(this.setExcelValues2(key, val))
                }
            });
            let row = worksheet.addRow(newLine); // Add Data value 
            let status = row.getCell(11); // Get Närvaro Status Column 
            let colorConfig = {
                color: 'ffffff',
                isChangeColor: true
            };
            colorConfig = this.setColorByStatus(val.attendance_status_id);
            if (colorConfig.isChangeColor) {  //  Change Color depends on Data Value
                status.fill = {
                    type: 'pattern',
                    pattern: 'solid',
                    fgColor: { argb: colorConfig.color }
                }
            }
        });
        // Write and Save to file 
        workbook.xlsx.writeBuffer().then((data) => {
            let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            fs.saveAs(blob, 'Säljare_Report_' + this.dateFormGroup.controls['attendancedate'].value + '.xlsx');
        });
    }

    setExcelHeaders2(attObj) {
        let toSetStr = ''
        switch (attObj.column) {
            case "first_name":
                toSetStr = "FÖRNAMN";
                break;
            case "last_name":
                toSetStr = "EFTERNAMN";
                break;
            case "mobile":
                toSetStr = "MOBIL";
                break;
            case "In_time":
                toSetStr = "FRÅN";
                break;
            case "Out_time":
                toSetStr = "SLUTLING";
                break;
            case "Lunch":
                toSetStr = "LUNCH";
                break;
            case "Total":
                toSetStr = "TOTALT";
                break;
            case "checkin":
                toSetStr = "E-CHECK IN";
                break;
            case "checkout":
                toSetStr = "E-CHECK UT";
                break;
            case "totalhours":
                toSetStr = "TOTAL E-CHECK";
                break;
            case "attendancestatus":
                toSetStr = "NÄRVARO STATUS";
                break;
            case "loxyin":
                toSetStr = "LOXY IN";
                break;
            case "loxyout":
                toSetStr = "LOXY UT";
                break;
            case "loxytotalhours":
                toSetStr = "TOTAL";
                break;
            case "extratime":
                toSetStr = "EXTRA TID";
                break;
            case "confirmationstatus":
                toSetStr = "GODKÄND";
                break;
            default:
                toSetStr = '';
        }
        return toSetStr;
    }

    setExcelValues2(attKey, attVal) {
        let toSetVal = '';
        switch (attKey.column) {
            case 'first_name':
                toSetVal = attVal.first_name ? attVal.first_name : '';
                break;
            case 'last_name':
                toSetVal = attVal.last_name ? attVal.last_name : '';
                break;
            case 'mobile':
                toSetVal = attVal.first_name ? attVal.first_name : '';
                break;
            case 'In_time':
                toSetVal = attVal.department_intime ? attVal.department_intime : '';
                break;
            case 'Out_time':
                toSetVal = attVal.department_outtime ? attVal.department_outtime : '';
                break;
            case 'Lunch':
                toSetVal = attVal.department_lunch ? attVal.department_lunch : '';
                break;
            case 'Total':
                toSetVal = attVal.department_total_time ? attVal.department_total_time : '';
                break;
            case 'checkin':
                toSetVal = attVal.attendance_intime ? attVal.attendance_intime : '';
                break;
            case 'checkout':
                toSetVal = attVal.attendance_outtime ? attVal.attendance_outtime : '';
                break;
            case 'totalhours':
                toSetVal = attVal.attendance_total_time ? attVal.attendance_total_time : '';
                break;
            case 'attendancestatus':
                toSetVal = attVal.attendance_status ? attVal.attendance_status : '';
                break;
            case 'loxyin':
                toSetVal = attVal.loxysoft_starttime ? attVal.loxysoft_starttime : '';
                break;
            case 'loxyout':
                toSetVal = attVal.loxysoft_endtime ? attVal.loxysoft_endtime : '';
                break;
            case 'loxytotalhours':
                toSetVal = attVal.loxysoft_total_time ? attVal.loxysoft_total_time : '';
                break;
            case 'extratime':
                toSetVal = attVal.extratime ? attVal.extratime : '';
                break;
            case 'confirmationstatus':
                toSetVal = attVal.approved_status ? attVal.approved_status : '';
            default:
                toSetVal = '';
        }
        return toSetVal;
    }

    setColorByStatus(statusId) {
        let colorSet = {
            color: '',
            isChangeColor: false
        };
        switch (statusId) {
            case 0: {
                colorSet.color = '70ad47';
                colorSet.isChangeColor = true;
            };
                break;
            case 1: {
                colorSet.color = 'c3c341';
                colorSet.isChangeColor = true;
            };
                break;
            case 2: {
                colorSet.color = 'ffbf00';
                colorSet.isChangeColor = true;
            };
                break;
            case 3: {
                colorSet.color = 'bd3530';
                colorSet.isChangeColor = true;
            };
                break;
            case 4: {
                colorSet.color = 'cc66ff';
                colorSet.isChangeColor = true;
            };
                break;
            case 5: {
                colorSet.color = 'c5e0b2';
                colorSet.isChangeColor = true;
            };
                break;
            case 6: {
                colorSet.color = '8eabdc';
                colorSet.isChangeColor = true;
            };
                break;
            case 7: {
                colorSet.color = 'a2a2a2';
                colorSet.isChangeColor = true;
            };
            break;
            case 9:
                colorSet.color =  "C8A2C8";
                colorSet.isChangeColor = true;
                break;
            case 10:
                colorSet.color = "FFC0CB";
                colorSet.isChangeColor = true;
                break;
            case 11:
                colorSet.color = "028A0F";
                colorSet.isChangeColor = true;
                break;                
            default:
                colorSet.isChangeColor = false;
        }
        return colorSet;
    }
}

class MyDataSource implements DataSource<any>, OnDestroy {

    private attendanceSubject = new BehaviorSubject<any[]>([]);
    private attendanceDataList: any = [];
    public loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$ = this.loadingSubject.asObservable();
    public paginator: MatPaginator;
    data = new BehaviorSubject<any>([]);
    attendancePageSizeSubject = new BehaviorSubject<number>(50);
    public attendancePageSize$ = this.attendancePageSizeSubject.asObservable();
    attendanceArrLengthSubject = new BehaviorSubject<number>(0);
    public attendanceArrLength$ = this.attendanceArrLengthSubject.asObservable();
    attendancePageIndexSubject = new BehaviorSubject<number>(0);
    public attendancePageIndex$ = this.attendancePageIndexSubject.asObservable();
    private pageIndexRef: number = 0;
    private pageSizeRef: number = 50;
    filteredAttendancDataList: any = [];
    pageIndexSubRef: any;
    pageSizeSubRef: any;
    isAllowLock: boolean = false;
    sortOption: any = {
        active: '',
        direction: ''
    };

    constructor(private attendanceService: AttendanceService) {
        this.pageIndexSubRef = this.attendancePageIndex$.subscribe((index) => {
            this.pageIndexRef = index;
        });
        this.pageSizeSubRef = this.attendancePageSize$.subscribe((size) => {
            this.pageSizeRef = size;
        });
    }

    ngOnDestroy() {
        this.pageIndexSubRef.unsubscribe();
        this.pageSizeSubRef.unsubscribe();
    }

    connect(collectionViewer: CollectionViewer): Observable<any[]> {
        return this.attendanceSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.attendanceSubject.complete();
        this.loadingSubject.complete();
    }

    getTime(value) {
        let ts = '';
        if (value) {
            ts = Moment(value).format('HH:mm:ss');
        }
        return ts;
    }

    getStatus(status) {
        switch (status) {
            case 0:
                return 'Närvaro';
            case 1:
                return 'Närvaro sen';
            case 2:
                return 'Sjuk';
            case 3:
                return 'Ogiltig frånvaro';
            case 4:
                return 'Ledighet';
            case 5:
                return 'Utbildning';
            case 6:
                return 'Sjuk Vab';
            case 7:
                return 'Ej Schemalagd';
            case 9:
                return 'Ledighet - påverkar timmarna';
            case 10:
                return 'Ledighet - påverkar inte timmarna';
            case 11:
                return 'Närvaro godkänd sen';
            default:
                return '';
        }
    }

    loadAttendanceDatewise(searchData, pageConfig?: any, filterChange?: boolean, filterValue?: any) {
        this.loadingSubject.next(true);
        this.isAllowLock = false;
        this.attendanceSubject.next([]);
        this.attendanceService.getAttendanceListForUserByDate(searchData).pipe(
            catchError(() => of([])),
            finalize(() => { this.loadingSubject.next(false); })
        )
            .subscribe((res: any) => {
                if (res[0]) {
                    let completeAttendanceList = [];
                    this.attendanceDataList = [];
                    this.attendanceSubject.next([]);
                    this.isAllowLock = !res[0].lock;
                    if (res[0].data && res[0].data.length > 0) {
                        res[0].data.forEach((obj) => {
                            if (obj.data) {
                                obj.data.forEach((aObj) => {
                                    let toStoreAtt = aObj;
                                    toStoreAtt.client_name = obj.project_name;
                                    toStoreAtt.Status_id = this.getStatus(toStoreAtt.attendance_status_id);
                                    toStoreAtt.In_time = toStoreAtt.attendance_intime ? toStoreAtt.attendance_intime : '00:00:00';
                                    toStoreAtt.Out_time = toStoreAtt.attendance_outtime ? toStoreAtt.attendance_outtime : '00:00:00';
                                    toStoreAtt.allowEdit = true;
                                    toStoreAtt.user_count = obj.data.length;
                                    completeAttendanceList.push(toStoreAtt);
                                    this.attendanceDataList.push(toStoreAtt);
                                });
                            }
                        });
                    }
                    this.filteredAttendancDataList = this.attendanceDataList;
                    this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
                    this.attendanceFilteredList(filterValue, pageConfig);
                } else {
                    this.attendanceDataList = [];
                    this.attendanceSubject.next([]);
                    this.isAllowLock = false;
                    this.filteredAttendancDataList = this.attendanceDataList;
                    this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
                    this.handleAttendancePaging();
                }
            }, err => {
                this.attendanceDataList = [];
                this.attendanceSubject.next([]);
                this.isAllowLock = false;
                this.filteredAttendancDataList = this.attendanceDataList;
                this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
                this.handleAttendancePaging();
            });
    }

    attendancePageFilter(toFilterArr) {
        let tempObj: any = {};
        let toRetArr = [];
        toFilterArr.forEach((listObj, listKey) => {
            if (listObj.client_name != tempObj.client_name) {
                toRetArr.push({ project: listObj.client_name + ' (' + listObj.user_count + ')', extend: true });
                tempObj.client_name = listObj.client_name;
            }
            toRetArr.push(listObj);
        });
        return toRetArr;
    }

    attendanceArrPageIterator() {
        let start = this.pageIndexRef * this.pageSizeRef;
        let end = (this.pageIndexRef + 1) * this.pageSizeRef;
        let tempAttendanceArr = this.filteredAttendancDataList.slice(start, end);
        let toRetAttendanceArr = this.attendancePageFilter(tempAttendanceArr);
        this.attendanceSubject.next(toRetAttendanceArr);
    }

    handleAttendancePaging(event?: any, sortEvent?: any, arrToPaginate?: any) {
        if (event) {
            this.attendancePageIndexSubject.next(event.pageIndex);
            this.attendancePageSizeSubject.next(event.pageSize);
        } else {
            this.attendancePageIndexSubject.next(0);
            this.attendancePageSizeSubject.next(50);
        }
        this.attendanceArrPageIterator();
    }

    attendanceFilteredList(filterData, pageConfig) {
        filterData = filterData ? filterData : '';
        let toRetAttendanceArr: any = this.filterList(filterData);
        this.filteredAttendancDataList = toRetAttendanceArr;
        this.attendanceSubject.next(toRetAttendanceArr);
        this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
        this.handleAttendancePaging(pageConfig);
    }

    filterList(filterValue) {
        let filteredArr = this.attendanceDataList.filter((item) => {
            let name = (item.first_name + " " + item.last_name);
            let filterString = item.Employee_id + item.first_name + item.last_name + name + item.project +
                item.mobile + item.In_time + item.Out_time + item.department_lunch + item.attendance_intime
                + item.attendance_lunch + item.attendance_status + item.attendance_total_time + item.department_intime
                + item.department_lunch + item.department_outtime + item.department_total_time;
            filterString = filterString.trim().toLowerCase();
            filterValue = filterValue.toLowerCase();
            return filterString.indexOf(filterValue) != -1;
        });
        return filteredArr;
    }

    setAllowLock(isAllowed) {
        this.isAllowLock = isAllowed;
    }

    //sort functionality - To be used in future
    sortData(sort: any, toSortArr) {
        const data = toSortArr.slice();
        const isAsc = sort.direction === 'asc' ? true : false;
        let sortedArr = [];
        if (sort) {
            this.sortOption = {
                active: sort.active,
                direction: sort.direction
            };
            if (!sort.active || sort.direction == '') {
                sortedArr = data;
            }
        }
    }

    compare(a, b, isAsc) {
        return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
    }
}
