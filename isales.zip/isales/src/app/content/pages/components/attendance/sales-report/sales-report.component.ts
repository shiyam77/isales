import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-sales-report',
  templateUrl: './sales-report.component.html',
  styleUrls: ['./sales-report.component.scss']
})
export class SalesReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
