import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AttendanceComponent } from './attendance.component';
import { Routes, RouterModule } from '@angular/router';
import { StatisticsComponent } from './statistics/statistics.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { CoreModule } from '../../../../core/core.module';
import { PartialsModule } from '../../../partials/partials.module';
import { NgbModule, NgbAlertConfig, NgbPopoverConfig } from '@ng-bootstrap/ng-bootstrap';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { CodePreviewModule } from '../../../partials/content/general/code-preview/code-preview.module';
import { MaterialPreviewModule } from '../../../partials/content/general/material-preview/material-preivew.module';
import {
	MatIconRegistry,
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatSliderModule,
	MatListModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatSlideToggleModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatSidenavModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatSnackBarModule,
	MatGridListModule,
	MatTableModule,
	MatExpansionModule,
	MatToolbarModule,
	MatSortModule,
	MatDividerModule,
	MatStepperModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	MatRadioModule,
  MAT_DATE_LOCALE,
  MAT_DATE_FORMATS,
  DateAdapter,
  MatPaginatorIntl,	
} from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { QRCodeModule } from 'angularx-qrcode';
import { SubheaderService } from '../../../../core/services/layout/subheader.service';
import { NgxPermissionsGuard, NgxPermissionsModule } from 'ngx-permissions';
import { SalesComponent } from './sales/sales.component';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { SalesReportComponent } from './sales-report/sales-report.component';
import { SalesViewComponent } from './sales-view/sales-view.component';
import { PersonalService } from '../personal/_core/services/personal.service';
import { LeaderViewComponent } from './leader-view/leader-view.component';
import { LeaderReportComponent } from './leader-report/leader-report.component';
import { OverviewComponent } from './overview/overview.component';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { AttendanceService } from './_core/services/attendance.service';

export const MY_FORMATS = {
	parse: {
	  dateInput: 'LL',
	},
	display: {
	  dateInput: 'YYYY-MM-DD',
	  monthYearLabel: 'YYYY',
	  dateA11yLabel: 'LL',
	  monthYearA11yLabel: 'YYYY',
	},
};

const routes: Routes = [
	{
		path: '',
    component: AttendanceComponent,
    canActivateChild:[NgxPermissionsGuard],
		children: [
      {
        path:'sales/report',
        component:SalesComponent,
        data:{
					permissions:{
            only:["attendanceSales"],
						redirectTo:'/attendance/overview'
					}
				}
      },
      {
        path:'leader/report',
        component:LeaderReportComponent,
        data:{
					permissions:{
            only:["attendanceManagement"],
						redirectTo:'/attendance/overview'
					}
				}       
      },
      {
        path:'overview',
        component:OverviewComponent,
        data:{
					permissions:{
            only:["attendanceOverview"],
						redirectTo:'/my-salary/list'
					}
				}
      }
	],
	}
];

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
};

const swedishRangeLabel = (page: number, pageSize: number, length: number) => {
  if (length == 0 || pageSize == 0) { return `0 av ${length}`; }
  length = Math.max(length, 0);
  const startIndex = page * pageSize;
  // If the start index exceeds the list length, do not try and fix the end index to the end.
  const endIndex = startIndex < length ?
      Math.min(startIndex + pageSize, length) :
      startIndex + pageSize;
  return `${startIndex + 1} - ${endIndex} av ${length}`;
}


function getSwedishPaginatorIntl() {
  const paginatorIntl = new MatPaginatorIntl();
  paginatorIntl.itemsPerPageLabel = 'Objekt per sida:';
  // paginatorIntl.nextPageLabel = 'Volgende pagina';
  // paginatorIntl.previousPageLabel = 'Vorige pagina';
  paginatorIntl.getRangeLabel = swedishRangeLabel;
  return paginatorIntl;
}

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    PartialsModule,
    NgbModule,
    CodePreviewModule,
    CoreModule,
    MaterialPreviewModule,
    FormsModule,
    ReactiveFormsModule,    
    PerfectScrollbarModule,	
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatSliderModule,
    MatListModule,
    MatCardModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    MatMenuModule,
    MatTabsModule,
    MatTooltipModule,
    MatSidenavModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatGridListModule,
    MatTableModule,
    MatExpansionModule,
    MatToolbarModule,
    MatSortModule,
    MatDividerModule,
    MatStepperModule,
    MatChipsModule,
    MatPaginatorModule,
    MatDialogModule,
    MatRadioModule,
    TranslateModule,
    QRCodeModule,
    WidgetChartsModule,
    NgxPermissionsModule.forChild(),
    NgxDaterangepickerMd,
    NgxMatSelectSearchModule
  ],
  declarations: [AttendanceComponent,StatisticsComponent,SalesComponent, SalesReportComponent, SalesViewComponent, LeaderViewComponent, LeaderReportComponent,OverviewComponent],
  providers: [
    NgbAlertConfig, {
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    MatIconRegistry,
    SubheaderService,
    PersonalService,
    NgbPopoverConfig,
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    { provide: MatPaginatorIntl, useValue: getSwedishPaginatorIntl() },
    AttendanceService
  ]
})
export class AttendanceModule { }