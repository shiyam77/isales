import { Component, OnInit, ViewChild, ChangeDetectorRef, OnDestroy, ElementRef } from '@angular/core';
import { DataSource, CollectionViewer } from '@angular/cdk/collections';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSelect } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ProjectService } from '../../project/_core/services/project.service';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { AttendanceService } from '../_core/services/attendance.service';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { Subject, ReplaySubject, BehaviorSubject, Observable, of } from 'rxjs';
import { takeUntil, take, catchError, finalize } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { Workbook } from 'exceljs/dist/exceljs.min.js';
import * as fs from 'file-saver';


@Component({
  selector: 'm-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss']
})

export class OverviewComponent implements OnInit, OnDestroy {
  monthList = [
    { label: "Januari", value: 1 },
    { label: "Februari", value: 2 },
    { label: "Mars", value: 3 },
    { label: "April", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Juni", value: 6 },
    { label: "Juli", value: 7 },
    { label: "Augusti", value: 8 },
    { label: "September", value: 9 },
    { label: "Oktober", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  setMonthYear: any = {
    month: null,
    year: null
  };
  datasSource: any = [];
  toggleEconomyEmployeeTable: any;
  loader: any;
  clientSelected: any;
  projectSelected: any;
  emp_dataSource: any = [];
  prodtottRowErr: boolean = false;
  prodtottRowNoRecord: boolean = false;
  salaryReportList: any = [];
  employeedisplayedColumns: string[] = ['employee', 'totaltimmar', 'totalorder', 'snitt', 'provperproduckt', 'totalprovperpro', 'timlön', 'totaltprovision', 'totalhourlysalary', 'totallön'];
  daysInMonth: any[] = [];
  depDate: any;
  worked_hours: any;
  total_hours: any;
  dataSource: MatTableDataSource<any>;
  footerDate: any;
  department: any = [];
  footerTotalTimar: any;
  statusArr: any = [];
  departmenList: any = [];
  selectedDepartment: any;
  projectsArr: any = [];
  selectedProject: any;
  selectedStatus: any;
  searchGroup: FormGroup;
  @ViewChild('departmentSearchSelect') departmentSearchSelect: MatSelect;
  protected _onDepDestroy = new Subject<void>();
  depFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  @ViewChild('projectSearchSelect') projectSearchSelect: MatSelect;
  protected _onProjectDestroy = new Subject<void>();
  projectFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  @ViewChild('statusSearchSelect') statusSearchSelect: MatSelect;
  protected _onStatusDestroy = new Subject<void>();
  statusFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  tempDataSource: any;
  departmentHeaderColumns: any = ['department_name', 'other'];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  clientsArr: Array<any> = [];
  @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
  protected _onClientDestroy = new Subject<void>();
  clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  firstColWidth: any = null;
  @ViewChild('overViewTableRef') overViewTableRef: ElementRef;
  pageIndexChange: any = 0;
  pageSizeChange: any = 0;
  tid: any;
  qty: any;
  deleteEmpModalRef: any;
  closeResult: string;
  attendanceHistory: any = [];
  permissionHistory: any = [];
  hasEmployeeRequestForPermission: boolean = false;
  dateLibVar = _moment;
  overviewSummaryArr: any = [];
  leaveHistory: any = [];
  pageIndexNumber: number = 0;
  pageChanged: boolean = false;

  constructor(
    private _ref: ChangeDetectorRef,
    private personalService: PersonalService,
    private attendanceService: AttendanceService,
    private modalService: NgbModal,
    private _formBuilder: FormBuilder,
    private sharedService: SharedService,
    private router: Router,
    private activeRoute: ActivatedRoute) { }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= 5); y++) {
      this.yearList.push(2020 + y);
    }
    if (new Date().getMonth() > 0) {
      this.monthSelected = new Date().getMonth() + 1;
    } else {
      this.monthSelected = 1;
    }
    this.tempDataSource = new MyDataSource(this.attendanceService);
    this.searchGroup = this._formBuilder.group({
      selectedDepartment: [[]],
      departmentFilterControls: [''],
      selectedProject: [[]],
      projectFilterControls: [''],
      selectedStatus: [[]],
      statusFilterControls: [''],
      selectedClient: [[]],
      clientFilterControls: ['']
    });
    this.statusArr = [];
    this.statusArr.push(
      { id: 0, name: 'Närvaro' },
      { id: 1, name: 'Närvaro sen' },
      { id: 11, name: 'Närvaro godkänd sen' },
      { id: 2, name: 'Sjuk' },
      { id: 3, name: 'Ogiltig frånvaro' },
      { id: 4, name: 'Ledighet' },
      { id: 5, name: 'Utbildning' },
      { id: 6, name: 'Sjuk Vab' },
      { id: 7, name: 'Ej Schemalagd' },
      { id: 9, name: 'Ledighet - påverkar timmarna' },
      { id: 10, name: 'Ledighet - påverkar inte timmarna' },
    );
    this.toggleEconomyEmployeeTable = true;
    this.getDepartmentListData();
    this.getProjectList();
    this.getEmployeeClientSelectionList();
    this.statusFilteredOptions.next(this.statusArr.slice());
    this.searchGroup.controls['departmentFilterControls'].valueChanges
      .pipe(takeUntil(this._onDepDestroy)).subscribe(() => this._DepFilter());
    this.searchGroup.controls['projectFilterControls'].valueChanges
      .pipe(takeUntil(this._onProjectDestroy)).subscribe(() => this._ProjectFilter());
    this.searchGroup.controls['statusFilterControls'].valueChanges
      .pipe(takeUntil(this._onStatusDestroy)).subscribe(() => this._StatusFilter());
    this.searchGroup.controls['clientFilterControls'].valueChanges
      .pipe(takeUntil(this._onClientDestroy)).subscribe(() => this._ClientFilter());
    this.getOverviewSummary();
    this.activeRoute.queryParams.subscribe((params) => {
      this.yearSelected = this.converToInteger(params['sa']) ? this.converToInteger(params.sa) : (new Date().getFullYear());
      this.monthSelected = this.converToInteger(params['ms']) ? this.converToInteger(params.ms) : (new Date().getMonth() + 1);
      this.pageIndexNumber = params['pin'] ? params['pin'] : 0;
      this.itemsPerPage = params['ipp'] ? params['ipp'] : this.itemsPerPage;
      this.pageChanged = params['pac'] == 'false' ? false : true;
      let toSetDepartments: any[] = [];
      let toSetClient: any[] = [];
      let toSetStatus: any[] = [];
      if (params['sd']) {
        atob(params['sd']).split(',').forEach((tsd) => {
          toSetDepartments.push(this.converToInteger(tsd));
        });
      }
      if (params['sc']) {
        atob(params['sc']).split(',').forEach((tsd) => {
          toSetClient.push(this.converToInteger(tsd));
        });
      }
      if (params['ss']) {
        atob(params['ss']).split(',').forEach((tsd) => {
          toSetStatus.push(this.converToInteger(tsd));
        });
      }
      this.searchGroup.patchValue({
        selectedDepartment: toSetDepartments,
        selectedProject: params['sp'] ? params['sp'].split(',') : [],
        selectedStatus: toSetStatus,
        selectedClient: toSetClient
      });
      this.getAttendanceOverviewData();
    });
  }

  ngOnDestroy() {
    this._onDepDestroy.next();
    this._onDepDestroy.complete();
    this._onProjectDestroy.next();
    this._onProjectDestroy.complete();
    this._onStatusDestroy.next();
    this._onStatusDestroy.complete();
    this._onClientDestroy.next();
    this._onClientDestroy.complete();
  }

  getMonthTitle(month) {
    let monthLabel = '';
    this.monthList.forEach((obj) => {
      if (obj.value == month) {
        monthLabel = obj.label;
      }
    });
    return monthLabel;
  }

  getMonthSelected(clientSel?: any, projectSel?: any) {
    this.setPageParams(false);
  }

  getDay(i) {
    let daynumber = new Date(this.yearSelected, this.monthSelected - 1, i).getDay();
    switch (daynumber) {
      case 0:
        return 'Sön';
      case 1:
        return 'Mån';
      case 2:
        return 'Tis';
      case 3:
        return 'Ons';
      case 4:
        return 'Tor';
      case 5:
        return 'Fre';
      case 6:
        return 'Lör';
      default:
        return 'default';
    }
  }


  getAttendanceOverviewData() {
    this.prodtottRowErr = false;
    this.prodtottRowNoRecord = false;
    if (this.monthSelected && this.yearSelected) {
      let reqFilterOptions: any = {
        month: this.monthSelected,
        year: this.yearSelected,
      };
      if (this.searchGroup.controls['selectedDepartment'].value.length > 0) {
        reqFilterOptions.department = this.searchGroup.controls['selectedDepartment'].value.join();
      }
      if (this.searchGroup.controls['selectedProject'].value.length > 0) {
        reqFilterOptions.project = this.searchGroup.controls['selectedProject'].value.join();
      }
      if (this.searchGroup.controls['selectedClient'].value.length > 0) {
        reqFilterOptions.client = this.searchGroup.controls['selectedClient'].value.join();
      }
      if (this.searchGroup.controls['selectedStatus'].value.length > 0) {
        reqFilterOptions.status = this.searchGroup.controls['selectedStatus'].value.join();
      }
      this.loader = true;
      let monthSet = '' + this.monthSelected;
      if (monthSet.length < 2) monthSet = '0' + monthSet;
      let dayscount = _moment((this.yearSelected + '-' + monthSet), 'YYYY-MM').daysInMonth();
      this.employeedisplayedColumns = [];
      this.employeedisplayedColumns.push('employee');
      this.depDate = [];
      this.daysInMonth = [];
      this.employeedisplayedColumns.push('Timmar');
      for (let i = 0; i < dayscount; i++) {
        let dt = i + 1;
        this.employeedisplayedColumns.push(dt + "  " + this.getDay(dt));
        this.daysInMonth.push(dt + "  " + this.getDay(dt));
        let month = '' + (this.monthSelected - 1);
        let day = '' + new Date(this.yearSelected, this.monthSelected - 1, dt).getDate();
        let year = this.yearSelected;
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        this.depDate.push([year, month, day].join('-'));
      }
      this.employeedisplayedColumns.push('Total Timmar');
      this.firstColWidth = null;
      this.tempDataSource.loadAttendanceOverview(reqFilterOptions, { pageIndex: this.pageIndexNumber, pageSize: this.itemsPerPage });
    }
  }

  isSticky(column: string): boolean {
    return column === 'employee' ? true : false;
  }

  getDepartmentListData() {
    this.personalService.getDepartmentList().subscribe((depResData) => {
      if (depResData) {
        this.departmenList = depResData;
        this.departmenList.sort(function (a, b) {
          if (a.department.toLowerCase() < b.department.toLowerCase()) { return -1; }
          if (a.department.toLowerCase() > b.department.toLowerCase()) { return 1; }
          return 0;
        });
        this.depFilteredOptions.next(this.departmenList.slice());
      }
    });
  }

  attendancePageFilter(toFilterArr) {
    let tempObj: any = {};
    let toRetArr = [];
    toFilterArr.forEach((listObj) => {
      if (listObj.department_name != tempObj.department_name) {
        toRetArr.push({ department_name: listObj.department_name + ' (' + listObj.user_count + ')', extend: true });
        tempObj.department_name = listObj.department_name;
      }
      toRetArr.push(listObj);
    });
    return toRetArr;
  }

  isExtendedRow = (index, item) => item.extend;

  getProjectList() {
    this.sharedService.getProjectList().subscribe((res: any) => {
      if (res) {
        this.projectsArr = res;
        this.projectsArr.sort(function (a, b) {
          if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
          if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
          return 0;
        });
        this.projectFilteredOptions.next(this.projectsArr.slice());
      }
    });
  }

  searchByFilters() {
    this.setPageParams(false);
  }

  protected _DepFilter(): any[] {
    if (this.departmenList.length <= 0) {
      return;
    }
    if (this.searchGroup && this.searchGroup.controls['departmentFilterControls'].value && (typeof this.searchGroup.controls['departmentFilterControls'].value == 'string') && this.searchGroup.controls['departmentFilterControls'].value.trim() != '') {
      const depfilterValue = this.searchGroup.controls['departmentFilterControls'].value.toLowerCase();
      this.depFilteredOptions.next(
        this.departmenList.filter(dep => (dep.department.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.depFilteredOptions.next(this.departmenList.slice());
      return;
    }
  }

  protected _ProjectFilter(): any[] {
    if (this.projectsArr.length <= 0) {
      return;
    }
    if (this.searchGroup && this.searchGroup.controls['projectFilterControls'].value && (typeof this.searchGroup.controls['projectFilterControls'].value == 'string') && this.searchGroup.controls['projectFilterControls'].value.trim() != '') {
      const projfilterValue = this.searchGroup.controls['projectFilterControls'].value.toLowerCase();
      this.projectFilteredOptions.next(
        this.projectsArr.filter(proj => (proj.Project_name.toLowerCase().indexOf(projfilterValue) > -1))
      );
    } else {
      this.projectFilteredOptions.next(this.projectsArr.slice());
      return;
    }
  }

  protected _StatusFilter(): any[] {
    if (this.statusArr.length <= 0) {
      return;
    }
    if (this.searchGroup && this.searchGroup.controls['statusFilterControls'].value && (typeof this.searchGroup.controls['statusFilterControls'].value == 'string') && this.searchGroup.controls['statusFilterControls'].value.trim() != '') {
      const statusfilterValue = this.searchGroup.controls['statusFilterControls'].value.toLowerCase();
      this.statusFilteredOptions.next(
        this.statusArr.filter(status => (status.name.toLowerCase().indexOf(statusfilterValue) > -1))
      );
    } else {
      this.statusFilteredOptions.next(this.statusArr.slice());
      return;
    }
  }

  toggleDepartmentSelectAll(selectAllValue: boolean) {
    let toSetArr = [];
    this.depFilteredOptions.pipe(take(1), takeUntil(this._onDepDestroy))
      .subscribe((val: any) => {
        if (selectAllValue) {
          val.forEach((valObj: any) => {
            toSetArr.push(valObj._id);
          });
          this.searchGroup.controls['selectedDepartment'].patchValue(toSetArr);
        } else {
          this.searchGroup.controls['selectedDepartment'].patchValue([]);
        }
      });
  }

  toggleProjectSelectAll(selectAllValue: boolean) {
    let toSetArr = [];
    this.projectFilteredOptions.pipe(take(1), takeUntil(this._onProjectDestroy))
      .subscribe((val: any) => {
        if (selectAllValue) {
          val.forEach((valObj: any) => {
            toSetArr.push(valObj.Project_id);
          });
          this.searchGroup.controls['selectedProject'].patchValue(toSetArr);
        } else {
          this.searchGroup.controls['selectedProject'].patchValue([]);
        }
      });
  }

  toggleStatusSelectAll(selectAllValue: boolean) {
    let toSetArr = [];
    this.statusFilteredOptions.pipe(take(1), takeUntil(this._onStatusDestroy))
      .subscribe((val: any) => {
        if (selectAllValue) {
          val.forEach((valObj: any) => {
            toSetArr.push(valObj.id);
          });
          this.searchGroup.controls['selectedStatus'].patchValue(toSetArr);
        } else {
          this.searchGroup.controls['selectedStatus'].patchValue([]);
        }
      });
  }

  getEmployeeClientSelectionList() {
    this.personalService.employeeClientList().subscribe((clientNewArr: any) => {
      if (clientNewArr && clientNewArr.length > 0) {
        this.clientsArr = clientNewArr;
        this.clientsArr.sort(function (a, b) {
          if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
          if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
          return 0;
        });
        this.clientFilteredOptions.next(this.clientsArr.slice());
      }
    });
  }

  toggleClientSelectAll(selectAllValue: boolean) {
    let toSetArr = [];
    this.clientFilteredOptions.pipe(take(1), takeUntil(this._onClientDestroy))
      .subscribe((val: any) => {
        if (selectAllValue) {
          val.forEach((valObj: any) => {
            toSetArr.push(valObj._id);
          });
          this.searchGroup.controls['selectedClient'].patchValue(toSetArr);
        } else {
          this.searchGroup.controls['selectedClient'].patchValue([]);
        }
      });
  }

  protected _ClientFilter(): any[] {
    if (this.clientsArr.length <= 0) {
      return;
    }
    if (this.searchGroup && this.searchGroup.controls['clientFilterControls'].value && (typeof this.searchGroup.controls['clientFilterControls'].value == 'string') && this.searchGroup.controls['clientFilterControls'].value.trim() != '') {
      const clientValue = this.searchGroup.controls['clientFilterControls'].value.toLowerCase();
      this.clientFilteredOptions.next(
        this.clientsArr.filter(client => (client.name.toLowerCase().indexOf(clientValue) > -1))
      );
    } else {
      this.clientFilteredOptions.next(this.clientsArr.slice());
      return;
    }
  }

  setSecondColOffset(elementRefVal: any, colVal) {
    if (!elementRefVal || !(elementRefVal && !(elementRefVal && !elementRefVal.dataSource && (elementRefVal.dataSource.filteredAttendancDataList.length <= 0))) || ((colVal != 'Timmar') && (colVal != 'employee'))) {
      return 'auto';
    } else if (elementRefVal && elementRefVal.dataSource && (elementRefVal.dataSource.filteredAttendancDataList.length > 0) && (colVal == 'Timmar')) {
      if (elementRefVal._elementRef.nativeElement.querySelectorAll('.first-column')[1] && elementRefVal._elementRef.nativeElement.querySelectorAll('.first-column')[1].offsetWidth) {
        let toSetLeft = elementRefVal._elementRef.nativeElement.querySelectorAll('.first-column')[1].offsetWidth;
        if ((elementRefVal.dataSource.pageIndexRef != this.pageIndexChange) || (elementRefVal.dataSource.pageSizeRef != this.pageSizeChange)) {
          this.pageIndexChange = elementRefVal.dataSource.pageIndexRef;
          this.pageSizeChange = elementRefVal.dataSource.pageSizeRef;
          this.firstColWidth = 0;
        }
        if (toSetLeft && this.firstColWidth < toSetLeft) {
          this.firstColWidth = toSetLeft - 2;
        }
        if (toSetLeft >= 0) {
          return (this.firstColWidth) + 'px';
        } else {
          return 0;
        }
      }
    }
  }

  loadProjectwiseTotal() {
    this.tid = {};
    this.qty = {};
    let reqFilterOptions: any = {
      month: this.monthSelected,
      year: this.yearSelected,
    };
    this.attendanceService.getProjectwiseStatistics(reqFilterOptions).subscribe(res => {
      if (res) {
        this.qty.presenceQty = 0;
        this.qty.presenceLateQty = 0;
        this.qty.presenceApprovedQty = 0;
        this.qty.sickQty = 0;
        this.qty.invalidAbsenceQty = 0;
        this.qty.approvedAbsenceQty = 0;
        this.qty.presenceEduQty = 0;
        this.qty.sickVabQty = 0;
        this.qty.totalQty = 0;
        this.tid.presenceHours = 0;
        this.tid.presenceLateHours = 0;
        this.tid.presenceApprovedHours = 0;
        this.tid.sickHours = 0;
        this.tid.invalidAbsenceHours = 0;
        this.tid.approvedAbsenceHours = 0;
        this.tid.presenceEduHours = 0;
        this.tid.sickVabHours = 0;
        this.tid.totaltime = 0;
        if (res.Grandtotal) {
          this.tid.totaltime = this.getTotalTime(res.Grandtotal);
          this.qty.totalQty = res.TotalMandays;
        }
        res.StatuswiseReport.forEach((obj) => {
          switch (obj.Status) {
            case 0: {
              this.qty.presenceQty = obj.Mandays;
              this.tid.presenceHours = this.getTotalTime(obj.Hours);
            };
              break;
            case 1: {
              this.qty.presenceLateQty = obj.Mandays;
              this.tid.presenceLateHours = this.getTotalTime(obj.Hours);
            };
              break;
            case 2: {
              this.qty.sickQty = obj.Mandays;
              this.tid.sickHours = this.getTotalTime(obj.Hours);
            };
              break;
            case 3: {
              this.qty.invalidAbsenceQty = obj.Mandays;
              this.tid.invalidAbsenceHours = this.getTotalTime(obj.Hours);
            };
              break;
            case 4: {
              this.qty.approvedAbsenceQty = obj.Mandays;
              this.tid.approvedAbsenceHours = this.getTotalTime(obj.Hours);
            };
              break;
            case 5: {
              this.qty.presenceEduQty = obj.Mandays;
              this.tid.presenceEduHours = this.getTotalTime(obj.Hours);
            };
              break;
            case 6: {
              this.qty.sickVabQty = obj.Mandays;
              this.tid.sickVabHours = this.getTotalTime(obj.Hours);
            };
              break;
            case 11: {
              this.qty.presenceApprovedQty = obj.Mandays;
              this.tid.presenceApprovedHours = this.getTotalTime(obj.Hours);
            };              
            default: {
            };
              break;
          }
        });
      }
      this._ref.detectChanges();
    }, err => {
      this.tid = {};
      this.qty = {};
      this._ref.detectChanges();
    })
  }
  getTotalTime(time) {
    if (time) {
      let tims = time.split(':');
      return tims[0] + ':' + tims[1];
    } else {
      return '';
    }
  }

  openModal(content, contentAccessId, totimersattning?, selectedDate?) {
    this.statusArr = [];
    if (content == 'history') {
      this.attendanceHistory = totimersattning.attendance_details;
      this.permissionHistory = [];
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'history', backdrop: "static" });
    } else if (content == 'leave') {
      this.leaveHistory = [];
      this.leaveHistory = (totimersattning.leave_details.length > 0) ? totimersattning.leave_details : [];
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'leave', size: 'lg', backdrop: "static" });
    }
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getOverviewSummary() {
    let resultarr = [];
    this.prodtottRowErr = false;
    this.prodtottRowNoRecord = false;
    let overviewData = {
      emp_type: 'Management',
      month: this.monthSelected,
      year: this.yearSelected
    };
    this.attendanceService.overviewSummary(overviewData).subscribe(res => {
      res.forEach((obj) => {
        if (obj.data && obj.data.length > 0) {
          obj.data.forEach((projObj) => {
            resultarr.push(projObj);
          });
        }
        if (obj.total_summary && obj.total_summary.length > 0) {
          obj.total_summary[0].project_name = 'Total';
          resultarr.push(obj.total_summary[0]);
        }
      });
      this.datasSource = resultarr;
      this.dataSource = new MatTableDataSource(resultarr);
      this._ref.detectChanges();
      this.loader = false;
    }, err => {
      this.datasSource = [];
      this.dataSource = new MatTableDataSource([]);
      this.loader = false;
      this._ref.detectChanges();
    });
  }

  converToNumber(val) {
    if (typeof val != 'number') {
      return parseFloat(val);
    } else {
      return val;
    }
  }

  converToInteger(val) {
    if (typeof val != 'number') {
      return parseInt(val);
    } else {
      return null;
    }
  }

  setPageParams(filterChanged: boolean, pageEvent?: any) {
    if (pageEvent) {
      this.pageIndexNumber = pageEvent.pageIndex;
      this.itemsPerPage = pageEvent.pageSize;
      this.pageChanged = true;
    } else {
      this.pageChanged = false;
    }
    let toSetQueryParams: any = {
      ms: this.monthSelected,
      sa: this.yearSelected,
      pin: this.pageIndexNumber,
      ipp: this.itemsPerPage,
      fic: filterChanged,
      pac: this.pageChanged,
      sd: (this.searchGroup.value.selectedDepartment && this.searchGroup.value.selectedDepartment.length > 0) ? btoa(this.searchGroup.value.selectedDepartment.join(',')) : '',
      sc: (this.searchGroup.value.selectedClient && this.searchGroup.value.selectedClient.length > 0) ? btoa(this.searchGroup.value.selectedClient.join(',')) : '',
      ss: (this.searchGroup.value.selectedStatus && this.searchGroup.value.selectedStatus.length > 0) ? btoa(this.searchGroup.value.selectedStatus.join(',')) : '',
    };
    this.router.navigate([],
      {
        queryParams: toSetQueryParams,
      });
  }

  generateAndDownloadDoc() {
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Översikt_Report');  // Add Xlsx File Name

    let headerarr = [];
    this.employeedisplayedColumns.forEach((obj) => {
      if (obj == 'employee') {
        headerarr.push("Anställd".toUpperCase());
      }
      else {
        headerarr.push(obj.toUpperCase());
      }
    });
    worksheet.addRow(headerarr); // Add Header
    // Set Cell width - Based On Sub Header (Max Length)
    worksheet.columns.forEach(function (column, i) {
      if (i == 1) {
        column.width = 20;
      }
      else if (i == 0) {
        column.width = 25;
      } else {
        column.width = 15;
      }
    });
    let departmentName = "";
    this.tempDataSource.filteredAttendancDataList.forEach(val => {
      let newLine = [];
      if (val.department_name != departmentName) {
        if (val.department_name) {
          let noOfRecords = this.tempDataSource.filteredAttendancDataList.filter(
            attendance => attendance.department_name === val.department_name);

          newLine.push(val.department_name.toUpperCase() + " (" + noOfRecords.length + ")")
          let projectNameHeader = worksheet.addRow(newLine); // Add Project Name as Sub title
          projectNameHeader.eachCell((cell, number) => {
            let last_cell_address = 'AE';
            if (val.monthly_data.length == 31) {
              last_cell_address = 'AH';
            }
            if (val.monthly_data.length == 30) {
              last_cell_address = 'AG';
            }
            if (val.monthly_data.length == 29) {
              last_cell_address = 'AF';
            }
            worksheet.mergeCells(cell._address + ':' + last_cell_address + cell._address.substring(1, 10)) // Find row and merge cells
            cell.fill = {  // Set Cell Background Color 
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: 'fff2e6' },
              bgColor: { argb: 'fff2e6' }
            }
            const row = worksheet.getRow(cell._address.substring(1, 10));
            row.getCell(number).font = { color: { argb: "ff884d" } }; // Set Font Color 
          });
        }
        departmentName = val.department_name;
        newLine = [];
      }
      this.employeedisplayedColumns.forEach((key, ind) => {
        if (key === 'employee') {
          if (val.first_name && val.last_name) {
            newLine.push(val.first_name + " " + val.last_name);
          }
          else {
            newLine.push("");
          }
        }
        if (key === 'Timmar') {
          newLine.push("E-check timmar" + "\n" + "Loxysoft timmar");
        }
        if (key !== 'employee' && key !== 'Timmar' && key !== 'Total Timmar') {
          newLine.push((val.monthly_data[ind - 2].attendance_total_time ? val.monthly_data[ind - 2].attendance_total_time + " " : "  ") + " \n " + (val.monthly_data[ind - 2].loxysoft_total_time ? val.monthly_data[ind - 2].loxysoft_total_time : " "));
        }
        if (key === 'Total Timmar') {
          let total_values = "";
          if (val.total_attendance_hours) {
            total_values = val.total_attendance_hours;
          }
          if (val.total_loxysoft_hours) {
            total_values = total_values + " " + val.total_loxysoft_hours;
          }
          if (total_values != "") {
            newLine.push(total_values);
          }
          else {
            newLine.push('');
          }
        }
      });
      let row = worksheet.addRow(newLine); // Add Data value 
      let col_1 = row.getCell(1); // Get Cell 
      col_1.alignment = { vertical: 'middle', horizontal: 'left', wrapText: true }; // Set Cell alignment
      let col_2 = row.getCell(2); // Get Cell 
      col_2.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true }; // Set Cell alignment
      if (val.monthly_data) {
        val.monthly_data.forEach((element, ind) => {
          let status = row.getCell(ind + 3); // Get Närvaro Status Column 
          let colorConfig = {
            color: 'ffffff',
            isChangeColor: true
          };
          colorConfig = this.setColorByStatus(element.attendance_status_id);
          if (colorConfig.isChangeColor) {  //  Change Color depends on Data Value
            status.fill = {
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: colorConfig.color }
            };
            status.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
          }
        });
      }
      let last_col = row.getCell(val.monthly_data.length + 3);
      last_col.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    });
    // Write and Save to file 
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, 'Översikt_Report_' + this.yearSelected + '_' + this.getMonthTitle(this.monthSelected) + '.xlsx');
    });
  }

  setColorByStatus(statusId) {
    let colorSet = {
      color: '',
      isChangeColor: false
    };
    switch (statusId) {
      case 0: {
        colorSet.color = '70ad47';
        colorSet.isChangeColor = true;
      };
        break;
      case 1: {
        colorSet.color = 'c3c341';
        colorSet.isChangeColor = true;
      };
        break;
      case 2: {
        colorSet.color = 'ffbf00';
        colorSet.isChangeColor = true;
      };
        break;
      case 3: {
        colorSet.color = 'bd3530';
        colorSet.isChangeColor = true;
      };
        break;
      case 4: {
        colorSet.color = 'cc66ff';
        colorSet.isChangeColor = true;
      };
        break;
      case 5: {
        colorSet.color = 'c5e0b2';
        colorSet.isChangeColor = true;
      };
        break;
      case 6: {
        colorSet.color = '8eabdc';
        colorSet.isChangeColor = true;
      };
        break;
      case 7: {
        colorSet.color = 'a2a2a2';
        colorSet.isChangeColor = true;
      };
        break;
      case 9: {
          colorSet.color = 'C8A2C8';
          colorSet.isChangeColor = true;
      };
          break;
      case 10: {
          colorSet.color = 'FFC0CB';
          colorSet.isChangeColor = true;
      };
            break;
      case 11: {
        colorSet.color = '028A0F';
        colorSet.isChangeColor = true;
      };
          break;            
      default:
        colorSet.isChangeColor = false;
    }
    return colorSet;
  }
}

class MyDataSource implements DataSource<any>, OnDestroy {
  private attendanceSubject = new BehaviorSubject<any[]>([]);
  private attendanceDataSubject = new BehaviorSubject<any[]>([]);
  private attendanceDataList: any = [];
  public loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();
  public paginator: MatPaginator;
  attendancePageSizeSubject = new BehaviorSubject<number>(50);
  public attendancePageSize$ = this.attendancePageSizeSubject.asObservable();
  attendanceArrLengthSubject = new BehaviorSubject<number>(0);
  public attendanceArrLength$ = this.attendanceArrLengthSubject.asObservable();
  attendancePageIndexSubject = new BehaviorSubject<number>(0);
  public attendancePageIndex$ = this.attendancePageIndexSubject.asObservable();
  private pageIndexRef: number = 0;
  private pageSizeRef: number = 50;
  private arrLengthRef: number = 0;
  filteredAttendancDataList: any = [];
  pageIndexSubRef: any;
  pageSizeSubRef: any;
  salaryReportList: any = [];

  constructor(private attendanceService: AttendanceService) {
    this.pageIndexSubRef = this.attendancePageIndex$.subscribe((index) => {
      this.pageIndexRef = index;
    });
    this.pageSizeSubRef = this.attendancePageSize$.subscribe((size) => {
      this.pageSizeRef = size;
    });
  }

  ngOnDestroy() {
    this.pageIndexSubRef.unsubscribe();
    this.pageSizeSubRef.unsubscribe();
  }

  connect(collectionViewer: CollectionViewer): Observable<any[]> {
    return this.attendanceSubject.asObservable();
  }

  disconnect(collectionViewer: CollectionViewer): void {
    this.attendanceSubject.complete();
    this.loadingSubject.complete();
  }

  getTime(value) {
    let ts = '';
    if (value) {
      ts = _moment(value).format('HH:mm:ss');
    }
    return ts;
  }

  getStatus(status) {
    switch (status) {
      case 0:
        return 'Närvaro';
      case 1:
        return 'Närvaro sen';
      case 2:
        return 'Sjuk';
      case 3:
        return 'Ogiltig frånvaro';
      case 4:
        return 'Ledighet';
      case 5:
        return 'Utbildning';
      case 6:
        return 'Sjuk Vab';
      case 7:
        return 'Ej Schemalagd';
      case 9:
        return 'Ledighet - påverkar timmarna';
      case 10:
        return 'Ledighet - påverkar inte timmarna';
      case 11:
        return 'Närvaro godkänd sen';
      default:
        return '';
    }
  }

  loadAttendanceOverview(searchData, pageConfig?: any, filterChange?: boolean, filterValue?: any) {

    this.loadingSubject.next(true);
    this.attendanceSubject.next([]);
    let resultarr: any = [];
    this.attendanceService.getAttendanceOverview(searchData).pipe(
      catchError(() => of([])),
      finalize(() => this.loadingSubject.next(false))
    )
      .subscribe(res => {
        if (res) {
          let completeAttendanceList = [];
          this.attendanceDataList = [];
          this.attendanceSubject.next([]);
          this.salaryReportList = res;
          if (res[0].data && res[0].data.length > 0) {
            if (this.salaryReportList[0].status) {
              this.salaryReportList[0].data.forEach((obj) => {
                obj.data.forEach((sdata) => {
                  if (obj.data && obj.data.length > 0) {
                    let toStoreAtt = sdata;
                    toStoreAtt.department_name = obj.department_name;
                    toStoreAtt.Status_id = this.getStatus(toStoreAtt.attendance_status_id);
                    toStoreAtt.In_time = toStoreAtt.department_intime;
                    toStoreAtt.Out_time = toStoreAtt.department_outtime;
                    toStoreAtt.allowEdit = false;
                    toStoreAtt.permissionHistory = [];
                    toStoreAtt.hasEmployeeRequestForPermission = false;
                    if (toStoreAtt.leave_details && toStoreAtt.leave_details.length > 0) {
                      toStoreAtt.leave_details.forEach((leaveObj) => {
                        if (leaveObj.fromdate == leaveObj.todate && leaveObj.start_time && leaveObj.end_time) {
                          toStoreAtt.permissionHistory.push(leaveObj);
                        }
                      });
                    }
                    if (toStoreAtt.permissionHistory.length > 0) {
                      toStoreAtt.hasEmployeeRequestForPermission = true;
                    }
                    toStoreAtt.user_count = obj.data.length;
                    completeAttendanceList.push(toStoreAtt);
                    this.attendanceDataList.push(toStoreAtt);
                    resultarr.push(toStoreAtt);
                  }
                });
              });
            }
          };
          this.filteredAttendancDataList = this.attendanceDataList;
          this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
          if (filterChange) {
            this.attendanceFilteredList(filterValue, pageConfig);
          } else {
            this.handleAttendancePaging(pageConfig);
          }
        } else {
          this.attendanceDataList = [];
          this.attendanceSubject.next([]);
          this.filteredAttendancDataList = this.attendanceDataList;
          this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
          this.handleAttendancePaging();
        }
      }, err => {
        this.attendanceDataList = [];
        this.attendanceSubject.next([]);
        this.filteredAttendancDataList = this.attendanceDataList;
        this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
        this.handleAttendancePaging();
      });
  }

  attendancePageFilter(toFilterArr) {
    let tempObj: any = {};
    let toRetArr = [];
    toFilterArr.forEach((listObj) => {
      if (listObj.department_name != tempObj.department_name) {
        toRetArr.push({ department_name: listObj.department_name + ' (' + listObj.user_count + ')', extend: true });
        tempObj.department_name = listObj.department_name;
      }
      toRetArr.push(listObj);
    });
    return toRetArr;
  }

  attendanceArrPageIterator() {
    let start = this.pageIndexRef * this.pageSizeRef;
    let end = (this.pageIndexRef + 1) * this.pageSizeRef;
    let tempAttendanceArr = this.filteredAttendancDataList.slice(start, end);
    let toRetAttendanceArr = this.attendancePageFilter(tempAttendanceArr);
    this.attendanceSubject.next(toRetAttendanceArr);
  }

  handleAttendancePaging(event?) {
    if (event) {
      this.attendancePageIndexSubject.next(event.pageIndex);
      this.attendancePageSizeSubject.next(event.pageSize);
    } else {
      this.attendancePageIndexSubject.next(0);
      this.attendancePageSizeSubject.next(50);
    }
    this.attendancePageIndex$.subscribe((index) => {
      this.pageIndexRef = index;
    });
    this.attendancePageSize$.subscribe((size) => {
      this.pageSizeRef = size;
    });
    this.attendanceArrPageIterator();
  }

  attendanceFilteredList(filterData, pageConfig) {
    let toRetAttendanceArr: any = this.filterList(filterData);
    this.filteredAttendancDataList = toRetAttendanceArr;
    this.attendanceSubject.next(toRetAttendanceArr);
    this.attendanceArrLengthSubject.next(this.filteredAttendancDataList.length);
    this.handleAttendancePaging(pageConfig);
  }

  filterList(filterValue) {
    let filteredArr = this.attendanceDataList.filter((item) => {
      let filterString = '';
      filterString = filterString.trim().toLowerCase();
      filterValue = filterValue.toLowerCase();
      return filterString.indexOf(filterValue) != -1;
    });
    return filteredArr;
  }
}
