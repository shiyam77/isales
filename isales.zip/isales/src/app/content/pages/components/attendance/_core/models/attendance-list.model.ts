export class AttendanceList {
}
