import { Component, OnInit, ViewChild ,ChangeDetectorRef} from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { DaterangepickerDirective, DaterangepickerComponent } from 'ngx-daterangepicker-material';
import { AttendanceService } from '../_core/services/attendance.service';

type AOA = any[][];

@Component({
  selector: 'm-statistics',
  templateUrl: './statistics.component.html',
  styleUrls: ['./statistics.component.scss']
})
export class StatisticsComponent implements OnInit {

  totalTime:any;
  totalQty:any;

  selected: {startDate: any, endDate: any};
  @ViewChild(DaterangepickerDirective) pickerDirective: DaterangepickerDirective;
  picker: DaterangepickerComponent;

  isExtendedRow = (index, item) => item.extend;

  modalFormGroup: FormGroup;
  deleteEmpModalRef:any;
  closeResult: string;
  totalDeptReportArray:Array<any> =[];

  dataSource:MatTableDataSource<any>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  arrToPrint:AOA = [];
  
  getuserData:any;
  userData:any = {
    role:'',
    id:null
  };
  loader:boolean = false;  
  displayColumnToShow = ['firstname','lastname'];
  allStatisticsList : any [] = [];
  xpandStatus:boolean = false;
  searchInput:string = '';
  statisticsList:any = [];
  totalHoursList:any = [];

  toggleColumns = [
    {arrIndex:1,column:'first_name',checked:true,label:'first_name'},
    {arrIndex:2,column:'last_name',checked:true,label:'last_name'},
    {arrIndex:3,column:'Hours',checked:true,label:'Hours'},
    {arrIndex:4,column:'salj',checked:true,label:'salj'},
    {arrIndex:5,column:'snitt',checked:true,label:'snitt'},
    {arrIndex:6,column:'narvaro',checked:true,label:'narvaro'},
    {arrIndex:7,column:'narvarogodkantsen',checked:true,label:'narvarogodkantsen'},
    {arrIndex:8,column:'sick',checked:true,label:'sick'},
    {arrIndex:9,column:'invalidAbsence',checked:true,label:'invalidAbsence'},
    {arrIndex:10,column:'approvedAbsence',checked:true,label:'approvedAbsence'},
    {arrIndex:11,column:'attendanceEducation',checked:true,label:'attendanceEducation'},
    {arrIndex:12,column:'sickvab',checked:true,label:'sickvab'},
  ];
  itemsPerPage: number = 50;
  itemsInPageList:Array<number> = [50,100,500];

  spinner: SpinnerButtonOptions = {
		active: false,
		spinnerSize: 18,
		raised: true,
		buttonColor: 'primary',
		spinnerColor: 'accent',
		fullWidth: false
  };

  selection:SelectionModel<any>;
  
  constructor(private attendanceService: AttendanceService, private modalService: NgbModal,private _formBuilder: FormBuilder,private translate: TranslateService,private _ref: ChangeDetectorRef) { 
    this.selected = {
      startDate: moment(),
      endDate: moment()
    }
  }

  ngOnInit() {
    this.setExcelHeaders();    
    this.dataSource = new MatTableDataSource<any>();
    this.getuserData = this.attendanceService.getRoleAndId();
    this.getuserData.role.subscribe(role =>{
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id =>{
      if(id){
        this.userData.id = parseInt(id);
      }      
    });

    this.modalFormGroup = this._formBuilder.group({
      kund: ['', Validators.required],
      attendance_name:['', Validators.required],
      summain: ['', Validators.required],
      summaut: ['', Validators.required],
      fromdate: ['', Validators.required],
      todate: ['', Validators.required],
      notes:[''],
      godkand:['']
    });

  }
  
  applyDate(evt){
    this.loadStatisticsList();
  }

  open(e) {
    this.pickerDirective.open(e);
    
  }

  clear(e) {
    this.selected = null;
  }
  
  calculateEmployeeTotalHours(totHoursVal,statuswiseHoursVal){
    let additionalHours:number = 0;
    let additionalMinutes:number = 0;
    let getTotHoursVal:any[] = this.getHourAndMin(totHoursVal);
    let toReturnHoursAndMin = '';
    let getStatuswiseHoursVal:any[] = this.getHourAndMin(statuswiseHoursVal);
    if(getTotHoursVal && getTotHoursVal.length > 0){
        if(getStatuswiseHoursVal && getStatuswiseHoursVal.length > 0){
            additionalHours = Math.floor((parseInt(getStatuswiseHoursVal[1]) + parseInt(getTotHoursVal[1]))/60);
            additionalMinutes = (parseInt(getStatuswiseHoursVal[1]) + parseInt(getTotHoursVal[1]))%60;
            let toReturnHour:any = parseInt(getStatuswiseHoursVal[0]) + parseInt(getTotHoursVal[0]) + additionalHours;
            let toReturnMin:any = additionalMinutes;
            if(toReturnHour <= 0){
                toReturnHour = '00';
            }
            if(toReturnMin <=0){
                toReturnMin = '00';
            }
            toReturnHoursAndMin =  toReturnHour + ':' + toReturnMin; 
            return toReturnHoursAndMin;
        }
    }        
}

private getHourAndMin(time){
    if(time){     
        let separateTime= time.split(':');
        return separateTime;
      }else{
        return [];
    }
}

setStatuswiseDaysCount(status,toShowObj,resObj){
    toShowObj.Hours = this.calculateEmployeeTotalHours(toShowObj.Hours,resObj.Hours);
    switch(status) {
        case 0:{
            toShowObj.presenceDaysCount = resObj.dayscount;
        };
        break;    
        case 1:{
            toShowObj.presenceLateDaysCount = resObj.dayscount;
        };
        break;
        case 2:{
            toShowObj.sickDaysCount = resObj.dayscount;
        };
        break;
        case 3:{
            toShowObj.invalidAbsenceDaysCount = resObj.dayscount;
        };
        break;
        case 4:{
            toShowObj.approvedAbsenceDaysCount = resObj.dayscount;
        };
        break;
        case 5:{
            toShowObj.preseceEduDaysCount = resObj.dayscount;
        };
        break;
        case 6:{
            toShowObj.sickVabDaysCount = resObj.dayscount;
        };
        break;
        case 11:{
          toShowObj.presenceApprovedDaysCount = resObj.dayscount;
        };
        break;        
        default:{
            toShowObj.notScheduledDaysCount = resObj.dayscount;
        };
        break;
    }        
}


  loadDepartmentwiseTotal(){

  this.totalTime = {};
  this.totalQty = {};

  //need to set daterange
  //let searchDate = Moment(this.dateFormGroup.controls.attendancedate.value).format('YYYY-MM-DD');
  this.attendanceService.getStatisticsDepartmentWiseTotalHoursByDateRange(this.selected).subscribe(res =>{
    if(res){
        this.totalTime.totalpresenceQty = 0;
        this.totalTime.totalpresenceLateQty= 0;
        this.totalTime.totalpresenceApprovedQty= 0;
        this.totalTime.totalsickQty= 0;
        this.totalTime.totalinvalidAbsenceQty= 0;
        this.totalTime.totalapprovedAbsenceQty= 0;
        this.totalTime.totalpresenceEduQty= 0;
        this.totalTime.totalsickVabQty= 0;
        this.totalTime.TotaltotalQty = 0;

        this.totalQty.TotalpresenceHours = 0;
        this.totalQty.TotalpresenceLateHours = 0;
        this.totalQty.TotalpresenceApprovedHours = 0;
        this.totalQty.TotalsickHours = 0;
        this.totalQty.TotalinvalidAbsenceHours = 0;
        this.totalQty.TotalapprovedAbsenceHours = 0;
        this.totalQty.TotalpresenceEduHours = 0;
        this.totalQty.TotalsickVabHours = 0;
        this.totalQty.Totaltotaltime = 0; 

        if(res.Grandtotal){
          this.totalQty.Totaltotaltime  = this.getTotalTime(res.Grandtotal);
          this.totalTime.TotaltotalQty = res.TotalMandays;
        }

      this.totalDeptReportArray = [];
      res.Department_wise_Report.forEach((obj)=>{
        let tempObj: any = {
          department: obj.Department,
        };
        
        if(obj.Row_wise_Total){
          obj.Row_wise_Total.forEach((rObj)=>{
            rObj.StatuswiseReport.forEach((sObj)=>{ 

            tempObj.totalqty = rObj.TotalMandays;
            tempObj.totaltime = this.getTotalTime(rObj.Totalhours);

              let time=this.getTotalTime(sObj.Hours);
              switch(sObj.Status) {
                case 0:{
                  tempObj.presenceHours = time;
                  tempObj.presenceQty = sObj.Mandays;  
                  this.totalTime.totalpresenceQty += sObj.Mandays;  
                };              
                break;
                case 1:{
                  tempObj.presenceLateHours = time;
                  tempObj.presenceLateQty = sObj.Mandays; 
                  this.totalTime.totalpresenceLateQty =+ sObj.Mandays;  
                };    
                break;               
                case 2:{
                  tempObj.sickHours = time;
                  tempObj.sickQty = sObj.Mandays;  
                  this.totalTime.totalsickQty =+ sObj.Mandays;  
                };    
                break;
                case 3:{
                  tempObj.invalidAbsenceHours = time;
                  tempObj.invalidAbsenceQty = sObj.Mandays;  
                  this.totalTime.totalinvalidAbsenceQty =+ sObj.Mandays;                     
                };   
                break;
                case 4:{
                  tempObj.approvedAbsenceHours = time;
                  tempObj.approvedAbsenceQty = sObj.Mandays;  
                  this.totalTime.totalapprovedAbsenceQty =+ sObj.Mandays;  
                };    
                break;
                case 5:{
                  tempObj.presenceEduHours = time;
                  tempObj.presenceEduQty = sObj.Mandays;  
                  this.totalTime.totalpresenceEduQty =+ sObj.Mandays;  
                };    
                break;
                case 6:{
                  tempObj.sickVabHours = time;
                  tempObj.sickVabQty = sObj.Mandays;  
                  this.totalTime.totalsickVabQty =+ sObj.Mandays;  
                };    
                break;
                case 11:{
                  tempObj.presenceApprovedHours = time;
                  tempObj.presenceApprovedQty = sObj.Mandays; 
                  this.totalTime.totalpresenceApprovedQty =+ sObj.Mandays;  
                };                  
                default:{
                  tempObj.notScheduledHours = '';
                  tempObj.notScheduledQty = '';
                };    
                break;           
              }            
            });
          });
        }
        this.totalDeptReportArray.push(tempObj);
        
      });
      if(res.Column_wise_Total){
        res.Column_wise_Total.forEach((cObj)=>{
          switch(cObj.Status) {
            case 0:{
              this.totalQty.TotalpresenceHours = this.getTotalTime(cObj.Hours);
              this.totalTime.totalpresenceQty = cObj.Mandays;       
            };              
            break;
            case 1:{
              this.totalTime.totalpresenceLateQty = cObj.Mandays;  
              this.totalQty.TotalpresenceLateHours =this.getTotalTime(cObj.Hours);
            };    
            break;               
            case 2:{
              this.totalTime.totalsickQty =  cObj.Mandays;  
              this.totalQty.TotalsickHours =this.getTotalTime(cObj.Hours);
            };    
            break;
            case 3:{
              this.totalTime.totalinvalidAbsenceQty =  cObj.Mandays;  
              this.totalQty.TotalinvalidAbsenceHours =this.getTotalTime(cObj.Hours);           
            };   
            break;
            case 4:{
              this.totalTime.totalapprovedAbsenceQty =  cObj.Mandays;  
              this.totalQty.TotalapprovedAbsenceHours =this.getTotalTime(cObj.Hours);         
            };    
            break;
            case 5:{
              this.totalTime.totalpresenceEduQty =  cObj.Mandays;  
              this.totalQty.TotalpresenceEduHours =this.getTotalTime(cObj.Hours);
            };    
            break;
            case 6:{
              this.totalTime.totalsickVabQty =  cObj.Mandays;  
              this.totalQty.TotalsickVabHours =this.getTotalTime(cObj.Hours);             
            };    
            break;
            case 11:{
              this.totalTime.totalpresenceApprovedQty = cObj.Mandays;  
              this.totalQty.TotalpresenceApprovedHours =this.getTotalTime(cObj.Hours);
            };                
            default:{
              
            };    
            break;           
          }   
        });
      }
    }
    this._ref.detectChanges();
  },err=>{
    this.totalDeptReportArray = [];
    this.totalTime = {};
    this.totalQty = {};
    this._ref.detectChanges();
  })
  }

  getTotalTime(time){
    if(time){     
      let tims= time.split(':');
      return tims[0]+':'+tims[1];
    }else{
      return '';
    }
  }

  loadStatisticsList() {
    this.loadDepartmentwiseTotal();
    this.loader = true;
    this.selection.clear();
    
    let resultarr = [];

    if(this.userData.role === 'admin' || this.userData.role === 'superadmin'){
      this.attendanceService.getStatisticsDepartmentWiseReportByDateRange(this.selected).subscribe(res =>{
        
        let completeAttendanceList =[];
        
        res.forEach((obj)=>{
          if(obj.StatuswiseReport){
            obj.StatuswiseReport.forEach((aObj)=> {
                let toShowAtt:any = {
                    first_name:aObj.first_name,
                    last_name:aObj.last_name,
                    Hours:'00:00'
                };
                aObj.StatuswiseReport.forEach((sObj)=>{
                    this.setStatuswiseDaysCount(sObj.Status,toShowAtt,sObj);   
                }); 
                completeAttendanceList.push(toShowAtt);                                   
            });
          }
        });

        this.dataSource = new MatTableDataSource(completeAttendanceList);
        
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.sortingDataAccessor = (item,property) => {  
            let sortString = property.split('.').reduce((o,i)=>o[i],item);
            if(typeof sortString === 'string'){
              sortString = sortString.toLowerCase();
            }
            return sortString;
        }
        this._ref.detectChanges();
        this.loader = false;
      },err=>{
        
        this.loader = false;
        this._ref.detectChanges();
      });
    }		
    this.selection.clear();
    this.showHideCols();    
  }



  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.filterPredicate = (item,filter) =>{
      let filterString = item.first_name + item.last_name + item.Hours + item.presenceDaysCount  + item.presenceLateDaysCount  + item.presenceApprovedDaysCount  + item.sickDaysCount  + item.invalidAbsenceDaysCount  + item.approvedAbsenceDaysCount  + item.preseceEduDaysCount  + item.sickVabDaysCount;
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1; 
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  private setExcelHeaders(){
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj)=>{
      this.arrToPrint[0].push(obj.column);
    });
  }

  private setExcelValues(){    
    this.statisticsList.forEach((val)=>{
      let newLine = [];      
      this.toggleColumns.forEach((obj)=>{
        if(obj.arrIndex !== 11){
          if(obj.arrIndex === 18 
            || obj.arrIndex === 20 || obj.arrIndex === 21 
            || obj.arrIndex === 22 || obj.arrIndex === 23){
              if(obj.arrIndex === 18) {               
                  newLine.push('True');                              
                }else{
                  newLine.push('False');
                }
          }else{
            let str = obj.label.split('.').reduce((o,i)=>o[i],val);            
            newLine.push(str);
          }
        }
      });
      this.arrToPrint.push(newLine);
    });
  }

  expandSearch(e,searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';      
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols(){
    this.displayColumnToShow = [];
    this.toggleColumns.forEach((obj,ind)=>{
      if(obj.checked){
        if(this.userData.role === 'admin' || this.userData.role === 'superadmin'){
          this.displayColumnToShow.push(obj.label);
        }     
      }      
    });    
  }

  generateAndDownloadDoc(){
    if(this.userData.role === 'admin' || this.userData.role === 'superadmin'){
      /* generate worksheet */
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Employee_List_'+_moment().format('x')+'.xls',{bookType:'xls',type:'array'});
    }    
  }

  openModal(content,contentAccessId,totimersattning?) {
    if(content === 'create'){
      this.modalFormGroup.reset();
      this.deleteEmpModalRef = this.modalService.open(contentAccessId,{ windowClass: 'create-timersattning-modal'});    
    }else if(content === 'update'){   
      this.modalFormGroup.patchValue({
        attendance_name: totimersattning.attendance_name,
        kund: totimersattning.kund,
        summain:totimersattning.summain,
        summaut:totimersattning.summaut,
        fromdate: totimersattning.fromdate,
        todate: totimersattning.todate,
      });
      this.deleteEmpModalRef = this.modalService.open(contentAccessId,{ windowClass: 'create-timersattning-modal'});    
    }else if(content === 'delete'){      
      this.deleteEmpModalRef = this.modalService.open(contentAccessId,{ windowClass: 'delete-timersattning-modal'});    
    }

    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
        return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
        return 'by clicking on a backdrop';
    } else {
        return  `with: ${reason}`;
    }
  }

  getStatisticsTotalHoursByDateRange(){
    if(this.userData.role === 'admin' || this.userData.role === 'superadmin'){
      this.attendanceService.getStatisticsDepartmentWiseTotalHoursByDateRange(this.selected).subscribe(res =>{
        if(res){
          this.totalHoursList = res;
        }
      });
    }
  }
}