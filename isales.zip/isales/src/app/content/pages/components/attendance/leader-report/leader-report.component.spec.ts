import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaderReportComponent } from './leader-report.component';

describe('LeaderReportComponent', () => {
  let component: LeaderReportComponent;
  let fixture: ComponentFixture<LeaderReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeaderReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaderReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
