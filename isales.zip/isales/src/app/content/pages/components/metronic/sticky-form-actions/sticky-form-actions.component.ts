import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'm-sticky-form-actions',
	templateUrl: './sticky-form-actions.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class StickyFormActionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
