import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
	selector: 'm-metronic',
	templateUrl: './metronic.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class MetronicComponent { }
