import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyAttendanceCalendarComponent } from './my-attendance-calendar.component';

describe('MyAttendanceCalendarComponent', () => {
  let component: MyAttendanceCalendarComponent;
  let fixture: ComponentFixture<MyAttendanceCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyAttendanceCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyAttendanceCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
