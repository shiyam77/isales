import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import * as _moment from 'moment';
import { Options } from 'fullcalendar';
import { CalendarComponent } from 'ng-fullcalendar';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { NgbModal, NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { Subject, ReplaySubject } from 'rxjs';
import { MatSelect } from '@angular/material';
import { takeUntil, take } from 'rxjs/operators';
const dateObj = new Date();
const yearMonth = dateObj.getUTCFullYear() + '-' + (dateObj.getUTCMonth() + 1);

@Component({
    selector: 'm-my-attendance-calendar',
    templateUrl: './my-attendance-calendar.component.html',
    styleUrls: ['./my-attendance-calendar.component.scss']
})
export class MyAttendanceCalendarComponent implements OnInit {

    empGroup: FormGroup;
    employee_id: string;
    empArr: Array<any> = [];
    userData: any = {};
    getUserData: any = {};
    total: any = {};
    role: any;
    calendarEventData: any = [];
    public config: any;
    scheduler: FormGroup;
    time1: NgbTimeStruct;
    time2: NgbTimeStruct;
    time3: NgbTimeStruct;
    note: string = '';
    leaves: boolean = false;
    days: string = '';
    start_dates: any;
    end_dates: any;
    start_time: FormControl;
    end_time: FormControl;
    lunch: FormControl;
    leave: FormControl;
    notes: FormControl;
    day: FormControl;
    stat: any;
    attendance_id: any;
    modalRef: any;

    leaveDate: FormControl;
    leaveNotes: FormControl;
    time = { hour: '', minute: '' };
    resMessage: {
        success?: boolean;
        error?: boolean;
        message?: string;
    } = {
            success: false,
            error: false,
            message: '',
        };
    statusArr: any = [{ id: 0, name: 'Närvaro' },
    { id: 1, name: 'Närvaro sen' },
    { id: 11, name: 'Närvaro godkänd sen' },
    { id: 2, name: 'Sjuk' },
    { id: 3, name: 'Ogiltig frånvaro' },
    { id: 4, name: 'Ledighet' },
    { id: 5, name: 'Utbildning' },
    { id: 6, name: 'Sjuk Vab' },
    { id: 7, name: 'Ej Schemalagd' }];
    @ViewChild('employeeSearchSelect') employeeSearchSelect: MatSelect;
    protected _onDestroy = new Subject<void>();
    empFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    attendanceStatuswiseSummaryData: any = {
        attendance_data: []
    };
    attendanceSummaryMonthYear: any = {
        month: '',
        year: ''
    };
    yearList = [new Date().getFullYear()];
    yearSelected = new Date().getFullYear();
    chartYearSelected = new Date().getFullYear();
    narvaroManadsvisData = {
        labelunit: 'Tim',
        backgroundColor: '#E7ADD5',
        data: {
            datasets: [
                {
                    label: 'E-checkin',
                    data: [],
                    backgroundColor: '#7d7d7d',
                },
                {
                    label: 'Loxysoft',
                    data: [],
                    backgroundColor: '#ef6a0f',
                },
                {
                    label: 'Månad',
                    data: [],
                    backgroundColor: '#121212',
                }
            ]
        },
        label: ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec']
    };
    showLegends: boolean = false;
    @ViewChild('attendanceChart') attendanceChart: any;
    monthList: any = [];
    monthSelected: any = 0;
    constructor(
        private personalService: PersonalService,
        private fb: FormBuilder,
        private sharedServices: SharedService,
        private _ref: ChangeDetectorRef,
        private modalService: NgbModal
    ) {
        this.getUserData = this.personalService.getRoleAndId();
        this.getUserData.userId.subscribe(id => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.getUserData.role.subscribe(role => {
            this.userData.role = role.toString();
        });
    }
    calendarOptions: Options;
    @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;
    html: any = '';

    ngOnInit() {
        this.empGroup = this.fb.group({
            empSelected: [null, Validators.required],
            employeeFilterControls: [''],
        });
        this.narvaroManadsvisData = {
            labelunit: 'Tim',
            backgroundColor: '#E7ADD5',
            data: {
                datasets: [
                    {
                        label: 'E-checkin',
                        data: [],
                        backgroundColor: '#7d7d7d',
                    },
                    {
                        label: 'Loxysoft',
                        data: [],
                        backgroundColor: '#ef6a0f',
                    },
                    {
                        label: 'Månad',
                        data: [],
                        backgroundColor: '#121212',
                    }
                ]
            },
            label: ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'],
        };
        this.calendarOptions = {
            editable: false,
            eventLimit: false,
            header: {
                left: 'prev,next',
                center: 'title',
                right: 'month,agendaWeek'
            },
            buttonText: {
                month: 'Månad',
                week: 'Vecka'
            },
            events: this.calendarEventData,
            locale: 'sv',
            droppable: false,
            eventStartEditable: false,
            eventDurationEditable: false,
            eventOverlap: false
        };
        this.createFormControls();
        this.scheduler = new FormGroup({
            start_time: this.start_time,
            end_time: this.end_time,
            lunch: this.lunch,
            notes: this.notes,
            leave: this.leave,
            statusid: new FormControl('')
        });
        this.empArr = [];
        this.yearList = [];
        for (let y = 0; (y <= 5); y++) {
            this.yearList.push(2020 + y);
        }
        this.monthList = [
            { number: 0, name: 'Alla' },
            { number: 1, name: 'Januari' },
            { number: 2, name: 'Februari' },
            { number: 3, name: 'Mars' },
            { number: 4, name: 'April' },
            { number: 5, name: 'Maj' },
            { number: 6, name: 'Juni' },
            { number: 7, name: 'Juli' },
            { number: 8, name: 'Augusti' },
            { number: 9, name: 'September' },
            { number: 10, name: 'Oktober' },
            { number: 11, name: 'November' },
            { number: 12, name: 'December' },
        ];
        this.monthSelected = 0;
        if (this.userData.role != 'admin' && this.userData.role != 'superadmin' && this.userData != 'teamleader') {
            this.empGroup.get('empSelected').setValue(this.userData.id);
        }
        this.loadEmployee();
        this.empGroup.controls['employeeFilterControls'].valueChanges
            .pipe(takeUntil(this._onDestroy)).subscribe(() => this._Empfilter());
        this.getAttendanceChartData();
    }

    createFormControls() {
        this.start_time = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.end_time = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.lunch = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.notes = new FormControl('');
        this.leave = new FormControl('');
        this.day = new FormControl('');
        this.leaveDate = new FormControl('');
        this.leaveNotes = new FormControl('');
    }

    get f() { return this.scheduler.controls; }

    getLeave(event) {
        if (event && event.id) {
            this.employee_id = this.userData.id;
            this.calendarEventData = [];
            var fromDate = _moment(this.ucCalendar.fullCalendar('getView').intervalStart).format('YYYY-MM-DD');
            var toDate = _moment(this.ucCalendar.fullCalendar('getView').intervalEnd).format('YYYY-MM-DD');
            this.getAttendanceStatuswiseSummary();
            this.personalService.calendarMonthly(this.userData.id, { start_date: fromDate, end_date: toDate }).subscribe(res => {
                if (res) {
                    if (res.length > 0) {
                        this.calendarEventData = [];
                        res.forEach((item, index) => {
                            if ((item.department_cal_details[0] && (item.department_cal_details[0].starttime !== "00:00:00" && item.department_cal_details[0].endtime !== "00:00:00")) || (item.status_id >= 0)) {
                                switch (item.status_id) {
                                    case 0:
                                        item.backgroundColor = "#70ad47";
                                        item.textColor = '#F8FBEF';
                                        break;
                                    case 1:
                                        item.backgroundColor = "#c3c341";
                                        item.textColor = '#0e0e0e';
                                        break;
                                    case 2:
                                        item.backgroundColor = "#d8a200";
                                        item.textColor = '#F8FBEF';
                                        break;
                                    case 3:
                                        item.backgroundColor = "#bd3530";
                                        item.textColor = '#F8FBEF';
                                        break;
                                    case 4:
                                        item.backgroundColor = "#7e04bb";
                                        item.textColor = '#F8FBEF';
                                        break;
                                    case 5:
                                        item.backgroundColor = "#296300";
                                        item.textColor = '#F8FBEF';
                                        break;
                                    case 6:
                                        item.backgroundColor = "#407fea";
                                        item.textColor = '#F8FBEF';
                                        break;
                                    case 9:
                                        item.backgroundColor = "#C8A2C8";
                                         item.textColor = '#F8FBEF';
                                        break;
                                    case 10:
                                        item.backgroundColor = "#FFC0CB";
                                        item.textColor = '#F8FBEF';
                                            break;
                                    case 11:
                                        item.backgroundColor = "#028A0F";
                                        item.textColor = '#F8FBEF';
                                            break;
                                    default:
                                        item.backgroundColor = "#a2a2a2";
                                        item.textColor = '#F8FBEF';
                                        break;
                                        
                                }
                                // if(item.status == "Ledighet - påverkar inte timmarna"){
                                //     item.backgroundColor = "#FFC0CB";
                                // }
                                // if(item.status == "Ledighet - påverkar timmarna"){
                                //     item.backgroundColor = "#C8A2C8";
                                // }
                                if (item.is_company_leave == 1) {
                                    item.backgroundColor = "#de9943";
                                }
                                this.calendarEventData.push(item);
                            }
                        });
                        this.ucCalendar.renderEvents(this.calendarEventData);
                    }
                }
            });
        }
    }

    loadEmployee() {
        this.empArr = [];
        this.sharedServices.getAllEmployees().subscribe(res => {
            if (this.userData.role == 'teamleader') {
                res.forEach((obj) => {
                    if (obj.role == 'sales') {
                        this.empArr.push({
                            id: obj.Employee_id,
                            name: obj.first_name + " " + obj.last_name
                        });
                    }
                });
            } else {
                res.forEach((obj) => {
                    this.empArr.push({
                        id: obj.Employee_id,
                        name: obj.first_name + " " + obj.last_name
                    });
                });
            }
            this._Empfilter();
        });
    }

    getView() {
        this.getLeave({ id: this.userData.id });
    }

    eventClick(evt, contentAccessId) {
        if ((this.userData.role == 'admin' || this.userData.role == 'superadmin' || this.userData.role == 'teamleader')) {
            this.days = evt.event.start._i;
            this.note = evt.event.notes;
            this.stat = evt.event.status != '' ? evt.event.status_id : "";
            this.attendance_id = (evt.event.attendance_id != '' && evt.event.status != '') ? evt.event.attendance_id : "";
            let start = evt.event.start_time;
            let end = evt.event.end_time;
            let lunch = evt.event.lunch;
            let time_start = start.split(":");
            let time_end = end.split(":");
            let time_lunch = lunch.split(":");
            this.time1 = { hour: parseInt(time_start[0]), minute: parseInt(time_start[1]), second: 0 };
            this.time2 = { hour: parseInt(time_end[0]), minute: parseInt(time_end[1]), second: 0 };
            this.time3 = { hour: parseInt(time_lunch[0]), minute: parseInt(time_lunch[1]), second: 0 };
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        }
    }

    updateTimings() {
        if (this.scheduler.invalid) {
            return;
        }
        let start_time_hour = this.scheduler.value.start_time.hour == 0 ? "00" : this.scheduler.value.start_time.hour;
        let start_time_minute = this.scheduler.value.start_time.minute == 0 ? "00" : this.scheduler.value.start_time.minute;
        let end_time_hour = this.scheduler.value.end_time.hour == 0 ? "00" : this.scheduler.value.end_time.hour;
        let end_time_minute = this.scheduler.value.end_time.minute == 0 ? "00" : this.scheduler.value.end_time.minute;
        let lunch_hour = this.scheduler.value.lunch.hour == 0 ? "00" : this.scheduler.value.lunch.hour;
        let lunch_minute = this.scheduler.value.lunch.minute == 0 ? "00" : this.scheduler.value.lunch.minute;
        let leave = this.scheduler.value.leave == true ? 1 : (this.attendance_id != '' && this.stat != '') ? 0 : 2;
        let input_data = {
            date: this.days,
            start_time: start_time_hour + ":" + start_time_minute,
            end_time: end_time_hour + ":" + end_time_minute,
            lunch: lunch_hour + ":" + lunch_minute,
            convertleave: this.scheduler.value.leave == true ? 1 : 0,
            notes: this.scheduler.value.notes,
            attendance_status: ((this.scheduler.value.statusid >= 0) && (this.scheduler.value.statusid < 7)) ? this.scheduler.value.statusid : ''
        };
        let id = (this.attendance_id == '' && this.stat == '') ? this.employee_id : this.attendance_id;
        this.personalService.calendarSchedule(this.employee_id, input_data, leave).subscribe(res => {
            if (res) {
                this.resMessage.success = true;
                this.resMessage.error = false;
                this.resMessage.message = "Uppdateras framgångsrikt";
                this.modalRef.close();
                this.getView();
            } else {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this.resMessage.message = "Uppdateras inte framgångsrikt";
            }
            this._ref.detectChanges();
        }, err => {
            this.resMessage.success = false;
            this.resMessage.error = true;
            this._ref.detectChanges();
        });
    }

    protected _Empfilter(): any[] {
        if (this.empArr.length <= 0) {
            return;
        }
        if (this.empGroup && this.empGroup.controls['employeeFilterControls'].value && (typeof this.empGroup.controls['employeeFilterControls'].value == 'string') && this.empGroup.controls['employeeFilterControls'].value.trim() != '') {
            const empfilterValue = this.empGroup.controls['employeeFilterControls'].value.toLowerCase();
            this.empFilteredOptions.next(
                this.empArr.filter(emp => (emp.name.toLowerCase().indexOf(empfilterValue) > -1))
            );
        } else {
            this.empFilteredOptions.next(this.empArr.slice());
            return;
        }
    }

    setIntialEmployeeSearch() {
        this.empFilteredOptions.pipe(take(1), takeUntil(this._onDestroy))
            .subscribe(() => {
            this.employeeSearchSelect.compareWith = (a: any, b: any) => a && b && ((a.id == b.id) || (a.personal_id == b.personal_id) || (a.loxysoft_id == b.loxysoft_id));
        });
    }

    setEmpFilterCtrl() {
        this.empGroup.patchValue({
            employeeFilterControls: this.empGroup.controls['empSelected'].value.name
        });
        this.getLeave(this.empGroup.controls['empSelected'].value);
    }

    getAttendanceStatuswiseSummary() {
        let yearSet = _moment(this.ucCalendar.fullCalendar('getView').intervalStart).format('YYYY');
        let monthSet = _moment(this.ucCalendar.fullCalendar('getView').intervalStart).format('MM');
        this.yearSelected = parseInt(yearSet);
        this.getAttendanceChartData();
        this.attendanceSummaryMonthYear = {
            year: yearSet,
            month: monthSet
        };
        this.personalService.getEmployeeAttendanceStatuswiseSummary(parseInt(this.userData.id), this.attendanceSummaryMonthYear).subscribe((resData) => {
            if (resData) {
                this.attendanceStatuswiseSummaryData = resData[0];
                this.attendanceStatuswiseSummaryData.total_hours = this.attendanceStatuswiseSummaryData.attendance_hours ? (this.attendanceStatuswiseSummaryData.attendance_hours.split(':')[0] + ':' + this.attendanceStatuswiseSummaryData.attendance_hours.split(':')[1] + ':' + this.attendanceStatuswiseSummaryData.attendance_hours.split(':')[2]) : '00:00:00';
                this.attendanceStatuswiseSummaryData.total_loxy_hours = this.attendanceStatuswiseSummaryData.loxysoft_hours ? (this.attendanceStatuswiseSummaryData.loxysoft_hours.split(':')[0] + ':' + this.attendanceStatuswiseSummaryData.loxysoft_hours.split(':')[1] + ':' + this.attendanceStatuswiseSummaryData.loxysoft_hours.split(':')[2]) : '00:00:00';
            }
        });
    }

    getAttendanceChartData() {
        let toSendReqData = {
            month: this.monthSelected,
            year: this.yearSelected
        };
        this.personalService.getAttendanceLoxysoftChartData(this.userData.id, toSendReqData).subscribe((resData) => {
            if (resData) {
                this.narvaroManadsvisData.label = [];
                let toSetArrData = [];
                if (this.monthSelected) {
                    let dayscount = new Date(this.yearSelected, this.monthSelected, 0).getDate();
                    for (let i = 0; i < dayscount; i++) {
                        let dt = i + 1;
                        toSetArrData.push("" + dt + "");
                    }
                    this.narvaroManadsvisData.label = toSetArrData;
                } else {
                    this.narvaroManadsvisData.label = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'];
                }
                this.narvaroManadsvisData.data.datasets[0].data = [];
                this.narvaroManadsvisData.data.datasets[1].data = [];
                this.narvaroManadsvisData.data.datasets[2].data = [];
                this.showLegends = false;
                this.attendanceChart.barChartLegend = false;
                this.attendanceChart.chartData.label = this.narvaroManadsvisData.label;
                if (resData.length > 0) {
                    resData.forEach((obj) => {
                        if (this.monthSelected) {
                            this.narvaroManadsvisData.data.datasets[0].data.push(parseFloat(obj.attendance_details).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[1].data.push(parseFloat(obj.loxysoft_details).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[2].data.push(parseFloat(obj.target_hours).toFixed(2));
                        } else {
                            this.narvaroManadsvisData.data.datasets[0].data.push(parseFloat(obj.worked_hours).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[1].data.push(parseFloat(obj.loxysoft_worked_hours).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[2].data.push(parseFloat(obj.target_hours).toFixed(2));
                        }
                    });
                    this.attendanceChart.barChartData = [];
                    if (this.attendanceChart.chartData.data && this.attendanceChart.chartData.data.datasets) {
                        for (let i = 0; i < this.attendanceChart.chartData.data.datasets.length; i++) {
                            this.attendanceChart.barChartData.push({ data: this.attendanceChart.chartData.data.datasets[i].data, backgroundColor: this.attendanceChart.chartData.data.datasets[i].backgroundColor, label: this.attendanceChart.chartData.data.datasets[i].label });
                        }
                        this.showLegends = true;
                        this.attendanceChart.barChartLegend = true;
                    } else {
                        this.attendanceChart.barChartData.push({ data: this.attendanceChart.chartData.data, backgroundColor: this.attendanceChart.chartData.backgroundColor });
                    }
                    this.attendanceChart.barChartLabels = this.narvaroManadsvisData.label;
                    this.attendanceChart.bcd.chart.config.data.labels = this.narvaroManadsvisData.label;
                    this.attendanceChart.bcd.chart.update();
                }
                setTimeout(() => {
                    this.attendanceChart.bcd.chart.update();
                }, 2000);
            }
            this._ref.detectChanges();
        });
    }

    eventRender(e) {
        this.html = ``;
        let status = [2, 3, 4, 6];
        e.event.hasEmployeeRequestForPermission = false;
        e.event.permissionHistory = [];
        e.event.leave_details.forEach((leaveObj) => {
            if (leaveObj.fromdate == leaveObj.todate && leaveObj.start_time && leaveObj.end_time) {
                e.event.permissionHistory.push(leaveObj);
                e.event.hasEmployeeRequestForPermission = true;
            }
        });
        if ((typeof e.event.status_id == 'undefined' || !status.includes(e.event.status_id)) && e.event.is_company_leave == 0) {
            if (e.event.attendance_details.length > 0 && (e.event.attendance_details[0].approval_status == 1) && (e.event.attendance_details[0].Godkand && e.event.attendance_details[0].Godkand == 2)) {
                if ((e.event.attendance_history && (e.event.attendance_history.length > 0)) || e.event.permissionHistory.length > 0) {
                    if (!!e.event.attendance_details[0].Note) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>                                
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>                                
                            </span>
                        </div>`;
                    }
                } else {
                    if (!!e.event.attendance_details[0].Note) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                }
            } else if (e.event.attendance_details.length > 0 && (e.event.attendance_details[0].approval_status != 1) && (e.event.attendance_details[0].Godkand && e.event.attendance_details[0].Godkand == 2)) {
                if (e.event.attendance_history.length > 0 || e.event.permissionHistory.length > 0) {
                    if (!!e.event.attendance_details[0].Note) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>                               
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>                                
                            </span>
                        </div>`;
                    }
                } else {
                    if (!!e.event.attendance_details[0].Note) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                }
            } else if (e.event.attendance_details.length > 0 && (e.event.attendance_details[0].approval_status == 1) && (e.event.attendance_details[0].Godkand && e.event.attendance_details[0].Godkand != 2)) {
                if (e.event.attendance_history.length > 0 || e.event.permissionHistory.length > 0) {
                    if (!!e.event.attendance_details[0].Note) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>                               
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>                                
                            </span>
                        </div>`;
                    }
                } else {
                    if (!!e.event.attendance_details[0].Note) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                }
            } else {
                if (e.event.permissionHistory.length > 0) {
                    this.html += ` <div class="fc-content"> 
                        <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}                            
                        </span>
                    </div>`;
                } else {
                    this.html += ` <div class="fc-content"> 
                        <span class="fc-title">
                            ${e.event.client != '' ? e.event.client + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                        </span>
                    </div>`;
                }
            }
            if (e.event.department_cal_details.length > 0) {
                let startHours = e.event.department_cal_details[0].starttime.split(':')[0];
                let startMins = e.event.department_cal_details[0].starttime.split(':')[1];
                let endHours = e.event.department_cal_details[0].endtime.split(':')[0];
                let endMins = e.event.department_cal_details[0].endtime.split(':')[1];
                this.html += `<div class="fc-content"><span class="fc-title">${e.event.department_cal_details.length > 0 ? (_moment().hours(startHours).minutes(startMins).format('HH:mm')) + ' - ' + (_moment().hours(endHours).minutes(endMins).format('HH:mm')) : (e.event.title)}</span>
                </div>`;
            }
            if (e.event.attendance_details.length > 0) {
                this.html += `<div class="fc-content">
                <span class="fc-title">${(e.event.attendance_details.length > 0) && e.event.attendance_details[0].In_time ? 'E-check in: ' + _moment(e.event.attendance_details[0].In_time).format('HH:mm') : ""} ${(e.event.attendance_details.length > 0) && e.event.attendance_details[0].Out_time ? ' Ut: ' + _moment(e.event.attendance_details[0].Out_time).format('HH:mm') : ""}</span>
                </div>`;
                this.html += `<div class="fc-content"><span class="fc-title">${(e.event.attendance_details.length > 0) && e.event.attendance_details[0].In_time && e.event.attendance_details[0].Out_time ? 'Total e-checkin: ' + _moment(e.event.attendance_details[0].total_time, 'HH:mm:ss', true).format('HH:mm') : ""}</span>
                </div>`;
            }
            if (e.event.loxysoft_details.length > 0) {
                this.html += `<div class="fc-content"><span class="fc-title">${(e.event.loxysoft_details.length > 0) && e.event.loxysoft_details[0].start_time ? 'Loxy in: ' + _moment(e.event.loxysoft_details[0].start_time).format('HH:mm') : ""} ${(e.event.loxysoft_details.length > 0) && e.event.loxysoft_details[0].end_time ? ' Ut: ' + _moment(e.event.loxysoft_details[0].end_time).format('HH:mm') : ""}</span>
                </div>`;
                this.html += `<div class="fc-content"><span class="fc-title">${(e.event.loxysoft_details.length > 0) && e.event.loxysoft_details[0].start_time && e.event.loxysoft_details[0].end_time ? 'Total loxysoft: ' + _moment(e.event.loxysoft_details[0].TotalTime, 'HH:mm:ss', true).format('HH:mm') : ""}</span>
                </div>`;
            }
            if (e.event.status != '') {
                if ((e.event.attendance_notes || (e.event.leave_details && e.event.leave_details[0] && e.event.leave_details[0].admin_notes)) && (e.event.attendance_details.length <= 0)) {
                    this.html += ` <div class="fc-content fc-event-status fc-status-link"> 
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                } else {
                    this.html += ` <div class="fc-content">
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                }
            }
        } else if (typeof e.event.status_id == 'undefined' && e.event.is_company_leave == 1) {
            this.html += ` <div class="fc-content"> 
                <span class="fc-title">${e.event.notes != '' ? e.event.notes : "ledigh"}</span>
            </div>`;
        } else {
            if (e.event.status != '') {
                if ((e.event.attendance_notes || (e.event.leave_details && e.event.leave_details[0] && e.event.leave_details[0].admin_notes))) {
                    this.html += ` <div class="fc-content fc-event-status fc-status-link"> 
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                } else {
                    this.html += ` <div class="fc-content"> 
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                }
            }
        }
        e.element.html(this.html)
    }

    mousePointerToggle(calendarEvent, PopoverElementRef) {
        if (calendarEvent.detail && calendarEvent.detail.event && calendarEvent.detail.event.status && (!!calendarEvent.detail.event.attendance_notes || (calendarEvent.detail.event.leave_details && calendarEvent.detail.event.leave_details[0] && !!calendarEvent.detail.event.leave_details[0].admin_notes)) && calendarEvent.type == 'eventMouseOver') {
            if ((calendarEvent.detail.event.leave_details && calendarEvent.detail.event.leave_details[0] && !!(calendarEvent.detail.event.leave_details[0].admin_notes))) {
                if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0]) {
                    calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0].setAttribute("data-tooltip", calendarEvent.detail.event.leave_details[0].admin_notes);
                }
            } else {
                if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0]) {
                    calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0].setAttribute("data-tooltip", calendarEvent.detail.event.attendance_notes);
                }
            }
        }
        else if (calendarEvent.detail && calendarEvent.detail.event && calendarEvent.detail.event.status && (!!calendarEvent.detail.event.attendance_notes || (calendarEvent.detail.event.leave_details && calendarEvent.detail.event.leave_details[0] && !!calendarEvent.detail.event.leave_details[0].admin_notes)) && calendarEvent.type == 'eventMouseOut') {
            if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0]) {
                calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0].removeAttribute("data-tooltip");
            }
        }

        if (calendarEvent.detail && calendarEvent.detail.event && (calendarEvent.detail.event.attendance_details[0] && calendarEvent.detail.event.attendance_details[0].approval_status == 1) && (calendarEvent.detail.event.attendance_details[0].Godkand && calendarEvent.detail.event.attendance_details[0].Godkand == 2) && calendarEvent.type == 'eventMouseOver') {
            if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0]) {
                calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0].setAttribute("data-tooltip", calendarEvent.detail.event.attendance_details[0].Note);
            }
        }
        else if (calendarEvent.detail && calendarEvent.detail.event && calendarEvent.detail.event.status && (calendarEvent.detail.event.attendance_details[0] && calendarEvent.detail.event.attendance_details[0].approval_status == 1) && (calendarEvent.detail.event.attendance_details[0].Godkand && calendarEvent.detail.event.attendance_details[0].Godkand == 2) && calendarEvent.type == 'eventMouseOut') {
            if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0]) {
                calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0].removeAttribute("data-tooltip");
            }
        }
    }

}
