import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule } from '@angular/router';
import { LayoutModule } from '../../../layout/layout.module';
import { PartialsModule } from '../../../partials/partials.module';
import { ListTimelineModule } from '../../../partials/layout/quick-sidebar/list-timeline/list-timeline.module';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { MatCardModule, MatDatepickerModule, MatSelectModule, MatFormFieldModule, MatInputModule, MatAutocompleteModule, MatSliderModule, MatListModule, MatButtonModule, MatIconModule, MatNativeDateModule, MatSlideToggleModule, MatCheckboxModule, MatMenuModule, MatTabsModule, MatTooltipModule, MatSidenavModule, MatProgressBarModule, MatProgressSpinnerModule, MatSnackBarModule, MatGridListModule, MatTableModule, MatExpansionModule, MatToolbarModule, MatSortModule, MatDividerModule, MatStepperModule, MatChipsModule, MatPaginatorModule, MatDialogModule, MatRadioModule } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { MomentDateModule } from '@angular/material-moment-adapter';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
import { PersonalService } from '../personal/_core/services/personal.service';
import { NgbAlertConfig, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MyAttendanceCalendarComponent } from './my-attendance-calendar/my-attendance-calendar.component';
import { MyAttendanceComponent } from './my-attendance.component';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
};

@NgModule({
	imports: [
		CommonModule,
		LayoutModule,
		PartialsModule,
		NgbModule,
		ListTimelineModule,
		WidgetChartsModule,
		FormsModule,
		ReactiveFormsModule,
		RouterModule.forChild([
			{
				path:'',
				component:MyAttendanceComponent,
				children:[
					{
						path:'',
						redirectTo:'calendar',
						pathMatch:'full'
					},
					{
						path:'calendar',
						component:MyAttendanceCalendarComponent       
					}
				]
      		}
		]),
		NgxPermissionsModule.forChild(),
		MatInputModule,
		MatDatepickerModule,
		MatFormFieldModule,
		MatAutocompleteModule,
		MatSliderModule,
		MatListModule,
		MatCardModule,
		MatSelectModule,
		MatButtonModule,
		MatIconModule,
		MatNativeDateModule,
		MatSlideToggleModule,
		MatCheckboxModule,
		MatMenuModule,
		MatTabsModule,
		MatTooltipModule,
		MatSidenavModule,
		MatProgressBarModule,
		MatProgressSpinnerModule,
		MatSnackBarModule,
		MatGridListModule,
		MatTableModule,
		MatExpansionModule,
		MatToolbarModule,
		MatSortModule,
		MatDividerModule,
		MatStepperModule,
		MatChipsModule,
		MatPaginatorModule,
		MatDialogModule,
		MatRadioModule,
		TranslateModule.forChild(),
		MomentDateModule,
		FullCalendarModule,
		NgxMatSelectSearchModule,
		PerfectScrollbarModule
	],
	providers: [
		PersonalService,
		NgbAlertConfig,
		{
		provide: PERFECT_SCROLLBAR_CONFIG,
		useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
		}
  	],
  	declarations: [MyAttendanceComponent, MyAttendanceCalendarComponent]
})
export class MyAttendanceModule { }
