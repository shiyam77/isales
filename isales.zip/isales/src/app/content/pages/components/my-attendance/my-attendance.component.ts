import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-my-attendance',
  templateUrl: './my-attendance.component.html',
  styleUrls: ['./my-attendance.component.scss']
})
export class MyAttendanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
