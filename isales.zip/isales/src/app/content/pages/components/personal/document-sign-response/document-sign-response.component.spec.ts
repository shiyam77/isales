import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentSignResponseComponent } from './document-sign-response.component';

describe('DocumentSignResponseComponent', () => {
  let component: DocumentSignResponseComponent;
  let fixture: ComponentFixture<DocumentSignResponseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentSignResponseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentSignResponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
