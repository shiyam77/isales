import { Component, OnInit, ViewChild, ChangeDetectorRef, ElementRef, Input, ViewChildren } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { MatPaginator, MatSort, MatStepper, MatTableDataSource, MatSelect, MatDatepicker } from '@angular/material';
import { PersonalService } from '../_core/services/personal.service';
import { CommonErrorStateMatcher } from '../../../../../core/models/common-error-state-matcher';
import * as Moments from "moment";
import { Employee, Contact } from '../_core/models/employee.model';
import { TranslateService } from '@ngx-translate/core';
import { DropdownConstants } from '../../../../../core/models/dropdown-constants';
import { Router } from '@angular/router';
import { SubheaderService } from '../../../../../core/services/layout/subheader.service';
import { CalendarComponent } from 'ng-fullcalendar';
import { Options } from 'fullcalendar';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { EconomyService } from '../../economy/_core/services/economy.service';
import { NgbModal, ModalDismissReasons, NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { FileUploader } from 'ng2-file-upload';
import { ApiEndpointConstants } from '../../../../../core/models/api-endpoint-constants';
import { BarChartComponent } from '../../../../partials/content/widgets/charts/bar-chart/bar-chart.component';
import { ImageCropperComponent, ImageCroppedEvent } from 'ngx-image-cropper';
import { ChartType, ChartOptions } from 'chart.js';
import { DecimalPipe } from '@angular/common';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { Subject, ReplaySubject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as pluginLabels from 'chartjs-plugin-labels';
import {default as _rollupMoment, Moment} from 'moment';
import * as _moment from 'moment';
const moment = _rollupMoment || _moment;

const URL = '';

@Component({
    selector: 'm-employee-form',
    templateUrl: './employee-form.component.html',
    styleUrls: ['./employee-form.component.scss'],
    providers: [ApiEndpointConstants, DecimalPipe]
})
export class EmployeeFormComponent implements OnInit {

    fromyear = new FormControl(moment());
  toyear = new FormControl(moment());
  chosenYearHandler(normalizedYear: Moment) {
    const ctrlValue = this.fromyear.value;
    ctrlValue.year(normalizedYear.year());
    this.fromyear.setValue(ctrlValue);
  }

  chosenMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.fromyear.value;
    ctrlValue.month(normalizedMonth.month());
    this.fromyear.setValue(ctrlValue);
   
    datepicker.close();
  }
  chosenToYearHandler(normalizedYear: Moment) {
    const ctrlValue = this.toyear.value;
    ctrlValue.year(normalizedYear.year());
    this.toyear.setValue(ctrlValue);
  }

  chosenToMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.toyear.value;
    ctrlValue.month(normalizedMonth.month());
    this.toyear.setValue(ctrlValue);
    datepicker.close();
  }
  

    errorMessage = "";
      from_month = new Date().getMonth() + 1;
      to_month = new Date().getMonth() + 1  
      from_year = new Date().getFullYear();
      to_year = new Date().getFullYear();
    loaderStatistics: boolean = true;
    loxyCreateOrupdate: string;
    updateLoxyID: any;
    updateEmployeeID: any;
    spinners = false;
    week: any = ["", { day: "Mån", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Tis", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Ons", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Tor", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Fre", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Lör", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Sön", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } }];

    schedule: FormGroup;
    timings: any = ["Fran", "Till", "Lunch"];
    errorMsg: string = '';
    espDetail: Array<any> = [];
    fTotOrder: number = 0;
    fRejOrder: number = 0;
    fTotProvision: number = 0;
    fTotTimlon: number = 0;
    fTotlon: number = 0;
    fTotLonInkSem: number = 0;
    fTotLonInkSoc: number = 0;
    fTotHour: number = 0;
    fTotMin: number = 0;
    fTotsec: number = 0;
    fTotTime: string = '00:00:00';
    fTotSnitt: number = 0;
    fTotEffective: number = 0;
    fTotWorkedHours: number = 0;
    fTotBusinessHours: number = 0;
    fTotIdleHours: number = 0;
    fsnittOrder: number = 0;
    reqFilterOptions: any;
    emp_dataSource: any = [];
    pieChartColors: Array<any>;
    pieChartAttendanceColors: Array<any>;
    datas: any = [];
    modalRef: any;
    closeResult: any;
    spinner: SpinnerButtonOptions = {
        active: false,
        spinnerSize: 18,
        raised: true,
        buttonColor: 'primary',
        spinnerColor: 'accent',
        fullWidth: false
    };
    resCreateMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    updateErrMsg: boolean;

    isSticky(column: string): boolean {
        return column === 'employee' ? true : false;
    }

    time1: NgbTimeStruct;
    time2: NgbTimeStruct;
    time3: NgbTimeStruct;
    note: string = '';
    leaves: boolean = false;
    days: string = '';
    start_dates: any;
    end_dates: any;
    calendarData: any = [];
    eventData: any = [];
    time = { hour: '', minute: '' };
    ctrl = new FormControl('', (control: FormControl) => {
        const value = control.value;
        if (!value) {
            return null;
        }
    });
    attendanceStatuswiseSummaryData: any = {
        attendance_data: []
    };
    attendanceSummaryMonthYear: any = {
        month: '',
        year: ''
    };
    employeedisplayedColumns: string[] = ['employee', 'totaltimmar', 'totalorder', 'snitt', 'effectivity', 'provperproduckt', 'totalprovperpro', 'timlon', 'totaltprovision', 'totalhourlysalary', 'totallon'];
    tottRowErr: boolean = false;
    tottRowNoRecord: boolean = false;
    xpandStatus: boolean = true;
    lonxpandStatus: boolean = false;
    dataSource: any;
    totalOrdersForIndvProducts: any = {};
    totalProvPerProd: any = [];
    productsForProject: any[] = [];
    prodtottRowErr: boolean = false;
    prodtottRowNoRecord: boolean = false;
    loader: boolean = false;
    loaderStatictics: boolean = true;
    projClientArr: Array<any> = [];
    clientsArr: Array<any> = [];
    clientSelected: any;
    projectSelected: any;
    salaryReportList: any = [];
    revenue: any;
    salary: any;
    salary_sem: any;
    salary_soc: any;
    profit: any;
    hourly_revenue: any;
    salary_percent: any;
    profit_percent: any;
    footerProductCountObj: any = {};
    calendarEventData: any = [];
    monthList = [
        { label: "Januari", value: 1 },
        { label: "Februari", value: 2 },
        { label: "Mars", value: 3 },
        { label: "April", value: 4 },
        { label: "Maj", value: 5 },
        { label: "Juni", value: 6 },
        { label: "Juli", value: 7 },
        { label: "Augusti", value: 8 },
        { label: "September", value: 9 },
        { label: "Oktober", value: 10 },
        { label: "November", value: 11 },
        { label: "December", value: 12 },
    ];
    chartMonthList = [
        { label: "Jan", value: 1 },
        { label: "Feb", value: 2 },
        { label: "Mar", value: 3 },
        { label: "Apr", value: 4 },
        { label: "Maj", value: 5 },
        { label: "Jun", value: 6 },
        { label: "Jul", value: 7 },
        { label: "Aug", value: 8 },
        { label: "Sep", value: 9 },
        { label: "Okt", value: 10 },
        { label: "Nov", value: 11 },
        { label: "Dec", value: 12 },
    ];
    yearList = [new Date().getFullYear()];
    monthSelected = new Date().getMonth() + 1;
    yearSelected = new Date().getFullYear();
    salaryTableYearSelected = new Date().getFullYear();
    salaryChartYearSelected = new Date().getFullYear();
    unchangedSelectedYear = null;
    unchangedSelectedMonth = null;
    calendarOptions: Options;
    @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;
    @Input() mode: String;
    @Input() readOnly: boolean = false;
    @Input() employeeId: number;
    isLinear = false;
    empLeave: FormGroup;
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    thirdFormGroup: FormGroup;
    fourthFormGroup: FormGroup;
    leaveList: FormGroup;
    provisionList: FormGroup;
    compensationList: FormGroup;
    fastionList: FormGroup;
    socialfeeList: FormGroup;
    vacationpayList: FormGroup;
    submitted = false;
    matcher = new CommonErrorStateMatcher();
    projectsArr: Array<any> = [];
    productsArr: Array<any> = [];
    recruitmentnArr: Array<any> = [];
    departmentArr: Array<any> = [];
    clientProjectsArr: Array<any> = [];
    clientsProductsArr: Array<any> = [];
    st4projectsArr: Array<any> = [];
    displayedColumns = ['sno', 'datetime', 'ipAddress'];
    displayedColumnsfamily = ['sno', 'name', 'type', 'contact', 'action'];
    displayedColumnsEmploymentHistory = ['sno', 'name', 'joinDate', 'resignationDate', 'experience', 'role', 'remarks', 'action'];
    displayedColumnsHealthHistory = ['sno', 'fromDate', 'toDate', 'remarks', 'action'];
    userData: any = {};
    getUserData: any = {};
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    employeeData: Employee = new Employee();
    changeView: any = {
        viewVal: "EmployeeInfo"
    };
    stat: any;
    attendance_id: any;
    userQRCode: string = btoa('test');
    resMessage: {
        success?: boolean;
        error?: boolean;
        message?: string;
    } = {
            success: false,
            error: false,
            message: '',
        };

    narvaroManadsvisData = {
        labelunit: 'Tim',
        backgroundColor: '#E7ADD5',
        data: {
            datasets: [
                {
                    label: 'E-checkin',
                    data: [],
                    backgroundColor: '#7d7d7d',
                },
                {
                    label: 'Loxysoft',
                    data: [],
                    backgroundColor: '#ef6a0f',
                },
                {
                    label: 'Månad',
                    data: [],
                    backgroundColor: '#121212',
                }
            ]
        },

        label: ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'],
    };

    @ViewChild('attendanceChart') attendanceChart: any = new BarChartComponent();

    narvaroReasonData = {
        labelunit: 'Hrs',
        backgroundColor: '#c8aee2',
        data: [10, 30, 120, 55, 80, 90, 110, 100, 81, 56, 150, 80],
        label: ['narvaro', 'narvaro-Godkant sen', 'Sjuk', 'Ogiltig Frånvaro', 'Godkand Frånvaro', 'Narvaro Utbildning', 'Sjuk Vab']
    }
    statusArr: any = [{ id: 0, name: 'Närvaro' },
    { id: 1, name: 'Närvaro sen' },
    { id: 11, name: 'Närvaro godkänd sen' },
    { id: 2, name: 'Sjuk' },
    { id: 3, name: 'Ogiltig frånvaro' },
    { id: 4, name: 'Ledighet' },
    { id: 5, name: 'Utbildning' },
    { id: 6, name: 'Sjuk Vab' },
    { id: 7, name: 'Ej Schemalagd' }];

    forsaljningRapportDiagramData = {
        backgroundColor: '#ef6a0f',
        data: {
            datasets: [
                {
                    label: 'Lön',
                    barPercentage: 0.5,
                    barThickness: 4,
                    maxBarThickness: 4,
                    data: [],
                    backgroundColor: '#ef6a0f',
                }]
        },
        label: ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'],
        labelunit: 'tkr',
        legendDisplay: false,
    };

    dropDownList: any = new DropdownConstants();
    semesterValList: Array<any> = [];
    fees = [
        { value: 31, viewValue: '31.42%' },
    ];

    private isSetProvisionAndCommission: any = {
        clientLoaded: false,
        projectLoaded: false,
        productLoaded: false,
        employeeLoaded: false
    };
    scheduler: FormGroup;
    clientProjectsSumArr: Array<any> = [];
    departmentCompensationList: FormGroup;
    userInitials: string;
    filedata: any[];
    uspFile: any[];
    showLegends: boolean;
    showAttendanceLegends: boolean;
    @ViewChild('salaryChart') salaryChart: any = new BarChartComponent();
    espDetailData: any = [];
    public uploader: FileUploader = new FileUploader({ url: URL, allowedMimeType: ['image/jpeg', 'image/jpg', 'image/png'] });
    scheduleStartDate: any = '';
    scheduleEndDate: any = '';
    minDate: any = Moments();
    isFromPastDate: boolean = false;
    isToPastDate: boolean = false;
    imageChangedEvent: any = '';
    croppedImage: any = '';
    showCropper = false;
    @ViewChild(ImageCropperComponent) imageCropper: ImageCropperComponent;
    showCroppedImage: boolean = false;
    st4ClientsArr: Array<any> = [];
    loxyHistoryDisplayColumnToShow: any = ['loxysoftid', 'fromdate', 'todate', 'created_at', 'edit'];
    tRowErr: boolean = false;
    tRowNoRecord: boolean = false;
    loxyDataSource: any = [];
    emp_status: string = 'G';
    empStatus: FormGroup;
    profileStatus: any = {};
    momentFormatDate = Moments;
    leaveDatasource: any = [];
    displayColumnToShow = ['fromdate', 'todate', 'starttime', 'endtime', 'created_at', 'notes', 'status', 'approval_note', 'actions'];
    addLeave: FormGroup;
    addLoxy: FormGroup;
    isLeavePendingList: boolean = true;
    isLeaveApprovedList: boolean = false;
    isLeaveRejectedList: boolean = false;
    itemsPerPage: number = 50;
    itemsInPageList: Array<number> = [50, 100, 500];
    leavetottRowErr: boolean = false;
    leavetottRowNoRecord: boolean = false;
    agreementDisplayColumnToShow = ['actions', 'fromDate', 'toDate', 'agreementNotes', 'status'];
    agreementDataSource: any = [];
    agreeRowErr: boolean = false;
    agreeNoRecord: boolean = false;
    agreementFormGroup: FormGroup = new FormGroup({});
    agreementId: any = '';
    agreementDownloadLink: any = '';
    allowStatusHistoryEdit: boolean = false;
    allowDeviceInfoEdit: boolean = false;
    statusHistoryList: any = [];
    attendanceHistory: any = [];
    hasEmployeeRequestForPermission: boolean = false;
    permissionHistory: any = [];
    selectedMode: string = 'leave';
    leaveId: any;
    loxyId: any;
    todayDate = Moments().unix();
    tomorrowDate = Moments(new Date()).add(1, 'days');
    modalFormGroup: FormGroup;
    modalInOutError: boolean = false;
    acMonthSelected: any = null;
    acMonthList: any = [];
    departmentHistoryDisplayColumnToShow: any = ['department', 'fromdate', 'todate'];
    departmentHistoryDataSource: any = [];
    targetHoursList: any = [];
    pieChartDatas: any = {};
    targetSource: any;
    bonusSource: any;
    tBonusRowErr: boolean = false;
    tBonusRowNoRecord: boolean = false;
    public pieChartLabels: any = ['Arbetade timmar', 'Måltimmar'];
    public pieChartData: any = [];
    public pieChartType: ChartType = 'pie';
    public pieChartLegend = true;
    public pieChartPlugins = [];
    public pieChartOptions: ChartOptions = {
        responsive: true
    };
    displayTargetColumnToShow = ['month_name', 'target_hours', 'loxysoft_worked_hours', 'loxy_percentage'];
    displayBonusColumnToShow = ['Employee', 'Total_hours', 'Recurit_bonus_default', 'Recuritment_bonus'];
    multiColFilter = {
        TotalTime: '',
        loxysoft_worked_hours: '',
        loxy_percentage: '',
        target_hours: '',
        month_name: ''
    };
    bonusColFilter = {
        Total_hours: '',
        Recuritment_bonus: '',
        Recurit_bonus_default: '',
        Employee: '',
    };
    contractBtnDisable: boolean = false;
    @ViewChild('targetChart') targetChart: any;
    individualBonusFormGroup: FormGroup;
    individualEmployeeBonusFormGroup: FormGroup;
    bonusCreateOrupdate: string;
    updateSettingsID: any = '';
    resUpdateeMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    individualBonusDataSource: any;
    individualEmployeeBonusDataSource: any;
    individualBonusColumnToShow = ['actions', 'Recurit_bonus', 'From_date', 'To_date', 'Created_date', 'Created_by'];
    individualEmployeeBonusColumnToShow = ['actions', 'Recurit_bonus', 'From_date', 'To_date', 'Created_date', 'Created_by'];
    recrutiedEmployeeList: any[] = [];
    disableIndividualRecruitmentBonus: boolean = false;
    disableIndividualEmployeeRecruitmentBonus: boolean = false;
    tIndBonusRowNoRecord: boolean = false;
    tIndEmpBonusNoRecord: boolean = true;
    indBonusMultiColFilter = {
        Recurit_bonus: '',
        From_date: '',
        To_date: '',
        Created_date: ''
    };

    indEmpBonusMultiColFilter = {
        Recurit_bonus: '',
        From_date: '',
        To_date: '',
        Created_date: '',
        employee_name: ''
    };

    tarRowErr: boolean = false;
    tarRowNoRecord: boolean = false;
    tomorrow = new Date(2017, 9, 20, 14, 34);
    timeLineList: any = [];
    recruitedEmployee: any = null;
    individualBonusId: any = null;
    @ViewChildren('timeLineComp') timeLineComp;
    toggleTimeLine: boolean = false;
    bonusSummaryData: any[] = [];
    bonusIndividualSummaryData: any[] = [];
    bonusEmployeeIndividualSummaryData: any[] = [];
    @ViewChild('recruitmentEmployeeSearchSelect') recruitmentEmployeeSearchSelect: MatSelect;
    protected _onRecEmpDestroy = new Subject<void>();
    recruitmentEmpFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    @ViewChild('referedEmployeeSearchSelect') referedEmployeeSearchSelect: MatSelect;
    protected _onRefEmpDestroy = new Subject<void>();
    referedEmpFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    initalLoader: boolean = false;
    displayIndividualTargetColumnToShow = ['actions', 'loxysoft_hours', 'Month', 'Year', 'Created_date', 'Created_by'];
    individualTargetSource: any;
    targetHoursFormGroup: FormGroup;
    targetCreateOrupdate: string = '';
    targetSettingsID: any = '';
    individualTargetColFilter = {
        Loxysoft_hours: '',
        Month: '',
        Year: '',
        Created_date: '',
        first_name: '',
        last_name: ''
    };
    indTarRowErr: boolean = false;
    indTarRowNoRecord: boolean = false;
    @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
    protected _onClientDestroy = new Subject<void>();
    clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    @ViewChild('departmentSearchSelect') departmentSearchSelect: MatSelect;
    protected _onDepDestroy = new Subject<void>();
    depFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    @ViewChild('roleListSearchSelect') roleListSearchSelect: MatSelect;
    protected _onRoleDestroy = new Subject<void>();
    roleFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    @ViewChild('extentSearchSelect') extentSearchSelect: MatSelect;
    protected _onExtentDestroy = new Subject<void>();
    extentFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

    employeeAttendanceNotes: string = '';
    adminAttendanceNotes: string = '';
    deleteEmpModalRef: any;

    addComment: FormGroup;
    commentDatasource: any = [];
    commenttottRowErr: boolean = false;
    commenttottRowNoRecord: boolean = false;
    commentsDisplayColumnToShow = ['created_at', 'created_by', 'comments'];
    espDetailList: any[] = [];

    pieChartstatisticsLabels: string[] = [];
    pieChartAttendanceLabels: string[] = [];
    pieChartstatisticsData: number[] = [];
    pieChartAttendanceData: number[] = [];
    pieChartListType: string[] = [];
    getUserstatisticsData: any = {};
    userstatisticsData: any = {
        role: '',
        id: null
    };
    referefBy = "0";
    statisticssalary = "0";
    attendanceTime = "0";
    attendanceDays = "0";
    report = "0";
    loadData: boolean = false;
    chart_visibility: boolean = true;
    form: FormGroup;
    constructor(
        private _formBuilder: FormBuilder,
        private personalService: PersonalService,
        private _ref: ChangeDetectorRef,
        private el: ElementRef,
        private translate: TranslateService,
        private router: Router,
        private subHeaderService: SubheaderService,
        private sharedServices: SharedService,
        private economyService: EconomyService,
        private modalService: NgbModal,
        private endpoints: ApiEndpointConstants,
        private numberPipe?: DecimalPipe
    )  { }


    checkRegEx = new RegExp('^([0 | \+[0-9]{1,5})?([6-9][0-9]{9})$');

    ngOnInit() {
        // this.form = this._formBuilder.group({
        //     fromdate: new FormControl(moment()),
        //     todate: new FormControl(moment()),
        //   });
        this.pieChartOptions = this.createOptions();
        this.pieChartPlugins = [pluginLabels];
        this.getSelectedData(true)
        // this.loadPieChart(this.userData.id);
        this.yearList = [];
        for (let y = 0; (y <= 5); y++) {
            this.yearList.push(2020 + y);
        }
        this.attendanceSummaryMonthYear.month = new Date().getMonth();
        this.attendanceSummaryMonthYear.year = new Date().getFullYear();

        this.calendarOptions = {
            editable: false,
            eventLimit: false,
            header: {
                left: 'prev,next',
                center: 'title',
                right: 'month,agendaWeek'
            },
            buttonText: {
                month: 'Månad',
                week: 'Vecka'
            },
            events: this.calendarEventData,
            locale: 'sv',
            droppable: false,
            eventStartEditable: false,
            eventDurationEditable: false,
            eventOverlap: false,
            showNonCurrentDates: false
        };
        this.acMonthList = [
            { number: 0, name: 'Alla' },
            { number: 1, name: 'Januari' },
            { number: 2, name: 'Februari' },
            { number: 3, name: 'Mars' },
            { number: 4, name: 'April' },
            { number: 5, name: 'Maj' },
            { number: 6, name: 'Juni' },
            { number: 7, name: 'Juli' },
            { number: 8, name: 'Augusti' },
            { number: 9, name: 'September' },
            { number: 10, name: 'Oktober' },
            { number: 11, name: 'November' },
            { number: 12, name: 'December' },
        ];
        this.acMonthSelected = 0;
        this.addLeave = this._formBuilder.group({
            fromdate: ['', [Validators.required]],
            todate: ['', [Validators.required]],
            note: ['', [Validators.required]],
            start_time: ['', Validators.required],
            end_time: ['', Validators.required],
            options: ['leave'],
            approval_note: ['']
        })
        this.addLoxy = this._formBuilder.group({
            fromdate: ['', [Validators.required]],
            todate: [''],
            loxysoft_id: ['', [Validators.required]],
            Employee_id: ['']

        });
        this.initializeAgreementFormControls();
        this.createFormControls();
        this.scheduler = new FormGroup({
            start_time: this.start_time,
            end_time: this.end_time,
            lunch: this.lunch,
            notes: this.notes,
            leave: this.leave,
            statusid: new FormControl('')
        });
        this.empLeave = this._formBuilder.group({
            'leaveNotes': ['', Validators.required],
            'leaveDate': ['', Validators.required]
        });
        this.empStatus = this._formBuilder.group({
            'startDate': ['', Validators.required],
            'endDate': ['', Validators.required],
            'status': ['', Validators.required]
        });
        this.changeView.viewVal = "EmployeeInfo";
        this.getUserData = this.personalService.getRoleAndId();
        this.getUserData.role.subscribe(role => {
            this.userData.role = role.toString();
        });
        this.getUserData.userId.subscribe(id => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.dropDownList.vacation_pay_list.forEach((val) => {
            let itemData = {};
            if (val === 'salary_12') {
                itemData = {
                    id: 12,
                    name: val
                }
            } 
            else if (val === 'salary_8') {
                itemData = {
                    id: 8,
                    name: val
                }
            } 
            else {
                itemData = {
                    id: 0,
                    name: val
                }
            }
            this.semesterValList.push(itemData);
        });
        this.firstFormGroup = this._formBuilder.group({
            personal_id: ['', Validators.required],
            email: ['', [Validators.required, Validators.email]],
            mobile: ['', [Validators.required]],
            zipcode: ['', Validators.required],
            first_name: [''],
            last_name: [''],
            landline: [''],
            address: [''],
            place: [''],
            itemRows: this._formBuilder.array([this.initItemRows()])
        });
        this.secondFormGroup = this._formBuilder.group({
            BankName: ['', Validators.required],
            AccountNumber: [''],
            ClearingNumber: ['']
        });
        this.thirdFormGroup = this._formBuilder.group({
            loxysoftid: [''],
            loxysoft: [false],
            vacation_pay: [''],
            role: ['', Validators.required],
            roleFilterControls: [''],
            extent: [''],
            extentFilterControls: [''],
            userstatus: [''],
            recruitment_id: [''],
            recruitmentEmployeeFilterControls: [''],
            department_group: ['', Validators.required],
            Semesterval: [''],
            semesterFilterControls: [''],
            refered_by: [''],
            refered: [false],
            referedEmployeeFilterControls: [''],
            visma_id: [''],
            departmentFilterControls: ['']
        });
        this.thirdFormGroup.controls['recruitmentEmployeeFilterControls'].valueChanges
            .pipe(takeUntil(this._onRecEmpDestroy)).subscribe(() => this._RecEmpfilter());

        this.thirdFormGroup.controls['referedEmployeeFilterControls'].valueChanges
            .pipe(takeUntil(this._onRecEmpDestroy)).subscribe(() => this._RefEmpfilter());


        this.fourthFormGroup = this._formBuilder.group({
            projects: [[]],
            clientFilterControls: [''],
            agreementRows: this._formBuilder.array([this.initAgreementRows()]),
            client: ['']
        });

        this.thirdFormGroup.controls['departmentFilterControls'].valueChanges
            .pipe(takeUntil(this._onDepDestroy)).subscribe(() => this._DepFilter());
        this.fourthFormGroup.controls['clientFilterControls'].valueChanges
            .pipe(takeUntil(this._onClientDestroy)).subscribe(() => this._ClientFilter());

        this.leaveList = this._formBuilder.group({
            leaveListFormArray: this._formBuilder.array([this.initLeaveListArr()])
        });

        this.modalFormGroup = this._formBuilder.group({
            fromdate: ['', Validators.required],
            loxysoft_id: ['', Validators.required],
            employee_id: [''],
            todate: [''],
            starttime: [{ hour: '', minute: '' }],
            finaltime: [{ hour: '', minute: '' }],
            lunchtime: [{ hour: '', minute: '' }],
            notes: [''],
        });

        this.provisionList = this._formBuilder.group({
            provisionListFormArray: this._formBuilder.array([])
        });

        this.compensationList = this._formBuilder.group({
            compensationListFormArray: this._formBuilder.array([])
        });

        this.fastionList = this._formBuilder.group({
            fastionListFormArray: this._formBuilder.array([this.initFastIonListArr()])
        });

        this.socialfeeList = this._formBuilder.group({
            socialfeeListFormArray: this._formBuilder.array([this.initSocialFeeListArr()])
        });

        this.vacationpayList = this._formBuilder.group({
            vacationpayListFormArray: this._formBuilder.array([this.initVacationPayListArr()])
        });

        this.departmentCompensationList = this._formBuilder.group({
            depCompensationListFormArray: this._formBuilder.array([])
        });
        this.individualBonusDataSource = new MatTableDataSource();
        this.individualEmployeeBonusDataSource = new MatTableDataSource();
        this.recrutiedEmployeeList = [];

        this.individualBonusFormGroup = this._formBuilder.group({
            recruit_bonus: ['', Validators.required],
            start_date: ['', Validators.required],
            end_date: ['']
        });
        this.individualEmployeeBonusFormGroup = this._formBuilder.group({
            recruit_bonus: ['', Validators.required],
            start_date: ['', Validators.required],
            end_date: [''],
            employee_id: ['']
        });
        this.targetHoursFormGroup = this._formBuilder.group({
            loxysoft_hours: ['', Validators.required],
            month: ['', Validators.required],
            year: ['', Validators.required]
        });
        this.getProductList();
        this.getProjectList();
        this.getClientList();
        this.getRecruitmentList();
        this.getDepartmentList();
        this.getEmployeeClientSelectionList();
        this.getLoxysoftHistoryData();
        this.getSettingList();
        this.getIndividualTargetHours();
        this.getIndividualBonusSettingList();
        this.getRecruitedEmployeeList();
       
        this.sharedServices.clientListSub$.subscribe((isClientListSet) => {
            if (isClientListSet) {
                this.clientsArr = this.sharedServices.clientListData;
                this.isSetProvisionAndCommission.clientLoaded = true;
                this.setProvisionAndCommission();
            }
        });
        this.sharedServices.projectListSub$.subscribe((isProjectListSet) => {
            if (isProjectListSet) {
                this.projectsArr = this.sharedServices.projectListData;
                this.projectsArr.sort(function (a, b) {
                    if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
                    if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
                    return 0;
                });
                this.isSetProvisionAndCommission.projectLoaded = true;
                this.projectsArr.forEach((obj) => {
                    this.st4projectsArr.push(obj);
                });
                this.setProvisionAndCommission();
            }
        });
        this.sharedServices.productListSub$.subscribe((isProductListSet) => {
            if (isProductListSet) {
                this.isSetProvisionAndCommission.productLoaded = true;
                this.productsArr = this.sharedServices.productListData;
                this.setProvisionAndCommission();
            }
        });
        this.sharedServices.departmentListSub$.subscribe((isDepartmentListSet) => {
            if (isDepartmentListSet) {
                this.departmentArr = this.sharedServices.departmentListData;
            }
        });
        if (this.mode === 'create') {
            let provArr = <FormArray>this.provisionList.controls['provisionListFormArray'];
            provArr.push(this.initProvisionListArr());

            let compArr = <FormArray>this.compensationList.controls['compensationListFormArray'];
            compArr.push(this.initCompensationListArr());
            this.subHeaderService.setBreadcrumbs([
                { title: 'Personnel', page: '/personal/employee/add', translate: 'MENU.PERSONNEL' },
                { title: 'Employee', page: '/personal/employee/add', translate: 'COMMON.EMPLOYEE' },
                { title: 'Employee Add', page: '/personal/employee/add', translate: 'MENU.PERSONAL.EMPLOYEE_ADD' }
            ]);

            let dCompArr = <FormArray>this.departmentCompensationList.controls['depCompensationListFormArray'];
            dCompArr.push(this.initDepCompensationListArr());

            if (this.userData.role != 'superadmin') {
                let saIndex = this.dropDownList.role_list.indexOf('superadmin');
                this.dropDownList.role_list.splice(saIndex, 1);
            }
        }
        if (this.mode === 'update' || this.mode === 'view') {
            if (this.mode === 'update') {
                this.subHeaderService.setBreadcrumbs([
                    { title: 'Personnel', translate: 'MENU.PERSONNEL' },
                    { title: 'Employee', translate: 'COMMON.EMPLOYEE' },
                    { title: 'Employee Edit', page: '/personal/employee/edit', translate: 'MENU.PERSONAL.EMPLOYEE_EDIT', queryParams: this.employeeId }
                ]);
            } else {
                this.subHeaderService.setBreadcrumbs([
                    { title: 'Personnel', translate: 'MENU.PERSONNEL' },
                    { title: 'Employee', translate: 'COMMON.EMPLOYEE' },
                    { title: 'Employee View', page: '/personal/employee/view', translate: 'MENU.PERSONAL.EMPLOYEE_VIEW', queryParams: this.employeeId }
                ]);
            }
            this.getEmployeeData();
            this.getAttendanceChartData();
            this.loadLeaveEmployee();
            this.getBonusList();
            this.loadEmployeeComments();
            if (this.mode == 'view') {
                this.disableIndividualRecruitmentBonus = true;
                this.disableIndividualEmployeeRecruitmentBonus = true;
            }
        }
        if (this.readOnly) {
            this.firstFormGroup.disable();
            this.secondFormGroup.disable();
            this.thirdFormGroup.disable();
            this.fourthFormGroup.disable();
            this.leaveList.disable();
            this.provisionList.disable();
            this.compensationList.disable();
            this.fastionList.disable();
            this.socialfeeList.disable();
            this.vacationpayList.disable();
            this.departmentCompensationList.disable();

        }
        let empfc = this;
        this.pieChartOptions = {
            responsive: true,
            tooltips: {
                callbacks: {
                    label: function (tooltipItem, data) {
                        let dataset = data.datasets[tooltipItem.datasetIndex];
                        // return formatted string here
                        return empfc.numberPipe.transform(dataset.data[tooltipItem.index], '', 'sv-SE');
                    }
                }
            }
        };
        this.dropDownList.role_list.sort(function (a, b) {
            if (a.toLowerCase() < b.toLowerCase()) { return -1; }
            if (a.toLowerCase() > b.toLowerCase()) { return 1; }
            return 0;
        });
        this.dropDownList.extent_list.sort(function (a, b) {
            if (a.toLowerCase() < b.toLowerCase()) { return -1; }
            if (a.toLowerCase() > b.toLowerCase()) { return 1; }
            return 0;
        });
        this.thirdFormGroup.controls['roleFilterControls'].valueChanges
            .pipe(takeUntil(this._onRoleDestroy)).subscribe(() => this._roleFilter());
        this._roleFilter();
        this.thirdFormGroup.controls['extentFilterControls'].valueChanges
            .pipe(takeUntil(this._onExtentDestroy)).subscribe(() => this._extentFilter());
        this._extentFilter();
        this.addComment = this._formBuilder.group({
            comments: ['', [Validators.required]]
        });
        this.pieChartstatisticsLabels = ['Ej Schemalagd', 'Ledighet', 'Narvaro', 'Narvaro Avvikelse', 'Narvaro Sen', 'Ogiltig Franvaro', 'Sjuk', 'Sjuk Vab'];
        this.pieChartAttendanceLabels = ['Attendance Time', 'Loxysoft Time'];
    }
    html: any = '';
    eventRender(e) {
        this.html = ``;
        let statusList = [2, 3, 4, 6];
        e.event.hasEmployeeRequestForPermission = false;
        e.event.permissionHistory = [];
        e.event.leave_details.forEach((leaveObj) => {
            if (leaveObj.fromdate == leaveObj.todate && leaveObj.start_time && leaveObj.end_time) {
                e.event.permissionHistory.push(leaveObj);
                e.event.hasEmployeeRequestForPermission = true;
            }
        });
        if ((typeof e.event.status_id == 'undefined' || !statusList.includes(e.event.status_id)) && e.event.is_company_leave == 0) {
            if (e.event.attendance_details.length > 0 && (e.event.attendance_details[0].approval_status == 1) && (e.event.attendance_details[0].Godkand && e.event.attendance_details[0].Godkand == 2)) {
                if (e.event.attendance_history.length > 0 || e.event.permissionHistory.length > 0) {
                    if (!!e.event.attendance_details[0].Note || e.event.attendance_details[0].emp_notes) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="info-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="info-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                } else {
                    if (!!e.event.attendance_details[0].Note || e.event.attendance_details[0].emp_notes) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                }
            } else if (e.event.attendance_details.length > 0 && (e.event.attendance_details[0].approval_status != 1) && (e.event.attendance_details[0].Godkand && e.event.attendance_details[0].Godkand == 2)) {
                if ((e.event.attendance_history && (e.event.attendance_history.length > 0)) || e.event.permissionHistory.length > 0) {
                    if (!!e.event.attendance_details[0].Note) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="info-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="info-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                } else {
                    if (!!e.event.attendance_details[0].Note || e.event.attendance_details[0].emp_notes) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="e-checkin-problem-indicator m-animate-blink"> </div>
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                }
            } else if (e.event.attendance_details.length > 0 && (e.event.attendance_details[0].approval_status == 1) && (e.event.attendance_details[0].Godkand && e.event.attendance_details[0].Godkand != 2)) {
                if (e.event.attendance_history.length > 0 || e.event.permissionHistory.length > 0) {
                    if (!!e.event.attendance_details[0].Note || e.event.attendance_details[0].emp_notes) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="info-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <div class="info-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }
                } else {
                    if (!!e.event.attendance_details[0].Note || e.event.attendance_details[0].emp_notes) {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon approve-notes">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    } else {
                        this.html += ` <div class="fc-content"> 
                            <span class="fc-title">
                                ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                                <div class="approve-icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </span>
                        </div>`;
                    }

                }
            } else {
                if (e.event.permissionHistory.length > 0) {
                    this.html += ` <div class="fc-content"> 
                        <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                            <div class="info-icon">
                                <i class="fas fa-info-circle"></i>
                            </div>
                        </span>
                    </div>`;
                } else {
                    this.html += ` <div class="fc-content"> 
                        <span class="fc-title">
                            ${e.event.project != '' ? e.event.project + '&nbsp;/&nbsp;' : ""}${e.event.department != '' ? e.event.department : ""}
                        </span>
                    </div>`;
                }
            }

            if (e.event.department_cal_details.length > 0) {
                let startHours = e.event.department_cal_details[0].starttime.split(':')[0];
                let startMins = e.event.department_cal_details[0].starttime.split(':')[1];
                let endHours = e.event.department_cal_details[0].endtime.split(':')[0];
                let endMins = e.event.department_cal_details[0].endtime.split(':')[1];

                this.html += `<div class="fc-content"><span class="fc-title">${e.event.department_cal_details.length > 0 ? (Moments().hours(startHours).minutes(startMins).format('HH:mm')) + ' - ' + (Moments().hours(endHours).minutes(endMins).format('HH:mm')) : (e.event.title)}</span>
                </div>`;
            }
            if (e.event.attendance_details.length > 0) {
                this.html += `<div class="fc-content">
                <span class="fc-title">${(e.event.attendance_details.length > 0) && e.event.attendance_details[0].In_time ? 'E-check in: ' + Moments(e.event.attendance_details[0].In_time).format('HH:mm') : ""} ${(e.event.attendance_details.length > 0) && e.event.attendance_details[0].Out_time ? ' Ut: ' + Moments(e.event.attendance_details[0].Out_time).format('HH:mm') : ""}</span>
                </div>`;
                this.html += `<div class="fc-content"><span class="fc-title">${(e.event.attendance_details.length > 0) && e.event.attendance_details[0].In_time && e.event.attendance_details[0].Out_time ? 'Total e-checkin: ' + Moments(e.event.attendance_details[0].total_time, 'HH:mm:ss', true).format('HH:mm') : ""}</span>
                </div>`;
            }
            if (e.event.loxysoft_details.length > 0) {
                this.html += `<div class="fc-content"><span class="fc-title">${(e.event.loxysoft_details.length > 0) && e.event.loxysoft_details[0].start_time ? 'Loxy in: ' + Moments(e.event.loxysoft_details[0].start_time).format('HH:mm') : ""} ${(e.event.loxysoft_details.length > 0) && e.event.loxysoft_details[0].end_time ? ' Ut: ' + Moments(e.event.loxysoft_details[0].end_time).format('HH:mm') : ""}</span>
                </div>`;
                this.html += `<div class="fc-content"><span class="fc-title">${(e.event.loxysoft_details.length > 0) && e.event.loxysoft_details[0].start_time && e.event.loxysoft_details[0].end_time ? 'Total loxysoft: ' + Moments(e.event.loxysoft_details[0].TotalTime, 'HH:mm:ss', true).format('HH:mm') : ""}</span>
                </div>`;
            }
            if (e.event.status != '') {
                if ((e.event.attendance_notes || (e.event.leave_details && e.event.leave_details[0] && e.event.leave_details[0].admin_notes)) && (e.event.attendance_details.length <= 0)) {
                    this.html += ` <div class="fc-content fc-event-status fc-status-link"> 
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                } else {
                    this.html += ` <div class="fc-content">
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                }

            }
        } else if (typeof e.event.status_id == 'undefined' && e.event.is_company_leave == 1) {
            this.html += ` <div class="fc-content"> 
                <span class="fc-title">${e.event.notes != '' ? e.event.notes : "ledigh"}</span>
            </div>`;
        } else {
            if (e.event.status != '') {
                if ((e.event.attendance_notes || (e.event.leave_details && e.event.leave_details[0] && e.event.leave_details[0].admin_notes))) {
                    this.html += ` <div class="fc-content fc-event-status fc-status-link"> 
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                } else {
                    this.html += ` <div class="fc-content"> 
                    <span class="fc-title " >${e.event.status != '' ? e.event.status : ""}</span>
                    </div>`;
                }
            }
        }
        e.element.html(this.html)
    }

    private createOptions(): ChartOptions {
        return {
          responsive: true,
              maintainAspectRatio: true,
              plugins: {
                labels: {
                    render: 'percentage',
                    fontColor: "#fff",
                    precision: 2
                  }
              },
        };
      }
    
    getESPMonthlyReport() {
        this.initalLoader = true;
        this.fTotOrder = 0;
        this.fRejOrder = 0;
        this.fTotProvision = 0;
        this.fTotTimlon = 0;
        this.fTotlon = 0;
        this.fTotLonInkSem = 0;
        this.fTotLonInkSoc = 0;
        this.fTotHour = 0;
        this.fTotMin = 0;
        this.fTotsec = 0;
        this.fTotSnitt = 0;
        this.fTotEffective = 0;
        this.fTotWorkedHours = 0;
        this.fTotBusinessHours = 0;
        this.fTotIdleHours = 0;

        let espData = {
            "year": this.salaryTableYearSelected,
            "Employee_id": this.employeeId,
            'month': this.monthSelected
        };
        this.personalService.getESPMonthlyReport(espData).subscribe((res: any) => {
            this.fTotHour = 0;
            this.fTotMin = 0;
            this.fTotsec = 0;
            if (res) {
                this.espDetailList = res;
                this.espDetail = [res[0].salary_data[this.monthSelected - 1]];
                this.espDetail = res[0].salary_data;
                this.espDetail.forEach((esObj) => {
                    esObj.tot_salary_amount = 0;
                    esObj.tot_salary_sem_amount = 0;
                    esObj.tot_salary_soc_amount = 0;
                    if (esObj.salary_data.length > 0) {
                        esObj.salary_data.forEach((sdataObj) => {
                            this.fTotOrder += sdataObj.total_orders;
                            this.fRejOrder += sdataObj.rejected_orders;
                            this.fsnittOrder += sdataObj.total_snitt_orders;
                            this.fTotProvision += sdataObj.total_provision;
                            this.fTotTimlon += sdataObj.total_hourly_salary;
                            this.fTotlon += sdataObj.total_salary;
                            this.fTotLonInkSem += sdataObj.total_salary_sem;
                            this.fTotLonInkSoc += sdataObj.total_salary_soc;
                            this.fTotWorkedHours += sdataObj.worked_hours;
                            this.fTotBusinessHours += sdataObj.overksam;
                            this.fTotIdleHours += sdataObj.efterbearbetnings;
                            esObj.tot_salary_amount += sdataObj.total_salary;
                            esObj.tot_salary_sem_amount += sdataObj.total_salary_sem;
                            esObj.tot_salary_soc_amount += sdataObj.total_salary_soc;

                            let a = sdataObj.total_time.split(":");
                            if (a.length >= 2) {
                                this.fTotHour += parseInt(a[0]);
                                this.fTotMin += parseInt(a[1]);
                                this.fTotsec += parseInt(a[2]) >= 0 ? parseInt(a[2]) : 0;
                            }
                        });
                        this.fTotSnitt = (this.fsnittOrder) / this.fTotWorkedHours;
                        let totEfft: any = (((this.fTotBusinessHours + this.fTotIdleHours) / this.fTotWorkedHours) * 100).toFixed(2);
                        this.fTotEffective = (100 - totEfft);
                    }
                });
                this.fTotTime = this.getTotalTime();
                this.initalLoader = false;
                this._ref.detectChanges();
            }
            this.initalLoader = false;
            this._ref.detectChanges();
        })
    }

    loadPieChart(id: number) {
        this.loaderStatictics = true;
        this.personalService.getStatisticsChartData(this.employeeId).subscribe(res => {
            this.pieChartColors = [
                { // all colors in order
                    backgroundColor: ["#a2a2a2", "#cc66ff", "#70ad47", "#97bbcd", "#c3c341", "#bd3530", "#ffbf00", "#8eabdc","#C8A2C8"," #C1E3C6"]
                }
            ]
            this.pieChartAttendanceColors = [
                { // all colors in order
                    backgroundColor: ["#ef6a0f", "#000000"]
                }
            ]
            this.loadData = true;
            this.loaderStatistics = false;
            this.referefBy = res.total_refered_by;
            this.statisticssalary = res.total_salary;
            this.attendanceTime = res.total_attendance_time
            this.attendanceDays = res.total_attendance_days;
            this.report = res.total_quality_report;
            this.pieChartstatisticsLabels = ['Ej Schemalagd', 'Ledighet', 'Narvaro', 'Narvaro Avvikelse', 'Narvaro Sen', 'Ogiltig Franvaro', 'Sjuk', 'Sjuk Vab','Ledighet - påverkar inte timmarna','Ledighet - påverkar timmarna'];
            this.pieChartstatisticsData = [res.ej_schemalagd, res.ledighet, res.narvaro, res.narvaro_avvikelse, res.narvaro_sen, res.ogiltig_franvaro, res.sjuk, res.sjuk_vab,res.ledighet_paverkar_inte_nb,res.ledighet_paverkar_nb];
            this.pieChartAttendanceLabels = ['Totalt Order', 'Totalt Ånger'];
            if (res.total_order == 0 && res.total_regret == 0) {
                this.chart_visibility = false;
            }
            this.pieChartAttendanceData = [res.total_order, res.total_regret];
            this._ref.detectChanges();
        });
    }

    getSelectedData(defaultLoad : boolean){
        this.loaderStatictics = true;
        let fromDate: Moment = this.fromyear.value;
        let toDate: Moment = this.toyear.value;
      console.log('fromdate',fromDate);
      console.log('toDate',toDate);
      console.log('this.fromdate.value',this.toyear.value)
      console.log('this.todate.value',this.toyear.value)
        let data = {}
        if(defaultLoad){
           data = {
            employee_id : this.employeeId
          }
        }else{
         data = {
            employee_id :this.employeeId,
            from_year : parseInt(fromDate.format('YYYY')),
            from_month :parseInt(fromDate.format('MM')),
            to_month : parseInt(toDate.format('MM')),
            to_year : parseInt(toDate.format('YYYY'))
    
          }
        }
          this.personalService.getStatisticsChartData(data).subscribe(res => {
            this.pieChartColors = [
              { // all colors in order
                backgroundColor: ["#a2a2a2", "#cc66ff", "#70ad47", "#97bbcd", "#c3c341", "#bd3530", "#ffbf00", "#8eabdc","#FFC0CB"," #C8A2C8"],
              }
            ]
            this.pieChartAttendanceColors = [
              { // all colors in order
                backgroundColor: ["#ef6a0f", "#000000"]
              }
            ]
           this.loadData = true;
           this.loaderStatictics = false;
            this.referefBy = res.total_refered_by;
            this.salary = res.total_salary;
            this.attendanceTime = res.total_attendance_time
            this.attendanceDays = res.total_attendance_days;
            this.report = res.total_quality_report;
            this.pieChartLabels = ['Ej Schemalagd', 'Ledighet', 'Narvaro', 'Narvaro Avvikelse', 'Narvaro Sen', 'Ogiltig Franvaro', 'Sjuk', 'Sjuk Vab','Ledighet - påverkar inte timmarna','Ledighet - påverkar timmarna'];
            this.pieChartData = [res.ej_schemalagd, res.ledighet, res.narvaro, res.narvaro_avvikelse, res.narvaro_sen, res.ogiltig_franvaro, res.sjuk, res.sjuk_vab,res.ledighet_paverkar_inte_nb,res.ledighet_paverkar_nb];
            this.pieChartAttendanceLabels = ['Totalt Order', 'Totalt Ånger'];
            if (res.total_order == 0 && res.total_regret == 0) {
              this.chart_visibility = false;
            }
            this.pieChartAttendanceData = [res.total_order, res.total_regret];
            
            // this.loader = false;
            this._ref.detectChanges();
          });
        
      }


  submitChart(){
  
    let from = this.fromyear.value;
    let to = this.toyear.value ;
  
    if(from <= to){
      this.getSelectedData(false)
      this.errorMessage = ""
    }else{
      this.errorMessage = "Till Månad och Till År måste vara större"
    }
  }
      
    public chartClicked(e: any): void {
    }

    public chartHovered(e: any): void {
    }
    getTotalTime() {
        let hh1 = this.fTotHour;
        let mm1 = this.fTotMin;
        let ss1 = this.fTotsec;

        if (ss1 > 59) {
            let ss2 = ss1 % 60;
            let ssx = ss1 / 60;
            //add into min
            let ss3 = Math.floor(ssx);
            mm1 = mm1 + ss3;
            ss1 = ss2;
        }
        if (mm1 > 59) {
            let mm2 = mm1 % 60;
            let mmx = mm1 / 60;
            //add into hour
            let mm3 = Math.floor(mmx);
            hh1 = hh1 + mm3;
            mm1 = mm2;
        }
        let finaladd = hh1.toFixed(0) + ':' + mm1.toFixed(0) + ':' + ss1.toFixed(0);
        return finaladd;
    }

    showTotTable() {
        this.xpandStatus = true;
        this.lonxpandStatus = false;
        this.emp_dataSource = [];
        this.salaryReportList = [];
    }

    showlonTable(ind, proj) {
        if (proj.type == 'project') {
            this.xpandStatus = false;
            this.lonxpandStatus = true;
            let monthInd = ind;
            this.loadEconomySalaryPeriodProductWiseReport(monthInd, proj.project_id);
        }
    }

    loadEconomySalaryPeriodProductWiseReport(monthIndx, projId) {
        let client_id_forProj = this.setClientByProject(projId);
        this.prodtottRowErr = false;
        this.prodtottRowNoRecord = false;

        if (this.monthSelected && this.salaryTableYearSelected) {
            let resultarr = [];
            this.loader = true;
            this.reqFilterOptions = { month: this.monthSelected, year: this.salaryTableYearSelected, Client_id: client_id_forProj, Project_id: projId, Employee_id: this.employeeId };
            this.economyService.getAllEconomySalaryPeriodReportProductwiseForProfile(this.reqFilterOptions).subscribe(res => {
                if (res) {
                    this.salaryReportList = res;
                    let ms_Data = this.salaryReportList[0].monthly_summary_data[0];
                    if (ms_Data) {
                        this.revenue = ms_Data.revenue;
                        this.salary = ms_Data.salary;
                        this.salary_sem = ms_Data.salary_sem;
                        this.salary_soc = ms_Data.salary_soc;
                        this.profit = ms_Data.profit;
                        this.hourly_revenue = ms_Data.hourly_revenue;
                        this.salary_percent = ms_Data.salary_percent;
                        this.profit_percent = ms_Data.profit_percent;
                    }


                    let dayscount = new Date(this.yearSelected, this.monthSelected, 0).getDate();
                    this.employeedisplayedColumns = [];
                    this.employeedisplayedColumns.push('employee');

                    for (let i = 0; i < dayscount; i++) {
                        let dt = i + 1;
                        this.employeedisplayedColumns.push(dt + "  " + this.getDay(dt));
                    }
                    this.employeedisplayedColumns.push('Total timmar');

                    if (this.salaryReportList[0].monthly_salary_data[0]) {
                        this.salaryReportList[0].monthly_salary_data[0].provison_data.forEach((prodObj) => {
                            this.employeedisplayedColumns.push(prodObj.product_name);
                            this.productsForProject.push(prodObj.product_name);
                        });
                    }

                    this.employeedisplayedColumns.push('Total order', 'Snitt', 'Effektivitet', 'Prov per produkt', 'Total prov per pro', 'Timlön', 'Totalt provision', 'Total timlön', 'Tot lön', 'Total lön ink sem', 'tot lön ink alt', 'Timl snitt');

                    let Count = 0;

                    res.forEach((obj) => {
                        this.footerProductCountObj = {};
                        let msdata = obj.monthly_salary_data[0]
                        {
                            let prodColDataOrders = {};
                            let productCountObj = {};
                            if (msdata.provison_data) {
                                this.employeedisplayedColumns.forEach((col_name, col_ind) => {
                                    if (col_name != 'employee' && col_name != 'Total timmar' && col_name != 'Total order' && col_name != 'Snitt' && col_name != 'Effektivitet' && col_name != 'Total prov per pro' && col_name != 'Tot lön' && col_name != 'Total timlön' && col_name != 'Totalt provision' && col_name != 'Timlön' && col_name != 'Total timlön' && col_name != 'Tot lön' && col_name != 'Total lön ink sem' && col_name != 'tot lön ink alt' && col_name != 'Timl snitt' && col_name != 'Prov per produkt' && (this.productsForProject.indexOf(col_name) < 0)) {
                                        productCountObj[col_name] = this.getProductCountArr(msdata.monthly_sales_data[col_ind - 1].sales_data, this.salaryReportList[0].monthly_salary_data[0].provison_data, msdata.monthly_sales_data[col_ind - 1].rejected_data);
                                        this.footerProductCountObj[col_name] = this.getProductCountArr(this.salaryReportList[0].daily_summary_data[col_ind - 1].sales_data, this.salaryReportList[0].monthly_salary_data[0].provison_data, this.salaryReportList[0].daily_summary_data[col_ind - 1].rejected_data);
                                    }
                                    if (this.productsForProject.indexOf(col_name) > -1) {
                                        prodColDataOrders[col_name] = this.getProdColData(msdata.provison_data, col_name);
                                        this.totalOrdersForIndvProducts[col_name] = this.getTotOrdersForIndvProducts(col_name);
                                    }

                                });
                                this.totalProvPerProd = this.getTotalProv();
                            }
                            let datasourceObj: any = {};
                            datasourceObj = msdata;
                            datasourceObj.prodColDataOrders = prodColDataOrders;
                            datasourceObj.productCountObj = productCountObj;
                            resultarr.push(datasourceObj);
                        }
                    });
                    this.emp_dataSource = new MatTableDataSource(resultarr);
                    this.emp_dataSource.paginator = this.paginator;
                    this.emp_dataSource.sort = this.sort;
                    this.emp_dataSource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split('.').reduce((o, i) => o[i], item);
                        if (typeof sortString === 'string') {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    }
                    this.loader = false;
                    this.emp_dataSource = new MatTableDataSource(resultarr);
                } else {
                    this.prodtottRowNoRecord = true;
                    this.loader = false;
                    this.dataSource = new MatTableDataSource([]);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;
                    this.dataSource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split('.').reduce((o, i) => o[i], item);
                        if (typeof sortString === 'string') {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    }
                }
                this._ref.detectChanges();
            }, err => {
                this.prodtottRowErr = true;
                this.loader = false;
                this._ref.detectChanges();
            });
        }
    }

    onSubmit(getStep, stepper: MatStepper, stayInStep: any, signAgreement?: boolean) {
        this.submitted = true;

        if (getStep === 'firstStep') {
            if (this.firstFormGroup.invalid) {
                this.validateAllFormFields(this.firstFormGroup);
            } else {
                if (this.mode === 'update' || this.employeeData.Employee_id || this.mode === 'view') {
                    let form1 = this.firstFormGroup.value;
                    this.employeeData.first_name = form1.first_name;
                    this.employeeData.last_name = form1.last_name;
                    this.employeeData.personal_id = form1.personal_id;
                    this.employeeData.contact = {
                        address: form1.address,
                        email: form1.email,
                        mobile: form1.mobile,
                        zipcode: form1.zipcode,
                        place: form1.place,
                        landline: form1.landline
                    };

                    if (form1.itemRows.length > 0) {
                        this.employeeData.emergencycontact = [];
                        form1.itemRows.forEach(irObj => {
                            if (irObj.name && irObj.contactnumber) {
                                this.employeeData.emergencycontact.push({
                                    name: irObj.name,
                                    contactnumber: irObj.contactnumber
                                });
                            }
                        });
                    }
                    this.personalService.updateEmployeePersonalDetails(this.employeeData).subscribe((res: any) => {
                        if (res.message === 'Updated Successfully') {
                            this.resMessage.success = true;
                            this.resMessage.error = false;
                        } else {
                            this.resMessage.success = false;
                            this.resMessage.error = true;
                        }
                        this._ref.detectChanges();
                        this.resetStepAlert(stepper, stayInStep);
                    }, err => {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this._ref.detectChanges();
                        this.resetStepAlert(stepper, true);
                    });
                } else {
                    if (this.mode === 'create') {
                        stepper.next();
                    }
                }
            }
        } else if (getStep === 'secondStep') {
            if (this.secondFormGroup.invalid) {
                this.validateAllFormFields(this.secondFormGroup);
            } else {
                if (this.mode === 'update' || this.employeeData.Employee_id || this.mode === 'view') {
                    this.employeeData.bank = {
                        BankName: this.secondFormGroup.value.BankName,
                        ClearingNumber: this.secondFormGroup.value.ClearingNumber,
                        AccountNumber: this.secondFormGroup.value.AccountNumber
                    };
                    this.personalService.updateEmployeeBankDetails(this.employeeData).subscribe((res: any) => {
                        if (res.message === 'Updated Successfully') {
                            this.resMessage.success = true;
                            this.resMessage.error = false;
                        } else {
                            this.resMessage.success = false;
                            this.resMessage.error = true;
                        }
                        this._ref.detectChanges();
                        this.resetStepAlert(stepper, stayInStep);
                    }, err => {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this._ref.detectChanges();
                        this.resetStepAlert(stepper, true);
                    })
                } else {
                    if (this.mode === 'create') {
                        stepper.next();
                    }
                }
            }
        } else if (getStep === 'thirdStep') {
            if (this.thirdFormGroup.invalid) {
                this.validateAllFormFields(this.thirdFormGroup);
            } else {
                if (this.mode === 'update' || this.employeeData.Employee_id || this.mode === 'view') {
                    this.employeeData.loxysoft_id = this.thirdFormGroup.value.loxysoftid;
                    this.employeeData.role = this.thirdFormGroup.value.role;
                    this.employeeData.emp_type = this.thirdFormGroup.value.extent;
                    this.employeeData.userstatus = this.thirdFormGroup.value.userstatus ? 1 : 0;
                    this.employeeData.Semesterval = this.thirdFormGroup.value.Semesterval;
                    this.employeeData.recruitment_id = this.thirdFormGroup.value.recruitment_id;
                    this.employeeData.department = this.thirdFormGroup.value.department_group.department;
                    this.employeeData.department_id = this.thirdFormGroup.value.department_group._id;
                    this.employeeData.refered_by = this.thirdFormGroup.value.refered_by ? this.thirdFormGroup.value.refered_by : null;
                    this.employeeData.visma_id = this.thirdFormGroup.value.visma_id ? this.thirdFormGroup.value.visma_id : null;
                    this.personalService.updateEmployeeEmployment(this.employeeData).subscribe((res: any) => {
                        if (res.message === 'Updated Successfully') {
                            this.resMessage.success = true;
                            this.resMessage.error = false;
                        } else {
                            this.resMessage.success = false;
                            this.resMessage.error = true;
                        }
                        this._ref.detectChanges();
                        this.resetStepAlert(stepper, stayInStep);
                    }, err => {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this._ref.detectChanges();
                        this.resetStepAlert(stepper, true);
                    });
                } else {
                    if (this.mode === 'create') {
                        stepper.next();
                    }
                }
            }
        } else if (getStep === 'fourthStep') {
            if (this.fourthFormGroup.invalid) {
                this.validateAllFormFields(this.fourthFormGroup);
            } else {
                let form1 = this.firstFormGroup.value;
                this.employeeData.first_name = form1.first_name;
                this.employeeData.last_name = form1.last_name;
                this.employeeData.personal_id = form1.personal_id;
                this.employeeData.contact = {
                    address: form1.address,
                    email: form1.email,
                    mobile: form1.mobile,
                    zipcode: form1.zipcode,
                    place: form1.place,
                    landline: form1.landline
                };
                if (form1.itemRows.length > 0) {
                    form1.itemRows.forEach(irObj => {
                        if (irObj.name && irObj.contactnumber) {
                            this.employeeData.emergencycontact.push({
                                name: irObj.name,
                                contactnumber: irObj.contactnumber
                            });
                        }
                    });
                }
                this.employeeData.bank = {
                    BankName: this.secondFormGroup.value.BankName,
                    ClearingNumber: this.secondFormGroup.value.ClearingNumber,
                    AccountNumber: this.secondFormGroup.value.AccountNumber
                };
                this.employeeData.loxysoft_id = this.thirdFormGroup.value.loxysoftid;
                this.employeeData.role = this.thirdFormGroup.value.role;

                this.employeeData.emp_type = this.thirdFormGroup.value.extent;
                this.employeeData.userstatus = this.thirdFormGroup.value.userstatus ? 1 : 0;
                this.employeeData.recruitment_id = this.thirdFormGroup.value.recruitment_id;
                this.employeeData.department = this.thirdFormGroup.value.department_group.department;
                this.employeeData.department_id = this.thirdFormGroup.value.department_group._id;
                this.employeeData.Semesterval = this.thirdFormGroup.value.Semesterval;
                this.employeeData.department_id = this.thirdFormGroup.value.department_group._id;
                this.employeeData.refered_by = this.thirdFormGroup.value.refered_by ? this.thirdFormGroup.value.refered_by : null;
                this.employeeData.visma_id = this.thirdFormGroup.value.visma_id ? this.thirdFormGroup.value.visma_id : null;

                this.employeeData.Projects = this.fourthFormGroup.value.projects;
                if (this.mode === 'update' || this.employeeData.Employee_id || this.mode === 'view') {
                    this.saveEmployeeClientDetails();
                }
                if (this.mode === 'create' && !this.employeeData.Employee_id) {
                    this.personalService.addEmployee(this.employeeData).subscribe((res: any) => {
                        if (res.Message === 'Added successfully') {
                            this.resMessage.success = true;
                            this.resMessage.error = false;
                        } else {
                            this.resMessage.success = false;
                            this.resMessage.error = true;
                        }
                        this._ref.detectChanges();
                        if (res.Employee_id) {
                            this.employeeData.Employee_id = res.Employee_id;
                            this.employeeId = res.Employee_id;
                            this.saveEmployeeClientDetails();
                            this.saveAgreement();
                        } else {
                            setTimeout(() => { this.router.navigate(['/personal/employee/list']); }, 3000);
                        }

                        setTimeout(() => {
                            this.resMessage.success = false;
                            this.resMessage.error = false;
                            this.router.navigate(['/personal/employee/list']);
                        }, 3000);

                    }, err => {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this._ref.detectChanges();
                        this.resetAlert();
                    });
                }
            }
        }
    }

    addNewRow() {
        if (!this.firstFormGroup.disabled) {
            const control = <FormArray>this.firstFormGroup.controls['itemRows'];
            control.push(this.initItemRows());
        }
    }

    deleteRow(index: number) {
        if (!this.firstFormGroup.disabled) {
            const control = <FormArray>this.firstFormGroup.controls['itemRows'];
            control.removeAt(index);
        }
    }

    getProjectList() {
        this.sharedServices.getProjectList().subscribe((res: any) => {
            if (res) {
                this.isSetProvisionAndCommission.projectLoaded = true;
                this.projectsArr = res;
                this.projectsArr.sort(function (a, b) {
                    if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
                    if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
                    return 0;
                });
                this.projectsArr.forEach((obj) => {
                    this.st4projectsArr.push(obj);
                });
                this.setProvisionAndCommission();
            }
        });
    }

    getProjectListByClient(clientId, ind, Project_id?: any) {
        this.clientProjectsArr[ind] = [];
        this.clientsProductsArr[ind] = [];
        this.projectsArr.forEach((obj) => {
            if (obj.Client_id === clientId) {
                this.clientProjectsArr[ind].push(obj);
            }
            else if (obj.Client_id === clientId && !Project_id) {
                this.clientProjectsArr[ind].push(obj);
            }
        });
    }

    getProductList() {
        this.sharedServices.getProductList().subscribe((res: any) => {
            if (res.length && res.length > 0) {
                this.isSetProvisionAndCommission.productLoaded = true;
                this.productsArr = res;
                this.productsArr.sort(function (a, b) {
                    if (a.Product_name.toLowerCase() < b.Product_name.toLowerCase()) { return -1; }
                    if (a.Product_name.toLowerCase() > b.Product_name.toLowerCase()) { return 1; }
                    return 0;
                });
                this.setProvisionAndCommission();
            }
        });
    }

    getProductsListByProject(clientId, project, ind) {
        this.clientsProductsArr[ind] = [];
        this.projectsArr.forEach((obj) => {
            if (obj.Project_id === project.Project_id) {
                obj.Products.sort(function (a, b) {
                    if (a.prod_name.toLowerCase() < b.prod_name.toLowerCase()) { return -1; }
                    if (a.prod_name.toLowerCase() > b.prod_name.toLowerCase()) { return 1; }
                    return 0;
                });
                this.clientsProductsArr[ind] = obj.Products;
            }
        });
    }

    getClientList() {
        this.sharedServices.getClientList().subscribe((res: any) => {
            if (res) {
                this.isSetProvisionAndCommission.clientLoaded = true;
                this.clientsArr = res;
                this.clientsArr.sort(function (a, b) {
                    if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
                    if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
                    return 0;
                });
                this.setProvisionAndCommission();
            }
        });
    }

    getRecruitmentList() {
        this.sharedServices.getAllActiveInactiveEmployeeList().subscribe((res: any) => {
            if (res) {
                this.recruitmentnArr = [];
                res.forEach((obj) => {
                    this.recruitmentnArr.push({
                        Employee_id: obj.Employee_id,
                        name: obj.first_name + " " + obj.last_name
                    });
                });
                this.recruitmentnArr.sort(function (a, b) {
                    if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
                    if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
                    return 0;
                });
                this._RecEmpfilter();
                this._RefEmpfilter();
            }
        });
    }

    getDepartmentList() {
        this.sharedServices.getDepartmentList().subscribe((res: any) => {
            if (res) {
                this.departmentArr = res;
                this.departmentArr.sort(function (a, b) {
                    if (a.department.toLowerCase() < b.department.toLowerCase()) { return -1; }
                    if (a.department.toLowerCase() > b.department.toLowerCase()) { return 1; }
                    return 0;
                });
                this._DepFilter();
            }
        });
    }

    getEmployeeData() {
        this.personalService.getEmployee(this.employeeId).subscribe((res: any) => {
            if (res) {
                this.isSetProvisionAndCommission.employeeLoaded = true;
                if (res.employeestatus.length > 0) {
                    this.statusHistoryList = res.employeestatus;
                    res.employeestatus = res.employeestatus[res.employeestatus.length - 1];
                } else {
                    this.statusHistoryList = [];
                    let todates = Moments(new Date()).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                    res.employeestatus = { fromdate: todates, todate: todates, Employeestatus: "G" };
                }
                this.profileStatus = res.employeestatus;
                this.employeeData = res;
                this.emp_status = res.emp_status;
                this.userInitials = this.employeeData.first_name.charAt(0).toUpperCase() + this.employeeData.last_name.charAt(0).toUpperCase();
                if (this.employeeData.Employee_id == this.userData.id && this.employeeData.img) {
                    this.sharedServices.profileImgSub$.next(this.employeeData.img);
                }
                this.employeeData.provision = [];
                this.employeeData.compensation = [];
                if (!res.contact && !res.contact[0]) {
                    this.employeeData.contact = new Contact();
                } else {
                    this.employeeData.contact = res.contact[0];
                }
                if (res.bank && res.bank[0]) {
                    this.employeeData.bank = res.bank[0];
                }

                if (res.contact) {
                    this.firstFormGroup.patchValue({
                        personal_id: res.personal_id,
                        email: res.contact.email,
                        mobile: res.contact.mobile,
                        zipcode: res.contact.zipcode,
                        first_name: res.first_name,
                        last_name: res.last_name,
                        landline: res.contact.landline,
                        address: res.contact.address,
                        place: res.contact.place
                    });
                } else {
                    this.firstFormGroup.patchValue({
                        personal_id: res.personal_id,
                        first_name: res.first_name,
                        last_name: res.last_name,
                    });
                }

                let familyInfo = <FormArray>this.firstFormGroup.controls['itemRows'];
                if (res.emergencycontact) {
                    this.employeeData.emergencycontact.forEach((obj, ind) => {
                        if (ind === 0) {
                            familyInfo.controls[0].patchValue({
                                name: obj.name,
                                contactnumber: obj.contactnumber
                            });
                        } else {
                            familyInfo.push(this.setItemRows(obj));
                        }
                    });
                }
                if (this.employeeData.bank) {
                    this.secondFormGroup.patchValue({
                        ClearingNumber: this.employeeData.bank.ClearingNumber,
                        AccountNumber: this.employeeData.bank.AccountNumber,
                        BankName: this.employeeData.bank.BankName
                    });
                }

                if (this.employeeData.loxysoft_id) {
                    this.thirdFormGroup.get('loxysoftid').setValidators([Validators.required]);
                    this.thirdFormGroup.get('loxysoftid').updateValueAndValidity();
                    this._ref.detectChanges();
                    this.thirdFormGroup.updateValueAndValidity();
                }

                if (this.employeeData.refered_by) {
                    this.thirdFormGroup.get('refered_by').setValidators([Validators.required]);
                    this.thirdFormGroup.get('refered_by').updateValueAndValidity();
                    this._ref.detectChanges();
                    this.thirdFormGroup.updateValueAndValidity();
                }

                this.thirdFormGroup.patchValue({
                    loxysoftid: res.loxysoft_id,
                    loxysoft: res.loxysoft_id,
                    role: res.role.toLowerCase(),
                    extent: res.emp_type,
                    userstatus: res.userstatus,
                    recruitment_id: res.recruitment_id,
                    department_group: { _id: res.department_id, department: res.department },
                    Semesterval: res.Semesterval,
                    refered_by: res.refered_by,
                    refered: res.refered_by,
                    visma_id: res.visma_id
                });


                if (res.role.toLowerCase() == 'superadmin') {
                    if (this.userData.role != 'superadmin') {
                        this.thirdFormGroup.get('role').disable();
                    }
                } else {
                    if (this.userData.role != 'superadmin') {
                        let saIndex = this.dropDownList.role_list.indexOf('superadmin');
                        this.dropDownList.role_list.splice(saIndex, 1);
                    }
                }

                if (res.EmployeeDepartment && res.EmployeeDepartment.length > 0) {
                    this.departmentHistoryDataSource = new MatTableDataSource(res.EmployeeDepartment);
                }

                let projectsArray = [];
                if (res.Projects && res.Projects.length > 0) {
                    res.Projects.forEach((obj, ind) => {
                        projectsArray.push({ Project_id: obj.Project_id, Project_name: obj.Project_name });
                    });
                }
                this.fourthFormGroup.patchValue({
                    projects: res.EmployeeProjects[0],
                    client: res.EmployeeClients[0] && res.EmployeeClients[0].Client_id
                });


                this.agreementDataSource = new MatTableDataSource([]);
                let projectDetailsInfo = <FormArray>this.fourthFormGroup.controls['agreementRows'];
                let toShowAgreementArr = [];
                if (res.agreement.length > 0) {
                    res.agreement.forEach((aObj, aind) => {
                        if (aind == 0) {
                            projectDetailsInfo.controls[0].patchValue({
                                startDate: this.parseISOString(aObj.fromdate),
                                agreement: aObj.Status,
                                notes: aObj.notes,
                                download: aObj.download,
                                _id: aObj._id
                            });
                            if (aObj.todate) {
                                projectDetailsInfo.controls[0].patchValue({
                                    endDate: this.parseISOString(aObj.todate)
                                });
                            } else {
                                projectDetailsInfo.controls[0].patchValue({
                                    endDate: ''
                                });
                            }
                        } else {
                            projectDetailsInfo.push(this.setAgreementRows(aObj));
                        }
                        toShowAgreementArr.push(projectDetailsInfo.controls[aind].value);
                    });
                    this.agreementDataSource = new MatTableDataSource(toShowAgreementArr);
                    this.agreeNoRecord = false;
                } else {
                    projectDetailsInfo.controls[0].patchValue({
                        startDate: '',
                        endDate: '',
                        agreement: null,
                        notes: '',
                        download: '',
                        _id: null
                    });
                    this.agreementDataSource = new MatTableDataSource([]);
                    this.agreeNoRecord = true;
                }

                let leaveData = <FormArray>this.leaveList.controls['leaveListFormArray'];
                if (res.leave.length > 0) {
                    res.leave.forEach((obj, ind) => {
                        if (ind === 0) {
                            leaveData.controls[0].patchValue({
                                fromdate: this.parseISOString(obj.fromdate),
                                todate: this.parseISOString(obj.todate),
                                note: obj.note
                            });
                        } else {
                            leaveData.push(this.setLeaveListArr(obj));
                        }
                    });
                }
                this.setProvisionAndCommission();

                let fixedsalaryData = <FormArray>this.fastionList.controls['fastionListFormArray'];
                if (res.fixedsalary && res.fixedsalary.length > 0) {
                    res.fixedsalary.forEach((obj, ind) => {
                        if (ind === 0) {
                            fixedsalaryData.controls[0].patchValue({
                                fromdate: this.parseISOString(obj.fromdate),
                                todate: this.parseISOString(obj.todate),
                                salary: obj.salary
                            });
                        } else {
                            fixedsalaryData.push(this.setFastIonListArr(obj));
                        }
                    });
                }

                let socialFeesData = <FormArray>this.socialfeeList.controls['socialfeeListFormArray'];
                if (res.socialfee && res.socialfee.length > 0) {
                    res.socialfee.forEach((obj, ind) => {
                        if (ind === 0) {
                            socialFeesData.controls[0].patchValue({
                                fromdate: this.parseISOString(obj.fromdate),
                                todate: this.parseISOString(obj.todate),
                                fees: obj.fees
                            });
                        } else {
                            socialFeesData.push(this.setSocialFeeListArr(obj));
                        }
                    });
                }

                let vacationData = <FormArray>this.vacationpayList.controls['vacationpayListFormArray'];
                if (res.holidaypay && res.holidaypay.length > 0) {
                    res.holidaypay.forEach((obj, ind) => {
                        if (ind === 0) {
                            vacationData.controls[0].patchValue({
                                fromdate: this.parseISOString(obj.fromdate),
                                todate: this.parseISOString(obj.todate),
                                holiday: obj.holiday
                            });
                        } else {
                            vacationData.push(this.setVacationPayListArr(obj));
                        }
                    });
                }
            }

            this.getDepartmentCompensationList();

            if (this.readOnly) {
                this.firstFormGroup.disable();
                this.secondFormGroup.disable();
                this.thirdFormGroup.disable();
                this.fourthFormGroup.disable();
                this.leaveList.disable();
                this.provisionList.disable();
                this.compensationList.disable();
                this.fastionList.disable();
                this.socialfeeList.disable();
                this.vacationpayList.disable();
            }

            this.userQRCode = btoa(this.employeeData.Employee_id + '' + this.employeeData.first_name + '' + this.employeeData.last_name + '' + this.employeeData.personal_id);
        });
    }

    initItemRows() {
        return this._formBuilder.group({
            name: [''],
            contactnumber: [''],
        });
    }


    setItemRows(resECObj) {
        return this._formBuilder.group({
            name: [resECObj.name],
            contactnumber: [resECObj.contactnumber]
        });
    }

    initAgreementRows() {
        return this._formBuilder.group({
            agreement: [false],
            startDate: [''],
            endDate: [''],
            notes: [''],
            download: [''],
            _id: [null]
        });
    }

    addAgreementRows() {
        if (!this.fourthFormGroup.disabled) {
            const control = <FormArray>this.fourthFormGroup.controls['agreementRows'];
            control.push(this.initAgreementRows());
        }
    }

    deleteAgreementRows(index: number) {
        if (!this.fourthFormGroup.disabled) {
            const control = <FormArray>this.fourthFormGroup.controls['agreementRows'];
            control.removeAt(index);
        }
    }

    setAgreementRows(resObj) {
        return this._formBuilder.group({
            agreement: [(resObj.Status ? true : false)],
            startDate: [this.parseISOString(resObj.fromdate)],
            endDate: [this.parseISOString(resObj.todate)],
            notes: [resObj.notes],
            download: [resObj.download],
            _id: [resObj._id]
        });
    }

    initLeaveListArr() {
        return this._formBuilder.group({
            fromdate: [''],
            todate: [''],
            note: ['']
        });
    }

    addLeaveListArr() {
        if (!this.leaveList.disabled) {
            const control = <FormArray>this.leaveList.controls['leaveListFormArray'];
            control.push(this.initLeaveListArr());
        }
    }

    deleteLeaveListArr(index: number) {
        if (!this.leaveList.disabled) {
            const control = <FormArray>this.leaveList.controls['leaveListFormArray'];
            control.removeAt(index);
        }
    }

    setLeaveListArr(resObj) {
        return this._formBuilder.group({
            fromdate: [this.parseISOString(resObj.fromdate)],
            todate: [this.parseISOString(resObj.todate)],
            note: [resObj.note]
        });
    }

    initProvisionListArr() {
        return this._formBuilder.group({
            Client_id: [''],
            project: [{ Project_id: '', Project_name: '' }],
            product: [{ Product_id: '', Product_name: '' }],
            provision: [''],
            fromdate: [''],
            todate: [''],
        });
    }

    addProvisionListArr() {
        if (!this.provisionList.disabled) {
            const control = <FormArray>this.provisionList.controls['provisionListFormArray'];
            control.push(this.initProvisionListArr());
        }
    }

    deleteProvisionListArr(index: number) {
        if (!this.provisionList.disabled) {
            const control = <FormArray>this.provisionList.controls['provisionListFormArray'];
            control.removeAt(index);
        }
    }

    setProvisionListArr(resObj) {
        return this._formBuilder.group({
            Client_id: [resObj.Client_id],
            project: [{ Project_id: resObj.project_id, Project_name: resObj.project_name }],
            product: [{ Product_id: resObj.product_id, Product_name: resObj.product_name }],
            provision: [resObj.provision],
            fromdate: [resObj.fromdate],
            todate: [resObj.todate]
        });
    }

    initCompensationListArr() {
        return this._formBuilder.group({
            Client_id: [''],
            project: [{ Project_id: '', Project_name: '' }],
            hourly: [''],
            fromdate: [''],
            todate: ['']
        });
    }

    addCompensationListArr() {
        if (!this.compensationList.disabled) {
            const control = <FormArray>this.compensationList.controls['compensationListFormArray'];
            control.push(this.initCompensationListArr());
        }
    }

    deleteCompensationListArr(index: number) {
        if (!this.compensationList.disabled) {
            const control = <FormArray>this.compensationList.controls['compensationListFormArray'];
            control.removeAt(index);
        }
    }

    setCompensationListArr(resObj) {
        return this._formBuilder.group({
            Client_id: resObj.Client_id,
            project: [{ Project_id: resObj.project_id, Project_name: resObj.project_name }],
            hourly: [resObj.hourly],
            fromdate: [this.parseISOString(resObj.fromdate)],
            todate: [this.parseISOString(resObj.todate)]
        });
    }

    initFastIonListArr() {
        return this._formBuilder.group({
            salary: [''],
            fromdate: [''],
            todate: [''],
        });
    }

    addFastIonListArr() {
        if (!this.fastionList.disabled) {
            const control = <FormArray>this.fastionList.controls['fastionListFormArray'];
            control.push(this.initFastIonListArr());
        }
    }

    deleteFastIonListArr(index: number) {
        if (!this.fastionList.disabled) {
            const control = <FormArray>this.fastionList.controls['fastionListFormArray'];
            control.removeAt(index);
        }
    }

    setFastIonListArr(resObj) {
        return this._formBuilder.group({
            fromdate: [this.parseISOString(resObj.fromdate)],
            todate: [this.parseISOString(resObj.todate)],
            salary: [resObj.salary]
        });
    }

    initSocialFeeListArr() {
        return this._formBuilder.group({
            fromdate: [''],
            todate: [''],
            fees: []
        });
    }

    addSocialFeeListArr() {
        if (!this.socialfeeList.disabled) {
            const control = <FormArray>this.socialfeeList.controls['socialfeeListFormArray'];
            control.push(this.initSocialFeeListArr());
        }
    }

    deleteSocialFeeListArr(index: number) {
        if (!this.socialfeeList.disabled) {
            const control = <FormArray>this.socialfeeList.controls['socialfeeListFormArray'];
            control.removeAt(index);
        }
    }

    setSocialFeeListArr(resObj) {
        return this._formBuilder.group({
            fromdate: this.parseISOString(resObj.fromdate),
            todate: this.parseISOString(resObj.todate),
            fees: [resObj.fees]
        });
    }

    initVacationPayListArr() {
        return this._formBuilder.group({
            fromdate: [''],
            todate: [''],
            holiday: ['']
        });
    }

    addVacationPayListArr() {
        if (!this.vacationpayList.disabled) {
            const control = <FormArray>this.vacationpayList.controls['vacationpayListFormArray'];
            control.push(this.initVacationPayListArr());
        }
    }

    deleteVacationPayListArr(index: number) {
        if (!this.fourthFormGroup.disabled) {
            const control = <FormArray>this.vacationpayList.controls['vacationpayListFormArray'];
            control.removeAt(index);
        }
    }

    setVacationPayListArr(resObj) {
        return this._formBuilder.group({
            fromdate: this.parseISOString(resObj.fromdate),
            todate: this.parseISOString(resObj.todate),
            holiday: [resObj.holiday]
        });
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup) {
                this.validateAllFormFields(control);
            }
        });
    }

    stepIconadd(posinsetval) {
        if (this.mode !== 'view') {
            let stepIcon = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="' + posinsetval + '"] .mat-step-icon');
            if (stepIcon.classList.contains('mat-step-icon')) {
                stepIcon.classList.add('mat-step-icon-not-touched');
                stepIcon.classList.remove('mat-step-icon');
            }
        }
        else if (this.mode == 'view') {
            let stepIcon = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="' + posinsetval + '"] .mat-step-icon');
            if (stepIcon !== null && stepIcon.classList.contains('mat-step-icon')) {
                stepIcon.classList.add('mat-step-icon-not-touched');
                stepIcon.classList.remove('mat-step-icon');
            }
        }
    }

    stepIconremove(posinsetval) {
        if (this.mode !== 'view') {
            let stepIcon = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="' + posinsetval + '"] .mat-step-icon-not-touched');
            if (stepIcon.classList.contains('mat-step-icon-not-touched')) {
                stepIcon.classList.add('mat-step-icon');
                stepIcon.classList.remove('mat-step-icon-not-touched');
            }
        } else if (this.mode == 'view') {
            let stepIcon = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="' + posinsetval + '"] .mat-step-icon-not-touched');
            if (stepIcon !== null && stepIcon.classList.contains('mat-step-icon-not-touched')) {
                stepIcon.classList.add('mat-step-icon');
                stepIcon.classList.remove('mat-step-icon-not-touched');
            }
        }
    }

    stepLabelAdd(labelval) {
        let stepLabel = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="' + labelval + '"] .mat-step-label');
        stepLabel.classList.add('active-label');
    }

    stepLabelRemove(labelval) {
        let stepLabel = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="' + labelval + '"] .mat-step-label');
        stepLabel.classList.remove('active-label');
    }

    stepSelector(event) {
        let info = "activeinfo";
        if (this.mode === 'view') {
            info = "viewactiveinfo";
        }

        let stepEl1 = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="1"]');
        let stepEl2 = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="2"]');
        let stepEl3 = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="3"]');
        let stepEl4 = this.el.nativeElement.querySelector('mat-step-header[aria-posinset="4"]');

        if (event.selectedIndex == 0) {
            if (stepEl1.classList.contains(info)) {
                stepEl1.classList.remove(info);
                this.stepLabelAdd(1);
                this.stepIconadd(2);
            }
            if (stepEl2.classList.contains(info)) {
                stepEl2.classList.remove(info);
                this.stepLabelRemove(2);
                this.stepIconadd(3);
            }
            if (stepEl3.classList.contains(info)) {
                stepEl3.classList.remove(info);
                this.stepLabelRemove(3);
                this.stepIconadd(4);
            }
        } else if (event.selectedIndex === 1) {
            if (!stepEl1.classList.contains(info)) {
                stepEl1.classList.add(info);
                this.stepLabelAdd(1);
                this.stepIconremove(2);
            }
            if (stepEl2.classList.contains(info)) {
                stepEl2.classList.remove(info);
                this.stepLabelRemove(2);
                this.stepIconadd(3);
            }
            if (stepEl3.classList.contains(info)) {
                stepEl3.classList.remove(info);
                this.stepLabelRemove(3);
                this.stepIconadd(4);
            }
            if (stepEl4.classList.contains(info)) {
                stepEl4.classList.remove(info);
                this.stepLabelRemove(4);
            }
        } else if (event.selectedIndex === 2) {
            if (!stepEl1.classList.contains(info)) {
                stepEl1.classList.add(info);
                this.stepLabelAdd(1);
                this.stepIconremove(2);
            }
            if (!stepEl2.classList.contains(info)) {
                stepEl2.classList.add(info);
                this.stepLabelAdd(2);
                this.stepIconremove(3);
            }
            if (stepEl3.classList.contains(info)) {
                stepEl3.classList.remove(info);
                this.stepLabelRemove(3);
                this.stepIconadd(4);
            }
            if (stepEl4.classList.contains(info)) {
                stepEl4.classList.remove(info);
                this.stepLabelRemove(4);
            }
        } else if (event.selectedIndex === 3) {
            if (!stepEl1.classList.contains(info)) {
                stepEl1.classList.add(info);
                this.stepLabelAdd(1);
                this.stepIconremove(2);
            }
            if (!stepEl2.classList.contains(info)) {
                stepEl2.classList.add(info);
                this.stepLabelAdd(2);
                this.stepIconremove(3);
            }
            if (!stepEl3.classList.contains(info)) {
                stepEl3.classList.add(info);
                this.stepLabelAdd(3);
                this.stepIconremove(4);
            }
        }
    }

    loxySlideToggleChange(e) {
        if (!this.thirdFormGroup.disabled) {
            if (e.checked) {
                this.thirdFormGroup.get('loxysoftid').setValidators([Validators.required]);
                this.thirdFormGroup.get('loxysoftid').updateValueAndValidity();
                this._ref.detectChanges();
                this.thirdFormGroup.updateValueAndValidity();
            } else {
                this.thirdFormGroup.get('loxysoftid').clearValidators();
                this.thirdFormGroup.get('loxysoftid').updateValueAndValidity();
                this._ref.detectChanges();
                this.thirdFormGroup.updateValueAndValidity();
            }
        }
    }

    slideToggleChange(e) { }

    submitLeaveDetails() {
        if (this.mode == 'update' || this.employeeData.Employee_id) {
            this.employeeData.leave = this.leaveList.controls['leaveListFormArray'].value;
            this.employeeData.leave.forEach((obj) => {
                let toSendFromDate = Moments(obj.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                let toSendToDate = Moments(obj.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                toSendFromDate = toSendFromDate + 'Z';
                toSendToDate = toSendToDate + 'Z';
                obj.fromdate = toSendFromDate;
                obj.todate = toSendToDate;
            });
            this.personalService.updateLeave(this.employeeData).subscribe((res: any) => {
                if (res.message === 'Updated Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this._ref.detectChanges();
                this.resetAlert();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });
        }

    }

    submitProvisionDetails() {
        if (this.mode == 'update' || this.employeeData.Employee_id) {
            let toSendProvision = this.provisionList.controls['provisionListFormArray'].value;
            let toSendCompensation = this.compensationList.controls['compensationListFormArray'].value;
            let setProjectData = this.employeeData.Projects;
            let toSendProvArr: any = [];

            if (toSendProvision.length > 0) {
                toSendProvision.forEach((objDat, ind) => {
                    let toSendFromDate = Moments(objDat.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                    let toSendToDate = Moments(objDat.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                    toSendFromDate = toSendFromDate + 'Z';
                    toSendToDate = toSendToDate + 'Z';
                    toSendProvArr.push({
                        Client_id: objDat.Client_id,
                        Project_id: objDat.project ? objDat.project.Project_id : '',
                        Product_id: objDat.product ? objDat.product.prod_id : '',
                        fromdate: toSendFromDate,
                        todate: toSendToDate,
                        Provision_rate: objDat.provision
                    });
                });
                let toSendProvData: any = {
                    Employee_id: this.employeeData.Employee_id,
                    Projects: toSendProvArr
                };

                this.personalService.addProvisionForEmployee(toSendProvData).subscribe((res1: any) => {
                    if (res1.message === 'Added Successfully') {
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                    } else {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                    }
                    this._ref.detectChanges();
                    this.resetAlert();
                }, err => {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this._ref.detectChanges();
                    this.resetAlert();
                });

            }
            this.employeeData.Projects = setProjectData;
        }
    }

    submitCompensationDetails() {
        if (this.mode == 'update' || this.employeeData.Employee_id) {
            let toSendCompensation = this.compensationList.controls['compensationListFormArray'].value;
            let setProjectData = this.employeeData.Projects;
            let toSendCompData: any = [];
            if (toSendCompensation.length > 0) {
                toSendCompensation.forEach((objDat3, ind) => {
                    let toSendFromDate = Moments(objDat3.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                    let toSendToDate = Moments(objDat3.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                    toSendFromDate = toSendFromDate + 'Z';
                    toSendToDate = toSendToDate + 'Z';
                    toSendCompData.push({
                        Client_id: objDat3.Client_id,
                        Summa_rate: objDat3.hourly,
                        fromdate: toSendFromDate,
                        todate: toSendToDate,
                        Project_id: objDat3.project.Project_id
                    });
                });
                this.personalService.addSalaryForEmployee({ salaries: toSendCompData, Employee_id: this.employeeData.Employee_id }).subscribe((res1: any) => {
                    if (res1.message === 'Added Successfully') {
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                    } else {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                    }
                    this._ref.detectChanges();
                    this.resetAlert();
                }, err => {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this._ref.detectChanges();
                    this.resetAlert();
                });

            }
            this.employeeData.Projects = setProjectData;
        }
    }

    submitFastIonDetails() {
        if (this.mode == 'update' || this.employeeData.Employee_id) {
            this.employeeData.fixedsalary = this.fastionList.controls['fastionListFormArray'].value;
            this.employeeData.fixedsalary.forEach((obj) => {
                let toSendFromDate = Moments(obj.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                let toSendToDate = Moments(obj.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                toSendFromDate = toSendFromDate + 'Z';
                toSendToDate = toSendToDate + 'Z';
                obj.fromdate = toSendFromDate;
                obj.todate = toSendToDate;
            });
            this.personalService.updateEmployeeFixedSalary(this.employeeData).subscribe((res: any) => {
                if (res.message === 'Updated Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this._ref.detectChanges();
                this.resetAlert();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });
        }
    }

    submitSocialFeeDetails() {
        if (this.mode == 'update' || this.employeeData.Employee_id) {
            this.employeeData.socialfee = this.socialfeeList.controls['socialfeeListFormArray'].value;
            this.employeeData.socialfee.forEach((obj) => {
                let toSendFromDate = Moments(obj.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                let toSendToDate = Moments(obj.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                toSendFromDate = toSendFromDate + 'Z';
                toSendToDate = toSendToDate + 'Z';
                obj.fromdate = toSendFromDate;
                obj.todate = toSendToDate;
            });
            this.personalService.updateEmployeeSocialFee(this.employeeData).subscribe((res: any) => {
                if (res.message === 'Updated Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this._ref.detectChanges();
                this.resetAlert();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });
        }
    }
    submitVacationPayDetails() {
        if (this.mode == 'update' || this.employeeData.Employee_id) {
            this.employeeData.holidaypay = this.vacationpayList.controls['vacationpayListFormArray'].value;
            this.employeeData.holidaypay.forEach((obj) => {
                let toSendFromDate = Moments(obj.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                let toSendToDate = Moments(obj.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                toSendFromDate = toSendFromDate + 'Z';
                toSendToDate = toSendToDate + 'Z';
                obj.fromdate = toSendFromDate;
                obj.todate = toSendToDate;
            });
            this.personalService.updateEmployeeHolidayPayDetails(this.employeeData).subscribe((res: any) => {
                if (res.message === 'Updated Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this._ref.detectChanges();
                this.resetAlert();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });
        }
    }


    private parseISOString(s) {
        if (s) {
            let b = s.split(/\D+/);
            return Moments(Date.UTC(b[0], --b[1], b[2], b[3], b[4], b[5])).toISOString();
        } else {
            return '';
        }

    }

    private resetAlert() {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this._ref.detectChanges();
        }, 5000);
    }

    private resetStepAlert(stepper, stayInStep) {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this._ref.detectChanges();
            if (!stayInStep) {
                setTimeout(() => { stepper.next(); }, 500);
            }
        }, 1000);
    }
    private resetsStepAlert(stepper, stayInStep) {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this.resMessage.message = '';
            this._ref.detectChanges();
        }, 5000);
    }

    private resetTableAlert() {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this._ref.detectChanges();
        }, 5000);
    }

    filterProjectArr(toFilterArr, projectId) {
        let retObj = { id: -1 };
        if (toFilterArr.length > 0) {
            toFilterArr.forEach((obj, in1) => {
                if (obj.Project_id == projectId) {
                    retObj.id = in1;
                }
            });
        }
        return retObj;
    }

    filterProductsArr(toFilterArr, productId) {
        let retObj = { id: -1 };
        if (toFilterArr && toFilterArr.length > 0) {
            toFilterArr.forEach((obj, in2) => {
                if (obj.Product_id === productId) {
                    retObj.id = in2;
                }
            });
        }
        return retObj;
    }

    compareProject(opt1: any, opt2: any) {
        if (opt1.Project_id === opt2.Project_id && opt1.Project_name === opt2.Project_name) {
            return true;
        } else {
            return false;
        }
    }

    compareProduct(opt1: any, opt2: any) {
        if (opt1.prod_id === opt2.Product_id) {
            return true;
        } else {
            return false;
        }
    }

    enableStep(toEnable, stepper) {
        this.stepSelector(stepper);
        if (toEnable === 'firstStep') {
            this.firstFormGroup.enable();
        }
        if (toEnable === 'secondStep') {
            this.secondFormGroup.enable();
        }
        if (toEnable === 'thirdStep') {
            this.thirdFormGroup.enable();
            if (this.employeeData.role.toLowerCase() == 'superadmin') {
                if (this.userData.role != 'superadmin') {
                    this.thirdFormGroup.get('role').disable();
                }
            }
        }
        if (toEnable === 'fourthStep') {
            this.fourthFormGroup.enable();
        }

    }

    checkStepper() {
        let setLinear = true;
        if (this.mode === 'view') {
            if (this.firstFormGroup.disabled && this.secondFormGroup.disabled && this.thirdFormGroup.disabled && this.fourthFormGroup.disabled) {
                setLinear = false;
            } else {
                if (!this.firstFormGroup.disabled) {
                    if (this.firstFormGroup.valid) {
                        setLinear = false;
                    } else {
                        setLinear = true;
                    }
                }
                if (!this.secondFormGroup.disabled) {
                    if (this.secondFormGroup.valid) {
                        setLinear = false;
                    } else {
                        setLinear = true;
                    }
                }
                if (!this.thirdFormGroup.disabled) {
                    if (this.thirdFormGroup.valid) {
                        setLinear = false;
                    } else {
                        setLinear = true;
                    }
                }
                if (!this.fourthFormGroup.disabled) {
                    if (this.fourthFormGroup.valid) {
                        setLinear = false;
                    } else {
                        setLinear = true;
                    }
                }
            }
        } else {
            if (this.firstFormGroup.valid && this.secondFormGroup.valid && this.thirdFormGroup.valid && this.fourthFormGroup.valid) {
                setLinear = false;
            } else {
                setLinear = true;
            }
        }
        return setLinear;
    }

    setClientByProject(getProjId) {
        let setClientId: any;
        this.projectsArr.forEach((projObj) => {
            if (projObj.Project_id === getProjId) {
                setClientId = projObj.Client_id;
            }
        });
        return setClientId;
    }

    getClientListByProject() {
        this.clientsArr.forEach((cObj) => {
            this.projClientArr.push(cObj);
        });
        this.projClientArr.sort(function (a, b) {
            if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
            if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
            return 0;
        });
    }

    filterClientProjArr(toFilterArr, clientId) {
        let retObj = { id: -1 };
        if (toFilterArr.length > 0) {
            toFilterArr.forEach((obj, in1) => {
                if (obj._id == clientId) {
                    retObj.id = in1;
                }
            });
        }
        return retObj;
    }

    saveEmployeeProjectDetails() {
        let tosendProj: any = {};
        tosendProj = {
            Project_id: this.employeeData.Projects.Project_id,
            Employee_id: this.employeeData.Employee_id
        };
        this.personalService.addProjectForEmployee(tosendProj).subscribe((res1: any) => {

        }, err => {
            console.error(err);
        });
    }

    setProvisionAndCommission() {
        if (this.isSetProvisionAndCommission.employeeLoaded && this.isSetProvisionAndCommission.clientLoaded && this.isSetProvisionAndCommission.projectLoaded && this.isSetProvisionAndCommission.productLoaded) {
            let provisionData = <FormArray>this.provisionList.controls['provisionListFormArray'];
            let initInd = 0;
            let compInd = 0;
            if (this.employeeData.EmployeeProvisons && this.employeeData.EmployeeProvisons.length > 0) {
                this.employeeData.EmployeeProvisons.forEach((obj) => {

                    if (obj.Products && obj.Products.length > 0) {
                        obj.Products.forEach((obj2, ind2) => {
                            if (obj2.EmployeeProductCost && obj2.EmployeeProductCost.length > 0) {
                                obj2.EmployeeProductCost.forEach((obj3, ind2) => {
                                    initInd += 1;
                                    let objval: any = {};
                                    objval = {
                                        project_id: obj.Project_id,
                                        project_name: obj.Project_name,
                                        product_id: obj2.Product_id,
                                        product_name: obj2.Product_name,
                                        provision: obj3.Provision_rate,
                                        fromdate: this.parseISOString(obj3.fromdate),
                                        todate: this.parseISOString(obj3.todate)
                                    };
                                    objval.Client_id = this.setClientByProject(obj.Project_id);
                                    this.getProjectListByClient(objval.Client_id, initInd - 1, obj.Project_id);
                                    this.getProductsListByProject(objval.Client_id, obj, initInd - 1);
                                    provisionData.push(this.setProvisionListArr(objval));
                                });
                            }
                        });
                    }
                });
                this.getClientListByProject();
                if (!provisionData.controls[0]) {
                    provisionData.push(this.initProvisionListArr());
                }
            } else {
                provisionData.push(this.initProvisionListArr());
                this.getClientListByProject();
            }

            let compensationData = <FormArray>this.compensationList.controls['compensationListFormArray'];
            if (this.employeeData.EmployeeProjectCost && this.employeeData.EmployeeProjectCost.length > 0) {
                this.employeeData.EmployeeProjectCost.forEach((obj) => {

                    let sendObj: any = {};
                    if (obj.EmployeeProjectCost && obj.EmployeeProjectCost.length > 0) {
                        obj.EmployeeProjectCost.forEach((obj2, ind2) => {
                            compInd += 1;
                            sendObj = {
                                Client_id: this.setClientByProject(obj.Project_id),
                                project_id: obj.Project_id,
                                project_name: obj.Project_name,
                                hourly: obj2.Summa_rate,
                                fromdate: this.parseISOString(obj2.fromdate),
                                todate: this.parseISOString(obj2.todate)
                            };
                            compensationData.push(this.setCompensationListArr(sendObj));
                            this.getProjectSumListByClient(sendObj.Client_id, compInd - 1, obj.Project_id);
                        });
                    }
                });
                if (!compensationData.controls[0]) {
                    compensationData.push(this.initCompensationListArr());
                }
            } else {
                compensationData.push(this.initCompensationListArr());
            }
        }
    }

    getProductCountArr(val, provData, rejVal) {
        let b: any[] = [];
        if (provData) {
            if (!val || val.length == 0) {
                provData.forEach((pdata) => {
                    b.push({
                        sales_count: '',
                        reject_count: ''
                    });
                });
            } else {
                provData.forEach((pdata) => {
                    let noCount = true;
                    if (!rejVal || rejVal.length == 0) {

                        val.forEach((vdata) => {
                            if (vdata.product_id == pdata.product_id) {
                                b.push({
                                    sales_count: vdata.sales_count,
                                    reject_count: ''
                                });
                                noCount = false;
                            }
                        });
                    } else {
                        val.forEach((vdata) => {
                            let productMatch = false;
                            let rejectCount = '';
                            if ((vdata.product_id == pdata.product_id)) {
                                rejVal.forEach((rData) => {
                                    if ((vdata.product_id == rData.product_id) && rData.sales_count) {
                                        rejectCount = rData.sales_count;
                                    }
                                    productMatch = true;
                                });
                            }
                            if (productMatch) {
                                b.push({
                                    sales_count: vdata.sales_count,
                                    reject_count: rejectCount
                                });
                                noCount = false;
                            }
                        });
                    }
                    if (noCount) {
                        b.push({
                            sales_count: '',
                            reject_count: ''
                        });
                    }
                });
                return b;
            }
        }
        return b;
    }

    getTotalProv() {
        let b: any[] = [];
        if (this.salaryReportList[0] && this.salaryReportList[0].monthly_salary_data[0] && this.salaryReportList[0].monthly_salary_data[0].provison_data) {
            for (let prodL = 0; prodL < this.salaryReportList[0].monthly_salary_data[0].provison_data.length; prodL++) {
                let total_prod_provisions = 0;
                this.salaryReportList[0].monthly_salary_data.forEach((msd) => {
                    msd.provison_data.forEach((pd, pdKey) => {
                        if (pdKey === prodL) {
                            total_prod_provisions += pd.total_products_provision;
                        }
                    });
                });
                b.push(total_prod_provisions);
            }
        }
        return b;
    }

    getTotOrdersForIndvProducts(col) {
        let b: any[] = [];
        if (this.salaryReportList[0] && this.salaryReportList[0].monthly_salary_data) {
            for (let prodL = 0; prodL < (this.salaryReportList[0].monthly_salary_data[0].provison_data.length + 2); prodL++) {
                b.push({ value: "", isEmpty: true });
            }
            let total_prod_orders = 0;
            let total_prod_rejected_orders = 0;
            let product_pos;
            let prod_total_prov = 0;
            this.salaryReportList[0].monthly_salary_data.forEach((msd) => {
                msd.provison_data.forEach((pd, pdKey) => {
                    if (pd.product_name === col) {
                        total_prod_orders += pd.total_orders;
                        total_prod_rejected_orders += pd.rejected_order;
                        product_pos = pdKey;
                    }
                });
            });
            if (this.salaryReportList[0].monthly_total_summary[0]) {
                this.salaryReportList[0].monthly_total_summary[0].sales_data.forEach((mtsd) => {
                    if (mtsd.product_name === col) {
                        prod_total_prov = mtsd.product_provison_cost;
                    }
                });
            }
            if (product_pos > -1) {
                if (total_prod_rejected_orders) {
                    b[0].value = total_prod_orders + '(' + total_prod_rejected_orders + ')';
                } else {
                    b[0].value = total_prod_orders;
                }
                b[0].isEmpty = false;
                b[b.length - 1].value = prod_total_prov;
                b[b.length - 1].isEmpty = false;
            }
        }
        return b;
    }

    addSchedule(stepper: MatStepper, stayInStep: any) {
        this.datas = [];
        this.checkDateRange();
        if (!this.isFromPastDate && !this.isToPastDate) {
            this.week.forEach((e, index) => {
                if (e != '') {
                    if (((e.start_time) && (e.start_time.hour > 0 || e.start_time.hour === 0) && (e.start_time.minute > 0 || e.start_time.minute === 0)) && ((e.end_time) && (e.end_time.hour > 0 || e.end_time.hour === 0) && (e.end_time.minute > 0 || e.end_time.minute === 0)) && ((e.lunch) && (e.lunch.hour > 0 || e.lunch.hour == 0) && (e.lunch.minute > 0 || e.lunch.minute == 0))) {
                        this.datas.push({ day: e.day, start_time: e.start_time.hour + ':' + e.start_time.minute, end_time: e.end_time.hour + ':' + e.end_time.minute, lunch: e.lunch.hour + ':' + e.lunch.minute });
                    } else if (((e.start_time) && (e.start_time.hour > 0 || e.start_time.hour === 0) && (e.start_time.minute > 0 || e.start_time.minute === 0)) && ((e.end_time) && (e.end_time.hour > 0 || e.end_time.hour === 0) && (e.end_time.minute > 0 || e.end_time.minute === 0))) {
                        this.datas.push({ day: e.day, start_time: e.start_time.hour + ':' + e.start_time.minute, end_time: e.end_time.hour + ':' + e.end_time.minute, lunch: '' });
                    } else {
                        this.datas.push({ day: e.day, start_time: '', end_time: '', lunch: '' });
                    }
                }
            });
            if (this.datas != '') {
                if (this.datas.length == 7) {
                    let toSendScheduleData: any = {
                        employee_id: this.employeeId,
                        workschedule: this.datas,
                        updatedBy: this.userData.id,
                        start_date: Moments(this.scheduleStartDate).format('YYYY-MM-DD'),
                        end_date: Moments(this.scheduleEndDate).format('YYYY-MM-DD')
                    };
                    this.personalService.addEmployeeSchedule(toSendScheduleData).subscribe(res => {
                        if (res) {
                            this.resMessage.success = true;
                            this.resMessage.error = false;
                            this.resMessage.message = "Schema läggs till med framgång";
                            this.modalRef.close();
                            this.onCalendarInit(this.start_dates, this.end_dates);
                        } else {
                            this.resMessage.success = false;
                            this.resMessage.error = true;
                            this.resMessage.message = "Schema har inte lagts till";
                        }
                        this._ref.detectChanges();
                        this.resetsStepAlert(stepper, stayInStep);
                    }, err => {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this._ref.detectChanges();
                        this.resetsStepAlert(stepper, true);
                    });
                }
            }
        }
    }

    checkForProductCol(prov_data, col) {
        let colIdentified = false;
        if (prov_data && col) {
            colIdentified = prov_data.find(x => x.product_name === col);
        }
        return colIdentified;
    }

    getProdColData(prov_data, col) {
        let ord: any[] = [];
        if (prov_data) {
            if (!col) {
                prov_data.forEach((pdata) => {
                    ord.push({ total_order_count: '', rejected_order_count: '' });
                });
            } else {
                prov_data.forEach((pdata) => {
                    if (col == pdata.product_name) {
                        if (pdata.rejected_order) {
                            ord.push({
                                total_order_count: pdata.total_orders,
                                rejected_order_count: pdata.rejected_order
                            });
                        } else {
                            ord.push({
                                total_order_count: pdata.total_orders,
                                rejected_order_count: ''
                            });
                        }
                    } else {
                        ord.push({ total_order_count: '', rejected_order_count: '' });
                    }
                });
                return ord;
            }
        }
        return ord;
    }


    getDay(i) {
        let daynumber = new Date(this.yearSelected, this.monthSelected - 1, i).getDay();
        switch (daynumber) {
            case 0:
                return 'Sön';
            case 1:
                return 'Mån';
            case 2:
                return 'Tis';
            case 3:
                return 'Ons';
            case 4:
                return 'Tor';
            case 5:
                return 'Fre';
            case 6:
                return 'Lör';
            default:
                return 'default';
        }
    }

    compareDepartmentData(opt1: any, opt2: any) {
        if (opt1._id === opt2._id && opt1.department === opt2.department) {
            return true;
        } else {
            return false;
        }
    }

    openModal(content, contentAccessId, toProduct?) {
        this.addLeave.enable();
        this.employeeAttendanceNotes = '';
        this.adminAttendanceNotes = '';
        if (content === 'schedule') {
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-schedule-modal', size: 'lg', backdrop: "static" });
        } else if (content === 'leave') {
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content === 'checkEvent') {
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content === 'loxy_history') {
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content === 'department_history') {
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content == 'notes') {
            this.addLeave.patchValue({
                note: toProduct.note
            });
            this.addLeave.disable();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'approval_notes') {
            this.addLeave.patchValue({
                approval_note: toProduct.approval_note
            });
            this.addLeave.disable();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'agreement') {
            if (toProduct) {
                this.agreementFormGroup.patchValue({
                    Status: toProduct.agreement,
                    fromDate: toProduct.startDate,
                    todate: toProduct.endDate,
                    notes: toProduct.notes
                });
            } else {
                this.initializeAgreementFormControls();
            }
            if (toProduct && toProduct._id) {
                this.agreementId = toProduct._id;
            } else {
                this.agreementId = null;
            }
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'history') {
            if (toProduct.attendance_history && (toProduct.attendance_history.length > 0)) {
                this.attendanceHistory = toProduct.attendance_history;
            } else {
                this.attendanceHistory = [];
            }
            if (toProduct.leave_details && (toProduct.leave_details.length > 0)) {
                this.permissionHistory = [];
                toProduct.leave_details.forEach((leaveObj) => {
                    if (leaveObj.fromdate == leaveObj.todate && leaveObj.start_time && leaveObj.end_time) {
                        this.permissionHistory.push(leaveObj);
                    }
                });
                if (this.permissionHistory.length > 0) {
                    this.hasEmployeeRequestForPermission = true;
                } else {
                    this.hasEmployeeRequestForPermission = false;
                }
            } else {
                this.permissionHistory = [];
                this.hasEmployeeRequestForPermission = false;
            }
            if (toProduct.notes || toProduct.emp_notes) {
                this.employeeAttendanceNotes = toProduct.notes ? toProduct.notes : (toProduct.emp_notes ? toProduct.emp_notes : '');
            }
            if (toProduct.attendance_notes) {
                this.adminAttendanceNotes = toProduct.attendance_notes;
            }
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        }
        if (content == 'ledghit') {
            this.leaveId = null;
            this.addLeave.reset();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content == 'edit_ledghit') {
            if (toProduct.leave_id) {
                this.leaveId = toProduct.leave_id;
            }
            this.addLeave.patchValue({
                employee: toProduct.employee_id
            });
            let start = toProduct.start_time ? toProduct.start_time : '00:00:00';
            let end = toProduct.end_time ? toProduct.end_time : '00:00:00';
            let time_start = start.split(":");
            let time_end = end.split(":");
            this.time1 = { hour: parseInt(time_start[0]), minute: parseInt(time_start[1]), second: 0 };
            this.time2 = { hour: parseInt(time_end[0]), minute: parseInt(time_end[1]), second: 0 };
            this.addLeave.controls['fromdate'].setValue(toProduct.fromdate);
            this.addLeave.controls['todate'].setValue(toProduct.todate);
            this.addLeave.controls['note'].setValue(toProduct.note);
            if (!toProduct.start_time && !toProduct.end_time) {
                this.addLeave.controls['options'].setValue('leave');
                this.onSelectionChange({ value: 'leave' });
            } else {
                this.addLeave.controls['options'].setValue('permission');
                this.onSelectionChange({ value: 'permission' });
            }
            this.addLeave.addControl('leave_id', new FormControl(toProduct.leave_id));
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content == 'single_day_schedule') {
            this.modalFormGroup.reset();
            this.modalFormGroup = this._formBuilder.group({
                fromdate: ['', Validators.required],
                starttime: [{ hour: '', minute: '' }],
                finaltime: [{ hour: '', minute: '' }],
                lunchtime: [{ hour: '', minute: '' }],
                notes: [''],
            });
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content === 'ind_bonus_create') {
            this.updateErrMsg = false;
            this.bonusCreateOrupdate = 'create';
            this.individualBonusFormGroup.reset();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-provision-modal', backdrop: "static" });
        } else if (content === 'ind_bonus_update') {
            this.updateErrMsg = false;
            this.bonusCreateOrupdate = 'update';
            this.updateSettingsID = toProduct._id;
            this.individualBonusFormGroup.patchValue({
                recruit_bonus: toProduct.Recurit_bonus,
                start_date: toProduct.From_date,
                end_date: toProduct.To_date == "--" ? '' : toProduct.To_date
            });
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-provision-modal', backdrop: "static" });

        } else if (content === 'ind_employee_bonus_create') {
            this.updateErrMsg = false;
            this.bonusCreateOrupdate = 'create';
            this.individualEmployeeBonusFormGroup.reset();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-provision-modal', backdrop: "static" });
        } else if (content === 'ind_employee_bonus_update') {
            this.updateErrMsg = false;
            this.bonusCreateOrupdate = 'update';
            this.updateSettingsID = toProduct._id;
            this.individualEmployeeBonusFormGroup.patchValue({
                recruit_bonus: toProduct.Recurit_bonus,
                start_date: toProduct.From_date,
                end_date: toProduct.To_date == "--" ? '' : toProduct.To_date,
                employee_id: toProduct.employee_id
            });
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-provision-modal', backdrop: "static" });
        } else if (content === 'ind_bonus_delete') {
            this.individualBonusId = toProduct._id;
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-provision-modal', backdrop: "static" });
        } else if (content === 'create_target_hours') {
            this.updateErrMsg = false;
            this.targetCreateOrupdate = 'create';
            this.targetSettingsID = '';
            this.targetHoursFormGroup.reset();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-provision-modal', backdrop: "static" });
        } else if (content === 'update_target_hours_list') {
            this.updateErrMsg = false;
            this.targetCreateOrupdate = 'update';
            this.targetSettingsID = toProduct._id;
            this.targetHoursFormGroup.patchValue({
                loxysoft_hours: toProduct.Loxysoft_hours,
                month: toProduct.Month,
                year: toProduct.Year
            });
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-provision-modal', backdrop: "static" });
        } else if (content == 'comment') {
            this.addComment.enable();
            this.addComment.patchValue({
                comments: ''
            });
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        } else if (content == 'commentNotes') {
            this.addComment.enable();
            this.addComment.patchValue({
                comments: toProduct.comments
            });
            this.addComment.disable();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-timersattning-modal', backdrop: "static" });
        }
        if (content === 'loxy_create') {
            this.updateErrMsg = false;
            this.loxyCreateOrupdate = 'create';
            this.loxyId = null;
            this.addLoxy.reset();
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        } else if (content == 'loxy_update') {
            this.updateErrMsg = false;
            this.loxyCreateOrupdate = 'update';
            if (toProduct._id) {
                this.loxyId = toProduct._id;
            }
            this.addLoxy.patchValue({
                Employee_id: toProduct.Employee_id,
                loxysoft_id: toProduct.loxysoft_id,
                fromdate: toProduct.fromdate,
                todate: toProduct.todate
            });
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });

        }

        this.modalRef.result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
    getLeave(stepper: MatStepper, stayInStep: any) {
        this.submitted = true;
        if (this.empLeave.invalid) {
            return;
        }

        let input_data = {
            date: Moments(this.empLeave.value.leaveDate).format('YYYY-MM-DD'),
            start_time: "00:00",
            end_time: "00:00",
            lunch: "00:00",
            convertleave: 1,
            notes: this.empLeave.value.leaveNotes
        };
        this.personalService.calendarSchedule(this.employeeId, input_data, 1).subscribe(res => {
            if (res) {
                this.resMessage.success = true;
                this.resMessage.error = false;
                this.resMessage.message = "Lämna Utated framgångsrikt";
                this.empLeave.reset();
                this.modalRef.close();
                this.onCalendarInit(this.start_dates, this.end_dates);
            } else {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this.resMessage.message = "Lämna utated misslyckades";
            }
            this._ref.detectChanges();
            this.resetsStepAlert(stepper, stayInStep);
        }, err => {
            this.resMessage.success = false;
            this.resMessage.error = true;
            this._ref.detectChanges();
            this.resetsStepAlert(stepper, true);
        });
    }

    start_time: FormControl;
    end_time: FormControl;
    lunch: FormControl;
    leave: FormControl;
    notes: FormControl;
    day: FormControl;

    leaveDate: FormControl;
    leaveNotes: FormControl;

    createFormControls() {
        this.start_time = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.end_time = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.lunch = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.notes = new FormControl('');
        this.leave = new FormControl('');
        this.day = new FormControl('');
        this.leaveDate = new FormControl('');
        this.leaveNotes = new FormControl('');
    }
    get f() { return this.scheduler.controls; }
    onCalendarInit(start?, end?) {
        this.attendanceSummaryMonthYear.month = this.ucCalendar.fullCalendar('getView').calendar.currentDate.format('MM');
        this.attendanceSummaryMonthYear.year = this.ucCalendar.fullCalendar('getView').calendar.currentDate.format('YYYY');
        this.yearSelected = parseInt(this.attendanceSummaryMonthYear.year);
        this.getChartData();
        this.calendarEventData = [];
        this.getAttendanceStatuswiseSummary();
        let fromDate = Moments(this.ucCalendar.fullCalendar('getView').intervalStart).format('YYYY-MM-DD');
        let toDate = Moments(this.ucCalendar.fullCalendar('getView').intervalEnd).format('YYYY-MM-DD');
        this.personalService.calendarMonthly(this.employeeId, { start_date: fromDate, end_date: toDate }).subscribe(res => {
            if (res) {
                if (res.length > 0) {
                    this.calendarEventData = [];
                    res.forEach((item, index) => {
                        if ((item.department_cal_details[0] && (item.department_cal_details[0].starttime !== "00:00:00" && item.department_cal_details[0].endtime !== "00:00:00")) || (item.status_id >= 0)) {
                            switch (item.status_id) {
                                case 0:
                                    item.backgroundColor = "#70ad47";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 1:
                                    item.backgroundColor = "#c3c341";
                                    item.textColor = '#0e0e0e';
                                    break;
                                case 2:
                                    item.backgroundColor = "#ffbf00";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 3:
                                    item.backgroundColor = "#bd3530";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 4:
                                    item.backgroundColor = "#cc66ff";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 5:
                                    item.backgroundColor = "#c5e0b2";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 6:
                                    item.backgroundColor = "#8eabdc";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 9:
                                    item.backgroundColor = "#C8A2C8";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 10:
                                    item.backgroundColor = "#FFC0CB";
                                    item.textColor = '#F8FBEF';
                                    break;
                                case 11:
                                    item.backgroundColor = "#028A0F";
                                    item.textColor = '#F8FBEF';
                                    break;
                                default:
                                    item.backgroundColor = "#a2a2a2";
                                    item.textColor = '#F8FBEF';
                                    break;
                            }
                            // if(item.status == "Ledighet - påverkar inte timmarna"){
                            //     item.backgroundColor = "#C8A2C8";
                            // }
                            // if(item.status == "Ledighet - påverkar timmarna"){
                            //     item.backgroundColor = "#C1E3C6";
                            //     item.textColor = '#0e0e0e';
                            // }
                            if (item.is_company_leave == 1) {
                                item.backgroundColor = "#de9943";
                            }
                            this.calendarEventData.push(item);
                        }
                    });
                    this.ucCalendar.renderEvents(this.calendarEventData);
                }
            }
        });
    }

    getView() {
        this.onCalendarInit();
    }

    updateTimings(stepper: MatStepper, stayInStep: any) {
        this.submitted = true;
        if (this.scheduler.invalid) {
            return;
        }
        let start_time_hour = this.scheduler.value.start_time.hour == 0 ? "00" : this.scheduler.value.start_time.hour;
        let start_time_minute = this.scheduler.value.start_time.minute == 0 ? "00" : this.scheduler.value.start_time.minute;
        let end_time_hour = this.scheduler.value.end_time.hour == 0 ? "00" : this.scheduler.value.end_time.hour;
        let end_time_minute = this.scheduler.value.end_time.minute == 0 ? "00" : this.scheduler.value.end_time.minute;
        let lunch_hour = this.scheduler.value.lunch.hour == 0 ? "00" : this.scheduler.value.lunch.hour;
        let lunch_minute = this.scheduler.value.lunch.minute == 0 ? "00" : this.scheduler.value.lunch.minute;
        let leave = this.scheduler.value.leave == true ? 1 : (this.attendance_id != '' && this.stat != '') ? 0 : 2;
        let input_data;
        input_data = {
            date: this.days,
            start_time: start_time_hour + ":" + start_time_minute,
            end_time: end_time_hour + ":" + end_time_minute,
            lunch: lunch_hour + ":" + lunch_minute,
            convertleave: this.scheduler.value.leave == true ? 1 : 0,
            notes: this.scheduler.value.notes,
            attendance_status: ((this.scheduler.value.statusid >= 0) && (this.scheduler.value.statusid < 7)) ? this.scheduler.value.statusid : ''
        };
        this.personalService.calendarSchedule(this.employeeId, input_data, leave).subscribe(res => {
            if (res) {
                this.resMessage.success = true;
                this.resMessage.error = false;
                this.resMessage.message = "Uppdateras framgångsrikt";
                this.modalRef.close();
                this.onCalendarInit(this.start_dates, this.end_dates);
            } else {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this.resMessage.message = "Uppdateras inte framgångsrikt";
            }
            this._ref.detectChanges();
            this.resetsStepAlert(stepper, stayInStep);
        }, err => {
            this.resMessage.success = false;
            this.resMessage.error = true;
            this._ref.detectChanges();
            this.resetsStepAlert(stepper, true);
        });
    }

    eventClick(evt, contentAccessId) {
        if ((this.userData.role == 'admin' || this.userData.role == 'superadmin')) {
            this.days = evt.event.start._i;
            this.note = evt.event.notes;
            this.stat = evt.event.status != '' ? evt.event.status_id : "";
            this.attendance_id = (evt.event.attendance_id != '' && evt.event.status != '') ? evt.event.attendance_id : "";
            let start = evt.event.start_time;
            let end = evt.event.end_time;
            let lunch = evt.event.lunch;
            let time_start = start.split(":");
            let time_end = end.split(":");
            let time_lunch = lunch.split(":");
            this.time1 = { hour: parseInt(time_start[0]), minute: parseInt(time_start[1]), second: 0 };
            this.time2 = { hour: parseInt(time_end[0]), minute: parseInt(time_end[1]), second: 0 };
            this.time3 = { hour: parseInt(time_lunch[0]), minute: parseInt(time_lunch[1]), second: 0 };
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
        }
    }

    getProjectSumListByClient(clientId, ind, Project_id?: any) {
        this.clientProjectsSumArr[ind] = [];
        this.projectsArr.forEach((obj) => {
            if (obj.Client_id === clientId) {
                this.clientProjectsSumArr[ind].push(obj);
            }
        });
    }

    createLoxy() {
        let form1 = this.addLoxy.value;

        let fromdate = Moments(this.addLoxy.value.fromdate).format('YYYY-MM-DD');
        let todate = Moments(this.addLoxy.value.todate).format('YYYY-MM-DD');
        if (this.addLoxy.valid) {
            this.spinner.active = true;
            let form1 = this.addLoxy.value;
            let loxyData = {
                "Employee_id": form1.employee_id,
                "loxysoft_id": form1.loxysoft_id,
                "fromdate": fromdate,
                "todate": todate
            }
            if (this.loxyCreateOrupdate === 'create') {
                this.personalService.addLoxy(loxyData).subscribe(res => {
                    if (res.message === 'Added Successfully') {
                        this.resCreateMessage.success = true;
                        this.resCreateMessage.error = false;
                    }
                    else {
                        this.spinner.active = false;
                        this.resCreateMessage.success = false;
                        this.resCreateMessage.error = true;
                    }
                    this.getLoxysoftHistoryData();
                    this.modalRef.close();
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                });
            } else if (this.loxyCreateOrupdate === 'update') {
                this.personalService.putLoxy(this.loxyId, loxyData).subscribe(res => {
                    if (res.message === 'Edited Successfully') {
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                    } else {
                        this.spinner.active = false;
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                    }
                    this.getLoxysoftHistoryData();
                    this.modalRef.close();
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 5000)
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                });
            }

            this.spinner.active = false;
        }
    }

    initDepCompensationListArr() {
        return this._formBuilder.group({
            Department_id: [''],
            hourly: [''],
            fromdate: [''],
            todate: ['']
        });
    }

    addDepCompensationListArr() {
        if (!this.departmentCompensationList.disabled) {
            const control = <FormArray>this.departmentCompensationList.controls['depCompensationListFormArray'];
            control.push(this.initDepCompensationListArr());
        }
    }

    deleteDepCompensationListArr(index: number) {
        if (!this.departmentCompensationList.disabled) {
            const control = <FormArray>this.departmentCompensationList.controls['depCompensationListFormArray'];
            control.removeAt(index);
        }
    }

    setDepCompensationListArr(resObj) {
        return this._formBuilder.group({
            Department_id: [resObj.Department_id],
            hourly: [resObj.hourly],
            fromdate: [this.parseISOString(resObj.fromdate)],
            todate: [this.parseISOString(resObj.todate)]
        });
    }

    submitDepartmentCompensationList() {
        let toSendDepCompensation = this.departmentCompensationList.controls['depCompensationListFormArray'].value;
        let toSendDepCompData: any = [];
        if (toSendDepCompensation.length > 0) {
            toSendDepCompensation.forEach((objDat3, ind) => {
                let toSendFromDate = Moments(objDat3.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                let toSendToDate = Moments(objDat3.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
                toSendFromDate = toSendFromDate + 'Z';
                toSendToDate = toSendToDate + 'Z';
                toSendDepCompData.push({
                    Department_id: objDat3.Department_id,
                    Summa_rate: objDat3.hourly,
                    fromdate: toSendFromDate,
                    todate: toSendToDate,
                });
            });
            this.personalService.addDepartmentCompensation({ salaries: toSendDepCompData, Employee_id: this.employeeData.Employee_id }).subscribe((res1: any) => {
                if (res1.message === 'Added Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this._ref.detectChanges();
                this.resetAlert();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });
        }
    }

    getDepartmentCompensationList() {
        let toSendParams = {
            Employee_id: this.employeeData.Employee_id
        };
        this.personalService.getDepartmentCompensation(toSendParams).subscribe((res: any) => {
            let depCompensationData = <FormArray>this.departmentCompensationList.controls['depCompensationListFormArray'];
            if (res && (res.length > 0) && (typeof res != 'string')) {
                res.forEach((obj) => {
                    let sendObj: any = {};
                    if (obj) {
                        sendObj = {
                            Department_id: obj.Department_id,
                            hourly: obj.Summa_rate,
                            fromdate: this.parseISOString(obj.fromdate),
                            todate: this.parseISOString(obj.todate)
                        };
                        depCompensationData.push(this.setDepCompensationListArr(sendObj));
                    }
                });
            } else {
                depCompensationData.push(this.initDepCompensationListArr());
            }
            if (this.readOnly) {
                this.departmentCompensationList.disable();
            }
        }, err => {
            let depCompensationData = <FormArray>this.departmentCompensationList.controls['depCompensationListFormArray'];
            depCompensationData.push(this.initDepCompensationListArr());
            if (this.readOnly) {
                this.departmentCompensationList.disable();
            }
        });
    }

    getAttendanceStatuswiseSummary() {
        this.personalService.getEmployeeAttendanceStatuswiseSummary(this.employeeData.Employee_id, this.attendanceSummaryMonthYear).subscribe((resData) => {
            if (resData) {
                this.attendanceStatuswiseSummaryData = resData[0];
                this.attendanceStatuswiseSummaryData.total_hours = this.attendanceStatuswiseSummaryData.attendance_hours ? (this.attendanceStatuswiseSummaryData.attendance_hours.split(':')[0] + ':' + this.attendanceStatuswiseSummaryData.attendance_hours.split(':')[1] + ':' + this.attendanceStatuswiseSummaryData.attendance_hours.split(':')[2]) : '00:00:00';
                this.attendanceStatuswiseSummaryData.total_loxy_hours = this.attendanceStatuswiseSummaryData.loxysoft_hours ? (this.attendanceStatuswiseSummaryData.loxysoft_hours.split(':')[0] + ':' + this.attendanceStatuswiseSummaryData.loxysoft_hours.split(':')[1] + ':' + this.attendanceStatuswiseSummaryData.loxysoft_hours.split(':')[2]) : '00:00:00';
            }
        });
    }

    getChartData(chartRef?: any) {
        let espData = {
            "year": this.salaryChartYearSelected,
            "Employee_id": this.employeeId
        };
        this.personalService.getESPMonthlyReport(espData).subscribe((res: any) => {
            if (res) {
                this.espDetailData = res[0].salary_data;
                this.forsaljningRapportDiagramData.data.datasets[0].data = [];
                if (this.espDetailData.length <= 0) {
                    if (chartRef) {
                        this.salaryChart = chartRef;
                    }
                    this.salaryChart.barChartData = [];
                    if (this.salaryChart.bcd.chart != undefined) {
                        this.salaryChart.bcd.chart.update();
                    }
                }
                this.espDetailData.forEach((esObj) => {
                    esObj.tot_salary_amount = 0;
                    esObj.tot_salary_sem_amount = 0;
                    esObj.tot_salary_soc_amount = 0;
                    if (esObj.salary_data.length > 0) {
                        esObj.salary_data.forEach((sdataObj) => {
                            esObj.tot_salary_amount += sdataObj.total_salary;
                            esObj.tot_salary_sem_amount += sdataObj.total_salary_sem;
                            esObj.tot_salary_soc_amount += sdataObj.total_salary_soc;
                        });
                        this.forsaljningRapportDiagramData.data.datasets[0].data.push(parseFloat(esObj.tot_salary_sem_amount).toFixed(2));

                    } else {
                        this.forsaljningRapportDiagramData.data.datasets[0].data.push(parseFloat(esObj.tot_salary_sem_amount).toFixed(2));
                    }
                });
                this.showLegends = false;
                if (this.salaryChart) {
                    this.salaryChart.barChartData = [];
                    if (this.salaryChart.chartData.data && this.salaryChart.chartData.data.datasets) {
                        for (let i = 0; i < this.salaryChart.chartData.data.datasets.length; i++) {
                            this.salaryChart.barChartData.push({ data: this.salaryChart.chartData.data.datasets[i].data, backgroundColor: this.salaryChart.chartData.data.datasets[i].backgroundColor, label: this.salaryChart.chartData.data.datasets[i].label });
                        }
                        this.showLegends = true;
                        this.salaryChart.barChartLegend = true;
                    } else {
                        this.salaryChart.barChartData.push({ data: this.salaryChart.chartData.data, backgroundColor: this.salaryChart.chartData.backgroundColor });
                    }
                    setTimeout(() => {
                        if (this.salaryChart.bcd.chart != undefined) {
                            this.salaryChart.bcd.chart.update();
                        }
                    }, 2000);
                }
                this._ref.detectChanges();
            }
        });
    }

    getAttendanceChartData(chartRef?: any) {
        let toSendReqData = {
            month: this.acMonthSelected,
            year: this.yearSelected
        };
        this.personalService.getAttendanceLoxysoftChartData(this.employeeId, toSendReqData).subscribe((resData) => {
            if (resData) {
                this.narvaroManadsvisData.label = [];
                let toSetArrData = [];
                if (this.acMonthSelected) {
                    let dayscount = new Date(this.yearSelected, this.acMonthSelected, 0).getDate();
                    for (let i = 0; i < dayscount; i++) {
                        let dt = i + 1;
                        toSetArrData.push("" + dt + "");
                    }
                    this.narvaroManadsvisData.label = toSetArrData;
                } else {
                    this.narvaroManadsvisData.label = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'];
                }
                this.narvaroManadsvisData.data.datasets[0].data = [];
                this.narvaroManadsvisData.data.datasets[1].data = [];
                this.narvaroManadsvisData.data.datasets[2].data = [];
                this.showAttendanceLegends = false;
                if (chartRef) {
                    this.attendanceChart = chartRef;
                }
                if (resData.length > 0) {
                    resData.forEach((obj) => {
                        if (this.acMonthSelected) {
                            this.narvaroManadsvisData.data.datasets[0].data.push(parseFloat(obj.attendance_details).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[1].data.push(parseFloat(obj.loxysoft_details).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[2].data.push(parseFloat(obj.target_hours).toFixed(2));
                        } else {
                            this.narvaroManadsvisData.data.datasets[0].data.push(parseFloat(obj.worked_hours).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[1].data.push(parseFloat(obj.loxysoft_worked_hours).toFixed(2));
                            this.narvaroManadsvisData.data.datasets[2].data.push(parseFloat(obj.target_hours).toFixed(2));
                        }
                    });
                    if (this.attendanceChart) {
                        this.attendanceChart.barChartData = [];
                        this.attendanceChart.barChartLabels = [];
                    } else {
                        this.attendanceChart = { barChartData: [] };
                        this.attendanceChart = { barChartLabels: [] };
                    }
                    if (this.attendanceChart.chartData) {
                        if (this.attendanceChart.chartData.data && this.attendanceChart.chartData.data.datasets) {
                            for (let i = 0; i < this.attendanceChart.chartData.data.datasets.length; i++) {
                                this.attendanceChart.barChartData.push({ data: this.attendanceChart.chartData.data.datasets[i].data, backgroundColor: this.attendanceChart.chartData.data.datasets[i].backgroundColor, label: this.attendanceChart.chartData.data.datasets[i].label });
                            }
                            this.showAttendanceLegends = true;
                            this.attendanceChart.barChartLegend = true;
                        } else {
                            this.attendanceChart.barChartData.push({ data: this.attendanceChart.chartData.data, backgroundColor: this.attendanceChart.chartData.backgroundColor });
                        }
                    }
                    this.attendanceChart.barChartLabels = this.narvaroManadsvisData.label;
                    if (this.attendanceChart.bcd) {
                        if (this.attendanceChart.bcd.chart != undefined) {
                            this.attendanceChart.bcd.chart.config.data.labels = this.narvaroManadsvisData.label;
                            this.attendanceChart.bcd.chart.update();
                        }
                    }
                    setTimeout(() => {
                        if (this.attendanceChart) {
                            if (this.attendanceChart.bcd != undefined) {
                                if (this.attendanceChart.bcd.chart != undefined) {
                                    this.attendanceChart.bcd.chart.update();
                                }
                            }
                        }
                    }, 2000);
                }
            }
        });
    }

    getSelectedMonth(monthObj?: any) {
        if (monthObj && monthObj.value) {
            this.monthSelected = monthObj.value;
        } else {
            this.monthSelected = new Date().getMonth() + 1;
        }
        if (!((this.monthSelected == this.unchangedSelectedMonth) && (this.yearSelected == this.unchangedSelectedYear))) {
            this.unchangedSelectedMonth = this.monthSelected;
            this.unchangedSelectedYear = this.yearSelected;
            this.getESPMonthlyReport();
        }
    }

    attendanceChangeView(charRef) {
        this.changeView.viewVal = 'AttendanceCalendar';
        this.getAttendanceChartData(charRef);
    }

    salaryChangeView(charRef) {
        this.changeView.viewVal = 'Forsaljning Table';
        this.getESPMonthlyReport();
        this.getChartData(charRef);
    }

    checkDateRange() {
        this.isFromPastDate = false;
        this.isToPastDate = false;
        if (this.scheduleStartDate) {
            if (Moments(this.scheduleStartDate).unix() <= this.minDate.unix()) {
                this.isFromPastDate = true;
                this._ref.detectChanges();
            }
        }
        if (this.scheduleEndDate && this.scheduleStartDate) {
            if (Moments(this.scheduleEndDate).unix() < Moments(this.scheduleStartDate).unix()) {
                this.isToPastDate = true;
                this._ref.detectChanges();
            }
        }
    }


    openProfilePhotoModal(content, contentAccessId, toContent?) {
        if (content === 'photo') {
            this.uploader.clearQueue();
            this.imageChangedEvent = null;
            this.croppedImage = '';
            this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-schedule-modal', size: 'lg', backdrop: "static" });
        }
    }

    dropped(eventData: any) {
        this.filedata = [];
        this.uspFile = [];
        this.showCroppedImage = false;
        for (let i = 0; i < eventData.length; i++) {
            if (eventData[i].type == "image/jpeg" || eventData[i].type == "image/png" || eventData[i].type == "image/jpg") {
                this.uspFile.push(eventData[i].name);
            }
        }

        if (this.uploader.queue.length === 1) {
            this.filedata[0] = this.uploader.queue[0];
        }

    }

    uploadProfileImg() {
        if (this.filedata.length > 0) {
            this.spinner.active = true;
            let toConvertBlob: Blob = this.dataURItoBlob(this.croppedImage);
            let toSendImg = new File([toConvertBlob], this.employeeData.first_name + '_' + this.employeeData.last_name + '.png', { type: 'image/png' });
            this.personalService.profileUpload(toSendImg, this.employeeData.Employee_id).subscribe((res: any) => {
                if (res && (res.message == "upload successfully" || res.message == 'Uploaded Successfully')) {
                    this.imageChangedEvent = null;
                    this.showCroppedImage = false;
                    this.resCreateMessage.success = true;
                    this.resCreateMessage.error = false;

                    this.modalRef.close('submitted');
                    this.getEmployeeData();
                }
                setTimeout(() => {
                    this.resCreateMessage.success = false;
                    this.resCreateMessage.error = false;
                    this._ref.detectChanges();
                }, 5000)
                this._ref.detectChanges();
                this.spinner.active = false;
            }, err => {
                this.spinner.active = false;
                this.updateErrMsg = true;
            });
        }
    }

    fileChangeEvent(event: any): void {
        this.imageChangedEvent = event;
    }

    imageCropped(event: ImageCroppedEvent) {
        this.croppedImage = event.base64;
    }

    imageLoaded() {
        this.showCropper = true;
    }

    cropperReady() {
    }
    loadImageFailed() {
    }

    displayCroppedImage() {
        this.showCroppedImage = !this.showCroppedImage;
    }

    dataURItoBlob(dataURI) {
        const byteString = window.atob(dataURI.split(',')[1]);
        const arrayBuffer = new ArrayBuffer(byteString.length);
        const int8Array = new Uint8Array(arrayBuffer);
        for (let i = 0; i < byteString.length; i++) {
            int8Array[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([int8Array], { type: 'image/jpeg' });
        return blob;
    }

    deleteFile(item) {
        this.uploader.removeFromQueue(item);
        this.imageChangedEvent = null;
        this.croppedImage = '';
        this.showCroppedImage = false;
    }

    getEmployeeClientSelectionList() {
        this.personalService.employeeClientList().subscribe((clientNewArr: any) => {
            if (clientNewArr && clientNewArr.length > 0) {
                this.st4ClientsArr = clientNewArr;
                this.st4ClientsArr.sort(function (a, b) {
                    if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
                    if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
                    return 0;
                });
                this._ClientFilter();
            }
        })
    }

    saveEmployeeClientDetails() {
        let employeeClientDetails = {
            Employee_id: this.employeeData.Employee_id,
            Client_id: this.fourthFormGroup.controls['client'].value,
            Modified_by: this.userData.id,
        };
        this.personalService.saveClientForEmployee(employeeClientDetails).subscribe((employeeClientRes: any) => {
            if (this.mode == 'update' || this.mode == 'view') {
                if (employeeClientRes.message === 'Employee Project Assigned Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this._ref.detectChanges();
                this.resetAlert();
            }
        }, err => {
            this.resMessage.success = false;
            this.resMessage.error = true;
            this._ref.detectChanges();
            this.resetAlert();
        });
    }

    getLoxysoftHistoryData() {
        if (this.employeeId) {
            this.personalService.getLoxysoftHistory(this.employeeId).subscribe((res: any) => {
                if (res && (res.length > 0)) {
                    this.loxyDataSource = new MatTableDataSource(res);
                    this.tRowNoRecord = false;
                    this.tRowErr = false;
                } else {
                    this.tRowNoRecord = true;
                    this.tRowErr = false;
                }
                this._ref.detectChanges();
                this.resetTableAlert();
            }, err => {
                this.tarRowNoRecord = false;
                this.tarRowErr = true;
                this._ref.detectChanges();
            });
        }

    }

    openStatusModal(content, contentAccessId, toContent?) {
        if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
            if (content === 'status') {
                this.empStatus.patchValue({
                    // 'startDate': Moments(toContent.fromdate).format('YYYY-MM-DD'),
                    // 'endDate': Moments(toContent.todate).format('YYYY-MM-DD'),
                    'startDate': Moments(new Date()).format('YYYY-MM-DD'),
                    'endDate': "",
                    'status': toContent.Employeestatus
                });
                this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-schedule-modal', size: 'lg', backdrop: "static" });
            }
        }
    }

    statusChange() {
        if (this.empStatus.status == 'VALID') {
            this.spinner.active = true;
            let startDate = Moments(this.empStatus.value.startDate).format('YYYY-MM-DD');
            let endDate = Moments(this.empStatus.value.endDate).format('YYYY-MM-DD');
            let datas = {
                "employee_id": this.employeeId,
                "fromdate": startDate,
                "todate": endDate,
                "status": this.empStatus.value.status,
                "approver_id": this.userData.id
            };
            this.personalService.statusChange(datas).subscribe((res: any) => {
                if (res && res.message == "Updated Successfully") {
                    this.resCreateMessage.success = true;
                    this.resCreateMessage.error = false;
                    this.modalRef.close('submitted');
                    this.getEmployeeData();
                }
                setTimeout(() => {
                    this.resCreateMessage.success = false;
                    this.resCreateMessage.error = false;
                    this._ref.detectChanges();
                }, 5000)
                this._ref.detectChanges();
                this.spinner.active = false;
            }, err => {
                this.spinner.active = false;
                this.updateErrMsg = true;
            });
        }
    }

    removeCurrentDeviceId() {
        this.personalService.deleteDeviceID(this.employeeId).subscribe((resData: any) => {
            if (resData && resData.status == "Valid") {
                this.resCreateMessage.success = true;
                this.resCreateMessage.error = false;
                this._ref.detectChanges();
                this.employeeData.device_id = '';
            } else {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
            }
            setTimeout(() => {
                this.resCreateMessage.success = false;
                this.resCreateMessage.error = false;
                this._ref.detectChanges();
            }, 5000)
            this._ref.detectChanges();
        }, err => {
            this.fourthFormGroup.enable();
            this.resMessage.success = false;
            this.resMessage.error = true;
            this._ref.detectChanges();
            this.resetAlert();
        });
    }

    loadLeaveEmployee() {
        let toSendReq: any = {
            "status": ""
        };
        if (!this.isLeaveApprovedList && this.isLeavePendingList) {
            toSendReq.status = 'Pending';
        }
        if (this.isLeaveApprovedList && !this.isLeavePendingList) {
            toSendReq.status = 'Approved';
        }
        if (!this.isLeaveApprovedList && !this.isLeavePendingList) {
            toSendReq.status = 'Rejected';
        }
        this.sharedServices.getDashboardLeaveByStatus(this.employeeId, toSendReq).subscribe((res: any) => {
            if (res && res[0] && res[0].el.length > 0 && res[0].el[0].fromdate) {
                this.leaveDatasource = new MatTableDataSource(res[0].el);
                this.leaveDatasource.paginator = this.paginator;
                this.leaveDatasource.sort = this.sort;
                this.leaveDatasource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                };
                if (this.leaveDatasource.data.length > 0) {
                    this.leavetottRowErr = false;
                    this.leavetottRowNoRecord = false;
                } else {
                    this.leavetottRowErr = false;
                    this.leavetottRowNoRecord = true;
                }
                this._ref.detectChanges();
            } else {
                this.leaveDatasource = new MatTableDataSource([]);
                this.leaveDatasource.paginator = this.paginator;
                this.leaveDatasource.sort = this.sort;
                this.leaveDatasource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                };
                this.leavetottRowErr = false;
                this.leavetottRowNoRecord = true;
                this._ref.detectChanges();
            }
        }, err => {
            this.leavetottRowErr = true;
            this.leavetottRowNoRecord = false;
            this._ref.detectChanges();
            this.resMessage.success = false;
            this.resMessage.error = true;
            this._ref.detectChanges();
            this.resetAlert();
        });
    }

    toggleApprovedLeaveList(isApproved: boolean, isPending?: boolean) {
        if (this.isLeaveApprovedList != isApproved || this.isLeavePendingList != isPending) {
            this.isLeaveApprovedList = isApproved;
            this.isLeavePendingList = isPending;
            this.loadLeaveEmployee();
        }
    }

    initializeAgreementFormControls() {
        this.agreementFormGroup = this._formBuilder.group({
            Status: [''],
            fromDate: ['', [Validators.required]],
            todate: ['', [Validators.required]],
            notes: [''],
        });
    }

    saveAgreement() {
        this.contractBtnDisable = true;
        let toSendAgreementData: any = {
            Status: (this.agreementFormGroup.value.Status == 1) ? true : false,
            fromDate: this.agreementFormGroup.value.fromDate ? Moments(this.agreementFormGroup.value.fromDate).format('YYYY-MM-DD') : '',
            toDate: this.agreementFormGroup.value.todate ? Moments(this.agreementFormGroup.value.todate).format('YYYY-MM-DD') : '',
            notes: this.agreementFormGroup.value.notes ? this.agreementFormGroup.value.notes : ''
        };
        if (this.agreementId) {
            this.personalService.editAgreement(toSendAgreementData, this.agreementId).subscribe((res: any) => {
                if (res.message == 'Updated Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                    this._ref.detectChanges();
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this._ref.detectChanges();
                }
                this.getEmployeeData();
                this.modalRef.close();
                this.contractBtnDisable = false;
                this.resetAlert();
                this._ref.detectChanges();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
                this.contractBtnDisable = false;
            });
        } else {
            if (this.agreementFormGroup && this.agreementFormGroup.value && this.agreementFormGroup.value.fromDate) {
                this.personalService.addAgreement(toSendAgreementData, this.employeeData.Employee_id).subscribe((res: any) => {
                    if (res) {
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                        this._ref.detectChanges();
                    } else {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this._ref.detectChanges();
                    }
                    this.getEmployeeData();
                    this.modalRef.close();
                    this.contractBtnDisable = false;
                    this.resetAlert();
                    this._ref.detectChanges();
                }, err => {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this._ref.detectChanges();
                    this.resetAlert();
                    this.contractBtnDisable = false;
                });
            }

        }
    }
    downloadSignedDoc(agreementData) {
        if (agreementData.download) {
            this.agreementDownloadLink = document.createElement('a');
            const element = this.agreementDownloadLink;
            const dFileName = `${this.employeeData.first_name}_${this.employeeData.last_name}_${this.employeeData.personal_id}_${Moments().format("YYY-MM-DD")}`;
            element.setAttribute('href', `${ApiEndpointConstants.agreement_doc_url}/${agreementData.download}`);
            element.setAttribute('target', '_blank');
            element.setAttribute('download', dFileName);
            var event = new MouseEvent("click");
            element.dispatchEvent(event);
        }
    }

    mousePointerToggle(calendarEvent, PopoverElementRef) {
        if (calendarEvent.detail && calendarEvent.detail.event && calendarEvent.detail.event.status && (!!calendarEvent.detail.event.attendance_notes || (calendarEvent.detail.event.leave_details && calendarEvent.detail.event.leave_details[0] && !!calendarEvent.detail.event.leave_details[0].admin_notes)) && calendarEvent.type == 'eventMouseOver') {
            if ((calendarEvent.detail.event.leave_details && calendarEvent.detail.event.leave_details[0] && !!(calendarEvent.detail.event.leave_details[0].admin_notes))) {
                if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0]) {
                    calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0].setAttribute("data-tooltip", calendarEvent.detail.event.leave_details[0].admin_notes);
                }
            } else {
                if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0]) {
                    calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0].setAttribute("data-tooltip", calendarEvent.detail.event.attendance_notes);
                }
            }
        }
        else if (calendarEvent.detail && calendarEvent.detail.event && calendarEvent.detail.event.status && (!!calendarEvent.detail.event.attendance_notes || (calendarEvent.detail.event.leave_details && calendarEvent.detail.event.leave_details[0] && !!calendarEvent.detail.event.leave_details[0].admin_notes)) && calendarEvent.type == 'eventMouseOut') {
            if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0]) {
                calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".fc-content.fc-event-status")[0].removeAttribute("data-tooltip");
            }
        }

        if (calendarEvent.detail && calendarEvent.detail.event && (calendarEvent.detail.event.attendance_details[0] && calendarEvent.detail.event.attendance_details[0].approval_status == 1) && (calendarEvent.detail.event.attendance_details[0].Godkand && calendarEvent.detail.event.attendance_details[0].Godkand == 2) && calendarEvent.type == 'eventMouseOver') {
            if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0]) {
                calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0].setAttribute("data-tooltip", calendarEvent.detail.event.attendance_details[0].Note);
            }
        }
        else if (calendarEvent.detail && calendarEvent.detail.event && calendarEvent.detail.event.status && (calendarEvent.detail.event.attendance_details[0] && calendarEvent.detail.event.attendance_details[0].approval_status == 1) && (calendarEvent.detail.event.attendance_details[0].Godkand && calendarEvent.detail.event.attendance_details[0].Godkand == 2) && calendarEvent.type == 'eventMouseOut') {
            if (calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0]) {
                calendarEvent.detail.jsEvent.currentTarget.querySelectorAll(".approve-icon.approve-notes")[0].removeAttribute("data-tooltip");
            }
        }
    }

    toggleStatusHistoryEdit() {
        this.allowStatusHistoryEdit = true;
    }

    toggleDeviceInfoEdit() {
        this.allowDeviceInfoEdit = true;
    }

    submitLeave() {
        if (this.selectedMode != 'permission') {
            this.addLeave.controls['start_time'].setErrors(null);
            this.addLeave.controls['end_time'].setErrors(null);
        }
        if (this.addLeave.status == 'VALID') {
            let toSendFromDate = Moments(this.addLeave.value.fromdate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
            let toSendToDate = this.selectedMode == 'leave' ? Moments(this.addLeave.value.todate).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss') : toSendFromDate;
            toSendFromDate = toSendFromDate + 'Z';
            toSendToDate = toSendToDate + 'Z';
            let startTime = this.selectedMode == 'permission' ? this.addLeave.value.start_time.hour + ':' + this.addLeave.value.start_time.minute : '';
            let endTime = this.selectedMode == 'permission' ? this.addLeave.value.end_time.hour + ':' + this.addLeave.value.end_time.minute : '';
            let datas = {
                "leave": [
                    {
                        "note": this.addLeave.value.note,
                        "fromdate": toSendFromDate,
                        "todate": toSendToDate,
                        "start_time": startTime,
                        "end_time": endTime,
                        "leave_id": ''
                    }],
                'Employee_id': this.employeeData.Employee_id
            };
            let leave_id = this.addLeave.value.leave_id ? this.addLeave.value.leave_id : '';
            if (leave_id != '') {
                datas.leave[0].leave_id = leave_id;
            }
            this.personalService.updateLeave(datas).subscribe((res: any) => {
                if (res.message === 'Updated Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this.loadLeaveEmployee();
                this._ref.detectChanges();
                this.modalRef.close();
                this.resetAlert();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });

        }
    }

    leaveForm() {
        this.addLeave = this._formBuilder.group({
            fromdate: ['', [Validators.required]],
            todate: ['', [Validators.required]],
            note: ['', [Validators.required]],
            start_time: ['', Validators.required],
            end_time: ['', Validators.required],
            options: ['leave'],
            approval_note: ['']
        });
    }

    onSelectionChange(event: any) {
        this.selectedMode = event.value;
        if (this.selectedMode == 'permission') {
            this.addLeave.controls['todate'].setErrors(null);
        } else {
            this.addLeave.controls['start_time'].setErrors(null);
            this.addLeave.controls['end_time'].setErrors(null);
        }
    }

    createTimerSattning() {
        if (this.modalFormGroup.valid && this.checkInOutInterval()) {
            if (this.modalFormGroup.valid) {
                this.spinner.active = true;
                let form1: any = this.modalFormGroup.controls;
                if (!form1.notes.value) {
                    form1.notes.value = "";
                }
                let toSendAttendanceData: any = {
                    "date": Moments(form1.fromdate.value).format('YYYY-MM-DD'),
                    "employee_id": this.employeeData.Employee_id,
                    'notes': form1.notes.value
                };
                let toSetStartTime = Moments().set({ hour: form1.starttime.value.hour, minute: form1.starttime.value.minute, second: form1.starttime.value.second }).format('HH:mm:ss');
                let toSetEndTime = Moments().set({ hour: form1.finaltime.value.hour, minute: form1.finaltime.value.minute, second: form1.finaltime.value.second }).format('HH:mm:ss');
                let toSetLunch = Moments().set({ hour: form1.lunchtime.value.hour, minute: form1.lunchtime.value.minute, second: form1.lunchtime.value.second }).format('HH:mm:ss');
                toSendAttendanceData.start_time = toSetStartTime;
                toSendAttendanceData.end_time = toSetEndTime;
                toSendAttendanceData.lunch = toSetLunch;
                this.personalService.singleDaySchema(toSendAttendanceData).subscribe((res: any) => {
                    if (res) {
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                        this.resMessage.message = "Schema läggs till med framgång";
                        this._ref.detectChanges();
                        this.modalRef.close('submitted');
                        this.onCalendarInit(this.start_dates, this.end_dates);
                        this.spinner.active = false;
                    } else {
                        this.spinner.active = false;
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this.resMessage.message = "Schema har inte lagts till";
                        this._ref.detectChanges();
                    }
                    setTimeout(() => {
                        this.resMessage.success = false;
                        this.resMessage.error = false;
                        this._ref.detectChanges();
                    }, 10000);
                });
            }
        }
    }

    checkInOutInterval() {
        let formData: any = this.modalFormGroup.controls;
        let toSendFormData: any = {};
        if ((formData.starttime.value && (formData.starttime.value.hour >= 0) && (formData.starttime.value.minute >= 0)) && (formData.finaltime.value && (formData.finaltime.value.hour >= 0) && (formData.finaltime.value.minute >= 0))) {
            if (formData.fromdate.value) {
                toSendFormData.In_time = Moments(formData.fromdate.value).set({ hour: formData.starttime.value.hour, minute: formData.starttime.value.minute }).valueOf();
                toSendFormData.Out_time = Moments(formData.fromdate.value).set({ hour: formData.finaltime.value.hour, minute: formData.finaltime.value.minute }).valueOf();
            } else {
                toSendFormData.In_time = Moments().set({ hour: formData.starttime.value.hour, minute: formData.starttime.value.minute }).valueOf();
                toSendFormData.Out_time = Moments().set({ hour: formData.finaltime.value.hour, minute: formData.finaltime.value.minute }).valueOf();
            }
            if (formData.starttime.value && (formData.starttime.value.hour == 0) && (formData.starttime.value.minute == 0)) {
                this.modalInOutError = true;
                return false;
            }
            if ((toSendFormData.Out_time >= toSendFormData.In_time)) {
                this.modalInOutError = false;
                return true;
            } else {
                this.modalInOutError = true;
                return false;
            }
        }
    }

    getBonusList() {
        this.loader = true;
        this.tBonusRowNoRecord = false;
        this.tBonusRowErr = false;
        let resultarr = [];
        this.personalService.summaryMonthlyBonus({ "month": this.monthSelected, "year": this.yearSelected, "employee_id": this.employeeId }).subscribe((res: any) => {
            if (res && res[0].bonus_summary && res[0].bonus_summary.length > 0) {
                res[0].bonus_summary.forEach((obj) => {
                    let datasourceObj: any = {};
                    datasourceObj = obj;
                    resultarr.push(datasourceObj);
                });
                this.bonusSource = new MatTableDataSource(resultarr);
                this.bonusSource.paginator = this.paginator;
                this.bonusSource.sort = this.sort;
                this.bonusSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.bonusSummaryData = res[0].total_summary;
                this.loader = false;
            } else {
                this.bonusSource = new MatTableDataSource([]);
                this.bonusSource.paginator = this.paginator;
                this.bonusSource.sort = this.sort;
                this.bonusSource.filterPredicate = this.columnwiseFilter();
                this.bonusSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.bonusSummaryData = [];
                this.tBonusRowNoRecord = true;
                this.loader = false;
            }
            this._ref.detectChanges();
        }, err => {
            this.tBonusRowErr = true;
            this._ref.detectChanges();
            this.loader = false;
        });
    }

    private columnwiseFilter() {
        let filterPred = (item, filter) => {
            let filterString = JSON.parse(filter);
            let isRowSet: boolean = true;
            Object.keys(filterString).forEach((key) => {
                let keyNodeValue = key.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
                if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
                    let itemString = '';
                    if (typeof keyNodeValue != 'string') {
                        itemString = keyNodeValue.toString();
                    } else {
                        itemString = keyNodeValue;
                    }
                    if (filterString[key]) {
                        isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
                    } else {
                        isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
                    }
                }
            });
            return isRowSet;
        }
        return filterPred;
    }

    getSettingList() {
        this.loader = true;
        this.tarRowNoRecord = false;
        this.tarRowErr = false;
        let resultarr = [];
        this.personalService.empTargetList({ "year": this.yearSelected, "employee_id": this.employeeId }).subscribe((res: any) => {
            if (res[0].data && res[0].data.length > 0) {
                res[0].data.forEach((obj) => {
                    this.pieChartData = [];
                    let datasourceObj: any = {};
                    datasourceObj = obj;
                    if (this.userData.role == 'admin' || this.userData.role == 'superadmin') {
                        datasourceObj.percentage = parseFloat(datasourceObj.loxy_percentage).toFixed(2);
                    } else {
                        datasourceObj.percentage = parseFloat("0.00").toFixed(2);
                        datasourceObj.target_hours = 0;
                    }
                    datasourceObj.graph = this.pieChartData;
                    resultarr.push(datasourceObj);
                });
                this.targetHoursList = res;
                this.targetSource = new MatTableDataSource(resultarr);
                this.targetSource.paginator = this.paginator;
                this.targetSource.sort = this.sort;
                this.targetSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.loader = false;
            } else {
                this.targetSource = new MatTableDataSource([]);
                this.targetSource.paginator = this.paginator;
                this.targetSource.sort = this.sort;
                this.targetSource.filterPredicate = this.columnwiseFilter();
                this.targetSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.tarRowNoRecord = true;
                this.loader = false;
            }
            this._ref.detectChanges();
        }, err => {
            this.tarRowErr = true;
            this._ref.detectChanges();
            this.loader = false;
        });
    }

    getIndividualBonusSettingList() {
        this.loader = true;
        this.tIndBonusRowNoRecord = false;
        let resultarr = [];
        let queryData: any = {
            userId: this.employeeId
        };
        this.personalService.individualBonusList(queryData).subscribe((res: any) => {
            if (res) {
                res.forEach((obj) => {
                    let datasourceObj: any = {};
                    datasourceObj = obj;
                    datasourceObj.To_date = typeof (obj.To_date) == "undefined" ? '--' : obj.To_date;
                    resultarr.push(datasourceObj);
                });
                this.individualBonusDataSource = new MatTableDataSource(resultarr);
                this.individualBonusDataSource.paginator = this.paginator;
                this.individualBonusDataSource.sort = this.sort;
                this.individualBonusDataSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.bonusIndividualSummaryData = res[0].total_summary;
                this.loader = false;
            } else {
                this.individualBonusDataSource = new MatTableDataSource([]);
                this.individualBonusDataSource.paginator = this.paginator;
                this.individualBonusDataSource.sort = this.sort;
                this.individualBonusDataSource.filterPredicate = this.columnwiseFilter();
                this.individualBonusDataSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.bonusIndividualSummaryData = [];
                this.tIndBonusRowNoRecord = true;
                this.loader = false;
            }
        }, err => {
            this.tIndBonusRowNoRecord = true;
            this.loader = false;
        });
    }

    getIndividualEmployeeBonusSettingList(recruitedEmployeeId?: any) {
        this.loader = true;
        this.tIndEmpBonusNoRecord = false;
        let resultarr = [];
        if (recruitedEmployeeId) {
            this.recruitedEmployee = recruitedEmployeeId;
        }
        let queryData: any = {
            userId: this.employeeId,
            employeeId: this.recruitedEmployee
        };
        this.personalService.individualEmployeeBonusList(queryData).subscribe((res: any) => {
            if (res) {
                res.forEach((obj) => {
                    let datasourceObj: any = {};
                    datasourceObj = obj;
                    datasourceObj.To_date = typeof (obj.To_date) == "undefined" ? '--' : obj.To_date;
                    resultarr.push(datasourceObj);
                });
                this.individualEmployeeBonusDataSource = new MatTableDataSource(resultarr);
                this.individualEmployeeBonusDataSource.paginator = this.paginator;
                this.individualEmployeeBonusDataSource.sort = this.sort;
                this.individualEmployeeBonusDataSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.bonusEmployeeIndividualSummaryData = res[0].total_summary;
                this.loader = false;
            } else {
                this.individualEmployeeBonusDataSource = new MatTableDataSource([]);
                this.individualEmployeeBonusDataSource.paginator = this.paginator;
                this.individualEmployeeBonusDataSource.sort = this.sort;
                this.individualEmployeeBonusDataSource.filterPredicate = this.columnwiseFilter();
                this.individualEmployeeBonusDataSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.bonusEmployeeIndividualSummaryData = [];
                this.tIndEmpBonusNoRecord = true;
                this.loader = false;
            }
        }, err => {
            this.tIndEmpBonusNoRecord = true;
            this.loader = false;
        });
    }

    createIndividualBonus() {
        let form1 = this.individualBonusFormGroup.value;
        if (this.individualBonusFormGroup.valid) {
            this.spinner.active = true;
            let bonusData: any = {
                "created_by": this.userData.id,
                "recruit_bonus": parseFloat(form1.recruit_bonus),
                "start_date": Moments(form1.start_date).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                "settings_id": this.updateSettingsID,
                "recruiter_id": this.employeeId
            };
            if (form1.end_date) {
                bonusData.end_date = Moments(form1.end_date).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss') + 'Z';
            }
            if (this.bonusCreateOrupdate === 'create') {
                delete bonusData.settings_id;
                this.personalService.addIndividualBonus(bonusData).subscribe(res => {
                    if (res[0].status === 1) {
                        this.getIndividualBonusSettingList();
                        this.modalRef.close('submitted');
                        this.spinner.active = false;
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                    } else {
                        this.spinner.active = false;
                        this.modalRef.close('submitted');
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                    }
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 5000);
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                    this.spinner.active = false;
                });
            } else if (this.bonusCreateOrupdate === 'update') {
                this.personalService.addIndividualBonus(bonusData).subscribe(res => {
                    if (res[0].status === 1) {
                        this.getIndividualBonusSettingList();
                        this.modalRef.close('submitted');
                        this.spinner.active = false;
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                    } else {
                        this.spinner.active = false;
                        this.modalRef.close('submitted');
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                    }
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 5000)
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                    this.spinner.active = false;
                });
            }
        }
    }

    createIndividualBonusForEmployee() {
        let form1 = this.individualEmployeeBonusFormGroup.value;
        if (this.individualEmployeeBonusFormGroup.valid) {
            this.spinner.active = true;
            let bonusData: any = {
                "created_by": this.userData.id,
                "recruit_bonus": parseFloat(form1.recruit_bonus),
                "start_date": Moments(form1.start_date).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                "settings_id": this.updateSettingsID,
                "recruiter_id": this.employeeId,
                "employee_id": form1.employee_id
            };
            if (form1.end_date) {
                bonusData.end_date = Moments(form1.end_date).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss') + 'Z';
            }
            if (this.bonusCreateOrupdate === 'create') {
                delete bonusData.settings_id;
                this.personalService.addIndividualBonus(bonusData).subscribe(res => {
                    if (res[0].status === 1) {
                        this.getIndividualEmployeeBonusSettingList(form1.employee_id);
                        this.modalRef.close('submitted');
                        this.spinner.active = false;
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                    } else {
                        this.spinner.active = false;
                        this.modalRef.close('submitted');
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                    }
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 5000)
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                    this.spinner.active = false;
                });
            } else if (this.bonusCreateOrupdate === 'update') {
                this.personalService.addIndividualBonus(bonusData).subscribe(res => {
                    if (res[0].status === 1) {
                        this.getIndividualEmployeeBonusSettingList(form1.employee_id);
                        this.modalRef.close('submitted');
                        this.spinner.active = false;
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                    } else {
                        this.spinner.active = false;
                        this.modalRef.close('submitted');
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                    }
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 5000);
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                    this.spinner.active = false;
                });
            }
        }
    }

    getRecruitedEmployeeList() {
        this.personalService.recruitedEmployeeList(this.employeeId).subscribe((res: any) => {
            if (res) {
                this.recrutiedEmployeeList = res;
                let joinedList: any = res;
                let relievedList: any = res.filter((lObj) => {
                    return !!lObj.todate;
                });
                let joinedSortedList = [];
                let relievedSortedList = [];
                let joinTempObj: any = {};
                let joinTempIndex: any = null;
                let relieveTempObj: any = {};
                let relieveTempIndex: any = null;
                let combinedList: any[] = [];
                let tempRelObj: any = {};
                joinedList.sort((a, b) => {
                    if (b.fromdate && a.fromdate) {
                        return <any>new Date(b.fromdate) - <any>new Date(a.fromdate);
                    }
                });
                joinedList.reverse();
                joinedList.forEach((jObj) => {
                    if (jObj.fromdate) {
                        if (new Date(jObj.fromdate).getTime() != new Date(joinTempObj.fromdate).getTime()) {
                            joinedSortedList.push({
                                date: jObj.fromdate,
                                joined: {
                                    employees: [{ name: jObj.first_name + ' ' + jObj.last_name, employee_id: jObj.Employee_id, from_date: jObj.fromdate, to_date: jObj.todate ? jObj.todate : null }],
                                    status: 'joined'
                                }
                            });
                            joinTempObj.fromdate = jObj.fromdate;
                            joinTempIndex = joinedSortedList.length - 1;
                        } else {
                            joinedSortedList[joinTempIndex].joined.employees.push({ name: jObj.first_name + ' ' + jObj.last_name, employee_id: jObj.Employee_id, from_date: jObj.fromdate, to_date: jObj.todate ? jObj.todate : null });
                        }
                    }
                });
                relievedList.sort((a, b) => {
                    if (b.todate && a.todate) {
                        return <any>new Date(b.todate) - <any>new Date(a.todate);
                    }
                });
                relievedList.reverse();
                relievedList.forEach((rObj) => {
                    joinedSortedList.forEach((jsObj) => {
                        if (new Date(rObj.todate).getTime() == new Date(jsObj.date).getTime()) {
                            if (!jsObj.relieved) {
                                jsObj.relieved = {
                                    employees: [{ name: rObj.first_name + ' ' + rObj.last_name, employee_id: rObj.Employee_id, from_date: rObj.fromdate, to_date: rObj.todate ? rObj.todate : null }],
                                    status: 'relieved'
                                };
                            } else {
                                jsObj.relieved.employees.push({ name: rObj.first_name + ' ' + rObj.last_name, employee_id: rObj.Employee_id, from_date: rObj.fromdate, to_date: rObj.todate ? rObj.todate : null });
                            }
                            tempRelObj.todate = null;
                        }
                    });
                    if (joinedSortedList.filter((jsObj) => { return rObj.todate == jsObj.date; }).length == 0) {
                        if (new Date(rObj.todate).getTime() != new Date(relieveTempObj.todate).getTime()) {
                            relievedSortedList.push({
                                date: rObj.todate,
                                relieved: {
                                    employees: [{ name: rObj.first_name + ' ' + rObj.last_name, employee_id: rObj.Employee_id, from_date: rObj.fromdate, to_date: rObj.todate ? rObj.todate : null }],
                                    status: 'relieved'
                                }
                            });
                            relieveTempObj.todate = rObj.todate;
                            relieveTempIndex = relievedSortedList.length - 1;
                        } else {
                            relievedSortedList[relieveTempIndex].relieved.employees.push({ name: rObj.first_name + ' ' + rObj.last_name, employee_id: rObj.Employee_id, from_date: rObj.fromdate, to_date: rObj.todate });
                        }
                    }
                });
                combinedList = joinedSortedList.concat(relievedSortedList);
                combinedList.sort((a, b) => {
                    if (b.date && a.date) {
                        return <any>new Date(b.date) - <any>new Date(a.date);
                    }
                });
                combinedList.reverse();
                this.timeLineList = combinedList;
            }
        });
    }

    toggleIndRecruitmentBonus() {
        this.disableIndividualRecruitmentBonus = false;
    }

    toggleIndEmpRecruitmentBonus() {
        this.disableIndividualEmployeeRecruitmentBonus = false;
    }

    applyColumnFilter() {
        this.targetSource.filterPredicate = this.columnwiseFilter();
        this.targetSource.filter = JSON.stringify(this.multiColFilter);
        if (this.targetSource.paginator) {
            this.targetSource.paginator.firstPage();
        }
    }

    applyBonusColumnFilter() {
        this.bonusSource.filterPredicate = this.columnwiseFilter();
        this.bonusSource.filter = JSON.stringify(this.bonusColFilter);
        if (this.bonusSource.paginator) {
            this.bonusSource.paginator.firstPage();
        }
    }

    applyIndBonusColumnFilter() {
        this.individualBonusDataSource.filterPredicate = this.columnwiseFilter();
        this.individualBonusDataSource.filter = JSON.stringify(this.indBonusMultiColFilter);
        if (this.individualBonusDataSource.paginator) {
            this.individualBonusDataSource.paginator.firstPage();
        }
    }

    applyIndEmpBonusColumnFilter() {
        this.individualEmployeeBonusDataSource.filterPredicate = this.columnwiseFilter();
        this.individualEmployeeBonusDataSource.filter = JSON.stringify(this.indEmpBonusMultiColFilter);
        if (this.individualEmployeeBonusDataSource.paginator) {
            this.individualEmployeeBonusDataSource.paginator.firstPage();
        }
    }

    deleteIndividualRecruitmentBonus() {
        this.spinner.active = true;
        if (this.individualBonusId) {
            let toSendData: any = {
                approver_id: this.userData.id,
                id: this.individualBonusId
            };
            this.personalService.deleteRecruitmentBonus(toSendData).subscribe((resData: any) => {
                if (resData) {
                    this.resUpdateeMessage.success = true;
                    this.resUpdateeMessage.error = false;
                    this.individualBonusId = null;
                    this._ref.detectChanges();
                    if (this.changeView.viewVal == 'IndividualRecruitmentBonusForEmployeeInfo') {
                        this.getIndividualEmployeeBonusSettingList();
                    } else if (this.changeView.viewVal == 'IndividualRecruitmentBonusInfo') {
                        this.getIndividualBonusSettingList();
                    }
                } else {
                    this.resUpdateeMessage.success = false;
                    this.resUpdateeMessage.error = true;
                    this._ref.detectChanges();
                }
                setTimeout(() => {
                    this.resUpdateeMessage.success = false;
                    this.resUpdateeMessage.error = false;
                    this._ref.detectChanges();
                }, 5000);
                this.spinner.active = false;
                this.modalRef.close('submitted');
                this._ref.detectChanges();
            }, err => {
                this.resUpdateeMessage.success = false;
                this.resUpdateeMessage.error = true;
                this._ref.detectChanges();
            });
        }
    }

    openTimeLineMenu() {
        this.changeView.viewVal = 'TimeLine';
        setTimeout(() => {
            this.timeLineComp.forEach((mglT) => {
                mglT.toggle({ path: [{ localName: 'mgl-timeline-entry-header' }] });
            });
        }, 250);
    }

    referedSlideToggleChange(e) {
        if (!this.thirdFormGroup.disabled) {
            if (e.checked) {
                this.thirdFormGroup.get('refered_by').setValidators([Validators.required]);
                this.thirdFormGroup.get('refered_by').updateValueAndValidity();
                this._ref.detectChanges();
                this.thirdFormGroup.updateValueAndValidity();
            } else {
                this.thirdFormGroup.get('refered_by').clearValidators();
                this.thirdFormGroup.get('refered_by').updateValueAndValidity();
                this._ref.detectChanges();
                this.thirdFormGroup.updateValueAndValidity();
            }
        }
    }

    validateItemRows(itemIndex) {
        let emergencyContactRowData: any = <FormArray>this.firstFormGroup.controls['itemRows'];
        if (emergencyContactRowData.controls[itemIndex]) {
            if (emergencyContactRowData.controls[itemIndex].get('name').value.trim() || emergencyContactRowData.controls[itemIndex].get('contactnumber').value.trim()) {
                emergencyContactRowData.controls[itemIndex].get('name').setValidators([Validators.required]);
                emergencyContactRowData.controls[itemIndex].get('contactnumber').setValidators([Validators.required]);
                emergencyContactRowData.controls[itemIndex].get('name').updateValueAndValidity();
                emergencyContactRowData.controls[itemIndex].get('contactnumber').updateValueAndValidity();
            } else {
                emergencyContactRowData.controls[itemIndex].get('name').clearValidators();
                emergencyContactRowData.controls[itemIndex].get('contactnumber').clearValidators();
                emergencyContactRowData.controls[itemIndex].get('name').updateValueAndValidity();
                emergencyContactRowData.controls[itemIndex].get('contactnumber').updateValueAndValidity();
            }
        }
        this._ref.detectChanges();
        this.firstFormGroup.updateValueAndValidity();
    }

    protected _RecEmpfilter(): any[] {
        if (this.recruitmentnArr.length <= 0) {
            return;
        }
        if (this.thirdFormGroup && this.thirdFormGroup.controls['recruitmentEmployeeFilterControls'].value && (typeof this.thirdFormGroup.controls['recruitmentEmployeeFilterControls'].value == 'string') && this.thirdFormGroup.controls['recruitmentEmployeeFilterControls'].value.trim() != '') {
            const empfilterValue = this.thirdFormGroup.controls['recruitmentEmployeeFilterControls'].value.toLowerCase();
            this.recruitmentEmpFilteredOptions.next(
                this.recruitmentnArr.filter(emp => (emp.name.toLowerCase().indexOf(empfilterValue) > -1))
            );
        } else {
            this.recruitmentEmpFilteredOptions.next(this.recruitmentnArr.slice());
            return;
        }
    }

    protected _RefEmpfilter(): any[] {
        if (this.recruitmentnArr.length <= 0) {
            return;
        }
        if (this.thirdFormGroup && this.thirdFormGroup.controls['referedEmployeeFilterControls'].value && (typeof this.thirdFormGroup.controls['referedEmployeeFilterControls'].value == 'string') && this.thirdFormGroup.controls['referedEmployeeFilterControls'].value.trim() != '') {
            const empfilterValue = this.thirdFormGroup.controls['referedEmployeeFilterControls'].value.toLowerCase();
            this.referedEmpFilteredOptions.next(
                this.recruitmentnArr.filter(emp => (emp.name.toLowerCase().indexOf(empfilterValue) > -1))
            );
        } else {
            this.referedEmpFilteredOptions.next(this.recruitmentnArr.slice());
            return;
        }
    }

    getIndividualTargetHours() {
        this.loader = true;
        this.indTarRowNoRecord = false;
        this.indTarRowErr = false;
        let resultarr = [];
        this.personalService.empTargetSettings({ "year": this.yearSelected, "employee_id": this.employeeId }).subscribe((res: any) => {
            if (res && res.length > 0) {
                res.forEach((obj) => {
                    let datasourceObj: any = {};
                    datasourceObj = obj;
                    if (this.userData.role == 'admin' || this.userData.role == 'superadmin') {
                        datasourceObj.percentage = parseFloat(datasourceObj.loxy_percentage).toFixed(2);
                    } else {
                        datasourceObj.percentage = parseFloat("0.00").toFixed(2);
                        datasourceObj.target_hours = 0;
                    }
                    resultarr.push(datasourceObj);
                });
                this.targetHoursList = res;
                this.individualTargetSource = new MatTableDataSource(resultarr);
                this.individualTargetSource.paginator = this.paginator;
                this.individualTargetSource.sort = this.sort;
                this.individualTargetSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.loader = false;
            } else {
                this.individualTargetSource = new MatTableDataSource([]);
                this.individualTargetSource.paginator = this.paginator;
                this.individualTargetSource.sort = this.sort;
                this.individualTargetSource.filterPredicate = this.columnwiseFilter();
                this.individualTargetSource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                }
                this.indTarRowNoRecord = true;

                this.loader = false;
            }
            this._ref.detectChanges();

        }, err => {
            this.indTarRowErr = true;
            this._ref.detectChanges();
            this.loader = false;
        });
    }

    saveEmployeeTargetHours() {
        let form1 = this.targetHoursFormGroup.value;
        if (this.targetHoursFormGroup.valid) {
            this.spinner.active = true;
            let targetHoursData: any = {};
            targetHoursData.loxysoft_hours = form1.loxysoft_hours;
            targetHoursData.month = form1.month;
            targetHoursData.year = form1.year;
            targetHoursData.employee_id = this.userData.id;
            targetHoursData.emp_id = this.employeeData.Employee_id;
            if (this.targetSettingsID !== '') {
                targetHoursData.settings_id = this.targetSettingsID;
            }
            if (this.targetCreateOrupdate === 'create') {
                this.personalService.crupTargetList(targetHoursData).subscribe(res => {
                    if (res[0].status === 1) {
                        this.getIndividualTargetHours();
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                    } else {
                        this.spinner.active = false;
                        this.modalRef.close('submitted');
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                    }
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 5000)
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                });
            } else if (this.targetCreateOrupdate === 'update') {
                this.personalService.crupTargetList(targetHoursData).subscribe(res => {
                    if (res[0].status === 1) {
                        this.getIndividualTargetHours();
                        this.resUpdateeMessage.success = true;
                        this.resUpdateeMessage.error = false;
                    } else {
                        this.spinner.active = false;
                        this.modalRef.close('submitted');
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = true;
                    }
                    setTimeout(() => {
                        this.resUpdateeMessage.success = false;
                        this.resUpdateeMessage.error = false;
                        this._ref.detectChanges();
                    }, 5000)
                    this._ref.detectChanges();
                }, error => {
                    if (error.error.message) {
                        this.updateErrMsg = true;
                    }
                });
            }
            this.modalRef.close('submitted');
            this.spinner.active = false;
        }

    }

    applyIndividualTargetHoursColumnFilter() {
        this.targetSource.filterPredicate = this.columnwiseFilter();
        this.targetSource.filter = JSON.stringify(this.individualTargetColFilter);
        if (this.targetSource.paginator) {
            this.targetSource.paginator.firstPage();
        }
    }

    protected _ClientFilter(): any[] {
        if (this.st4ClientsArr.length <= 0) {
            return;
        }
        if (this.fourthFormGroup && this.fourthFormGroup.controls['clientFilterControls'].value && (typeof this.fourthFormGroup.controls['clientFilterControls'].value == 'string') && this.fourthFormGroup.controls['clientFilterControls'].value.trim() != '') {
            const clientValue = this.fourthFormGroup.controls['clientFilterControls'].value.toLowerCase();
            this.clientFilteredOptions.next(
                this.st4ClientsArr.filter(client => (client.name.toLowerCase().indexOf(clientValue) > -1))
            );
        } else {
            this.clientFilteredOptions.next(this.st4ClientsArr.slice());
            return;
        }
    }

    protected _DepFilter(): any[] {
        if (this.departmentArr.length <= 0) {
            return;
        }
        if (this.thirdFormGroup && this.thirdFormGroup.controls['departmentFilterControls'].value && (typeof this.thirdFormGroup.controls['departmentFilterControls'].value == 'string') && this.thirdFormGroup.controls['departmentFilterControls'].value.trim() != '') {
            const depfilterValue = this.thirdFormGroup.controls['departmentFilterControls'].value.toLowerCase();
            this.depFilteredOptions.next(
                this.departmentArr.filter(dep => (dep.department.toLowerCase().indexOf(depfilterValue) > -1))
            );
        } else {
            this.depFilteredOptions.next(this.departmentArr.slice());
            return;
        }
    }

    protected _roleFilter(): any[] {
        if (this.dropDownList.role_list.length <= 0) {
            return;
        }
        if (this.thirdFormGroup && this.thirdFormGroup.controls['roleFilterControls'].value && (typeof this.thirdFormGroup.controls['roleFilterControls'].value == 'string') && this.thirdFormGroup.controls['roleFilterControls'].value.trim() != '') {
            const rolefilterValue = this.thirdFormGroup.controls['roleFilterControls'].value.toLowerCase();
            this.roleFilteredOptions.next(
                this.dropDownList.role_list.filter(role => (this.translate.instant('COMMON.ROLE_LIST.' + role).toLowerCase().indexOf(rolefilterValue) > -1))
            );
        } else {
            this.roleFilteredOptions.next(this.dropDownList.role_list.slice());
            return;
        }
    }

    protected _extentFilter(): any[] {
        if (this.dropDownList.extent_list.length <= 0) {
            return;
        }
        if (this.thirdFormGroup && this.thirdFormGroup.controls['extentFilterControls'].value && (typeof this.thirdFormGroup.controls['extentFilterControls'].value == 'string') && this.thirdFormGroup.controls['extentFilterControls'].value.trim() != '') {
            const extentfilterValue = this.thirdFormGroup.controls['extentFilterControls'].value.toLowerCase();
            this.extentFilteredOptions.next(
                this.dropDownList.extent_list.filter(extent => (this.translate.instant('EMPLOYEE.EXTENT_LIST.' + extent).toLowerCase().indexOf(extentfilterValue) > -1))
            );
        } else {
            this.extentFilteredOptions.next(this.dropDownList.extent_list.slice());
            return;
        }
    }

    submitComments() {
        if (this.addComment.status == 'VALID') {
            let datas = {
                "comments": this.addComment.value.comments,
                approver_id: this.userData.id,
                'Employee_id': this.employeeData.Employee_id
            };
            this.personalService.addComments(datas).subscribe((res: any) => {
                if (res.message === 'Added Successfully') {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this.loadEmployeeComments();
                this._ref.detectChanges();
                this.modalRef.close();
                this.resetAlert();
            }, err => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });

        }
    }

    loadEmployeeComments() {
        this.personalService.getComments(this.employeeId).subscribe((res: any) => {
            if (res && res.length > 0) {
                res.forEach((cObj) => {
                    cObj.created_at = this.momentFormatDate(cObj.created_date).format('YYYY-MM-DD HH:mm:ss');
                    cObj.created_by = cObj.approver_first_name + ' ' + cObj.approver_last_name;
                });
                this.commentDatasource = new MatTableDataSource(res);
                this.commentDatasource.paginator = this.paginator;
                this.commentDatasource.sort = this.sort;
                this.commentDatasource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                };
                if (this.commentDatasource.data.length > 0) {
                    this.commenttottRowErr = false;
                    this.commenttottRowNoRecord = false;
                } else {
                    this.commenttottRowErr = false;
                    this.commenttottRowNoRecord = false;
                }
                this._ref.detectChanges();
            } else {
                this.commentDatasource = new MatTableDataSource([]);
                this.commentDatasource.paginator = this.paginator;
                this.commentDatasource.sort = this.sort;
                this.commentDatasource.sortingDataAccessor = (item, property) => {
                    let sortString = property.split('.').reduce((o, i) => o[i], item);
                    if (typeof sortString === 'string') {
                        sortString = sortString.toLowerCase();
                    }
                    return sortString;
                };
                this.commenttottRowErr = false;
                this.commenttottRowNoRecord = true;
                this._ref.detectChanges();
            }
        }, err => {
            this.commenttottRowErr = true;
            this.commenttottRowNoRecord = false;
            this._ref.detectChanges();
            this.resetAlert();
        });
    }
}