import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatSnackBar, MatSelect } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { PersonalService } from '../_core/services/personal.service';
import { TranslateService } from '@ngx-translate/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import * as Xlsx from 'xlsx';
import * as _moment from 'moment';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Subject, ReplaySubject } from 'rxjs';
import { takeUntil, take } from 'rxjs/operators';

type AOA = any[][];
@Component({
  selector: 'm-employee-logs',
  templateUrl: './employee-logs.component.html',
  styleUrls: ['./employee-logs.component.scss']
})
export class EmployeeLogsComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  loader: boolean = false;
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  displayColumnToShow = ['employee_id', 'first_name', 'last_name', 'type', 'message'];
  excelColumns = [];
  arrToPrint: AOA = [];
  toggleColumns = [
    { arrIndex: 0, column: 'EMPLOYEE_ID', checked: true, label: 'employee_id' },
    { arrIndex: 1, column: 'FIRST_NAME', checked: true, label: 'first_name' },
    { arrIndex: 2, column: 'LAST_NAME', checked: true, label: 'last_name' },
    { arrIndex: 3, column: 'SKAPAT DATUM', checked: true, label: 'created_date' },
    { arrIndex: 3, column: 'TYPE', checked: true, label: 'type' },
    { arrIndex: 4, column: 'MESSAGE', checked: true, label: 'message' },
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  xpandStatus: boolean = false;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  selection = new SelectionModel<any>(true, []);
  allEmployeeList: any[] = [];
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  closeResult: string;
  delEmployeeData: any;
  deleteEmpModalRef: any;
  closeEmployeeCredEmailResult: any;
  closeEmployeeEsignEmailResult: any;
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  searchInput: string = '';
  screenLoader: boolean = false;
  scriveDynamicDownload: any;
  multiColFilter = {
    employee_id: '',
    first_name: '',
    last_name: '',
    created_date: '',
    'type': '',
    'message': ''
  };
  selectedEmployee: any = null;
  empGroup: FormGroup;
  @ViewChild('employeeSearchSelect') employeeSearchSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  empFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  empArr = [];
  Moment = _moment;
  constructor(
    private personalService: PersonalService,
    public matDialog: MatDialog,
    private translate: TranslateService,
    public snackBar: MatSnackBar,
    private modalService: NgbModal,
    private sharedServices: SharedService,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    this.empGroup = this.fb.group({
      empSelected: [null, Validators.required],
      employeeFilterControls: [''],
    });
    this.setExcelHeaders();
    this.dataSource = new MatTableDataSource<any>();
    this.getuserData = this.personalService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.loadEmployeesList();
    this.loadEmployee();
    this.empGroup.controls['employeeFilterControls'].valueChanges
      .pipe(takeUntil(this._onDestroy)).subscribe(() => this._Empfilter());
  }

  ngAfterViewInit() { }

  loadEmployeesList() {
    this.loader = true;
    this.selection.clear();
    this.dataSource = new MatTableDataSource([]);
    let toSendEmployeeLogsReq: any = {};
    if (this.selectedEmployee) {
      toSendEmployeeLogsReq.employee_id = this.selectedEmployee;
    }
    this.personalService.getEmployeeLogsHistory(toSendEmployeeLogsReq).subscribe((res: any) => {
      if (res.length > 0) {
        this.allEmployeeList = res;
        res.sort((a, b) => (a.first_name > b.first_name) ? 1 : ((b.first_name > a.first_name) ? -1 : 0));
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        };
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.loader = false;
        this.setExcelValues();
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.tRowNoRecord = true;
        this.loader = false;
      }
    }, err => {
      this.tRowErr = true;
      this.loader = false;
      this.dataSource = new MatTableDataSource([]);
      this.dataSource.paginator = this.paginator;
    });
    this.selection.clear();
    this.showHideCols();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.Employee_id + item.personal_id + item.first_name + item.last_name + item.contact[0].email + item.contact[0].mobile + item.contact[0].place + item.department + item.loxysoft_id;
      filterString = filterString.trim().toLocaleLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      /* generate worksheet */
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Anställd_Loggar_Lista_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }

  showHideCols() {
    this.displayColumnToShow = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        this.displayColumnToShow.push(obj.label);
      }
    });
  }

  private setExcelHeaders() {
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      this.translate.get('EMPLOYEE.EMPLOYEE_LIST.' + obj.column).subscribe((res: string) => {
        if (obj.arrIndex !== 11) {
          this.arrToPrint[0].push(res);
        }
      });
    });
  }

  private setExcelValues() {
    this.allEmployeeList.forEach((val) => {
      let newLine = [];
      this.toggleColumns.forEach((obj) => {
        if (obj.arrIndex !== 11) {
          if (obj.arrIndex === 18
            || obj.arrIndex === 20 || obj.arrIndex === 21
            || obj.arrIndex === 22 || obj.arrIndex === 23) {
            if (obj.arrIndex === 18) {
              newLine.push('True');
            } else {
              newLine.push('False');
            }
            if (obj.arrIndex === 20 || obj.arrIndex === 21) {
              if (val.emergencycontact && val.emergencycontact[0]) {
                newLine[18] = val.emergencycontact[0].name;
                newLine[19] = val.emergencycontact[0].contactnumber;
              } else {
                newLine[18] = '';
                newLine[19] = '';
              }
            }
            if (obj.arrIndex === 22 || obj.arrIndex === 23) {
              if (val.emergencycontact && val.emergencycontact[1]) {
                newLine[20] = val.emergencycontact[1].name;
                newLine[21] = val.emergencycontact[1].contactnumber;
              } else {
                newLine[20] = '';
                newLine[21] = '';
              }
            }
          } else {
            let str = obj.label.split('.').reduce((o, i) => { if (o) { return o[i] } }, val);
            newLine.push(str);
          }
        }
      });
      this.arrToPrint.push(newLine);
    });
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  openModal(content, toDelEmployee) {
    this.deleteEmpModalRef = this.modalService.open(content);
    this.delEmployeeData = toDelEmployee;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  deleteEmployee() {
    this.spinner.active = true;
    this.personalService.deleteEmployee(this.delEmployeeData.Employee_id).subscribe(res => {
      if (res) {
        this.loadEmployeesList();
      }
      this.spinner.active = false;
      this.deleteEmpModalRef.close('submitted');
    }, err => {
      this.spinner.active = false;
    });
  }

  applyColumnFilter() {
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(filterString).forEach((key) => {
        let keyNodeValue = key.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
        if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (keyNodeValue && (typeof keyNodeValue != 'string')) {
            itemString = keyNodeValue.toString();
          } else if (keyNodeValue) {
            itemString = keyNodeValue;
          }
          if (filterString[key]) {
            if (key == 'created_date') {
              isRowSet = isRowSet && (this.Moment(itemString).format('YYYY-MM-DD HH:mm:ss').trim().toLowerCase().indexOf((filterString[key]).trim().toLowerCase()) != -1);
            } else {
              isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
            }
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!keyNodeValue || (keyNodeValue <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  getLogsById(e) {
    this.selectedEmployee = null;
    if (e.value && e.value.id) {
      this.selectedEmployee = e.value.id;
    }
    this.loadEmployeesList();
  }

  loadEmployee() {
    this.empArr = [];
    this.sharedServices.getAllEmployees().subscribe(res => {
      if (this.userData.role == 'teamleader') {
        res.forEach((obj) => {
          if (obj.role == 'sales') {
            this.empArr.push({
              id: obj.Employee_id,
              name: obj.first_name + " " + obj.last_name
            });
          }
        });
      } else {
        res.forEach((obj) => {
          this.empArr.push({
            id: obj.Employee_id,
            name: obj.first_name + " " + obj.last_name
          });
        });
      }
      this._Empfilter();
    });
  }

  protected _Empfilter(): any[] {
    if (this.empArr.length <= 0) {
      return;
    }
    if (this.empGroup && this.empGroup.controls['employeeFilterControls'].value && (typeof this.empGroup.controls['employeeFilterControls'].value == 'string') && this.empGroup.controls['employeeFilterControls'].value.trim() != '') {
      const empfilterValue = this.empGroup.controls['employeeFilterControls'].value.toLowerCase();
      this.empFilteredOptions.next(
        this.empArr.filter(emp => (emp.name.toLowerCase().indexOf(empfilterValue) > -1))
      );
    } else {
      this.empFilteredOptions.next(this.empArr.slice());
      return;
    }
  }

  setIntialEmployeeSearch() {
    this.empFilteredOptions.pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        this.employeeSearchSelect.compareWith = (a: any, b: any) => a && b && ((a.id == b.id) || (a.personal_id == b.personal_id) || (a.loxysoft_id == b.loxysoft_id));
      });
  }
}
