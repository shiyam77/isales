import { Component, OnInit, ChangeDetectorRef, Input, Output, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from '../../../../../core/auth/authentication.service';
import { AuthNoticeService } from '../../../../../core/auth/auth-notice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'm-document-sign-response',
  templateUrl: './document-sign-response.component.html',
  styleUrls: ['./document-sign-response.component.scss']
})
export class DocumentSignResponseComponent implements OnInit {

  public model: any = { email: '' };
  @Input() action: string;
  @Output() actionChange = new Subject<string>();
  public loading = false;

  today: number = Date.now();

  @ViewChild('f') f: NgForm;
  errors: any = [];

  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };

  adminSignLink: any;
  docId: any;
  docLink: any;
  docName: any;
  signParams: any;
  role: any;

  constructor(private translate: TranslateService,
    private authService: AuthenticationService,
    private cdr: ChangeDetectorRef,
    private authNoticeService: AuthNoticeService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.signParams = params['sign'];
      this.docId = params['document_id'];
      this.role = params['type'];

      let updateParams: any = {};
      updateParams.docId = this.docId;
      updateParams.sign_status = this.signParams;
      updateParams.role = 'Admin';
      this.authService.updateSign(updateParams).subscribe((res) => {
      }, err => {
      });
    });

    if (!this.authNoticeService.onNoticeChanged$.getValue()) {
      const initialNotice = ``;
      this.authNoticeService.setNotice(initialNotice, 'success');
    }
    this.setMessage();
  }

  ngOnDestroy(): void {
    this.authNoticeService.setNotice(null);
  }

  setMessage() {
    let initialNotice = ''
    if (this.router.url.includes('/personal/document-sign-response?sign=Success')) {
      initialNotice = `Dokument undertecknat framgångsrikt!`;
      this.authNoticeService.setNotice(initialNotice, 'success');
    } else if (this.router.url.includes('/personal/document-sign-response?sign=Failure')) {
      initialNotice = `Dokument-e-post misslyckades!!`;
      this.authNoticeService.setNotice(initialNotice, 'error');
    }
  }

}
