import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Employee, Contact } from '../_core/models/employee.model';
import { PersonalService } from '../_core/services/personal.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { ActivatedRoute } from '@angular/router';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter,MAT_DATE_FORMATS,MAT_DATE_LOCALE} from '@angular/material/core';
export const MY_FORMATS = {
  parse: {
    dateInput: 'YYYY.MM.DD'
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};
@Component({
  selector: 'm-employee-loxy-history',
  templateUrl: './employee-loxy-history.component.html',
  styleUrls: ['./employee-loxy-history.component.scss'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ]
  
})
export class EmployeeLoxyHistoryComponent implements OnInit {
  loxyCreateOrupdate: string;
  employeeId: any;
  userData: any = {};
  getUserData: any = {};
  loxyDatasource: MatTableDataSource<any>;
  itemsPerPage: number = 10;
  itemsInPageList: Array<number> = [10, 50, 500];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  loader: boolean = false;
  productsArr: Array<any> = [];
  clientsArr: Array<any> = [];
  projectsArr: Array<any> = [];
  st4projectsArr: Array<any> = [];
  statusHistoryList: any = [];
  profileStatus: any = {};
  momentFormatDate = moment;
  employeeData: Employee = new Employee();
  userQRCode: string = btoa('test');
  resMessage: {
    success?: boolean;
    error?: boolean;
    message?: string;
  } = {
      success: false,
      error: false,
      message: ''
    };
  updateErrMsg: boolean;

  spinners = false;
  addLoxy: FormGroup;
  modalRef: any;
  errorMsg: string = '';
  closeResult: any;
  datas: any = [];
  deleteLeaveModalRef: any;
  deleteLeaveData: any;
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  fromDate: any = '';
  toDate: any = '';
  minDate = new Date();
  isFromPastDate: boolean = false;
  isToPastDate: boolean = false;
  userInitials: string;
  momentDateFormat = moment;
  loxyId: any;
  loxyDataSource: any = [];
  emp_status: string = 'G';
  loxyHistoryDisplayColumnToShow: any = ['loxysoftid', 'fromdate', 'todate', 'created_at', 'edit'];
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tarRowNoRecord: boolean = false;
  tarRowErr: boolean = false;
  changeView: any = {
    viewVal: "EmployeeInfo"
  };

  private isSetProvisionAndCommission: any = {
    clientLoaded: false,
    projectLoaded: false,
    productLoaded: false,
    employeeLoaded: false
  };
  paramsSub: any;

  constructor(
    private _formBuilder: FormBuilder,
    private personalService: PersonalService,
    private sharedServices: SharedService,
    private _ref: ChangeDetectorRef,
    private modalService: NgbModal,
    private route: ActivatedRoute) {
    this.route.params.subscribe(params => this.employeeId = +params.id);
  }

  ngOnInit() {
    this.addLoxy = this._formBuilder.group({
      fromdate: ['', [Validators.required]],
      todate: [''],
      loxysoft_id: ['', [Validators.required]],
      Employee_id: ['']
    });
    this.getUserData = this.personalService.getRoleAndId();
    this.getUserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getUserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.getLoxysoftHistoryData();
    this.getEmployeeData();
  }

  private resetTableAlert() {
    setTimeout(() => {
      this.resMessage.success = false;
      this.resMessage.error = false;
      this._ref.detectChanges();
    }, 5000);
  }

  getEmployeeData() {
    this.personalService.getEmployee(this.employeeId).subscribe((res: any) => {
      if (res) {
        if (res.employeestatus.length > 0) {
          this.statusHistoryList = res.employeestatus;
          res.employeestatus = res.employeestatus[res.employeestatus.length - 1];
        } else {
          this.statusHistoryList = [];
          let todates = moment(new Date()).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
          res.employeestatus = { fromdate: todates, todate: todates, Employeestatus: "G" };
        }
        this.profileStatus = res.employeestatus;
        this.employeeData = res;
        this.emp_status = res.emp_status;
        this.userInitials = this.employeeData.first_name.charAt(0).toUpperCase() + this.employeeData.last_name.charAt(0).toUpperCase();
        if (this.employeeData.Employee_id == this.userData.id && this.employeeData.img) {
          this.sharedServices.profileImgSub$.next(this.employeeData.img);
        }
        this.employeeData.provision = [];
        this.employeeData.compensation = [];
        if (!res.contact && !res.contact[0]) {
          this.employeeData.contact = new Contact();
        } else {
          this.employeeData.contact = res.contact[0];
        }
        if (res.bank && res.bank[0]) {
          this.employeeData.bank = res.bank[0];
        }
        let projectsArray = [];
        if (res.Projects && res.Projects.length > 0) {
          res.Projects.forEach((obj, ind) => {
            projectsArray.push({ Project_id: obj.Project_id, Project_name: obj.Project_name });
          });
        }
      }
      this.userQRCode = btoa(this.employeeData.Employee_id + '' + this.employeeData.first_name + '' + this.employeeData.last_name + '' + this.employeeData.personal_id);
    });
  }

  getLoxysoftHistoryData() {
    this.loader = true;
    if (this.employeeId) {
      this.personalService.getLoxysoftHistory(this.employeeId).subscribe((res: any) => {
        if (res && (res.length > 0)) {
          this.loxyDataSource = new MatTableDataSource(res);
          this.loxyDataSource.paginator = this.paginator;
          this.loxyDataSource.sort = this.sort;
          this.tRowNoRecord = false;
          this.tRowErr = false;
        }
        else {
          this.tRowNoRecord = true;
          this.tRowErr = false;
          this.loader = false;
        }
        this._ref.detectChanges();
        this.resetTableAlert();
        this.loader = false;
      }, err => {
        this.tarRowNoRecord = false;
        this.tarRowErr = true;
        this._ref.detectChanges();
        this.loader = true;
      });
    }
  }

  openModal(content, contentAccessId, toProduct?) {
    if (content === 'loxy_create') {
      this.updateErrMsg = false;
      this.loxyCreateOrupdate = 'create';
      this.loxyId = null;
      this.addLoxy.reset();
      this.addLoxy.controls['Employee_id'].enable();
      this.addLoxy.patchValue({
        Employee_id: this.employeeData.first_name + '' + this.employeeData.last_name,
      });
      this.addLoxy.controls['Employee_id'].disable();
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    } else if (content == 'loxy_update') {
      this.updateErrMsg = false;
      this.loxyCreateOrupdate = 'update';
      if (toProduct._id) {
        this.loxyId = toProduct._id;
      }
      this.addLoxy.controls['Employee_id'].enable();
      this.addLoxy.patchValue({
        Employee_id: this.employeeData.first_name + '' + this.employeeData.last_name,
        loxysoft_id: toProduct.loxysoft_id,
        fromdate: toProduct.fromdate,
        todate: toProduct.todate
      });
      this.addLoxy.controls['Employee_id'].disable();
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    }
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }



  createLoxy() {
    let form1 = this.addLoxy.value;

    let fromdate = moment(this.addLoxy.value.fromdate).format('YYYY-MM-DD');
    let todate = moment(this.addLoxy.value.todate).format('YYYY-MM-DD');
    if (this.addLoxy.valid) {
      this.spinner.active = true;
      let form1 = this.addLoxy.value;
      let loxyData: any = {
        "Employee_id": this.employeeId,
        "loxysoft_id": form1.loxysoft_id,
        "fromdate": fromdate,
        "todate": todate
      }
      if (this.loxyCreateOrupdate === 'create') {
        loxyData.todate = this.addLoxy.value.todate ? todate : "";
        this.personalService.addLoxy(loxyData).subscribe(res => {
          if (res.message === 'Loxysoft id added successfully') {
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          this.getLoxysoftHistoryData();
          this.modalRef.close();
          this._ref.detectChanges();
          this.resetAlert();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      } else if (this.loxyCreateOrupdate === 'update') {
        loxyData.employee_id = this.employeeId;
        loxyData.todate = this.addLoxy.value.todate ? todate : "";
        this.personalService.putLoxy(this.loxyId, loxyData).subscribe(res => {
          if (res.message === 'Updated Successfully') {
            this.resUpdateeMessage.success = true;
            this.resUpdateeMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resUpdateeMessage.success = false;
            this.resUpdateeMessage.error = true;
          }
          this.getLoxysoftHistoryData();
          this.modalRef.close();
          this._ref.detectChanges();
          this.resetAlert();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      }

      this.spinner.active = false;
    }
  }
  private resetAlert() {
    setTimeout(() => {
      this.resUpdateeMessage.success = false;
      this.resUpdateeMessage.error = false;
      this.resCreateMessage.success = false;
      this.resCreateMessage.error = false;
      this._ref.detectChanges();
    }, 3000);
  }

}
