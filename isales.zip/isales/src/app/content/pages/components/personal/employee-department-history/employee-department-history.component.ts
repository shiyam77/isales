import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatSelect } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Employee } from '../_core/models/employee.model';
import { PersonalService } from '../_core/services/personal.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { ActivatedRoute } from '@angular/router';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter,MAT_DATE_FORMATS,MAT_DATE_LOCALE} from '@angular/material/core';
export const MY_FORMATS = {
  parse: {
    dateInput: 'YYYY.MM.DD'
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

@Component({
  selector: 'm-employee-department-history',
  templateUrl: './employee-department-history.component.html',
  styleUrls: ['./employee-department-history.component.scss'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ]
})
export class EmployeeDepartmentHistoryComponent implements OnInit {
  [x: string]: any;
  employeeId: number;
  userData: any = {};
  getUserData: any = {};
  itemsPerPage: number = 10;
  itemsInPageList: Array<number> = [10, 50, 500];
  departmentHistoryDisplayColumnToShow: any = ['department', 'fromdate', 'todate', 'created_at', 'edit'];
  departmentHistoryDataSource: any = [];
  addDepartment: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  loader: boolean = false;
  productsArr: Array<any> = [];
  clientsArr: Array<any> = [];
  projectsArr: Array<any> = [];
  st4projectsArr: Array<any> = [];
  statusHistoryList: any = [];
  profileStatus: any = {};
  momentFormatDate = moment;
  employeeData: Employee = new Employee();
  userQRCode: string = btoa('test');
  resMessage: {
    success?: boolean;
    error?: boolean;
    message?: string;
  } = {
      success: false,
      error: false,
      message: ''
    };
  updateErrMsg: boolean;
  spinners = false;
  addLoxy: FormGroup;
  modalRef: any;
  errorMsg: string = '';
  closeResult: any;
  datas: any = [];
  deleteLeaveModalRef: any;
  deleteLeaveData: any;
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };


  @ViewChild('departmnetSearchSelect') departmnetSearchSelect: MatSelect;
  protected _onClientDestroy = new Subject<void>();
  departmentFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  fromDate: any = '';
  toDate: any = '';
  minDate = new Date();
  isFromPastDate: boolean = false;
  isToPastDate: boolean = false;
  userInitials: string;
  momentDateFormat = moment;
  departmentId: any;
  emp_status: string = 'G';
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tarRowNoRecord: boolean = false;
  tarRowErr: boolean = false;
  changeView: any = {
    viewVal: "EmployeeInfo"
  };
  departmentArr: Array<any> = [];
  private isSetProvisionAndCommission: any = {
    clientLoaded: false,
    projectLoaded: false,
    productLoaded: false,
    employeeLoaded: false
  };
  paramsSub: any;

  constructor(
    private _formBuilder: FormBuilder,
    private personalService: PersonalService,
    private sharedServices: SharedService,
    private _ref: ChangeDetectorRef,
    private modalService: NgbModal,
    private route: ActivatedRoute
  ) {
    this.route.params.subscribe(params => this.employeeId = +params.id);
  }

  ngOnInit() {
    this.addDepartment = this._formBuilder.group({
      fromdate: ['', [Validators.required]],
      todate: [''],
      department: ['', [Validators.required]],
      Employee_id: [''],
      department_id: [''],
      departmentNameFilter: [''],
    });
    this.getUserData = this.personalService.getRoleAndId();
    this.getUserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getUserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.getDepartmentHistory();
    this.getDepartmentList();
    this.addDepartment.controls['departmentNameFilter'].valueChanges
      .pipe(takeUntil(this._onClientDestroy)).subscribe(() => this._clientFilter());
  }

  private resetTableAlert() {
    setTimeout(() => {
      this.resMessage.success = false;
      this.resMessage.error = false;
      this._ref.detectChanges();
    }, 5000);
  }

  getDepartmentHistory() {
    this.loader = true;
    this.personalService.getDepartmentHistory(this.employeeId).subscribe((res: any) => {
      if (this.employeeId) {
        this.personalService.getDepartmentHistory(this.employeeId).subscribe((res: any) => {
          if (res && (res.length > 0)) {
            this.departmentHistoryDataSource = new MatTableDataSource(res);
            this.departmentHistoryDataSource.paginator = this.paginator;
            this.departmentHistoryDataSource.sort = this.sort;
            this.tRowNoRecord = false;
            this.tRowErr = false;
          }
          else {
            this.departmentHistoryDataSource.paginator = this.paginator;
            this.tRowNoRecord = true;
            this.tRowErr = false;
            this.loader = false;
          }
          this._ref.detectChanges();
          this.resetTableAlert();
          this.loader = false;
        }, err => {
          this.tarRowNoRecord = false;
          this.tarRowErr = true;
          this._ref.detectChanges();
          this.loader = true;
        });
      }
      this.userQRCode = btoa(this.employeeData.Employee_id + '' + this.employeeData.first_name + '' + this.employeeData.last_name + '' + this.employeeData.personal_id);
    });
  }

  openModal(content, contentAccessId, toProduct?) {
    if (content === 'department_create') {
      this.updateErrMsg = false;
      this.departmentCreateOrupdate = 'create';
      this.departmentId = null;
      this.addDepartment.reset();
      this.addDepartment.controls['todate'].disable();
      this.addDepartment.patchValue({
        todate: "",
      });
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    } else if (content === 'department_update') {
      this.updateErrMsg = false;
      this.departmentCreateOrupdate = 'update';
      if (toProduct._id) {
        this.departmentId = toProduct._id;
      }
      this.addDepartment.controls['todate'].enable();
      this.addDepartment.patchValue({
        Employee_id: this.employeeId,
        department_id: toProduct.department_id,
        department: { _id: toProduct.department_id, department: toProduct.department },
        fromdate: toProduct.fromdate,
        todate: toProduct.todate,
        departmentNameFilter: ['']
      });
      console.log(toProduct);
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    }
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getDepartmentList() {
    this.sharedServices.getDepartmentList().subscribe((res: any) => {
      if (res) {
        let deptData = res;
        if (deptData.length && deptData.length > 0) {
          this.clientsArr = deptData;
        }
      }
    });
  }

  createDepartment() {
    let fromdate = moment(this.addDepartment.value.fromdate).format('YYYY-MM-DD');
    let todate = moment(this.addDepartment.value.todate).format('YYYY-MM-DD');
    if (this.addDepartment.valid) {
      this.spinner.active = true;
      let form1 = this.addDepartment.value;
      let deptData: any = {
        "Employee_id": this.employeeId,
        "department_id": form1.department._id,
        "department": form1.department.department,
        "fromdate": fromdate,
        "todate": todate
      }
      if (this.departmentCreateOrupdate === 'create') {
        deptData.todate = this.addDepartment.value.todate ? todate : ""
        this.personalService.addDepartment(deptData).subscribe(res => {
          if (res.message === 'Department added successfully') {
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          this.getDepartmentHistory();
          this.modalRef.close();
          this.resetAlert();
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      } else if (this.departmentCreateOrupdate === 'update') {
        deptData.Employee_id = this.employeeId;
        deptData.todate = this.addDepartment.value.todate ? todate : ""
        this.personalService.updateDepartment(this.departmentId, deptData).subscribe(res => {
          console.log(this.departmentId);
          if (res.message === 'Updated Successfully') {
            this.resMessage.success = true;
            this.resMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resMessage.success = false;
            this.resMessage.error = true;
          }
          this.getDepartmentHistory();
          this.modalRef.close();
          setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this._ref.detectChanges();
          }, 5000)
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      }
      this.spinner.active = false;
    }
  }

  protected _clientFilter(): any[] {
    if (this.clientsArr.length <= 0) {
      return;
    }
    if (this.addDepartment && this.addDepartment.controls['departmentNameFilter'].value && (typeof this.addDepartment.controls['departmentNameFilter'].value == 'string') && this.addDepartment.controls['departmentNameFilter'].value.trim() != '') {
      const depfilterValue = this.addDepartment.controls['departmentNameFilter'].value.toLowerCase();
      this.departmentFilteredOptions.next(
        this.clientsArr.filter(dep => (dep.name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.departmentFilteredOptions.next(this.clientsArr.slice());
      return;
    }
  }

  compareDearptmentData(opt1: any, opt2: any) {
    if (opt1._id === opt2._id && opt1.department === opt2.department) {
      return true;
    } else {
      return false;
    }
  }

  private resetAlert() {
    setTimeout(() => {
      this.resCreateMessage.success = false;
      this.resCreateMessage.error = false;
      this._ref.detectChanges();
    }, 3000);
  }
}