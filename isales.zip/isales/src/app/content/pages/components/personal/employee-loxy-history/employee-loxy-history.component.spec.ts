import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeLoxyHistoryComponent } from './employee-loxy-history.component';

describe('EmployeeLoxyHistoryComponent', () => {
  let component: EmployeeLoxyHistoryComponent;
  let fixture: ComponentFixture<EmployeeLoxyHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeLoxyHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeLoxyHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
