import { Component, OnInit } from '@angular/core';
import { PersonalService } from '../_core/services/personal.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'm-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.scss']
})
export class EmployeeEditComponent implements OnInit {

  employeeId:Number;
  constructor(private personalService: PersonalService, private router:Router, private route:ActivatedRoute) { 
    this.route.params.subscribe(params => this.employeeId = +params.id);
  }

  ngOnInit() {
  }

}
