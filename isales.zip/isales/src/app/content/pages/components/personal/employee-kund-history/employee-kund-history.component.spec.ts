import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeKundHistoryComponent } from './employee-kund-history.component';

describe('EmployeeKundHistoryComponent', () => {
  let component: EmployeeKundHistoryComponent;
  let fixture: ComponentFixture<EmployeeKundHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeKundHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeKundHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
