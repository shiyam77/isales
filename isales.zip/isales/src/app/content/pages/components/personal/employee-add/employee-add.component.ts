import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.scss']
})
export class EmployeeAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
