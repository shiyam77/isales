import { Component, OnInit, ViewChild, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatSnackBar, MatDialog, MatTableDataSource } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { EmployeeList } from '../_core/models/employee-list.model';
import { PersonalService } from '../_core/services/personal.service';
import * as Xlsx from 'xlsx';
import * as _moment from 'moment';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { Employee } from '../_core/models/employee.model';
import { Router } from '@angular/router';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
type AOA = any[][];

@Component({
  selector: 'm-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss'],
  providers: []
})
export class EmployeeListComponent implements OnInit, AfterViewInit {
  recruitment_name:any
  recuitrment : any []
  dataSource: MatTableDataSource<EmployeeList>;
  loader: boolean = false;
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  displayColumnToShow = ['Employee_id', 'personal_id', 'first_name', 'last_name', 'contact.0.email', 'contact.0.mobile', 'loxysoft_id', 'EmployeeProjects.0.Project_name', 'department','contact.0.place', 'agreement.0.fromdate','agreement.0.todate','userstatus', 'actions','recruitment.0.name','referedby.0.name'];
  excelColumns = [];
  arrToPrint: AOA = [];
  toggleColumns = [
    { arrIndex: 0, column: 'ACTIONS', checked: true, label: 'actions' },
    { arrIndex: 1, column: 'EMPLOYEE_ID', checked: true, label: 'Employee_id' },
    { arrIndex: 2, column: 'PERSONAL_ID', checked: true, label: 'personal_id' },
    { arrIndex: 3, column: 'FIRST_NAME', checked: true, label: 'first_name' },
    { arrIndex: 4, column: 'LAST_NAME', checked: true, label: 'last_name' },
    { arrIndex: 5, column: 'EMAIL', checked: true, label: 'contact.0.email' },
    { arrIndex: 6, column: 'MOBILE', checked: true, label: 'contact.0.mobile' },
    { arrIndex: 7, column: 'LOXYSOFT_ID', checked: true, label: 'loxysoft_id' },
    { arrIndex: 8, column: 'CLIENT', checked: true, label: 'EmployeeClients.0.Client_name' },
    { arrIndex: 9, column: 'LOGIN_DEPARTMENT', checked: true, label: 'role' },
    { arrIndex: 10, column: 'CITY', checked: true, label: 'contact.0.place' },
    { arrIndex: 11, column: 'DEPARTMENT', checked: true, label: 'department' },
    { arrIndex: 12, column: 'START_DATUM', checked: true, label: 'agreement.0.fromdate' },
    { arrIndex: 13, column: 'TILL_DATUM', checked: true, label: 'agreement.0.todate' },
    { arrIndex: 14, column: 'STATUS', checked: true, label: 'userstatus' },
    { arrIndex: 15, column: 'RECRUITER', checked: false, label: 'recruitment.0.name' },
    { arrIndex: 16, column: 'RECRUITED_BY', checked: false, label: 'referedby.0.name' },
    { arrIndex: 17, column: 'HOME_PHONE', checked: false, label: 'contact.0.landline', onlyAdmin: true },
    { arrIndex: 18, column: 'ADDRESS', checked: false, label: 'contact.0.address', onlyAdmin: true },
    { arrIndex: 19, column: 'ZIPCODE', checked: false, label: 'contact.0.zipcode', onlyAdmin: true },
    { arrIndex: 20, column: 'BANKNAME', checked: false, label: 'bank.0.BankName', onlyAdmin: true },
    { arrIndex: 21, column: 'CLEARING_NUMBER', checked: false, label: 'bank.0.ClearingNumber', onlyAdmin: true },
    { arrIndex: 22, column: 'ACCOUNT_NUMBER', checked: false, label: 'bank.0.AccountNumber', onlyAdmin: true },
    { arrIndex: 23, column: 'LOXYSOFT', checked: false, label: 'loxysoft', onlyAdmin: true },
    { arrIndex: 22, column: 'EXTENT', checked: false, label: 'emp_type', onlyAdmin: true },
    { arrIndex: 24, column: 'EMERGENCY_CONTACT_NAME_1', checked: false, label: 'emergencycontact[0].name', onlyAdmin: true },
    { arrIndex: 25, column: 'EMERGENCY_CONTACT_NUMBER_1', checked: false, label: 'emergencycontact[0].contactnumber', onlyAdmin: true },
    { arrIndex: 26, column: 'EMERGENCY_CONTACT_NAME_2', checked: false, label: 'emergencycontact[1].name', onlyAdmin: true },
    { arrIndex: 27, column: 'EMERGENCY_CONTACT_NUMBER_2', checked: false, label: 'emergencycontact[1].contactnumber', onlyAdmin: true },
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  xpandStatus: boolean = false;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  selection = new SelectionModel<EmployeeList>(true, []);
  allEmployeeList: EmployeeList[] = [];
  tempdata = [];
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  closeResult: string;
  delEmployeeData: any;
  deleteEmpModalRef: any;
  closeEmployeeCredEmailResult: any;
  closeEmployeeEsignEmailResult: any;

  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  searchInput: string = '';
  screenLoader: boolean = false;
  scriveDynamicDownload: any;
  multiColFilter = {
    Employee_id: '',
    personal_id: '',
    first_name: '',
    last_name: '',
    'contact.0.email': '',
    'contact.0.mobile': '',
    Product_name: '',
    EmpProvisionIn: '',
    EmpProvisionOut: '',
    WorkingDate: '',
    loxysoft_id: '',
    "EmployeeClients.0.Client_name": '',
    role: '',
    'contact.0.place': '',
    department: '',
    userstatus: '',
    'bank.0.BankName': '',
    'bank.0.ClearingNumber': '',
    'bank.0.AccountNumber': '',
    emp_type: '',
    'emergencycontact.0.name': '',
    'emergencycontact.0.contactnumber': '',
    'emergencycontact.1.name': '',
    'emergencycontact.1.contactnumber': '',
    'agreement.0.fromdate':'',
    'agreement.0.todate':'',
    'recruitment.0.name':'',
    'referedby.0.name':'',
  };
  isUserActiveList: boolean = true;
  isUnSignedList: boolean = false;
  unSignedListLength: number = null;
  isUserPendingList: boolean = true;
  filterColumns = ['Actions', 'Id', 'Pid', 'firstName', 'lastName', 'Email', 'Mobile', 'Lid', 'Client', 'Role', 'Place', 'Department','Startdate', 'Status', 'Landline', 'Address', 'Zipcode', 'Bankname', 'Clearingnumber', 'Accountnumber', 'Loxysoft', 'Emptype', 'Emergencyname1', 'Emergencycontactnumber1', 'Emergencyname2', 'Emergencycontactnumber2','recruitedBy','recruited'];
  toggleFilterColumns = [
    { arrIndex: 0, column: 'ACTIONS', checked: true, label: 'Actions' },
    { arrIndex: 1, column: 'EMPLOYEE_ID', checked: true, label: 'Id' },
    { arrIndex: 2, column: 'PERSONAL_ID', checked: true, label: 'Pid' },
    { arrIndex: 3, column: 'FIRST_NAME', checked: true, label: 'firstName' },
    { arrIndex: 4, column: 'LAST_NAME', checked: true, label: 'lastName' },
    { arrIndex: 5, column: 'EMAIL', checked: true, label: 'Email' },
    { arrIndex: 6, column: 'MOBILE', checked: true, label: 'Mobile' },
    { arrIndex: 7, column: 'LOXYSOFT_ID', checked: true, label: 'Lid' },
    { arrIndex: 8, column: 'CLIENT', checked: true, label: 'Client' },
    { arrIndex: 9, column: 'LOGIN_DEPARTMENT', checked: true, label: 'Role' },
    { arrIndex: 10, column: 'CITY', checked: true, label: 'Place' },
    { arrIndex: 11, column: 'DEPARTMENT', checked: true, label: 'Department' },
    { arrIndex: 12, column: 'START_DATUM', checked: true, label: 'Startdate' },
    { arrIndex: 13, column: 'TILL_DATUM', checked: true, label: 'Todate' },
    { arrIndex: 14, column: 'STATUS', checked: true, label: 'Status' },
    { arrIndex: 15, column: 'RECRUITED', checked: true, label: 'recruited' },
    { arrIndex: 16, column: 'RECRUITED_BY', checked: true, label: 'recruitedBy' },
    { arrIndex: 17, column: 'HOME_PHONE', checked: false, label: 'Landline', onlyAdmin: true },
    { arrIndex: 18, column: 'ADDRESS', checked: false, label: 'Address', onlyAdmin: true },
    { arrIndex: 19, column: 'ZIPCODE', checked: false, label: 'Zipcode', onlyAdmin: true },
    { arrIndex: 20, column: 'BANKNAME', checked: false, label: 'Bankname', onlyAdmin: true },
    { arrIndex: 21, column: 'CLEARING_NUMBER', checked: false, label: 'Clearingnumber', onlyAdmin: true },
    { arrIndex: 22, column: 'ACCOUNT_NUMBER', checked: false, label: 'Accountnumber', onlyAdmin: true },
    { arrIndex: 23, column: 'LOXYSOFT', checked: false, label: 'Loxysoft', onlyAdmin: true },
    { arrIndex: 24, column: 'EXTENT', checked: false, label: 'Emptype', onlyAdmin: true },
    { arrIndex: 25, column: 'EMERGENCY_CONTACT_NAME_1', checked: false, label: 'Emergencyname1', onlyAdmin: true },
    { arrIndex: 26, column: 'EMERGENCY_CONTACT_NUMBER_1', checked: false, label: 'Emergencycontactnumber1', onlyAdmin: true },
    { arrIndex: 27, column: 'EMERGENCY_CONTACT_NAME_2', checked: false, label: 'Emergencyname2', onlyAdmin: true },
    { arrIndex: 28, column: 'EMERGENCY_CONTACT_NUMBER_2', checked: false, label: 'Emergencycontactnumber2', onlyAdmin: true }
  ];
  employeeDateRange:FormGroup;
  constructor(
    private personalService: PersonalService,
    public matDialog: MatDialog,
    private translate: TranslateService,
    public snackBar: MatSnackBar,
    private modalService: NgbModal,
    private router: Router,
    private sharedServices: SharedService,
    private _ref: ChangeDetectorRef,
    private _fb:FormBuilder
  ) { }

  ngOnInit() {
    this.dataSource = new MatTableDataSource<EmployeeList>();
    this.unSignedListLength = null;
    this.getuserData = this.personalService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.loadEmployeesList();
    this.employeeDateRange = this._fb.group({
      fromdate: ['',[Validators.required]],
      todate: ['', [Validators.required]]
    });
  }

  ngAfterViewInit() { }

  loadEmployeesList() {
    // this.recruitment_name = [];
    this.loader = true;
    this.selection.clear();
    this.tempdata = [];
    this.dataSource = new MatTableDataSource([]);
      this.personalService.getAllEmployeesWithCount(this.isUserActiveList, this.isUnSignedList,this.isUserPendingList).subscribe((res: any) => {
      if (res || res[0]) {
        res.Data.forEach((val)=>{
          this.tempdata.push({
            EmployeeClients:JSON.parse(val.EmployeeClients),
            EmployeeDepartment:JSON.parse(val.EmployeeDepartment),
            EmployeeProjectCost:JSON.parse(val.EmployeeProjectCost),
            EmployeeProjects: JSON.parse(val.EmployeeProjects),
            EmployeeProvisons:JSON.parse(val.EmployeeProvisons),
            Employee_id:val.Employee_id,
            Projects: JSON.parse(val.Projects),
            admin_sign_status: val.admin_sign_status,
            agreement:JSON.parse(val.agreement),
            bank:JSON.parse(val.bank),
            contact:JSON.parse(val.contact),
            department: val.department,
            department_id: val.department_id,
            emergencycontact:JSON.parse(val.emergencycontact),
            emp_status: val.emp_status,
            emp_type: val.emp_type,
            employeestatus:JSON.parse(val.employeestatus),
            first_name: val.first_name,
            fixedsalary: val.fixedsalary,
            holidaypay: val.holidaypay,
            last_name: val.last_name,
            leave:JSON.parse(val.leave),
            loxysoft_id: val.loxysoft_id,
            menupermission: val.menupermission,
            personal_id: val.personal_id,
            recruitment: JSON.parse(val.recruitment),
            recruitment_id: val.recruitment_id,
            referedby: JSON.parse(val.referedby),
            role:val.role,
            sign_status: val.sign_status,
            socialfee:JSON.parse(val.socialfee),
            userstatus: val.userstatus,
            visma_id: val.visma_id,
            document_admin_url: val.document_admin_url,
            Semesterval:val.Semesterval,
            agreementdownload: val.agreementdownload,
            device_id: val.device_id,
            document_id: val.document_id,
            document_url: val.document_url,
            img: val.img,
            refered_by: val.refered_by,
          })
        })
        this.allEmployeeList = this.tempdata;
        
        // this.recruitment_name =  res[0].data.recruitment[0].first_name + "" + res[0].data.recruitment[0].last_name;
        // if(res && res[0].data){
         
        //    res[0].data.forEach(elements=>{
        //     let name = ""
        //      if((elements.recuritment).length>0){
        //           name = elements.recuritment[0].first_name + "" + elements.recuritment[0].last_name
        //      }
        //      elements.name = name
        //   });
        //   console.log('res[0].data',res[0].data)
        // }
        // this.recuitrment =  this.recruitment_name
        this.sharedServices.allEmployeeListData =this.tempdata;
        this.sharedServices.employeeListSub$.next(true);
        if (this.tempdata) {
          this.tempdata.sort((a, b) => (a.first_name > b.first_name) ? 1 : ((b.first_name > a.first_name) ? -1 : 0));
        }
        this.dataSource = new MatTableDataSource(this.tempdata);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        };
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.loader = false;
        if (!this.tempdata || (this.tempdata && (this.tempdata.length <= 0))) {
          this.tRowNoRecord = true;
        } else {
          this.tRowNoRecord = false;
        }
        this.unSignedListLength = (res.AdminNotSignedcount);          
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = this.columnwiseFilter();
        this.dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.tRowNoRecord = true;
        this.loader = false;
        this._ref.detectChanges();
      }
    }, err => {
      setTimeout(function () {
        this.tRowNoRecord = true;
        this.loader = false;
        this._ref.detectChanges();
      }, 1);
    });
    this.selection.clear();
    this.showHideCols();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.Employee_id + item.personal_id + item.first_name + item.last_name + item.contact[0].email + item.contact[0].mobile + item.contact[0].place + item.department + item.loxysoft_id;
      filterString = filterString.trim().toLocaleLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin' || this.userData.role === 'recruitment') {
      /* generate worksheet */
      this.setExcelHeaders();
      this.setExcelValues();
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Anställd_Lista_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }

  showHideCols() {
    this.displayColumnToShow = [];
    this.filterColumns = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
          this.displayColumnToShow.push(obj.label);
          this.filterColumns.push(this.toggleFilterColumns[ind].label);
          if (this.multiColFilter[obj.label] === undefined) {
            this.multiColFilter[obj.label] = '';
          }
        } else {
          if (!obj.onlyAdmin) {
            this.displayColumnToShow.push(obj.label);
            this.filterColumns.push(this.toggleFilterColumns[ind].label);
            if (this.multiColFilter[obj.label] === undefined) {
              this.multiColFilter[obj.label] = '';
            }
          }
        }
      } else {
        if (this.multiColFilter[obj.label]) {
          this.multiColFilter[obj.label] = '';
          this.applyColumnFilter();
        }
      }
    });
  }

  private setExcelHeaders() {
    this.arrToPrint = [];
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      this.translate.get('EMPLOYEE.EMPLOYEE_LIST.' + obj.column).subscribe((res: string) => {
        if (this.displayColumnToShow.indexOf(obj.label) > -1 && obj.label != 'actions') {
          this.arrToPrint[0].push(res);
        }
      });
    });
    this.arrToPrint[0].push('Grön/Gul/Röd/Orange');
  }

  private setExcelValues() {
    if (this.dataSource && this.dataSource.data.length) {
      this.dataSource.filteredData.forEach((val: any) => {
        let newLine = [];
        this.displayColumnToShow.forEach((key, ind) => {
          if (key != 'actions') {
            if (key === 'userstatus' || key === 'loxysoft'
              || key === 'emergencycontact[0].name' || key === 'emergencycontact[0].contactnumber'
              || key === 'emergencycontact[1].name' || key === 'emergencycontact[1].contactnumber' || key === 'agreement.0.fromdate' || key === 'agreement.0.todate') {
              if (key === 'userstatus') {
                if (val.userstatus) {
                  newLine.push('Aktiva');
                } else {
                  newLine.push('Inaktiva');
                }
              }
              if (key === 'loxysoft') {
                if (val.loxysoft_id) {
                  newLine.push('Ja');
                } else {
                  newLine.push('Nej');
                }
              }
              if (key === 'emergencycontact[0].name') {
                if (val.emergencycontact && val.emergencycontact[0]) {
                  newLine.push(val.emergencycontact[0].name);
                } else {
                  newLine.push('');
                }
              }
              if (key === 'emergencycontact[0].contactnumber') {
                if (val.emergencycontact && val.emergencycontact[0]) {
                  newLine.push(val.emergencycontact[0].contactnumber);
                } else {
                  newLine.push('');
                }
              }
              if (key === 'emergencycontact[1].name') {
                if (val.emergencycontact && val.emergencycontact[1]) {
                  newLine.push(val.emergencycontact[1].name);
                } else {
                  newLine.push('');
                }
              }
              if (key === 'emergencycontact[1].contactnumber') {
                if (val.emergencycontact && val.emergencycontact[1]) {
                  newLine.push(val.emergencycontact[1].contactnumber);
                } else {
                  newLine.push('');
                }
              }
              if(key === 'agreement.0.fromdate'){
                if(val.agreement[val.agreement.length-1] && val.agreement[val.agreement.length-1].fromdate){
                  newLine.push(_moment(val.agreement[val.agreement.length-1].fromdate).format('YYYY-MM-DD'));  
                }else{
                  newLine.push('');
                }
              }
              if (key === 'agreement.0.todate') {
                if(val.agreement[val.agreement.length-1] && val.agreement[val.agreement.length-1].todate){
                  newLine.push(_moment(val.agreement[val.agreement.length-1].todate).format('YYYY-MM-DD'));
                }else{
                  newLine.push('');
                }
              }
            } else {
              let str = key.split('.').reduce((o, i) => { if (o && o[i]) { return o[i] } }, val);
              newLine.push(str);
            }
          }
          if(newLine.length == (this.displayColumnToShow.length-1)){
            if(val.emp_status){
              if(val.emp_status == 'G'){
                newLine.push('Grön')
              }else if(val.emp_status == 'R'){
                newLine.push('Röd');
              }else if(val.emp_status == 'Y'){
                newLine.push('Gul');
              }else if(val.emp_status == 'O'){
                newLine.push('Orange');
              }else{
                newLine.push('');  
              }
            }else{
              newLine.push('');
            }
          }
        });
        this.arrToPrint.push(newLine);
      });
    }
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  openModal(content, toDelEmployee) {
    this.deleteEmpModalRef = this.modalService.open(content),{backdrop:"static"};
    this.delEmployeeData = toDelEmployee;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  deleteEmployee() {
    this.spinner.active = true;
    this.personalService.deleteEmployee(this.delEmployeeData.Employee_id).subscribe(res => {
      if (res) {
        this.loadEmployeesList();
      }
      this.spinner.active = false;
      this.deleteEmpModalRef.close('submitted');
    }, err => {
      this.spinner.active = false;
    });
  }

  viewEmployee(d: Employee) {
    if (this.userData.role !== 'admin' || this.userData.role == 'superadmin') {
      this.router.navigate(['/personal/employee', 'view', d.Employee_id]);
    } else {
      this.router.navigate(['/personal/employee', 'view', d.Employee_id]);
    }
  }

  editEmployee(d: Employee) {
    this.router.navigate(['/personal/employee', 'edit', d.Employee_id]);
  }

  sendMailForEmployeeCredentials(employeeId, content) {
    this.screenLoader = true;
    this.personalService.resendEmployeeCredentialViaEmail(employeeId).subscribe((res: any) => {
      if (res) {
        if (res.message === 'Password resend Successfully') {
          this.screenLoader = false;
          let emailEmployeeCredentials = this.modalService.open(content,{backdrop:"static"});
          emailEmployeeCredentials.result.then((result) => {
            this.closeEmployeeCredEmailResult = `Closed with: ${result}`;
          }, (reason) => {
            this.closeEmployeeCredEmailResult = `Dismissed ${this.getDismissReason(reason)}`;
          });
        }
      }
    });
  }

  sendMailForEmployeeEsignLink(employeeId, content) {
    this.screenLoader = true;
    this.personalService.resendEmployeeEsignLinkViaEmail(employeeId).subscribe((res: any) => {
      if (res) {
        this.screenLoader = false;
        let emailEmployeeEsign = this.modalService.open(content,{backdrop:"static"});
        emailEmployeeEsign.result.then((result) => {
          this.closeEmployeeEsignEmailResult = `Closed with: ${result}`;
        }, (reason) => {
          this.closeEmployeeEsignEmailResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
      }
    });
  }

  downloadSignedDoc(employee) {
    this.personalService.getSignedDoc(employee.Employee_id).subscribe((res: any) => {
      if (res) {
        if (!this.scriveDynamicDownload) {
          this.scriveDynamicDownload = document.createElement('a');
        }
        const element = this.scriveDynamicDownload;
        const dFileName = `${employee.first_name}_${employee.last_name}_${employee.personal_id}_${_moment().format("YYYY-MM-DD")}`;
        element.setAttribute('href', `data:application/pdf;base64,${res.document_bytes}`);
        element.setAttribute('download', dFileName);
        var event = new MouseEvent("click");
        element.dispatchEvent(event);
      }
    });
  }

  applyColumnFilter() {
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(filterString).forEach((key) => {
        let keyNodeValue = key.split('.').reduce((o, i) => { 
          if (o) { 
            if (key === 'agreement.0.fromdate') {
              if(item.agreement[item.agreement.length-1]){
                return item.agreement[item.agreement.length-1].fromdate;   
              }else{
                return;
              }
            }
            if (key === 'agreement.0.todate') {
              if(item.agreement[item.agreement.length-1]){
              return item.agreement[item.agreement.length-1].todate;
              }else{
                return;
              }
            }
            return o[i] 
          } 
        }, item);
        if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (keyNodeValue && (typeof keyNodeValue != 'string')) {
            itemString = keyNodeValue.toString();
          } else if (keyNodeValue) {
            itemString = keyNodeValue;            
          }
          if (key === 'role') {
            this.translate.get('COMMON.ROLE_LIST.' + itemString.toLowerCase()).subscribe((transString) => {
              if (transString) {
                itemString = transString;
              }
            });
          }
          if (key === 'emp_type') {
            this.translate.get('EMPLOYEE.EXTENT_LIST.' + itemString.toLowerCase()).subscribe((transString) => {
              if (transString) {
                itemString = transString;
              }
            });
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          }
          else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        }else{
          if((!keyNodeValue || (keyNodeValue <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))){
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  toggleUserActiveList(isUserActive: boolean, isUnSigned?: boolean,isUserPending?: boolean) {
    if (this.isUserActiveList != isUserActive || this.isUnSignedList != isUnSigned || this.isUserPendingList != !isUserPending) {
      this.isUserActiveList = isUserActive;
      this.isUnSignedList = isUnSigned;
      this.isUserPendingList = isUserPending;
      this.loadEmployeesList();
    }
  }

  searchEmployeeList(){
    if(this.employeeDateRange.valid){
      this.loader = true;
      let toSendDateRange = this.employeeDateRange.value;
      toSendDateRange.fromdate = _moment(toSendDateRange.fromdate).format('YYYY-MM-DD');
      toSendDateRange.todate = _moment(toSendDateRange.todate).format('YYYY-MM-DD');
      this.dataSource = new MatTableDataSource([]);
      this.personalService.getAllEmployeesByDateRange(toSendDateRange).subscribe((res) => {
        if (res && res[0]) {
          this.allEmployeeList = res[0].data;
          this.sharedServices.allEmployeeListData = res[0].data;
          this.sharedServices.employeeListSub$.next(true);
          if (res[0].data) {
            res[0].data.sort((a, b) => (a.first_name > b.first_name) ? 1 : ((b.first_name > a.first_name) ? -1 : 0));
          }
          this.dataSource = new MatTableDataSource(res[0].data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            let sortString = property.split('.').reduce((o, i) => o[i], item);
            if (typeof sortString === 'string') {
              sortString = sortString.toLowerCase();
            }
            return sortString;
          };
          this.dataSource.filterPredicate = this.columnwiseFilter();
          this.loader = false;
          if (!res[0].data || (res[0].data && (res[0].data.length <= 0))) {
            this.tRowNoRecord = true;
          } else {
            this.tRowNoRecord = false;
          }
        }
      });
    }else{
      this.validateAllFormFields(this.employeeDateRange);
    }
  }
  
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
        const control = formGroup.get(field);
        if (control instanceof FormControl) {
            control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {
            this.validateAllFormFields(control);
        }
    });
  }
}