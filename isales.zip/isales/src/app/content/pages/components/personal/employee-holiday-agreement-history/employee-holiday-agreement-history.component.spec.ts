import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeHolidayAgreementHistoryComponent } from './employee-holiday-agreement-history.component';

describe('EmployeeHolidayAgreementHistoryComponent', () => {
  let component: EmployeeHolidayAgreementHistoryComponent;
  let fixture: ComponentFixture<EmployeeHolidayAgreementHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeHolidayAgreementHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeHolidayAgreementHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
