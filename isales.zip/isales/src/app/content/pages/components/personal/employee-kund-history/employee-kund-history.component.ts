import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PersonalService } from '../_core/services/personal.service';
import { MatPaginator, MatSelect, MatSort, MatTableDataSource } from '@angular/material';
import moment from 'moment';
import { ReplaySubject, Subject } from 'rxjs';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { takeUntil } from 'rxjs/operators';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';

@Component({
  selector: 'm-employee-kund-history',
  templateUrl: './employee-kund-history.component.html',
  styleUrls: ['./employee-kund-history.component.scss']
})
export class EmployeeKundHistoryComponent implements OnInit {
  employeeId: number;
  kundHistoryDataSource: any = [];
  getUserData: any = {};
  userData: any = {};
  itemsPerPage: number = 10;
  itemsInPageList: Array<number> = [10, 50, 500];
  kundHistoryDisplayColumnToShow: any = ['kund', 'fromdate', 'todate', 'created_at', 'created_by', 'edit'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  loader: boolean = false;
  momentFormatDate = moment;
  resMessage: {
    success?: boolean;
    error?: boolean;
    message?: string;
  } = {
      success: false,
      error: false,
      message: ''
    };
  updateErrMsg: boolean;
  spinners = false;
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
  protected _onClientDestroy = new Subject<void>();
  clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  fromDate: any = '';
  toDate: any = '';
  minDate = new Date();
  isFromPastDate: boolean = false;
  isToPastDate: boolean = false;
  momentDateFormat = moment;
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tarRowNoRecord: boolean = false;
  tarRowErr: boolean = false;
  modalRef: any;
  closeResult: any;
  kundID: any;
  addkund: FormGroup;
  clientsArr: Array<any> = [];
  kundCreateOrupdate: string;
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  modifier_name: string;

  constructor(
    private route: ActivatedRoute,
    private personalService: PersonalService,
    private _ref: ChangeDetectorRef,
    private modalService: NgbModal,
    private _formBuilder: FormBuilder,
    private sharedServices: SharedService,

  ) {
    this.route.params.subscribe(params => this.employeeId = +params.id);
  }

  ngOnInit() {
    this.addkund = this._formBuilder.group({
      fromdate: ['', [Validators.required]],
      todate: [''],
      employee_id: [''],
      client: ['', [Validators.required]],
      clientNameFilter: [''],
    });
    this.getUserData = this.personalService.getRoleAndId();
    this.getUserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getUserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.getKundHistoryList();
    this.getClientList();
    this.getModifiedByName();
    this.addkund.controls['clientNameFilter'].valueChanges
      .pipe(takeUntil(this._onClientDestroy)).subscribe(() => this._clientFilter());

  }
  compareKundData(opt1: any, opt2: any) {
    if (opt1._id === opt2.Client_id && opt1.name === opt2.Client_name) {
      return true;
    } else {
      return false;
    }
  }
  getKundHistoryList() {
    this.loader = true;
    this.personalService.getKundHistory(this.employeeId).subscribe((res: any) => {
      if (this.employeeId) {
        this.personalService.getKundHistory(this.employeeId).subscribe((res: any) => {
          if (res && (res.length > 0)) {
            this.kundHistoryDataSource = new MatTableDataSource(res);
            this.kundHistoryDataSource.paginator = this.paginator;
            this.kundHistoryDataSource.sort = this.sort;
            this.tRowNoRecord = false;
            this.tRowErr = false;
          }
          else {
            this.kundHistoryDataSource.paginator = this.paginator;
            this.tRowNoRecord = true;
            this.tRowErr = false;
            this.loader = false;
          }
          this._ref.detectChanges();
          this.resetTableAlert();
          this.loader = false;
        }, err => {
          this.tarRowNoRecord = false;
          this.tarRowErr = true;
          this._ref.detectChanges();
          this.loader = true;
        });
      }
    })
  }
  private resetTableAlert() {
    setTimeout(() => {
      this.resMessage.success = false;
      this.resMessage.error = false;
      this._ref.detectChanges();
    }, 5000);
  }
  openModal(content, contentAccessId, toProduct?) {
    if (content === 'kund_create') {
      this.updateErrMsg = false;
      this.kundCreateOrupdate = 'create';
      this.addkund.reset();
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    } else if (content == 'kund_Update') {
      this.updateErrMsg = false;
      this.kundCreateOrupdate = 'update';
      this.kundID = toProduct._id;
      this.addkund.controls['employee_id'].enable();
      this.addkund.patchValue({
        employee_id: toProduct.Employee_id,
        fromdate: toProduct.fromdate,
        todate: toProduct.todate,
        client: { Client_id: toProduct.Client_id, Client_name: toProduct.Client_name },
        clientNameFilter: [''],
        _id: this.kundID
      });
      this.addkund.controls['employee_id'].disable();
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    }
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  getClientList() {
    this.sharedServices.getClientList().subscribe((res: any) => {
      if (res) {
        this.clientsArr = res;
        this.clientsArr.sort(function (a, b) {
          if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
          if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
          return 0;
        });

      }
    });
  }
  protected _clientFilter(): any[] {
    if (this.clientsArr.length <= 0) {
      return;
    }
    if (this.addkund && this.addkund.controls['clientNameFilter'].value && (typeof this.addkund.controls['clientNameFilter'].value == 'string') && this.addkund.controls['clientNameFilter'].value.trim() != '') {
      const clientfilterValue = this.addkund.controls['clientNameFilter'].value.toLowerCase();
      this.clientFilteredOptions.next(
        this.clientsArr.filter(dep => (dep.name.toLowerCase().indexOf(clientfilterValue) > -1))
      );
    } else {
      this.clientFilteredOptions.next(this.clientsArr.slice());
      return;
    }
  }
  getModifiedByName() {
    this.personalService.getModifierName(this.userData.id).subscribe((res: any) => {
      this.modifier_name = res[0].first_name + " " + res[0].last_name;
    })
  }

  createClientContent() {
    let fromdate = moment(this.addkund.value.fromdate).format('YYYY-MM-DD');
    let todate = moment(this.addkund.value.todate).format('YYYY-MM-DD');
    if (this.addkund.valid) {
      this.spinner.active = true;
      //let form1 = this.addkund.value;
      let clientDetails: any = {
        "employee_id": this.addkund.controls['employee_id'].value,
        "Client_id": this.addkund.value.client._id || this.addkund.value.client.Client_id,
        "Client_name": this.addkund.value.client.name || this.addkund.value.client.Client_name,
        "fromdate": fromdate,
        "todate": todate,
        "modified_by": this.userData.id,
        "modifier_name": this.modifier_name,
      }
      if (this.kundCreateOrupdate === 'create') {
        this.personalService.updateClient(this.kundID, clientDetails).subscribe(res => {
          if (res.message === 'Employee Client Assigned Successfully') {
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          this.getKundHistoryList();
          this.modalRef.close();
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      } else if (this.kundCreateOrupdate === 'update') {
        clientDetails.employee_id = this.employeeId;
        clientDetails.todate = this.addkund.value.todate ? todate : ""
        this.personalService.updateClient(this.kundID, clientDetails).subscribe(res => {
          if (res.message === 'Employee Client Assigned Successfully') {
            this.resMessage.success = true;
            this.resMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resMessage.success = false;
            this.resMessage.error = true;
          }
          this.getKundHistoryList();
          this.modalRef.close();
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      }
      this.spinner.active = false;
    }
  }

}
