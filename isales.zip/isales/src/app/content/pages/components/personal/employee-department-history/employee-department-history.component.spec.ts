import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeDepartmentHistoryComponent } from './employee-department-history.component';

describe('EmployeeDepartmentHistoryComponent', () => {
  let component: EmployeeDepartmentHistoryComponent;
  let fixture: ComponentFixture<EmployeeDepartmentHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeDepartmentHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDepartmentHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
