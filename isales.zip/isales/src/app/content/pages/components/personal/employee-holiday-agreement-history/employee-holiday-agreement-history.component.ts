import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Employee, Contact } from '../_core/models/employee.model';
import { PersonalService } from '../_core/services/personal.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { ActivatedRoute } from '@angular/router';
import { DropdownConstants } from '../../../../../core/models/dropdown-constants';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter,MAT_DATE_FORMATS,MAT_DATE_LOCALE} from '@angular/material/core';
export const MY_FORMATS = {
  parse: {
    dateInput: 'YYYY.MM.DD'
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};
@Component({
  selector: 'm-employee-holiday-agreement-history',
  templateUrl: './employee-holiday-agreement-history.component.html',
  styleUrls: ['./employee-holiday-agreement-history.component.scss'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ]
})
export class EmployeeHolidayAgreementHistoryComponent implements OnInit {

  socialFeeCreateOrupdate: string;
  employeeId: any;
  userData: any = {};
  getUserData: any = {};
  loxyDatasource: MatTableDataSource<any>;
  itemsPerPage: number = 10;
  itemsInPageList: Array<number> = [10, 50, 500];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  loader: boolean = false;
  productsArr: Array<any> = [];
  clientsArr: Array<any> = [];
  projectsArr: Array<any> = [];
  st4projectsArr: Array<any> = [];
  statusHistoryList: any = [];
  profileStatus: any = {};
  momentFormatDate = moment;
  employeeData: Employee = new Employee();
  userQRCode: string = btoa('test');
  updateSettingsID: any;
  resMessage: {
    success?: boolean;
    error?: boolean;
    message?: string;
  } = {
      success: false,
      error: false,
      message: ''
    };
  updateErrMsg: boolean;
  spinners = false;
  addSocialfee: FormGroup;
  modalRef: any;
  errorMsg: string = '';
  closeResult: any;
  datas: any = [];
  deleteLeaveModalRef: any;
  deleteLeaveData: any;
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  fromDate: any = '';
  toDate: any = '';
  minDate = new Date();
  isFromPastDate: boolean = false;
  isToPastDate: boolean = false;
  userInitials: string;
  momentDateFormat = moment;
  socialFeeId: any;
  socialFeeDataSource: any = [];
  emp_status: string = 'G';
  loxyHistoryDisplayColumnToShow: any = ['semesterval', 'social_fee', 'fromdate', 'todate', 'created_at', 'edit'];
  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  tarRowNoRecord: boolean = false;
  tarRowErr: boolean = false;
  changeView: any = {
    viewVal: "EmployeeInfo"
  };
  dropDownList: any = new DropdownConstants();
  semesterValList: Array<any> = [];

  private isSetProvisionAndCommission: any = {
    clientLoaded: false,
    projectLoaded: false,
    productLoaded: false,
    employeeLoaded: false
  };
  paramsSub: any;

  constructor(
    private _formBuilder: FormBuilder,
    private personalService: PersonalService,
    private sharedServices: SharedService,
    private _ref: ChangeDetectorRef,
    private modalService: NgbModal,
    private route: ActivatedRoute) {
    this.route.params.subscribe(params => this.employeeId = +params.id);
  }

  ngOnInit() {
    this.addSocialfee = this._formBuilder.group({
      fromdate: ['', [Validators.required]],
      todate: [''],
      semester: ['', [Validators.required]],
      socialfee: ['', [Validators.required]],
      employee_id: ['']
    });
    this.dropDownList.vacation_pay_list.forEach((val) => {
      let itemData = {};
      if (val === 'salary_12') {
        itemData = {
          id: 12,
          name: val
        }
      } 
      else if (val === 'salary_8') {
        itemData = {
            id: 8,
            name: val
        }
      }      
      else {
        itemData = {
          id: 0,
          name: val
        }
      }
      this.semesterValList.push(itemData);
    });
    this.getUserData = this.personalService.getRoleAndId();
    this.getUserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getUserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.getSocialFeeData();
    this.getEmployeeData();
  }

  private resetTableAlert() {
    setTimeout(() => {
      this.resMessage.success = false;
      this.resMessage.error = false;
      this._ref.detectChanges();
    }, 5000);
  }

  getEmployeeData() {
    this.personalService.getEmployee(this.employeeId).subscribe((res: any) => {
      if (res) {
        if (res.employeestatus.length > 0) {
          this.statusHistoryList = res.employeestatus;
          res.employeestatus = res.employeestatus[res.employeestatus.length - 1];
        } else {
          this.statusHistoryList = [];
          let todates = moment(new Date()).set({ hour: 0, minute: 0, second: 0 }).format('YYYY-MM-DDTHH:mm:ss');
          res.employeestatus = { fromdate: todates, todate: todates, Employeestatus: "G" };
        }
        this.profileStatus = res.employeestatus;
        this.employeeData = res;
        this.emp_status = res.emp_status;
        this.userInitials = this.employeeData.first_name.charAt(0).toUpperCase() + this.employeeData.last_name.charAt(0).toUpperCase();
        if (this.employeeData.Employee_id == this.userData.id && this.employeeData.img) {
          this.sharedServices.profileImgSub$.next(this.employeeData.img);
        }
        this.employeeData.provision = [];
        this.employeeData.compensation = [];
        if (!res.contact && !res.contact[0]) {
          this.employeeData.contact = new Contact();
        } else {
          this.employeeData.contact = res.contact[0];
        }
        if (res.bank && res.bank[0]) {
          this.employeeData.bank = res.bank[0];
        }
        let projectsArray = [];
        if (res.Projects && res.Projects.length > 0) {
          res.Projects.forEach((obj, ind) => {
            projectsArray.push({ Project_id: obj.Project_id, Project_name: obj.Project_name });
          });
        }
      }
    });
  }

  getSocialFeeData() {
    this.loader = true;
    if (this.employeeId) {
      this.personalService.getSocialFee(this.employeeId).subscribe((res: any) => {
        if (res && (res.length > 0)) {
          this.socialFeeDataSource = new MatTableDataSource(res);
          this.socialFeeDataSource.paginator = this.paginator;
          this.socialFeeDataSource.sort = this.sort;
          this.tRowNoRecord = false;
          this.tRowErr = false;
        }
        else {
          this.tRowNoRecord = true;
          this.tRowErr = false;
          this.loader = false;
        }
        this._ref.detectChanges();
        this.resetTableAlert();
        this.loader = false;
      }, err => {
        this.tarRowNoRecord = false;
        this.tarRowErr = true;
        this._ref.detectChanges();
        this.loader = true;
      });
    }
  }

  openModal(content, contentAccessId, toProduct?) {
    if (content === 'loxy_create') {
      this.updateErrMsg = false;
      this.socialFeeCreateOrupdate = 'create';
      this.socialFeeId = null;
      this.addSocialfee.reset();
      this.addSocialfee.controls['employee_id'].enable();
      this.addSocialfee.patchValue({
        employee_id: this.employeeData.first_name + ' ' + this.employeeData.last_name,
      });
      this.addSocialfee.controls['employee_id'].disable();
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    } else if (content == 'social_fee_update') {
      this.updateErrMsg = false;
      this.socialFeeCreateOrupdate = 'update';
      this.updateSettingsID = toProduct._id;
      this.addSocialfee.controls['employee_id'].enable();
      this.addSocialfee.patchValue({
        employee_id: this.employeeData.first_name + ' ' + this.employeeData.last_name,
        semester: toProduct.semester,
        socialfee: toProduct.socialfee,
        fromdate: toProduct.fromdate,
        todate: toProduct.todate,
      });
      this.addSocialfee.controls['employee_id'].disable();
      this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', size: 'lg', backdrop: "static" });
    }
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  createSocialFee() {
    let fromdate = moment(this.addSocialfee.value.fromdate).format('YYYY-MM-DD');
    let todate = moment(this.addSocialfee.value.todate).format('YYYY-MM-DD');
    if (this.addSocialfee.valid) {
      this.spinner.active = true;
      let form1 = this.addSocialfee.value;
      let socialFeeData: any = {
        "employee_id": this.employeeId,
        "semester": form1.semester,
        "socialfee": form1.socialfee,
        "fromdate": fromdate,
        "todate": todate
      }
      if (this.updateSettingsID !== '') {
        socialFeeData.settings_id = this.updateSettingsID;
      }
      if (this.socialFeeCreateOrupdate === 'create') {
        this.personalService.updateSocialFee(socialFeeData).subscribe(res => {
          if (res.message === 'Added Successfully') {
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          this.getSocialFeeData();
          this.modalRef.close();
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      } else if (this.socialFeeCreateOrupdate === 'update') {
        socialFeeData.employee_id = this.employeeId;
        socialFeeData.todate = this.addSocialfee.value.todate ? todate : ""
        this.personalService.updateSocialFee(socialFeeData).subscribe(res => {
          if (res.message === 'Social fees added successfully') {
            this.resMessage.success = true;
            this.resMessage.error = false;
          } else {
            this.spinner.active = false;
            this.resMessage.success = false;
            this.resMessage.error = true;
          }
          this.getSocialFeeData();
          this.modalRef.close();
          this._ref.detectChanges();
        }, error => {
          if (error.error.message) {
            this.updateErrMsg = true;
          }
        });
      }
      this.spinner.active = false;
    }
  }
}
