import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentSignNoticeComponent } from './document-sign-notice.component';

describe('DocumentSignNoticeComponent', () => {
  let component: DocumentSignNoticeComponent;
  let fixture: ComponentFixture<DocumentSignNoticeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentSignNoticeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentSignNoticeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
