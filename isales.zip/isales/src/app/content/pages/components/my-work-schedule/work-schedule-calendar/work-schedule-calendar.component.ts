import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { NgbTimeStruct, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Options } from 'fullcalendar';
import { ProjectService } from '../../project/_core/services/project.service';
import { TranslateService } from '@ngx-translate/core';
import { SystemSettingService } from '../../systemsetting/_core/service/system-setting.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { CalendarComponent } from 'ng-fullcalendar';
import { MatStepper } from '@angular/material';
import { PersonalService } from '../../personal/_core/services/personal.service';

@Component({
    selector: 'm-work-schedule-calendar',
    templateUrl: './work-schedule-calendar.component.html',
    styleUrls: ['./work-schedule-calendar.component.scss']
})

export class WorkScheduleCalendarComponent implements OnInit {
    spinners = false;
    week: any = ["", { day: "Mån", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Tis", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Ons", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Tor", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Fre", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Lör", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Sön", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } }];
    schedule: FormGroup;
    submitted = false;
    timings: any = ["Fran", "Till", "Lunch"];
    modalRef: any;
    errorMsg: string = '';
    closeResult: any;
    calendarOptions: Options;
    scheduleModalFormGroup: FormGroup;
    spinner: any = { active: false };
    time1: NgbTimeStruct;
    time2: NgbTimeStruct;
    time3: NgbTimeStruct;
    note: string = '';
    leaves: boolean = false;
    days: string = '';
    start_dates: any;
    end_dates: any;
    resMessage: {
        success?: boolean;
        error?: boolean;
        message?: string;
    } = {
            success: false,
            error: false,
            message: ''
        };
    calendarEventData: any = [];
    calendarData: any = [];
    eventData: any = [];
    time = { hour: '', minute: '' };
    ctrl = new FormControl('', (control: FormControl) => {
        const value = control.value;
        if (!value) {
            return null;
        }
    });
    datas: any = [];
    departmentId: any = '';
    timpepicker: any = [];

    constructor(private projectService: ProjectService,
        private _ref: ChangeDetectorRef,
        private fb: FormBuilder,
        private translate: TranslateService,
        private modalService: NgbModal,
        private systemSettingService: SystemSettingService,
        private sharedServices: SharedService,
        private personalService: PersonalService) {
        this.getuserData = this.projectService.getRoleAndId();
        this.getuserData.userId.subscribe(id => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.getuserData.role.subscribe(role => {
            if (role) {
                this.userData.role = role.toString();
            }
        });
    }
    companySchedule: FormGroup;
    cmpLeave: FormGroup;
    leaveDate: FormControl;
    leaveNotes: FormControl;
    getuserData: any;
    userData: any = {
        role: '',
        id: null
    };
    departmentArr: any = [];
    departmentSetToggle: boolean = false;

    ngOnInit() {
        this.getSchedule();
        this.calendarOptions = {
            editable: false,
            eventLimit: false,
            header: {
                left: 'prev,next',
                center: 'title',
                right: 'month,agendaWeek'
            },
            buttonText: {
                month: 'Månad',
                week: 'Vecka'
            },
            events: (start, end, timezone, callback) => {
                this.start_dates = start;
                this.end_dates = end;
                this.onCalendarInit(start, end);
                callback(this.calendarData);
            },
            locale: 'sv',
            droppable: false,
            eventRender: (v, el) => {
            },
            eventStartEditable: false,
            eventDurationEditable: false,
            eventOverlap: false,
            showNonCurrentDates: false
        };
        this.createFormControls();
        this.schedule = new FormGroup({
            start_time: this.start_time,
            end_time: this.end_time,
            notes: this.notes,
            leave: this.leave
        });
        this.cmpLeave = this.fb.group({
            'leaveNotes': ['', Validators.required],
            'leaveDate': ['', Validators.required]
        });
        this.personalService.getEmployee(this.userData.id).subscribe((empData: any) => {
            if (empData) {
                this.departmentId = empData.department_id;
                this.onCalendarInit(this.start_dates, this.end_dates);
            }
        });
    }
    @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;
    start_time: FormControl;
    end_time: FormControl;
    leave: FormControl;
    notes: FormControl;
    day: FormControl;
    html: any = '';
    eventRender(e) {
        if (e.event.leave == 0) {
            if (e.event.notes != '') {
                this.html = `<div class="fc-content"> 
                    <span class="fc-title">${e.event.title}</span>
                </div>
                <div class="fc-content"> 
                    <span class="fc-title">${e.event.notes}</span>
                </div>`;
            } else {
                this.html = `
                <div class="fc-content"> 
                    <span class="fc-title">${e.event.title}</span>
                </div>`;
            }
        } else {

            this.html = `<div class="fc-content"> 
                <span class="fc-title">${e.event.title}</span>
            </div>`;
        }
        e.element.html(this.html)
    }

    createFormControls() {
        this.start_time = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.end_time = new FormControl('', [
            Validators.required,
            (control: FormControl) => {
                const value = control.value;
                if (!value) {
                    return null;
                }
            }
        ]);
        this.notes = new FormControl('', [Validators.required]);
        this.leave = new FormControl('');
        this.day = new FormControl('');
        this.leaveDate = new FormControl('');
        this.leaveNotes = new FormControl('');
    }
    get f() { return this.schedule.controls; }

    onCalendarInit(start, end) {
        if (this.departmentId) {
            this.systemSettingService.DepartmentcalendarMonthly({ start_date: start.format('YYYY-MM-DD'), end_date: end.format('YYYY-MM-DD') }, this.departmentId).subscribe(res => {
                if (res) {
                    if (res.length > 0) {
                        this.calendarData = [];
                        res.forEach((item, index) => {
                            if (item.start_time != "00:00" && item.end_time != "00:00") {
                                item.backgroundColor = "#508250";
                                this.calendarData.push(item);
                            } else if (item.leave == 1) {
                                item.backgroundColor = "#de9943";
                                this.calendarData.push(item);
                            }
                        });
                        this.ucCalendar.renderEvents(this.calendarData);
                    }
                }
            });
        } else {
            this.calendarData = [];
            this.ucCalendar.renderEvents(this.calendarData);
        }
    }

    updateTimings(stepper: MatStepper, stayInStep: any) {
        if (this.departmentId) {
            this.submitted = true;
            if (this.schedule.invalid) {
                return;
            } else if (this.schedule.value.leave == true) {
                this.schedule.value.start_time.hour = 0;
                this.schedule.value.start_time.minute = 0;
                this.schedule.value.end_time.hour = 0;
                this.schedule.value.end_time.minute = 0;
            }
            let start_time_hour = this.schedule.value.start_time.hour == 0 ? "00" : this.schedule.value.start_time.hour;
            let start_time_minute = this.schedule.value.start_time.minute == 0 ? "00" : this.schedule.value.start_time.minute;
            let end_time_hour = this.schedule.value.end_time.hour == 0 ? "00" : this.schedule.value.end_time.hour;
            let end_time_minute = this.schedule.value.end_time.minute == 0 ? "00" : this.schedule.value.end_time.minute;
            let input_data = {
                date: this.days,
                start_time: start_time_hour + ":" + start_time_minute,
                end_time: end_time_hour + ":" + end_time_minute,
                lunch: "01:00",
                convertleave: this.schedule.value.leave == true ? 1 : 0,
                notes: this.schedule.value.notes
            };
            if (this.schedule.value.leave == true) {
                input_data = {
                    date: this.days,
                    start_time: start_time_hour + ":" + start_time_minute,
                    end_time: end_time_hour + ":" + end_time_minute,
                    lunch: "00:00",
                    convertleave: this.schedule.value.leave == true ? 1 : 0,
                    notes: this.schedule.value.notes
                };
            }
            let inputScheduleArr: any[] = [input_data];
            if (this.departmentId) {
                this.systemSettingService.DepartmentcalendarSchedule(inputScheduleArr, this.departmentId).subscribe(res => {
                    if (res) {
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                        this.resMessage.message = "Uppdateras framgångsrikt";
                        this.modalRef.close();
                        this.onCalendarInit(this.start_dates, this.end_dates);
                    } else {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                        this.resMessage.message = "Uppdateras inte framgångsrikt";
                    }
                    this._ref.detectChanges();
                    this.resetStepAlert(stepper, stayInStep);
                }, err => {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this._ref.detectChanges();
                    this.resetStepAlert(stepper, true);
                });
            }
        }
    }

    getSchedule() {
        this.projectService.getEmployee(this.userData.id).subscribe(datas => {
            this.departmentId = datas.department_id ? datas.department_id : 6;
            this.onCalendarInit(this.start_dates, this.end_dates);
        });
        this.sharedServices.getDepartmentList().subscribe((res: any) => {
            if (res) {
                this.departmentArr = res;
            }
        });
    }

    clearWeek() {
        this.week = ["", { day: "Mån", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Tis", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Ons", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Tor", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Fre", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Lör", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } },
        { day: "Sön", start_time: { hour: '', minute: '' }, end_time: { hour: '', minute: '' }, lunch: { hour: '', minute: '' }, status: { start_time: false, end_time: false, lunch: false } }];
    }

    private resetStepAlert(stepper, stayInStep) {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this.resMessage.message = '';
            this._ref.detectChanges();
        }, 5000);
    }

    changeMsg(check: any) {
        this.week.forEach(e => {
            if (e.day == check.day) {
                if (check.status.start_time == true && (check.start_time.hour != '' && check.start_time.minute != '')) {
                } else if (check.status.end_time == true && (check.end_time.hour != '' && check.end_time.minute != '')) {
                } else if (check.status.lunch == true && (check.lunch.hour != '' && check.lunch.minute != '')) {
                }
            }
        });
    }
    
    openModal(content, contentAccessId, toProduct?) {
        if (this.departmentId) {
            if (content === 'schedule') {
                this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-schedule-modal', size: 'lg', backdrop: "static" });
            } else if (content === 'checkEvent') {
                this.modalRef = this.modalService.open(contentAccessId, { windowClass: 'create-leave-modal', backdrop: "static" });
            }

            this.modalRef.result.then((result) => {
                this.closeResult = `Closed with: ${result}`;
            }, (reason) => {
                this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
            });
        } else {
            this.isDepartmentSelected();
        }
    }


    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }

    isDepartmentSelected() {
        if (this.departmentId) {
            this.departmentSetToggle = false;
        } else {
            this.departmentSetToggle = true;
        }
        this.onCalendarInit(this.start_dates, this.end_dates);
    }

}
