import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyWorkScheduleComponent } from './my-work-schedule.component';
import { WorkScheduleCalendarComponent } from './work-schedule-calendar/work-schedule-calendar.component';
import { Routes, RouterModule } from '@angular/router';
import { PerfectScrollbarConfigInterface, PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PartialsModule } from '../../../partials/partials.module';
import { NgbModule, NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { CoreModule } from '../../../../core/core.module';
import { MatDatepickerModule, MatInputModule, MatFormFieldModule, MatAutocompleteModule, MatCardModule, MatSelectModule, MatButtonModule, MatIconModule, MatNativeDateModule, MatCheckboxModule, MatMenuModule, MatTabsModule, MatTooltipModule, MatProgressBarModule, MatProgressSpinnerModule, MatTableModule, MatExpansionModule, MatSortModule, MatDividerModule, MatChipsModule, MatPaginatorModule, MatDialogModule, MatIconRegistry } from '@angular/material';
import { TranslateModule } from '@ngx-translate/core';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { PersonalService } from '../personal/_core/services/personal.service';
import { SubheaderService } from '../../../../core/services/layout/subheader.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
import { SystemSettingService } from '../systemsetting/_core/service/system-setting.service';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
	// suppressScrollX: true
};

const routes: Routes = [
	{
    path:'',
    component:MyWorkScheduleComponent,
    children:[
      {
        path:'',
        redirectTo:'calendar',
        pathMatch:'full'
      },
      {
        path:'calendar',
        component:WorkScheduleCalendarComponent        
      }
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
	PartialsModule,
	NgbModule,
	CoreModule,
	RouterModule.forChild(routes),
	FormsModule,
	ReactiveFormsModule,	
	PerfectScrollbarModule,	
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatTableModule,
	MatExpansionModule,
	MatSortModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	TranslateModule,	
	WidgetChartsModule,
	NgxPermissionsModule.forChild(),
  	WidgetChartsModule,
  	FullCalendarModule  
  ],
  declarations: [MyWorkScheduleComponent, WorkScheduleCalendarComponent],
  providers: [
    NgbAlertConfig, 
    {
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    MatIconRegistry,
    PersonalService,
    SubheaderService,
    SystemSettingService
  ]
})
export class MyWorkScheduleModule { }
