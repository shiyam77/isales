import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-my-work-schedule',
  templateUrl: './my-work-schedule.component.html',
  styleUrls: ['./my-work-schedule.component.scss']
})
export class MyWorkScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
