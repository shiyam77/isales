import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyWorkScheduleComponent } from './my-work-schedule.component';

describe('MyWorkScheduleComponent', () => {
  let component: MyWorkScheduleComponent;
  let fixture: ComponentFixture<MyWorkScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyWorkScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyWorkScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
