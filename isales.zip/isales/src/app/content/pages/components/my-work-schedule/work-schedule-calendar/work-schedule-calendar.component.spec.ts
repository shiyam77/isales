import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkScheduleCalendarComponent } from './work-schedule-calendar.component';

describe('WorkScheduleCalendarComponent', () => {
  let component: WorkScheduleCalendarComponent;
  let fixture: ComponentFixture<WorkScheduleCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkScheduleCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkScheduleCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
