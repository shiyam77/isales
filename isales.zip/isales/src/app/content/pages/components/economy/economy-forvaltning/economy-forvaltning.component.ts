import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';
import { ClientList } from '../../project/_core/models/client-list.model';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ProjectService } from '../../project/_core/services/project.service';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { EconomyService } from '../_core/services/economy.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
    selector: 'm-economy-forvaltning',
    templateUrl: './economy-forvaltning.component.html',
    styleUrls: ['./economy-forvaltning.component.scss']
})

export class EconomyForvaltningComponent implements OnInit {
    rValue: number;
    totbonusSalary: number = 0;
    totbonusSalary_soc: number = 0;

    isSticky(column: string): boolean {
        return column === 'employee' ? true : false;
    }
    consultant: number = 0;
    cost: number = 0;
    projClientArr: Array<any> = [];
    clientsArr: Array<any> = [];
    clientSelected: any;
    projectSelected: any;
    column: any = ['position', 'name', 'weight', 'symbol'];
    salaryReportList: any = [];
    revenue: any;
    salary: any;
    salary_sem: any;
    salary_soc: any;
    profit: any;
    hourly_revenue: any;
    salary_percent: any;
    profit_percent: any;
    total_hourly_salary: any;
    total_hours: any;
    worked_hours: any;
    modalFormGroup: FormGroup;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    monthList = [
        { label: "Januari", value: 1 },
        { label: "Februari", value: 2 },
        { label: "Mars", value: 3 },
        { label: "April", value: 4 },
        { label: "Maj", value: 5 },
        { label: "Juni", value: 6 },
        { label: "Juli", value: 7 },
        { label: "Augusti", value: 8 },
        { label: "September", value: 9 },
        { label: "Oktober", value: 10 },
        { label: "November", value: 11 },
        { label: "December", value: 12 },
    ];
    yearList = [new Date().getFullYear()];
    monthSelected = new Date().getMonth() + 1;
    yearSelected = new Date().getFullYear();
    dataSource: any;
    selectedClient: any;
    selectedProject: any;
    getuserData: any;
    userData: any = {
        role: '',
        id: null
    };
    loader: boolean = false;
    displayedColumns: string[] = ['project_name', 'actual_revenue', 'realsales_vat', 'revenue', 'revenue_vat', 'hours', 'actual_hourly_income_ex_vat', 'houry_income', 'salary', 'salary_soc', 'inksemsoc', 'salary_revenue_percent'];
    seconddisplayedColumns: string[] = ['firstcolumn', 'calculated', 'real'];
    employeedisplayedColumns: string[] = ['employee', 'totaltimmar', 'totalorder', 'snitt', 'provperproduckt', 'totalprovperpro', 'timlön', 'totaltprovision', 'totalhourlysalary', 'totallön'];
    allClientList: ClientList[] = [];
    xpandStatus: boolean = false;
    searchInput: string = '';
    emp_dataSource: any = [];
    deleteEmpModalRef: any;
    closeResult: string;
    clientTitle: string;
    delEmployeeData: any;
    updateClientID: any;
    projectsArr: Array<any> = [];
    clientProjectsArr: Array<any> = [];
    showAssignedMessage: boolean = false;
    resDeleteMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    resCreateMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    resUpdateeMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };
    spinner: SpinnerButtonOptions = {
        active: false,
        spinnerSize: 18,
        raised: true,
        buttonColor: 'primary',
        spinnerColor: 'accent',
        fullWidth: false
    };
    toggleColumns = [
        { arrIndex: 1, column: 'ID', checked: true, label: '_id' },
        { arrIndex: 2, column: 'KUND', checked: true, label: 'name' },
        { arrIndex: 3, column: 'STATUS', checked: true, label: 'status' },
        { arrIndex: 4, column: 'Åtgärder', checked: true, label: 'actions', onlyAdmin: true },
    ];
    itemsPerPage: number = 20;
    itemsInPageList: Array<number> = [20, 50, 100, 500];
    toggleEconomyProjectTable: boolean = true;
    toggleEconomyEmployeeTable: boolean = true;
    productsForProject: any[] = [];
    footerProductCountObj: any = {};
    isClientButton: boolean = false;
    totalOrdersForIndvProducts: any = {};
    totalProvPerProd: any = [];
    daysInMonth: any[] = [];
    footerDate: any = [];
    department: any = [
        "Förvaltning",
        "Rekrytering",
        "Kundtjänst",
        "Produktion",
        "Utvecklare",
        "Kiosken",
        "Backoffice"
    ];
    depDate: any[] = [];
    footerTotalTimar: any;
    
    constructor(
        private projectService: ProjectService,
        private economyService: EconomyService,
        private _formBuilder: FormBuilder,
        private _ref: ChangeDetectorRef,
        private sharedServices: SharedService,
        private router: Router,
        private activeRoute: ActivatedRoute) { }

    getMonthTitle(month) {
        let monthLabel = '';
        this.monthList.forEach((obj) => {
            if (obj.value == month) {
                monthLabel = obj.label;
            }
        });
        return monthLabel;
    }

    tottRowErr: boolean = false;
    tottRowNoRecord: boolean = false;
    prodtottRowErr: boolean = false;
    prodtottRowNoRecord: boolean = false;

    ngOnInit() {
        this.yearList = [];
        for (let y = 0; (y <= 5); y++) {
            this.yearList.push((2020 + y));
        }
        if (new Date().getMonth() > 0) {
            this.monthSelected = new Date().getMonth();
        } else {
            this.monthSelected = 1;
        }

        this.modalFormGroup = this._formBuilder.group({
            client_name: ['', Validators.required],
            client_stat: [false],
        });

        this.getuserData = this.projectService.getRoleAndId();
        this.getuserData.role.subscribe(role => {
            this.userData.role = role.toString();
        });
        this.getuserData.userId.subscribe(id => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.getProjectList();
        this.getClientList();
        this.activeRoute.queryParams.subscribe((params) => {
            this.yearSelected = this.converToInteger(params['sa']) ? this.converToInteger(params.sa) : (new Date().getFullYear());
            this.monthSelected = this.converToInteger(params['ms']) ? this.converToInteger(params.ms) : (new Date().getMonth() + 1);
            this.loadEconomySalaryPeriodReport();
        });
    }

    updateActualSalary(evt, objData) {
        if (evt.target.value == '') {
            this.rValue = 0;
        } else {
            this.rValue = evt.target.value;
        }
        let revenueData: any = {};
        revenueData.ActualSalary = objData.actual_salary;
        revenueData.ActualBonus = objData.actual_bonus;
        revenueData.EmployeeId = objData.Employee_id;
        revenueData.Year = this.yearSelected;
        revenueData.Month = this.monthSelected;
        this.economyService.updateEconomyManagement(revenueData).subscribe(res => {
            if (res) {
                let reqFilterOptions = {
                    month: this.monthSelected,
                    year: this.yearSelected,
                };
                let resultarr = [];
                this.economyService.getAllEconomyManagement(reqFilterOptions).subscribe(res => {
                    if (res) {
                        this.salaryReportList = res;
                        let ms_Data = this.salaryReportList[0].monthly_salary_summary_data[0];
                        this.hourly_revenue = ms_Data.hourly_cut;
                        this.salary = ms_Data.total_salary;
                        this.salary_sem = ms_Data.salary_sem;
                        this.salary_soc = ms_Data.salary_soc;
                        this.worked_hours = ms_Data.worked_hours;
                        this.total_hourly_salary = ms_Data.total_hourly_salary;
                        this.total_hours = ms_Data.total_hours;

                        res.forEach((obj) => {
                            this.footerProductCountObj = {};
                            obj.monthly_salary_data.forEach((data) => {

                                data.monthly_attedance_data.forEach((msdata) => {
                                    let datasourceObj: any = {};
                                    datasourceObj = msdata;
                                    datasourceObj.monthly_sales_data = msdata.monthly_attedance_data;
                                    if (!datasourceObj.actual_salary || (datasourceObj.actual_salary <= 0)) {
                                        datasourceObj.actual_salary = msdata.fixed_salary + msdata.total_hourly_salary;
                                    }

                                    if ((!datasourceObj.actual_bonus || (datasourceObj.actual_bonus <= 0)) && msdata.bonus) {
                                        datasourceObj.actual_bonus = msdata.bonus;
                                    }
                                    datasourceObj.footerProductCountObj = [];
                                    resultarr.push(datasourceObj);
                                });
                            });

                        });
                        this.dataSource = new MatTableDataSource(resultarr);
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;
                        this.dataSource.sortingDataAccessor = (item, property) => {
                            let sortString = property.split('.').reduce((o, i) => o[i], item);
                            if (typeof sortString === 'string') {
                                sortString = sortString.toLowerCase();
                            }
                            return sortString;
                        }
                        this.emp_dataSource = new MatTableDataSource(resultarr);
                        this.loader = false;
                        this.emp_dataSource = new MatTableDataSource(resultarr);
                    } else {
                        this.dataSource = new MatTableDataSource([]);
                        this.dataSource.paginator = this.paginator;
                        this.dataSource.sort = this.sort;
                        this.dataSource.sortingDataAccessor = (item, property) => {
                            let sortString = property.split('.').reduce((o, i) => o[i], item);
                            if (typeof sortString === 'string') {
                                sortString = sortString.toLowerCase();
                            }
                            return sortString;
                        }
                    }
                    this._ref.detectChanges();
                }, err => {
                });
            } else {

            }
            this._ref.detectChanges();
        });
    }

    getTime(time) {
        var str = time;
        var str_array = str.split(':');

        for (var i = 0; i < str_array.length; i++) {
            str_array[i] = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
        }
        var hour = parseInt(str_array[0]);
        var minute = parseInt(str_array[1]);
        var second = parseInt(str_array[2]);
        var tottime = hour + (minute / 60) + (second / 3600);
        return tottime;
    }
    monthly_salary_data: any;

    loadEconomySalaryPeriodReport() {
        this.prodtottRowErr = false;
        this.prodtottRowNoRecord = false;
        if (this.monthSelected && this.yearSelected) {

            let reqFilterOptions = {
                month: this.monthSelected,
                year: this.yearSelected,
            };
            let resultarr = [];
            this.loader = true;
            this.economyService.getAllEconomyManagement(reqFilterOptions).subscribe(res => {
                if (res) {
                    this.salaryReportList = res;
                    let ms_Data = this.salaryReportList[0].monthly_salary_summary_data[0];
                    this.hourly_revenue = ms_Data.hourly_cut;
                    this.salary = ms_Data.total_salary;
                    this.salary_sem = ms_Data.salary_sem;
                    this.salary_soc = ms_Data.salary_soc;
                    this.worked_hours = ms_Data.worked_hours;
                    this.total_hourly_salary = ms_Data.total_hourly_salary;
                    this.total_hours = ms_Data.total_hours;
                    var dayscount = new Date(this.yearSelected, this.monthSelected, 0).getDate();
                    this.employeedisplayedColumns = [];
                    this.employeedisplayedColumns.push('employee');
                    this.depDate = [];
                    for (let i = 0; i < dayscount; i++) {
                        let dt = i + 1;
                        this.employeedisplayedColumns.push(dt + "  " + this.getDay(dt));
                        this.daysInMonth.push(dt + "  " + this.getDay(dt));
                        let month = '' + this.monthSelected;
                        let day = '' + new Date(this.yearSelected, this.monthSelected - 1, dt).getDate();
                        let year = this.yearSelected;
                        if (month.length < 2) month = '0' + month;
                        if (day.length < 2) day = '0' + day;
                        this.depDate.push([year, month, day].join('-'));
                    }
                    this.employeedisplayedColumns.push('Total timmar', 'Timlön', 'Total timlön', 'Avvikande', 'Bonus', 'Lön', 'Tot lön', 'Total lön ink sem', 'tot lön ink alt');
                    res.forEach((obj) => {
                        this.footerTotalTimar = obj.monthly_summary_department_data;
                        this.department = [];
                        obj.monthly_summary_department_data.forEach((msda) => {
                            this.department.push(msda.department);
                        });
                        obj.monthly_salary_data.forEach((sdata) => {
                            let datasourcesObj: any = {};
                            datasourcesObj = sdata;
                            datasourcesObj.salary_data = [];
                            datasourcesObj.monthly_attedance_data.forEach((msdata) => {
                                let datasourceObj: any = {};
                                datasourceObj = msdata;
                                datasourceObj.monthly_sales_data = msdata.monthly_attedance_data;
                                if (!datasourceObj.actual_salary || (datasourceObj.actual_salary <= 0)) {
                                    datasourceObj.actual_salary = msdata.fixed_salary + msdata.total_hourly_salary;
                                }
                                if ((!datasourceObj.actual_bonus || (datasourceObj.actual_bonus <= 0)) && msdata.bonus) {
                                    datasourceObj.actual_bonus = msdata.bonus;
                                }
                                datasourcesObj.footerProductCountObj = [];
                                resultarr.push(datasourceObj);
                            });


                        });
                        this.footerDate = [];
                        this.depDate.forEach((item, key) => {
                            let dateobj = [];
                            let val = [];
                            let valdep = [];
                            this.department.forEach(dep => {
                                val.push({ department: dep, total_hours: "00:00:00" });
                            });
                            obj.daily_department_summary_data.forEach(element => {
                                if (item == element.working_date) {
                                    let valInd = val.findIndex(v => v.department == element.department);
                                    if (valInd > -1) {
                                        val[valInd].total_hours = element.total_hours;
                                    }
                                    valdep.push(element.department);
                                }
                            });
                            this.footerDate.push(val);
                        });
                    });
                    this.dataSource = new MatTableDataSource(resultarr);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;
                    this.dataSource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split('.').reduce((o, i) => o[i], item);
                        if (typeof sortString === 'string') {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    };
                    this.emp_dataSource = new MatTableDataSource(resultarr);
                    this.loader = false;
                    this.emp_dataSource = new MatTableDataSource(resultarr);
                } else {
                    this.dataSource = new MatTableDataSource([]);
                    this.dataSource.paginator = this.paginator;
                    this.dataSource.sort = this.sort;
                    this.dataSource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split('.').reduce((o, i) => o[i], item);
                        if (typeof sortString === 'string') {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    }
                    this.prodtottRowNoRecord = true;
                    this.loader = false;
                }
                this._ref.detectChanges();
            }, err => {
                this.prodtottRowErr = true;
                this.loader = false;
            });
        }
    }

    getMonthSelected() {
        this.dataSource = [];
        this.emp_dataSource = [];
        this.router.navigate(['/economy/management/list'], { queryParams: { ms: this.monthSelected, sa: this.yearSelected } });
    }

    getDay(i) {
        var daynumber = new Date(this.yearSelected, this.monthSelected - 1, i).getDay();
        switch (daynumber) {
            case 0:
                return 'Sön';
            case 1:
                return 'Mån';
            case 2:
                return 'Tis';
            case 3:
                return 'Ons';
            case 4:
                return 'Tor';
            case 5:
                return 'Fre';
            case 6:
                return 'Lör';
            default:
                return 'default';
        }
    }

    slideToggleChange(e) {
    }

    getClientList() {
        this.sharedServices.getClientList().subscribe((res: any) => {
            if (res) {
                this.clientsArr = res;
            }
        });
    }

    getProjectList() {
        this.sharedServices.getProjectList().subscribe((res: any) => {
            if (res) {
                this.projectsArr = res;
            }
        });
    }

    clearkund() {
        this.clientSelected = '';
        this.projectSelected = '';
    }

    getSalaryDataByClientAndProject(clientId?: any, project?: any) {
        this.toggleColumns = [
            { arrIndex: 1, column: 'ID', checked: true, label: '_id' },
            { arrIndex: 2, column: 'KUND', checked: true, label: 'name' },
            { arrIndex: 3, column: 'STATUS', checked: true, label: 'status' },
            { arrIndex: 4, column: 'Åtgärder', checked: true, label: 'actions', onlyAdmin: true },
        ];
    }

    converToNumber(val) {
        if (typeof val != 'number') {
            return parseFloat(val);
        } else {
            return val;
        }
    }

    converToInteger(val) {
        if (typeof val != 'number') {
            return parseInt(val);
        } else {
            return null;
        }
    }

}