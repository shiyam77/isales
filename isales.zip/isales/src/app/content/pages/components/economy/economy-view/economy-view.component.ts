import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatSelect } from '@angular/material';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { EconomyService } from '../_core/services/economy.service';
import { EconomyOverview } from '../_core/models/economy-overview.model';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, ReplaySubject } from 'rxjs';
type AOA = any[][];

@Component({
  selector: 'm-economy-view',
  templateUrl: './economy-view.component.html',
  styleUrls: ['./economy-view.component.scss']
})

export class EconomyViewComponent implements OnInit {

  tRowErr: boolean = false;
  tRowNoRecord: boolean = false;
  projClientArr: Array<any> = [];
  clientsArr: Array<any> = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  arrToPrint: AOA = [];
  monthList = [
    { label: "Januari", value: 1 },
    { label: "Februari", value: 2 },
    { label: "Mars", value: 3 },
    { label: "April", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Juni", value: 6 },
    { label: "Juli", value: 7 },
    { label: "Augusti", value: 8 },
    { label: "September", value: 9 },
    { label: "Oktober", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  clientSelected: any;
  projectSelected: any;
  dataSource: any;
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  displayedColumns: string[] = ['name', 'worked_hours', 'revenue', 'revenue_hour', 'expense', 'expense_hour', 'profit', 'cost'];
  overviewList: EconomyOverview[] = [];
  xpandStatus: boolean = false;
  xpandStatuss: boolean = false;
  bonusxpandStatus: boolean = false;
  searchInput: string = '';
  projectsArr: Array<any> = [];
  clientProjectsArr: Array<any> = [];
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  toggleColumns = [
    { arrIndex: 1, column: 'Säljare', checked: true, label: 'name' },
    { arrIndex: 2, column: 'Timmar', checked: true, label: 'worked_hours' },
    { arrIndex: 3, column: 'Intäkt', checked: true, label: 'revenue' },
    { arrIndex: 4, column: 'Intäkt/Timmar', checked: true, label: 'revenue_hour' },
    { arrIndex: 5, column: 'Förbruknings', checked: true, label: 'expense' },
    { arrIndex: 6, column: 'Förbruknings/Timmar', checked: true, label: 'expense_hour' },
    { arrIndex: 7, column: '% Kostnad', checked: true, label: 'profit' },
    { arrIndex: 8, column: '% Vinst', checked: true, label: 'cost' }
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  multiColFilter = {
    name: '',
    worked_hours: '',
    revenue: '',
    revenue_hour: '',
    expense: '',
    expense_hour: '',
    cost: '',
    profit: '',
  };
  btRowErr: boolean = false;
  btRowNoRecord: boolean = false;
  @ViewChild('projectSearchSelect') projectSearchSelect: MatSelect;
  protected _onProjSearchDestroy = new Subject<void>();
  projectFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
  protected _onClientSearchDestroy = new Subject<void>();
  clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  projectFilter: string = '';
  clientFilter: string = '';

  constructor(
    private economyService: EconomyService,
    private sharedServices: SharedService,
    private activeRoute: ActivatedRoute,
    private router: Router) { }

  getMonthTitle(month) {
    let monthLabel = '';
    this.monthList.forEach((obj) => {
      if (obj.value == month) {
        monthLabel = obj.label;
      }
    });
    return monthLabel;
  }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= 5); y++) {
      this.yearList.push(2020 + y);
    }
    if (new Date().getMonth() > 0) {
      this.monthSelected = new Date().getMonth();
    } else {
      this.monthSelected = 1;
    }
    this.dataSource = new MatTableDataSource();
    this.getuserData = this.economyService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.getProjectList();
    this.getClientList();
    this.activeRoute.queryParams.subscribe((params) => {
      this.yearSelected = this.converToInteger(params['sa']) ? this.converToInteger(params.sa) : (new Date().getFullYear());
      this.monthSelected = this.converToInteger(params['ms']) ? this.converToInteger(params.ms) : (new Date().getMonth() + 1);
      this.loadEconomyOverviewList();
    });
  }

  getClientList() {
    this.sharedServices.getClientList().subscribe((res: any) => {
      if (res) {
        this.clientsArr = res;
        this.clientsArr.sort(function (a, b) {
          if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
          if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
          return 0;
        });
        this._clientListFilter();
      }
    });
  }

  getProjectList() {
    this.sharedServices.getProjectList().subscribe((res: any) => {
      if (res) {
        this.projectsArr = res;
        this.projectsArr.sort(function (a, b) {
          if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
          if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
          return 0;
        });
      }
    });
  }

  getProjectListByClient(clientId) {
    this.projectSelected = null;
    this.clientProjectsArr = [];
    this.projectsArr.forEach((obj) => {
      if (obj.Client_id === clientId) {
        this.clientProjectsArr.push(obj);
      }
    });
    this.clientProjectsArr.sort(function (a, b) {
      if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
      if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
      return 0;
    });
    this._projectListFilter();
  }

  getMonthSelected(clientSel?: any, projectSel?: any) {
    this.router.navigate(['/economy/overview/list'], { queryParams: { ms: this.monthSelected, sa: this.yearSelected } });
  }

  loadEconomyOverviewList() {
    this.tRowNoRecord = false;
    this.tRowErr = false;
    if (this.monthSelected && this.yearSelected) {
      this.loader = true;
      let reqFilterOptions = {
        month: this.monthSelected,
        year: this.yearSelected,
        Client_id: this.clientSelected,
        Project_id: this.projectSelected
      };
      if (!this.clientSelected) {
        reqFilterOptions.Client_id = null;
      }
      if (!this.projectSelected) {
        reqFilterOptions.Project_id = null;
      }
      this.economyService.getEconomyOverviewList(reqFilterOptions).subscribe(res => {
        if (res) {
          this.overviewList = res;
          this.dataSource = new MatTableDataSource(res);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            let sortString = property.split('.').reduce((o, i) => o[i], item);
            if (typeof sortString === 'string') {
              sortString = sortString.toLowerCase();
            }
            return sortString;
          }
          this.loader = false;
        } else {
          this.dataSource = new MatTableDataSource([]);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            let sortString = property.split('.').reduce((o, i) => o[i], item);
            if (typeof sortString === 'string') {
              sortString = sortString.toLowerCase();
            }
            return sortString;
          }
          this.tRowNoRecord = true;
          this.loader = false;
        }
      }, err => {
        this.tRowErr = true;
        this.loader = false;
      });
    }
    this.showHideCols();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.name + item.sales_Exvat + item.realsales_vat + item.turnover_exvat + item.hours + item.actualincomex_vat + item.hourlytax_exvat;
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private setExcelHeaders() {
    this.arrToPrint = [];
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      if (this.displayedColumns.indexOf(obj.label) > -1) {
        this.arrToPrint[0].push(obj.column);
      }
    });
  }

  private setExcelValues() {
    if (this.dataSource && this.dataSource.data.length) {
      this.dataSource.filteredData.forEach((val: any) => {
        let newLine = [];
        this.displayedColumns.forEach((key, ind) => {
          let str = key.split('.').reduce((o, i) => { if (o && o[i]) { return o[i] } }, val);
          newLine.push(str);
        });
        this.arrToPrint.push(newLine);
      });
    }
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.overview-search .mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.overview-search .mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.overview-search .mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols() {
    this.displayedColumns = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        this.displayedColumns.push(obj.label);
      }
    });
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      /* generate worksheet */
      this.setExcelHeaders();
      this.setExcelValues();
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Ekonomisk_översikt_' + this.monthSelected + '_' + this.yearSelected + '_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
    }
  }

  getDataSourceByClientProject(isClientProjectSelected?: boolean) {
    this.bonusxpandStatus = false;
    this.xpandStatus = isClientProjectSelected;
    if (!isClientProjectSelected) {
      this.clientSelected = null;
      this.projectSelected = null;
      this.loadEconomyOverviewList();
    }
  }

  applyColumnFilter() {
    this.dataSource.filterPredicate = this.columnwiseFilter();
    this.dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(filterString).forEach((key) => {
        let keyNodeValue = key.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
        if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (typeof keyNodeValue != 'string') {
            itemString = keyNodeValue.toString();
          } else {
            itemString = keyNodeValue;
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!keyNodeValue || (keyNodeValue <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  converToInteger(val) {
    if (typeof val != 'number') {
      return parseInt(val);
    } else {
      return null;
    }
  }

  _projectListFilter(projectName?: string): any[] {
    if (this.clientProjectsArr.length <= 0) {
      return;
    }
    if (projectName && (typeof projectName == 'string') && projectName.trim() != '') {
      const depfilterValue = projectName.toLowerCase();
      this.projectFilteredOptions.next(
        this.clientProjectsArr.filter(dep => (dep.Project_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.projectFilteredOptions.next(this.clientProjectsArr.slice());
      return;
    }
  }

  _clientListFilter(clientName?: string): any[] {
    if (this.clientsArr.length <= 0) {
      return;
    }
    if (clientName && (typeof clientName == 'string') && clientName.trim() != '') {
      const depfilterValue = clientName.toLowerCase();
      this.clientFilteredOptions.next(
        this.clientsArr.filter(dep => (dep.name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.clientFilteredOptions.next(this.clientsArr.slice());
      return;
    }
  }

}