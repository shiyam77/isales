import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EconomyDailyturnoverComponent } from './economy-dailyturnover.component';

describe('EconomyDailyturnoverComponent', () => {
  let component: EconomyDailyturnoverComponent;
  let fixture: ComponentFixture<EconomyDailyturnoverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EconomyDailyturnoverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EconomyDailyturnoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
