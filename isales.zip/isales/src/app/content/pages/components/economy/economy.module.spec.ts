import { EconomyModule } from './economy.module';

describe('EconomyModule', () => {
  let economyModule: EconomyModule;

  beforeEach(() => {
    economyModule = new EconomyModule();
  });

  it('should create an instance', () => {
    expect(economyModule).toBeTruthy();
  });
});
