import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EconomyComponent } from './economy.component';
import { RouterModule, Routes } from '@angular/router';
import {
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatSliderModule,
	MatListModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatSlideToggleModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatSidenavModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatSnackBarModule,
	MatGridListModule,
	MatTableModule,
	MatExpansionModule,
	MatToolbarModule,
	MatSortModule,
	MatDividerModule,
	MatStepperModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	MatRadioModule,
  MatPaginatorIntl,	
} from '@angular/material';
import { PartialsModule } from '../../../partials/partials.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CodePreviewModule } from '../../../partials/content/general/code-preview/code-preview.module';
import { CoreModule } from '../../../../core/core.module';
import { MaterialPreviewModule } from '../../../partials/content/general/material-preview/material-preivew.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { TranslateModule } from '@ngx-translate/core';
import { QRCodeModule } from 'angularx-qrcode';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { PersonalService } from '../personal/_core/services/personal.service';
import { EconomyViewComponent } from './economy-view/economy-view.component';
import { EconomyLonComponent } from './economy-lon/economy-lon.component';
import { EconomyService } from './_core/services/economy.service';
import { EconomyDailyturnoverComponent } from './economy-dailyturnover/economy-dailyturnover.component';
import { NgxPermissionsModule, NgxPermissionsGuard } from 'ngx-permissions';
import { EconomyForvaltningComponent } from './economy-forvaltning/economy-forvaltning.component';
import { VirtualScrollerModule } from 'ngx-virtual-scroller';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { EconomyBonusComponent } from './economy-bonus/economy-bonus.component';

const routes: Routes = [
	{
    path: '',
		canActivateChild:[NgxPermissionsGuard],
		children: [
      {
        path:'wages/list',
        component:EconomyLonComponent,
        data:{
					permissions:{
            only:["economySalaryTable"],
						redirectTo:'/attendance/overview'
					}
				}
      },
      {
        path:'overview/list',
        component:EconomyViewComponent,
        data:{
					permissions:{
            only:["economyOverviewList"],
						redirectTo:'/attendance/overview'
					}
				}
      },
      {
        path:'bonus/list',
        component:EconomyBonusComponent,
        data:{
					permissions:{
            only:["economyBonusList"],
						redirectTo:'/attendance/overview'
					}
				}
      },
      {
        path:'management/list',
        component:EconomyForvaltningComponent,
        data:{
					permissions:{
            only:['economyMangementList'],
						redirectTo:'/economy/overview/list'
					}
				}
      }
	  ],
	}
];

const swedishRangeLabel = (page: number, pageSize: number, length: number) => {
  if (length == 0 || pageSize == 0) { return `0 av ${length}`; }
  length = Math.max(length, 0);
  const startIndex = page * pageSize;
  // If the start index exceeds the list length, do not try and fix the end index to the end.
  const endIndex = startIndex < length ?
      Math.min(startIndex + pageSize, length) :
      startIndex + pageSize;
  return `${startIndex + 1} - ${endIndex} av ${length}`;
}


function getSwedishPaginatorIntl() {
  const paginatorIntl = new MatPaginatorIntl();
  paginatorIntl.itemsPerPageLabel = 'Objekt per sida:';
  // paginatorIntl.nextPageLabel = 'Volgende pagina';
  // paginatorIntl.previousPageLabel = 'Vorige pagina';
  paginatorIntl.getRangeLabel = swedishRangeLabel;
  return paginatorIntl;
}

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    CommonModule,
    PartialsModule,
    NgbModule,
    CodePreviewModule,
    CoreModule,
    MaterialPreviewModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,    
    PerfectScrollbarModule,	
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatSliderModule,
    MatListModule,
    MatCardModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    MatMenuModule,
    MatTabsModule,
    MatTooltipModule,
    MatSidenavModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatGridListModule,
    MatTableModule,
    MatExpansionModule,
    MatToolbarModule,
    MatSortModule,
    MatDividerModule,
    MatStepperModule,
    MatChipsModule,
    MatPaginatorModule,
    MatDialogModule,
    MatRadioModule,
    TranslateModule,
    QRCodeModule,
    WidgetChartsModule,
    NgxPermissionsModule.forChild(),
    VirtualScrollerModule,
    NgxMatSelectSearchModule
  ],
  declarations: [EconomyComponent, EconomyViewComponent, EconomyLonComponent, EconomyDailyturnoverComponent,EconomyForvaltningComponent, EconomyBonusComponent],
  providers:[
    PersonalService,
    EconomyService,
    { provide: MatPaginatorIntl, useValue: getSwedishPaginatorIntl() }
  ]
})
export class EconomyModule { }
