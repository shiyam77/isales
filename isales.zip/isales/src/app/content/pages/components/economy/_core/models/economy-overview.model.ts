export class EconomyOverview {
    Employee?:any;
    Client_id:any;
    name:string;
    Project_id:any;    
}
