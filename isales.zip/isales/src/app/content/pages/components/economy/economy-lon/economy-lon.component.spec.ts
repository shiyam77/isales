import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EconomyLonComponent } from './economy-lon.component';

describe('EconomyLonComponent', () => {
  let component: EconomyLonComponent;
  let fixture: ComponentFixture<EconomyLonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EconomyLonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EconomyLonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
