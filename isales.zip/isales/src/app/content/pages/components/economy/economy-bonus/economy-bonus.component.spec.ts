import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EconomyBonusComponent } from './economy-bonus.component';

describe('EconomyBonusComponent', () => {
  let component: EconomyBonusComponent;
  let fixture: ComponentFixture<EconomyBonusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EconomyBonusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EconomyBonusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
