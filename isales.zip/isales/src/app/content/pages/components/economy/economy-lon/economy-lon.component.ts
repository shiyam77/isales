import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatSelect } from '@angular/material';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { ProjectService } from '../../project/_core/services/project.service';
import { EconomyService } from '../_core/services/economy.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { Observable, ReplaySubject, Subject } from 'rxjs';

@Component({
  selector: 'm-economy-lon',
  templateUrl: './economy-lon.component.html',
  styleUrls: ['./economy-lon.component.scss']
})

export class EconomyLonComponent implements OnInit {
  rValue: number;
  totbonusSalary: number = 0;
  totbonusSalary_soc: number = 0;
  isSticky(column: string): boolean {
    return column === 'employee' ? true : false;
  }
  projClientArr: Array<any> = [];
  clientsArr: Array<any> = [];
  clientSelected: any;
  projectSelected: any;
  salaryReportList: any = [];
  revenue: any;
  salary: any;
  salary_sem: any;
  salary_soc: any;
  profit: any;
  hourly_revenue: any;
  salary_percent: any;
  profit_percent: any;
  bonusxpandStatus: boolean = false;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  monthList = [
    { label: "Januari", value: 1 },
    { label: "Februari", value: 2 },
    { label: "Mars", value: 3 },
    { label: "April", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Juni", value: 6 },
    { label: "Juli", value: 7 },
    { label: "Augusti", value: 8 },
    { label: "September", value: 9 },
    { label: "Oktober", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  setMonthYear: any = {
    month: null,
    year: null
  };
  dataSource: any;
  selectedClient: any;
  selectedProject: any;
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  displayedColumns: string[] = ['project_name', 'actual_revenue', 'realsales_vat', 'revenue', 'revenue_vat', 'hours', 'actual_hourly_income_ex_vat', 'houry_income', 'salary', 'salary_soc', 'inksemsoc', 'salary_revenue_percent'];
  seconddisplayedColumns: string[] = ['firstcolumn', 'calculated', 'real'];
  employeedisplayedColumns: string[] = ['employee', 'totaltimmar', 'totalorder', 'snitt', 'provperproduckt', 'totalprovperpro', 'timlön', 'totaltprovision', 'totalhourlysalary', 'totallön'];
  xpandStatus: boolean = false;
  searchInput: string = '';
  emp_dataSource: any = [];
  projectsArr: Array<any> = [];
  clientProjectsArr: Array<any> = [];
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  toggleColumns = [
    { arrIndex: 1, column: 'ID', checked: true, label: '_id' },
    { arrIndex: 2, column: 'KUND', checked: true, label: 'name' },
    { arrIndex: 3, column: 'STATUS', checked: true, label: 'status' },
    { arrIndex: 4, column: 'ATGARDER', checked: true, label: 'actions', onlyAdmin: true },
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  toggleEconomyProjectTable: boolean = true;
  toggleEconomyEmployeeTable: boolean = false;
  productsForProject: any[] = [];
  footerProductCountObj: any = {};
  isClientButton: boolean = false;
  totalOrdersForIndvProducts: any = {};
  totalProvPerProd: any = [];
  daysInMonth: any[] = [];
  bonusArr: Array<any> = [];
  bonusLoader: boolean = false;
  filteredOptions: Observable<string[]>;
  costAmount: any = '';
  consulationAmount: any = '';
  costPercent: any = '';
  consultPercent: any = '';
  multiColFilter = {
    name: '',
    fromdate: '',
    todate: '',
    start_time: '',
    end_time: '',
    created_time: '',
    note: '',
    status: '',
    approval_note: ''
  };
  arrToPrint: any[] = [];
  @ViewChild('projectSearchSelect') projectSearchSelect: MatSelect;
  protected _onProjSearchDestroy = new Subject<void>();
  projectFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  @ViewChild('clientSearchSelect') clientSearchSelect: MatSelect;
  protected _onClientSearchDestroy = new Subject<void>();
  clientFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  projectFilter: string = '';
  clientFilter: string = '';

  constructor(
    private projectService: ProjectService,
    private economyService: EconomyService,
    private _ref: ChangeDetectorRef,
    private sharedServices: SharedService) { }

  getMonthTitle(month) {
    let monthLabel = '';
    this.monthList.forEach((obj) => {
      if (obj.value == month) {
        monthLabel = obj.label;
      }
    });
    return monthLabel;
  }

  tottRowErr: boolean = false;
  tottRowNoRecord: boolean = false;
  prodtottRowErr: boolean = false;
  prodtottRowNoRecord: boolean = false;

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= 5); y++) {
      this.yearList.push(2020 + y);
    }
    if (new Date().getMonth() > 0) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.getProjectList();
    this.getClientList();
    this.loadEconomySalaryPeriodReport();
  }

  updateActualRevenue(evt, objData) {
    if (evt.target.value == '') {
      this.rValue = 0;
    } else {
      this.rValue = evt.target.value;
    }
    let revenueData: any = {};
    revenueData.Revenue = this.rValue;
    revenueData.ProjectId = objData.project_id;
    revenueData.Year = this.yearSelected;
    revenueData.Month = this.monthSelected;
    this.economyService.updateActualRevenue(revenueData).subscribe(res => {
      if (res) {
        this.loadEconomySalaryPeriodReport();
      } 
      this._ref.detectChanges();
    });
  }

  getProductCountArr(val, provData, rejVal) {
    let b: any[] = [];
    if (provData) {
      if (!val || val.length == 0) {
        provData.forEach((pdata) => {
          b.push({
            sales_count: '',
            reject_count: ''
          });
        });
      } else {
        provData.forEach((pdata) => {
          let noCount = true;
          if (!rejVal || rejVal.length == 0) {
            val.forEach((vdata) => {
              if (vdata.product_id == pdata.product_id) {
                b.push({
                  sales_count: vdata.sales_count,
                  reject_count: ''
                });
                noCount = false;
              }
            });
          } else {
            val.forEach((vdata) => {
              let productMatch = false;
              let rejectCount = '';
              if ((vdata.product_id == pdata.product_id)) {
                rejVal.forEach((rData) => {
                  if ((vdata.product_id == rData.product_id) && rData.sales_count) {
                    rejectCount = rData.sales_count;
                  }
                  productMatch = true;
                });
              }
              if (productMatch) {
                b.push({
                  sales_count: vdata.sales_count,
                  reject_count: rejectCount
                });
                noCount = false;
              }
            });
          }
          if (noCount) {
            b.push({
              sales_count: '',
              reject_count: ''
            });
          }
        });
        return b;
      }
    }
    return b;
  }

  getTotalProv() {
    let b: any[] = [];
    if (this.salaryReportList[0] && this.salaryReportList[0].monthly_salary_data[0] && this.salaryReportList[0].monthly_salary_data[0].provison_data) {
      for (let prodL = 0; prodL < this.salaryReportList[0].monthly_salary_data[0].provison_data.length; prodL++) {
        let total_prod_provisions = 0;
        this.salaryReportList[0].monthly_salary_data.forEach((msd) => {
          msd.provison_data.forEach((pd, pdKey) => {
            if (pdKey === prodL) {
              total_prod_provisions += pd.total_products_provision;
            }
          });
        });
        b.push(total_prod_provisions);
      }
    }
    return b;
  }

  getTotOrdersForIndvProducts(col) {
    let b: any[] = [];
    if (this.salaryReportList[0] && this.salaryReportList[0].monthly_salary_data) {
      for (let prodL = 0; prodL < (this.salaryReportList[0].monthly_salary_data[0].provison_data.length + 5); prodL++) {
        b.push({ value: "", isEmpty: true });
      }
      let total_prod_orders = 0;
      let total_prod_rejected_orders = 0;
      let product_pos;
      let prod_total_prov = 0;
      this.salaryReportList[0].monthly_salary_data.forEach((msd) => {
        msd.provison_data.forEach((pd, pdKey) => {
          if (pd.product_name === col) {
            total_prod_orders += pd.total_orders;
            total_prod_rejected_orders += pd.rejected_order;
            product_pos = pdKey;
          }
        });
      });
      if (this.salaryReportList[0].monthly_total_summary[0]) {
        this.salaryReportList[0].monthly_total_summary[0].sales_data.forEach((mtsd) => {
          if (mtsd.product_name === col) {
            prod_total_prov = mtsd.product_provison_cost;
          }
        });
      }
      if (product_pos > -1) {
        if (total_prod_rejected_orders) {
          b[0].value = total_prod_orders + '(' + total_prod_rejected_orders + ')';
        } else {
          b[0].value = total_prod_orders;
        }
        b[0].isEmpty = false;
        b[b.length - 1].value = prod_total_prov;
        b[b.length - 1].isEmpty = false;
      }
    }
    return b;
  }

  getTime(time) {
    let str = time;
    let str_array = str.split(':');
    for (let i = 0; i < str_array.length; i++) {
      str_array[i] = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
    }
    let hour = parseInt(str_array[0]);
    let minute = parseInt(str_array[1]);
    let second = parseInt(str_array[2]);
    let tottime = hour + (minute / 60) + (second / 3600);
    return tottime;
  }

  loadEconomySalaryPeriodReport() {
    this.tottRowErr = false;
    this.tottRowNoRecord = false;
    if (this.monthSelected && this.yearSelected) {
      this.loader = true;
      let reqFilterOptions = {
        month: this.monthSelected,
        year: this.yearSelected,
      };
      if (this.clientSelected) {
        reqFilterOptions['Client_id'] = this.clientSelected;
      }
      if (this.projectSelected) {
        reqFilterOptions['Project_id'] = this.projectSelected.Project_id;
      }
      this.economyService.getAllEconomySalaryPeriod(reqFilterOptions).subscribe(res => {
        if (res) {
          this.salaryReportList = res;
          let econSalaryPeriodResponse = [];
          if (res[0].monthly_salary_data) {
            econSalaryPeriodResponse = res[0].monthly_salary_data;
          }
          if (!this.clientSelected) {
            if (res[0].monthly_bonus_type_summary_data) {
              let bonusArr = res[0].monthly_bonus_type_summary_data;
              let totalBonusArr = res[0].monthly_bonus_summary_data;
              bonusArr.forEach((bonObj) => {
                econSalaryPeriodResponse.push({ project_name: bonObj.bonus_name, salary: bonObj.summa_ink, salary_soc: bonObj.summa_soc, hideCol: true });
              });
              totalBonusArr.forEach((totBonObj) => {
                econSalaryPeriodResponse.push({ project_name: 'Total Bonus', salary: totBonObj.summa_ink, salary_soc: totBonObj.summa_soc, hideCol: true, totalBenefit: true });
              });
            }
            if (res[0].viafone_emp_monthly_summary_report && res[0].viafone_emp_monthly_summary_report[0].total_hours) {
              let managementSalaryArr = res[0].viafone_emp_monthly_summary_report;
              managementSalaryArr.forEach((manSalObj) => {
                let hours_arr = manSalObj.total_hours.toString().split(':');
                let total_hours_data = hours_arr[0] + ':' + hours_arr[1] + ':' + hours_arr[2].split('.')[0];
                econSalaryPeriodResponse.push({ project_name: 'iSales', hours: total_hours_data, houry_income: manSalObj.hourly_cut, salary: manSalObj.salary_sem, salary_soc: manSalObj.salary_soc, hideCol: true });
              });
            }
          }
          if (res[0].monthly_sales_salary_summary_data && res[0].monthly_sales_salary_summary_data[0].actual_revenue) {
            res[0].monthly_sales_salary_summary_data[0].isSummedValue = true;
            econSalaryPeriodResponse.push(res[0].monthly_sales_salary_summary_data[0]);
          }
          econSalaryPeriodResponse.push({ project_name: 'Total', hours: this.salaryReportList[0].monthly_sales_salary_summary_data[0].hours, houry_income: this.salaryReportList[0].monthly_sales_salary_summary_data[0].hourly_income, salary: this.salaryReportList[0].monthly_sales_salary_summary_data[0].salary, salary_soc: this.salaryReportList[0].monthly_sales_salary_summary_data[0].salary_soc, revenue: this.salaryReportList[0].monthly_sales_salary_summary_data[0].revenue, revenue_vat: this.salaryReportList[0].monthly_sales_salary_summary_data[0].revenue_vat, actual_revenue: this.salaryReportList[0].monthly_sales_salary_summary_data[0].actual_revenue, isSummedValue: true });
          this.dataSource = new MatTableDataSource(econSalaryPeriodResponse);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            let sortString = property.split('.').reduce((o, i) => o[i], item);
            if (typeof sortString === 'string') {
              sortString = sortString.toLowerCase();
            }
            return sortString;
          }
          if (econSalaryPeriodResponse.length < 1) {
            this.tottRowNoRecord = true;
            this.loader = false;
          }
          this.loader = false;
        } else {
          this.dataSource = new MatTableDataSource([]);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            let sortString = property.split('.').reduce((o, i) => o[i], item);
            if (typeof sortString === 'string') {
              sortString = sortString.toLowerCase();
            }
            return sortString;
          }
          this.tottRowNoRecord = true;
          this.loader = false;
        }
        this._ref.detectChanges();
      }, err => {
        this.tottRowErr = true;
        this.loader = false;
      });
    }
  }

  loadEconomySalaryPeriodProductWiseReport() {
    this.prodtottRowErr = false;
    this.prodtottRowNoRecord = false;
    if (this.monthSelected && this.yearSelected && this.clientSelected && this.projectSelected) {
      let reqFilterOptions: any = {
        month: this.monthSelected,
        year: this.yearSelected,
      };

      if (this.clientSelected) {
        reqFilterOptions['Client_id'] = this.clientSelected;
      }
      if (this.projectSelected) {
        reqFilterOptions['Project_id'] = this.projectSelected.Project_id;
      }
      let resultarr = [];
      this.loader = true;
      let dayscount = new Date(this.yearSelected, this.monthSelected, 0).getDate();
      this.employeedisplayedColumns = [];
      this.employeedisplayedColumns.push('employee');
      for (let i = 0; i < dayscount; i++) {
        let dt = i + 1;
        this.employeedisplayedColumns.push(dt + "  " + this.getDay(dt));
        this.daysInMonth.push(dt + "  " + this.getDay(dt));
      }
      this.employeedisplayedColumns.push('Total timmar');
      this.economyService.getAllEconomySalaryPeriodReportProductwise(reqFilterOptions).subscribe(res => {
        if (res) {
          this.salaryReportList = res;
          let ms_Data = this.salaryReportList[0].monthly_summary_data[0];
          this.revenue = ms_Data.revenue;
          this.salary = ms_Data.salary;
          this.salary_sem = ms_Data.salary_sem;
          this.salary_soc = ms_Data.salary_soc;
          this.profit = ms_Data.profit;
          this.hourly_revenue = ms_Data.hourly_revenue;
          this.salary_percent = ms_Data.salary_percent;
          this.profit_percent = ms_Data.profit_percent;
          if (this.salaryReportList[0].monthly_salary_data[0]) {
            this.salaryReportList[0].monthly_salary_data[0].provison_data.forEach((prodObj) => {
              this.employeedisplayedColumns.push(prodObj.product_name);
              this.productsForProject.push(prodObj.product_name);
            });
          }
          this.employeedisplayedColumns.push('Total order', 'Netto', 'Snitt', 'Prov per produkt', 'Total prov per pro', 'Timlön', 'Totalt provision', 'Total timlön', 'Tot lön', 'Total lön ink sem', 'tot lön ink alt', 'Timl snitt');
          res.forEach((obj) => {
            this.footerProductCountObj = {};
            obj.monthly_salary_data.forEach((msdata) => {
              let prodColDataOrders = {};
              let productCountObj = {};
              if (msdata.provison_data) {
                this.employeedisplayedColumns.forEach((col_name, col_ind) => {
                  if (this.daysInMonth.indexOf(col_name) > -1) {
                    productCountObj[col_name] = this.getProductCountArr(msdata.monthly_sales_data[col_ind - 1].sales_data, this.salaryReportList[0].monthly_salary_data[0].provison_data, msdata.monthly_sales_data[col_ind - 1].rejected_data);
                    this.footerProductCountObj[col_name] = this.getProductCountArr(this.salaryReportList[0].daily_summary_data[col_ind - 1].sales_data, this.salaryReportList[0].monthly_salary_data[0].provison_data, this.salaryReportList[0].daily_summary_data[col_ind - 1].rejected_data);
                  }
                  if (this.productsForProject.indexOf(col_name) > -1) {
                    prodColDataOrders[col_name] = this.getProdColData(msdata.provison_data, col_name);
                    this.totalOrdersForIndvProducts[col_name] = this.getTotOrdersForIndvProducts(col_name);
                  }
                });
                this.totalProvPerProd = this.getTotalProv();
              }
              let datasourceObj: any = {};
              datasourceObj = msdata;
              datasourceObj.prodColDataOrders = prodColDataOrders;
              datasourceObj.productCountObj = productCountObj;
              resultarr.push(datasourceObj);

            });
          });
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            let sortString = property.split('.').reduce((o, i) => o[i], item);
            if (typeof sortString === 'string') {
              sortString = sortString.toLowerCase();
            }
            return sortString;
          }
          this.emp_dataSource = new MatTableDataSource(resultarr);
          this.loader = false;
        } else {
          this.dataSource = new MatTableDataSource([]);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.dataSource.sortingDataAccessor = (item, property) => {
            let sortString = property.split('.').reduce((o, i) => o[i], item);
            if (typeof sortString === 'string') {
              sortString = sortString.toLowerCase();
            }
            return sortString;
          }
          this.prodtottRowNoRecord = true;
          this.loader = false;
        }
        this._ref.detectChanges();
      }, err => {
        this.prodtottRowErr = true;
        this.loader = false;
      });
    }
  }

  getMonthSelected(clientSel?: any, projectSel?: any) {
    if (!this.bonusxpandStatus) {
      if (this.xpandStatus && clientSel && projectSel) {
        this.loadEconomySalaryPeriodProductWiseReport();
      } else {
        this.loadEconomySalaryPeriodReport();
      }
    }
  }

  getDay(i) {
    let daynumber = new Date(this.yearSelected, this.monthSelected - 1, i).getDay();
    switch (daynumber) {
      case 0:
        return 'Sön';
      case 1:
        return 'Mån';
      case 2:
        return 'Tis';
      case 3:
        return 'Ons';
      case 4:
        return 'Tor';
      case 5:
        return 'Fre';
      case 6:
        return 'Lör';
      default:
        return 'default';
    }
  }

  getClientList() {
    this.sharedServices.getClientList().subscribe((res: any) => {
      if (res) {
        this.clientsArr = res;
        this.clientsArr.sort(function (a, b) {
          if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
          if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
          return 0;
        });
        this._clientListFilter();
      }
    });
  }

  getProjectList() {
    this.sharedServices.getProjectList().subscribe((res: any) => {
      if (res) {
        this.projectsArr = res;
        this.projectsArr.sort(function (a, b) {
          if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
          if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
          return 0;
        });
      }
    });
  }

  getProjectListByClient(clientId) {
    this.clientProjectsArr = [];
    this.projectsArr.forEach((obj) => {
      if (obj.Client_id === clientId) {
        this.clientProjectsArr.push(obj);
      }
    });
    this.clientProjectsArr.sort(function (a, b) {
      if (a.Project_name.toLowerCase() < b.Project_name.toLowerCase()) { return -1; }
      if (a.Project_name.toLowerCase() > b.Project_name.toLowerCase()) { return 1; }
      return 0;
    });
    this._projectListFilter();
  }

  clearkund() {
    this.clientSelected = '';
    this.projectSelected = '';
  }

  getSalaryDataByClientAndProject(clientId?: any, project?: any) {
    if (this.xpandStatus && clientId && project) {
      this.toggleEconomyProjectTable = false;
      this.toggleEconomyEmployeeTable = true;
      this.bonusxpandStatus = false;
    } else {
      this.toggleEconomyEmployeeTable = false;
      this.toggleEconomyProjectTable = true;
      this.bonusxpandStatus = false;
    }
    this.toggleColumns = [
      { arrIndex: 1, column: 'ID', checked: true, label: '_id' },
      { arrIndex: 2, column: 'KUND', checked: true, label: 'name' },
      { arrIndex: 3, column: 'STATUS', checked: true, label: 'status' },
      { arrIndex: 4, column: 'ATGARDER', checked: true, label: 'actions', onlyAdmin: true },
    ];
  }

  getDataSourceByClientProject(isClientProjectSelected?: boolean, projectId?: any, isBenifitCol?: any) {
    this.bonusxpandStatus = false;
    if (!isBenifitCol) {
      this.xpandStatus = isClientProjectSelected;
      if (!this.isClientButton) {
        if (!isClientProjectSelected && !projectId) {
          this.clientSelected = null;
          this.projectSelected = null;
          this.toggleEconomyProjectTable = true;
          this.toggleEconomyEmployeeTable = false;
          if (!(this.setMonthYear.month == this.monthSelected && this.setMonthYear.year == this.yearSelected)) {
            this.loadEconomySalaryPeriodReport();
            this.setMonthYear.month = this.monthSelected;
            this.setMonthYear.year = this.yearSelected;
          }
        } else {
          this.toggleEconomyProjectTable = true;
          this.toggleEconomyEmployeeTable = false;
          this.getSalaryDataByClientAndProject(true, this.projectSelected);
          if (isClientProjectSelected && projectId) {
            this.getMonthSelected(true, true);
          }
          if (!this.userData.role.includes('admin') && !this.userData.role.includes('superadmin')) {
            this.isClientButton = false;
          } else {
            this.isClientButton = true;
          }
        }
      }
      if (isClientProjectSelected && projectId) {
        this.clientSelected = this.getClientByProject(projectId);
        this.getProjectListByClient(this.clientSelected);
        this.projectSelected = this.getProjectObjByProjectId(projectId);
        this.getSalaryDataByClientAndProject(this.clientSelected, this.projectSelected);
        this.getMonthSelected(this.clientSelected, this.projectSelected);
      }  
    }
  }

  getProdColData(prov_data, col) {
    let ord: any[] = [];
    if (prov_data) {
      if (!col) {
        prov_data.forEach((pdata) => {
          ord.push({ total_order_count: '', rejected_order_count: '' });
        });
      } else {
        prov_data.forEach((pdata) => {
          if (col == pdata.product_name) {
            if (pdata.rejected_order) {
              ord.push({
                total_order_count: pdata.total_orders,
                rejected_order_count: pdata.rejected_order
              });
            } else {
              ord.push({
                total_order_count: pdata.total_orders,
                rejected_order_count: ''
              });
            }
          } else {
            ord.push({ total_order_count: '', rejected_order_count: '' });
          }
        });
        return ord;
      }
    }
    return ord;
  }

  getClientByProject(projectId) {
    let clientId = null;
    this.projectsArr.forEach((obj) => {
      if (obj.Project_id === projectId) {
        clientId = obj.Client_id;
      }
    });
    return clientId;
  }

  getProjectObjByProjectId(projectId) {
    let project = null;
    this.projectsArr.forEach((obj) => {
      if (obj.Project_id === projectId) {
        project = obj;
      }
    });
    return project;
  }

  getMonthlySalartReport() {
    if (this.monthSelected && this.yearSelected) {
      this.loader = true;
      let reqFilterOptions = {
        month: this.monthSelected,
        year: this.yearSelected,
      };
      this.economyService.monthlySalaryReportDownload(reqFilterOptions).subscribe((res) => {
        if (res && res[0] && res[0].salary_data) {
          if (this.userData.role === 'admin' || this.userData.role === 'superadmin' || this.userData.role === 'recruitment') {
            /* generate worksheet */
            this.arrToPrint = [];
            this.arrToPrint[0] = ['Anställnings ID', 'Förnamn', 'Efternamn', 'Löneperiod ' + this.yearSelected, 'Avdelning', 'Löneart', 'Projekt', 'Lönetyp', 'Belopp', 'Visma Id','Timmar'];
            let toSetFields = ['employee_id', 'first_name', 'last_name', 'lon_period', 'department_name', 'lon_no', 'project_name', 'lon_type', 'total_salary', 'visma_id','attendance_time'];
            res[0].salary_data.forEach((sData) => {
              let toPushData = [];
              Object.keys(sData).forEach((key) => {
                let toSetFieldIndex = toSetFields.indexOf(key);
                toPushData[toSetFieldIndex] = sData[key];
              });
              this.arrToPrint.push(toPushData);
            });
            const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
            /* generate workbook and add the worksheet */
            const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
            Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
            /* save to file */
            Xlsx.writeFile(wb, 'Lönrapport_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
          }
        } else {
          if (this.userData.role === 'admin' || this.userData.role === 'superadmin' || this.userData.role === 'recruitment') {
            /* generate worksheet */
            this.arrToPrint = [];
            this.arrToPrint[0] = ['Anställnings ID', 'Förnamn', 'Efternamn', 'Löneperiod ' + this.yearSelected, 'Avdelning', 'Löneart', 'Projekt', 'Lönetyp', 'Belopp', 'Datum', 'Visma Id']
            const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
            /* generate workbook and add the worksheet */
            const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
            Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
            /* save to file */
            Xlsx.writeFile(wb, 'Lönrapport_' + _moment().format('x') + '.xlsx', { bookType: 'xlsx', type: 'array' });
          }
        }
        this.loadEconomySalaryPeriodReport();
        this.loader = false;
      }, err => {
        this.loader = false;
      });
    }
  }

  _projectListFilter(projectName?: string): any[] {
    if (this.clientProjectsArr.length <= 0) {
      return;
    }
    if (projectName && (typeof projectName == 'string') && projectName.trim() != '') {
      const depfilterValue = projectName.toLowerCase();
      this.projectFilteredOptions.next(
        this.clientProjectsArr.filter(dep => (dep.Project_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.projectFilteredOptions.next(this.clientProjectsArr.slice());
      return;
    }
  }

  _clientListFilter(clientName?: string): any[] {
    if (this.clientsArr.length <= 0) {
      return;
    }
    if (clientName && (typeof clientName == 'string') && clientName.trim() != '') {
      const depfilterValue = clientName.toLowerCase();
      this.clientFilteredOptions.next(
        this.clientsArr.filter(dep => (dep.name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.clientFilteredOptions.next(this.clientsArr.slice());
      return;
    }
  }

}