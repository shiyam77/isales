import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';
import * as Xlsx from 'xlsx';
import { ClientList } from '../../project/_core/models/client-list.model';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { PersonalService } from '../../personal/_core/services/personal.service';
import { EconomyService } from '../_core/services/economy.service';
import { EconomyOverview } from '../_core/models/economy-overview.model';
type AOA = any[][];

@Component({
  selector: 'm-economy-dailyturnover',
  templateUrl: './economy-dailyturnover.component.html',
  styleUrls: ['./economy-dailyturnover.component.scss']
})

export class EconomyDailyturnoverComponent implements OnInit {

  projClientArr: Array<any> = [];
  clientsArr: Array<any> = [];
  modalFormGroup: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  arrToPrint: AOA = [];
  monthList = [
    { label: "Januari", value: 1 },
    { label: "Februari", value: 2 },
    { label: "Mars", value: 3 },
    { label: "April", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Juni", value: 6 },
    { label: "Juli", value: 7 },
    { label: "Augusti", value: 8 },
    { label: "September", value: 9 },
    { label: "Oktober", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  clientSelected: any;
  projectSelected: any;
  selection = new SelectionModel<ClientList>(true, []);
  dataSource: any;
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  displayedColumns: string[] = ['name', 'worked_hours', 'revenue', 'revenue_hour', 'expense', 'expense_hour', 'profit', 'cost'];
  overviewList: EconomyOverview[] = [];
  xpandStatus: boolean = false;
  xpandStatuss: boolean = false;
  searchInput: string = '';
  deleteEmpModalRef: any;
  closeResult: string;
  clientTitle: string;
  delEmployeeData: any;
  updateClientID: any;
  projectsArr: Array<any> = [];
  clientProjectsArr: Array<any> = [];
  showAssignedMessage: boolean = false;
  resDeleteMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };

  toggleColumns = [
    { arrIndex: 1, column: 'Säljare', checked: true, label: 'name' },
    { arrIndex: 2, column: 'Timmar', checked: true, label: 'worked_hours' },
    { arrIndex: 3, column: 'Omsättning', checked: true, label: 'revenue' },
    { arrIndex: 4, column: 'Omsättning/Timmar', checked: true, label: 'revenue_hour' },
    { arrIndex: 5, column: 'Förbruknings', checked: true, label: 'expense' },
    { arrIndex: 6, column: 'Förbruknings/Timmar', checked: true, label: 'expense_hour' },
    { arrIndex: 7, column: '% Kostnad', checked: true, label: 'profit' },
    { arrIndex: 8, column: '% Vinst', checked: true, label: 'cost' }
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];

  constructor(private economyService: EconomyService,
    private modalService: NgbModal, 
    private _formBuilder: FormBuilder, 
    private personalService: PersonalService) { }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= 4); y++) {
      this.yearList.push(2020 + y);
    }
    if (new Date().getMonth() > 0) {
      this.monthSelected = new Date().getMonth();
    } else {
      this.monthSelected = 1;
    }
    this.modalFormGroup = this._formBuilder.group({
      client_name: ['', Validators.required],
      client_stat: [false],
    });
    this.setExcelHeaders();
    this.getuserData = this.economyService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.loadEconomyOverviewList();
    this.getProjectList();
    this.getClientList();
  }

  slideToggleChange(e) {
  }

  getClientList() {
    this.personalService.getClientList().subscribe((res: any) => {
      if (res) {
        this.clientsArr = res;
      }
    })
  }

  getProjectList() {
    this.personalService.getProjectList().subscribe((res: any) => {
      if (res) {
        this.projectsArr = res;
      }
    });
  }

  getProjectListByClient(clientId) {
    this.projectSelected = null;
    this.clientProjectsArr = [];
    this.projectsArr.forEach((obj) => {
      if (obj.Client_id === clientId) {
        this.clientProjectsArr.push(obj);
      }
    });
  }

  loadEconomyOverviewList() {
    this.selection.clear();
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      if (this.monthSelected && this.yearSelected) {
        this.loader = true;
        let reqFilterOptions = {
          month: this.monthSelected,
          year: this.yearSelected,
          Client_id: this.clientSelected,
          Project_id: this.projectSelected
        };
        if (!this.clientSelected) {
          reqFilterOptions.Client_id = null;
        }
        if (!this.projectSelected) {
          reqFilterOptions.Project_id = null;
        }
        this.economyService.getEconomyOverviewList(reqFilterOptions).subscribe(res => {
          if (res) {
            this.overviewList = res;
            this.dataSource = new MatTableDataSource(res);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            this.dataSource.sortingDataAccessor = (item, property) => {
              let sortString = property.split('.').reduce((o, i) => o[i], item);
              if (typeof sortString === 'string') {
                sortString = sortString.toLowerCase();
              }
              return sortString;
            }
            this.loader = false;
            this.setExcelValues();
          } else {
            this.dataSource = new MatTableDataSource([]);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            this.dataSource.sortingDataAccessor = (item, property) => {
              let sortString = property.split('.').reduce((o, i) => o[i], item);
              if (typeof sortString === 'string') {
                sortString = sortString.toLowerCase();
              }
              return sortString;
            }
            this.loader = false;
          }
        });
      }
    }
    this.selection.clear();
    this.showHideCols();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.filterPredicate = (item, filter) => {
      let filterString = item.name + item.sales_Exvat + item.realsales_vat + item.turnover_exvat + item.hours + item.actualincomex_vat + item.hourlytax_exvat;
      filterString = filterString.trim().toLowerCase();
      return filterString.indexOf(filter) != -1;
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  private setExcelHeaders() {
    this.arrToPrint[0] = [];
    this.toggleColumns.forEach((obj) => {
      if (obj.arrIndex !== 4) {
        this.arrToPrint[0].push(obj.column);
      }
    });
  }

  private setExcelValues() {
    this.overviewList.forEach((val) => {
      let newLine = [];
      this.toggleColumns.forEach((obj) => {
        if (obj.arrIndex === 4 || obj.arrIndex === 3) {
          if (obj.arrIndex === 3) {
            if (val.name) {
              newLine.push('True');
            } else {
              newLine.push('False');
            }
          }
        } else {
          let str = obj.label.split('.').reduce((o, i) => o[i], val);
          newLine.push(str);
        }
      });
      this.arrToPrint.push(newLine);
    });
  }

  expandSearch(e, searchText) {
    if (e.type == "blur") {
      if (e.target.value) {
        (document.querySelector('.overview-search .mat-form-field-flex') as HTMLElement).style.width = '200px';
      } else {
        (document.querySelector('.overview-search .mat-form-field-flex') as HTMLElement).style.width = '18px';
      }
    } else if (e.type == "click") {
      if (!searchText) {
        (document.querySelector('.overview-search .mat-form-field-flex') as HTMLElement).style.width = '200px';
      }
    }
  }

  showHideCols() {
    this.displayedColumns = [];
    this.toggleColumns.forEach((obj, ind) => {
      if (obj.checked) {
        if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
          this.displayedColumns.push(obj.label);
        }
      }
    });
  }

  generateAndDownloadDoc() {
    if (this.userData.role === 'admin' || this.userData.role === 'superadmin') {
      /* generate worksheet */
      const ws: Xlsx.WorkSheet = Xlsx.utils.aoa_to_sheet(this.arrToPrint);
      /* generate workbook and add the worksheet */
      const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
      Xlsx.utils.book_append_sheet(wb, ws, 'Sheet 1');
      /* save to file */
      Xlsx.writeFile(wb, 'Ekonomisk_översikt_' + this.monthSelected + '_' + this.yearSelected + '_' + _moment().format('x') + '.xls', { bookType: 'xls', type: 'array' });
    }
  }

  openModal(content, contentAccessId, toClient?) {
    if (content === 'create') {
      this.clientTitle = "Add Client";
      this.modalFormGroup.patchValue({
        client_name: '',
        client_stat: true,
      });
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient' });
    } else if (content === 'update') {
      this.clientTitle = "Update Client";
      this.updateClientID = toClient._id
      this.modalFormGroup.patchValue({
        client_name: toClient.name,
        client_stat: toClient.clientstatus,
      });
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient' });
    } else if (content === 'delete') {
      this.showAssignedMessage = false;
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-deleteClient' });
    }
    this.delEmployeeData = toClient;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  deleteClient() {
    this.spinner.active = true;
    this.spinner.active = false;
  }

  createClient() {
    if (this.modalFormGroup.valid) {
      this.spinner.active = true;
      let form1 = this.modalFormGroup.value;
      let clientData = {
        "name": form1.client_name,
        "clientstatus": form1.client_stat ? true : false
      }
      this.deleteEmpModalRef.close('submitted');
      this.spinner.active = false;
    }
  }

  getDataSourceByClientProject(isClientProjectSelected?: boolean) {
    this.xpandStatus = isClientProjectSelected;
    if (!isClientProjectSelected) {
      this.clientSelected = null;
      this.projectSelected = null;
      this.loadEconomyOverviewList();
    } 
  }
}