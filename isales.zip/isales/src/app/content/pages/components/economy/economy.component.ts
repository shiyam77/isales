

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-economy',
  templateUrl: './economy.component.html',
  styleUrls: ['./economy.component.scss']
})
export class EconomyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
