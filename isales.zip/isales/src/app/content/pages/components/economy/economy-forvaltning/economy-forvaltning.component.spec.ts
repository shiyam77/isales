import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EconomyForvaltningComponent } from './economy-forvaltning.component';

describe('EconomyForvaltningComponent', () => {
  let component: EconomyForvaltningComponent;
  let fixture: ComponentFixture<EconomyForvaltningComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EconomyForvaltningComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EconomyForvaltningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
