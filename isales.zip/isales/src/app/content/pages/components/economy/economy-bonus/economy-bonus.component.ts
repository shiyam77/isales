import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource, MatSelect } from '@angular/material';
import { ClientList } from '../../project/_core/models/client-list.model';
import { SpinnerButtonOptions } from '../../../../partials/content/general/spinner-button/button-options.interface';
import { SelectionModel } from '@angular/cdk/collections';
import { Observable, Subject, ReplaySubject } from 'rxjs';
import { ProjectService } from '../../project/_core/services/project.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { EconomyService } from '../_core/services/economy.service';
import { SharedService } from '../../../../../core/services/pages/shared.service';
import { startWith, map, takeUntil, take } from 'rxjs/operators';

@Component({
  selector: 'm-economy-bonus',
  templateUrl: './economy-bonus.component.html',
  styleUrls: ['./economy-bonus.component.scss']
})

export class EconomyBonusComponent implements OnInit {
  rValue: number;
  totbonusSalary: number = 0;
  totbonusSalary_soc: number = 0;
  isSticky(column: string): boolean {
    return column === 'employee' ? true : false;
  }
  projClientArr: Array<any> = [];
  clientsArr: Array<any> = [];
  clientSelected: any;
  projectSelected: any;
  salaryReportList: any = [];
  revenue: any;
  salary: any;
  salary_sem: any;
  salary_soc: any;
  profit: any;
  hourly_revenue: any;
  salary_percent: any;
  profit_percent: any;
  bonusxpandStatus: boolean = true;
  empArr: Array<any> = [];
  delEmployeeData: any;
  delEmployeeBonusData: any;
  modalFormGroup: FormGroup;
  bonusmodalFormGroup: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  monthList = [
    { label: "Januari", value: 1 },
    { label: "Februari", value: 2 },
    { label: "Mars", value: 3 },
    { label: "April", value: 4 },
    { label: "Maj", value: 5 },
    { label: "Juni", value: 6 },
    { label: "Juli", value: 7 },
    { label: "Augusti", value: 8 },
    { label: "September", value: 9 },
    { label: "Oktober", value: 10 },
    { label: "November", value: 11 },
    { label: "December", value: 12 },
  ];
  yearList = [new Date().getFullYear()];
  monthSelected = new Date().getMonth() + 1;
  yearSelected = new Date().getFullYear();
  setMonthYear: any = {
    month: null,
    year: null
  };
  dataSource: any;
  selectedClient: any;
  selectedProject: any;
  getuserData: any;
  userData: any = {
    role: '',
    id: null
  };
  loader: boolean = false;
  displayedColumns: string[] = ['project_name', 'actual_revenue', 'realsales_vat', 'revenue', 'revenue_vat', 'hours', 'actual_hourly_income_ex_vat', 'houry_income', 'salary', 'salary_soc', 'inksemsoc', 'salary_revenue_percent'];
  seconddisplayedColumns: string[] = ['firstcolumn', 'calculated', 'real'];
  employeedisplayedColumns: string[] = ['employee', 'totaltimmar', 'totalorder', 'snitt', 'provperproduckt', 'totalprovperpro', 'timlön', 'totaltprovision', 'totalhourlysalary', 'totallön'];
  bonus_displayedColumns: string[] = ['Employee_Name', 'bonus_type', 'bonus_amount', 'ink_sem', 'ink_soc', 'actions'];
  displayIndividualBonusColumnToShow = ['Employee', 'Total_hours', 'Recurit_bonus_default', 'Recuritment_bonus'];
  allClientList: ClientList[] = [];
  xpandStatus: boolean = false;
  searchInput: string = '';
  emp_dataSource: any = [];
  deleteEmpModalRef: any;
  closeResult: string;
  clientTitle: string;
  updateBonusID: any;
  btRowErr: boolean = false;
  btRowNoRecord: boolean = false;
  bonus_dataSource: any;
  projectsArr: Array<any> = [];
  clientProjectsArr: Array<any> = [];
  showAssignedMessage: boolean = false;

  resDeleteMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  resCreateMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };
  resUpdateeMessage: {
    success?: boolean;
    error?: boolean;
  } = {
      success: false,
      error: false
    };

  spinner: SpinnerButtonOptions = {
    active: false,
    spinnerSize: 18,
    raised: true,
    buttonColor: 'primary',
    spinnerColor: 'accent',
    fullWidth: false
  };
  toggleColumns = [
    { arrIndex: 1, column: 'ID', checked: true, label: '_id' },
    { arrIndex: 2, column: 'KUND', checked: true, label: 'name' },
    { arrIndex: 3, column: 'STATUS', checked: true, label: 'status' },
    { arrIndex: 4, column: 'ATGARDER', checked: true, label: 'actions', onlyAdmin: true },
  ];
  itemsPerPage: number = 50;
  itemsInPageList: Array<number> = [50, 100, 500];
  toggleEconomyProjectTable: boolean = true;
  toggleEconomyEmployeeTable: boolean = false;
  productsForProject: any[] = [];
  footerProductCountObj: any = {};
  isClientButton: boolean = false;
  totalOrdersForIndvProducts: any = {};
  totalProvPerProd: any = [];
  daysInMonth: any[] = [];
  bonusArr: Array<any> = [];
  bonusLoader: boolean = false;
  selection = new SelectionModel<ClientList>(true, []);
  filteredOptions: Observable<string[]>;
  costAmount: any = '';
  consulationAmount: any = '';
  costPercent: any = '';
  consultPercent: any = '';
  multiColFilter = {
    name: '',
    fromdate: '',
    todate: '',
    start_time: '',
    end_time: '',
    created_time: '',
    note: '',
    status: '',
    approval_note: ''
  };
  tottRowErr: boolean = false;
  tottRowNoRecord: boolean = false;
  searchGroup: FormGroup;
  @ViewChild('bonusSearchSelect') bonusSearchSelect: MatSelect;
  @ViewChild('empBonusSearchSelect') empBonusSearchSelect: MatSelect;
  protected _onBonusDestroy = new Subject<void>();
  protected _onEmpBonusDestroy = new Subject<void>();
  bonusFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  empbonusFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  bonusTotal: any = {
    summa_val: '',
    summa_ink: '',
    summa_soc: '',
  };
  summaryArr: any = [];
  tBonusRowNoRecord: boolean = false;
  tBonusRowErr: boolean = false;
  bonusSource: any;
  bonusColFilter = {
    Total_hours: '',
    Recuritment_bonus: '',
    Recurit_bonus_default: '',
    Employee: '',
  };
  @ViewChild('employeeSearchSelect') employeeSearchSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  empFilteredOptions: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  constructor(
    private projectService: ProjectService,
    private modalService: NgbModal,
    private _formBuilder: FormBuilder,
    private _ref: ChangeDetectorRef,
    private sharedServices: SharedService,
    private economyService: EconomyService) { }

  getMonthTitle(month) {
    let monthLabel = '';
    this.monthList.forEach((obj) => {
      if (obj.value == month) {
        monthLabel = obj.label;
      }
    });
    return monthLabel;
  }

  ngOnInit() {
    this.yearList = [];
    for (let y = 0; (y <= 5); y++) {
      this.yearList.push(2020 + y);
    }
    if (new Date().getMonth() > 0) {
      this.monthSelected = new Date().getMonth() + 1;
    }
    this.modalFormGroup = this._formBuilder.group({
      client_name: ['', Validators.required],
      client_stat: [false],
    });
    this.getuserData = this.projectService.getRoleAndId();
    this.getuserData.role.subscribe(role => {
      this.userData.role = role.toString();
    });
    this.getuserData.userId.subscribe(id => {
      if (id) {
        this.userData.id = parseInt(id);
      }
    });
    this.searchGroup = this._formBuilder.group({
      selectedBonus: [[]],
      bonusFilterControls: [''],
    });
    this.bonusmodalFormGroup = this._formBuilder.group({
      emp_name: ['', Validators.required],
      summa_value: ['', Validators.required],
      inksem: ['', Validators.required],
      inksoc: ['', Validators.required],
      bonus_id: ['', Validators.required],
      employeeBonusFilterControls: ['']
    });
    this.sharedServices.clientListSub$.subscribe((isClientListSet) => {
      if (isClientListSet) {
        this.clientsArr = this.sharedServices.clientListData;
      }
    });
    this.sharedServices.projectListSub$.subscribe((isProjectListSet) => {
      if (isProjectListSet) {
        this.projectsArr = this.sharedServices.projectListData;
      }
    });
    if (!this.userData.role.includes('admin') && !this.userData.role.includes('superadmin')) {
      this.xpandStatus = true;
    } else {
      this.xpandStatus = false;
    }
    this.loadBonusList();
    this.loadEmployee();
    this.bonusmodalFormGroup.controls['inksem'].disable();
    this.bonusmodalFormGroup.controls['inksoc'].disable();
    this.filteredOptions = this.bonusmodalFormGroup.controls['emp_name'].valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
    this.searchGroup.controls['bonusFilterControls'].valueChanges
      .pipe(takeUntil(this._onBonusDestroy)).subscribe(() => this._DepFilter());
    this.bonusmodalFormGroup.controls['employeeBonusFilterControls'].valueChanges
      .pipe(takeUntil(this._onEmpBonusDestroy)).subscribe(() => this._empBonusFilter());
    this.getBonusField(true);
  }

  ngOnDestroy() {
    this._onBonusDestroy.next();
    this._onBonusDestroy.complete();
    this._onEmpBonusDestroy.next();
    this._onEmpBonusDestroy.complete();
  }

  getTime(time) {
    let str = time;
    let str_array = str.split(':');
    for (let i = 0; i < str_array.length; i++) {
      str_array[i] = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
    }
    let hour = parseInt(str_array[0]);
    let minute = parseInt(str_array[1]);
    let second = parseInt(str_array[2]);
    let tottime = hour + (minute / 60) + (second / 3600);
    return tottime;
  }

  getMonthSelected(clientSel?: any, projectSel?: any) {
    this.getBonusField(true);
  }

  getDay(i) {
    let daynumber = new Date(this.yearSelected, this.monthSelected - 1, i).getDay();
    switch (daynumber) {
      case 0:
        return 'Sön';
      case 1:
        return 'Mån';
      case 2:
        return 'Tis';
      case 3:
        return 'Ons';
      case 4:
        return 'Tor';
      case 5:
        return 'Fre';
      case 6:
        return 'Lör';
      default:
        return 'default';
    }
  }

  slideToggleChange(e) {
  }

  getBonusField(bonus?: boolean) {
    this.xpandStatus = false;
    this.toggleEconomyProjectTable = false;
    this.toggleEconomyEmployeeTable = false;
    this.loadEmpBonusList();
  }

  addEmpBonus() {
    let form1 = this.bonusmodalFormGroup.value;
    if (this.bonusmodalFormGroup.valid) {
      this.spinner.active = true;
      let empBonusData: any = {
        "bonus_id": form1.bonus_id,
        "employee_id": form1.emp_name.id,
        "summa_value": form1.summa_value,
        "month": this.monthSelected,
        "year": this.yearSelected
      };
      if (!this.updateBonusID) {
        this.projectService.createEmpBonus(empBonusData).subscribe(res => {
          if (res.message === 'Bouns Added Successfully') {
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
            this.bonusmodalFormGroup.reset();
            this.loadEmpBonusList();
            this.deleteEmpModalRef.close('submitted');
            this.spinner.active = false;
          } else {
            this.spinner.active = false;
            this.deleteEmpModalRef.close('submitted');
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          setTimeout(() => {
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this._ref.detectChanges();
          }, 5000);
          this._ref.detectChanges();
        });
      } else {
        empBonusData.settings_id = this.updateBonusID;
        this.projectService.updateEmpBonus(empBonusData).subscribe(res => {
          if (res.message === 'Bouns Updated Successfully') {
            this.resCreateMessage.success = true;
            this.resCreateMessage.error = false;
            this.bonusmodalFormGroup.reset();
            this.loadEmpBonusList();
            this.deleteEmpModalRef.close('submitted');
            this.spinner.active = false;
          } else {
            this.spinner.active = false;
            this.deleteEmpModalRef.close('submitted');
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = true;
          }
          setTimeout(() => {
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this._ref.detectChanges();
          }, 5000);
          this._ref.detectChanges();
        });
      }
    }
  }

  deleteBonus() {
    this.spinner.active = true;
    this.projectService.deleteEmpBonus(this.delEmployeeBonusData).subscribe(res => {
      if (res.message === 'Deleted Successfully') {
        this.loadEmpBonusList();
        this.resDeleteMessage.success = true;
        this.resDeleteMessage.error = false;
        this.deleteEmpModalRef.close('submitted');
      } else {
        this.spinner.active = false;
        this.deleteEmpModalRef.close('submitted');
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = true;
      }
      setTimeout(() => {
        this.resDeleteMessage.success = false;
        this.resDeleteMessage.error = false;
        this._ref.detectChanges();
      }, 5000);
      this.spinner.active = false;
      this._ref.detectChanges();
    }, error => {
      if (error.error.message) {
        this.spinner.active = false;
      }
    });
    this.spinner.active = false;
  }

  loadBonusList() {
    this.projectService.getAllBonus().subscribe(res => {
      if (res) {
        this.bonusArr = res;
        this.bonusArr.sort(function (a, b) {
          if (a.bonus_name.toLowerCase() < b.bonus_name.toLowerCase()) { return -1; }
          if (a.bonus_name.toLowerCase() > b.bonus_name.toLowerCase()) { return 1; }
          return 0;
        });
        this.bonusFilteredOptions.next(this.bonusArr.slice());
      }
    }, err => {
      this.bonusLoader = false;
    });
  }

  loadEmpBonusList() {
    this.btRowNoRecord = false;
    this.btRowErr = false;
    this.bonusLoader = true;
    this.selection.clear();
    let data: any = { month: this.monthSelected, year: this.yearSelected };
    if (this.searchGroup.value.selectedBonus && this.searchGroup.value.selectedBonus.length > 0) {
      data.bonus_id = this.searchGroup.value.selectedBonus.join();
    }
    this.projectService.getAllEmpMonthlyBonus(data).subscribe(res => {
      if (res && res[0] && res[0].bonus_summary && (res[0].bonus_summary.length > 0)) {
        this.bonus_dataSource = new MatTableDataSource(res[0].bonus_summary);
        this.bonus_dataSource.paginator = this.paginator;
        this.bonus_dataSource.sort = this.sort;
        this.bonus_dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        }
        this.bonusTotal.summa_val = (res[0].total_summary[0].total_bonus);
        this.bonusTotal.summa_ink = (res[0].total_summary[0].total_bonus_summa_ink);
        this.bonusTotal.summa_soc = (res[0].total_summary[0].total_bonus_summa_soc);
        this.summaryArr = res[0].monthly_bonus_summary_data;
        this.summaryArr.push({ bonus_name: 'Total', summa_val: this.bonusTotal.summa_val, summa_ink: this.bonusTotal.summa_ink, summa_soc: this.bonusTotal.summa_soc });
        this.btRowNoRecord = false;
        this.btRowErr = false;
        this.bonusLoader = false;
      } else {
        this.bonus_dataSource = new MatTableDataSource([]);
        this.bonus_dataSource.paginator = this.paginator;
        this.bonus_dataSource.sort = this.sort;
        this.bonus_dataSource.sortingDataAccessor = (item, property) => {
          let sortString = property.split('.').reduce((o, i) => o[i], item);
          if (typeof sortString === 'string') {
            sortString = sortString.toLowerCase();
          }
          return sortString;
        };
        this.bonusTotal.summa_val = '';
        this.bonusTotal.summa_ink = '';
        this.bonusTotal.summa_ink = '';
        this.summaryArr = [];
        this.summaryArr.push({ bonus_name: 'Total', summa_val: this.bonusTotal.summa_val, summa_ink: this.bonusTotal.summa_ink, summa_soc: this.bonusTotal.summa_soc });
        this.btRowNoRecord = true;
        this.bonusLoader = false;
      }
    }, err => {
      this.btRowErr = true;
      this.bonusLoader = false;
      this.bonusTotal.summa_val = '';
      this.bonusTotal.summa_ink = '';
      this.bonusTotal.summa_ink = '';
      this.summaryArr = [];
      this.summaryArr.push({ bonus_name: 'Total', summa_val: this.bonusTotal.summa_val, summa_ink: this.bonusTotal.summa_ink, summa_soc: this.bonusTotal.summa_soc });
    });
    this.selection.clear();
  }

  onAddProductsFromClick(event) {
    if (event.option.value) {
    }
  }

  loadEmployee() {
    this.sharedServices.getAllActiveInactiveEmployeeList().subscribe(res => {
      res.forEach((obj) => {
        this.empArr.push({
          id: obj.Employee_id,
          name: obj.first_name + " " + obj.last_name
        });
      });
      this.empArr.sort(function (a, b) {
        if (a.name.toLowerCase() < b.name.toLowerCase()) { return -1; }
        if (a.name.toLowerCase() > b.name.toLowerCase()) { return 1; }
        return 0;
      });
    });
  }

  displayFn(user?: any): string | undefined {
    return user ? user.name : '';
  }

  openBonusModal(content, contentAccessId, toClient?) {
    if (content === 'create') {
      this.bonusmodalFormGroup.reset();
      this.clientTitle = "Lägg till bonus";
      this.updateBonusID = null;
      this.spinner.active = false;
      this.bonusmodalFormGroup.controls['inksem'].disable();
      this.bonusmodalFormGroup.controls['inksoc'].disable();
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', size: 'sm', backdrop: "static" });
    } else if (content === 'update') {
      this.bonusmodalFormGroup.reset();
      this.clientTitle = "Uppdatera bonus";
      this.updateBonusID = toClient.id;
      this.spinner.active = false;
      this.bonusmodalFormGroup.controls['inksem'].enable();
      this.bonusmodalFormGroup.controls['inksoc'].enable();
      this.bonusmodalFormGroup.patchValue({
        emp_name: { id: toClient.employee_id, name: toClient.first_name + " " + toClient.last_name },
        bonus_id: toClient.bonus_id,
        summa_value: toClient.summa_val,
        inksem: toClient.summa_val ? (toClient.summa_ink * 1.12).toFixed(2) : '',
        inksoc: toClient.summa_val ? ((toClient.summa_soc * 1.12) * 1.3142).toFixed(2) : ''
      });
      this.bonusmodalFormGroup.controls['inksem'].disable();
      this.bonusmodalFormGroup.controls['inksoc'].disable();
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-createClient', size: 'sm', backdrop: "static" });
    } else if (content === 'delete') {
      this.showAssignedMessage = false;
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { windowClass: 'my-modal-class-deleteClient', backdrop: "static" });
    } else if (content === 'individual_bonus_list') {
      this.getIndividualBonusList(toClient.employee_id);
      this.deleteEmpModalRef = this.modalService.open(contentAccessId, { size: 'lg', backdrop: "static" });
    }
    this.delEmployeeBonusData = toClient;
    this.deleteEmpModalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  //autocomplete
  private _filter(value: string): string[] {
    if (typeof value === 'string') {
      const filterValue = value.toLowerCase();
      return this.empArr.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
    }
  }

  applyColumnFilter() {
    this.bonus_dataSource.filterPredicate = this.columnwiseFilter();
    this.bonus_dataSource.filter = JSON.stringify(this.multiColFilter);
    if (this.bonus_dataSource.paginator) {
      this.bonus_dataSource.paginator.firstPage();
    }
  }

  private columnwiseFilter() {
    let filterPred = (item, filter) => {
      let filterString = JSON.parse(filter);
      let isRowSet: boolean = true;
      Object.keys(filterString).forEach((key) => {
        let keyNodeValue: any;
        if (key != 'name') {
          keyNodeValue = key.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
        } else {
          let nameKey1 = 'first_name';
          let nameKey2 = 'last_name';
          keyNodeValue = nameKey1.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
          keyNodeValue += ' ' + nameKey2.split('.').reduce((o, i) => { if (o) { return o[i] } }, item);
        }
        if ((keyNodeValue && filterString[key]) || ((keyNodeValue >= 0) && (filterString[key] >= 0))) {
          let itemString = '';
          if (keyNodeValue && (typeof keyNodeValue != 'string')) {
            itemString = keyNodeValue.toString();
          } else if (keyNodeValue) {
            itemString = keyNodeValue;
          }
          if (filterString[key]) {
            isRowSet = isRowSet && ((itemString != '') ? (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1) : false);
          } else {
            isRowSet = isRowSet && (itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1);
          }
        } else {
          if ((!keyNodeValue || (keyNodeValue <= 0)) && (filterString[key] || ((parseInt(filterString[key]) === 0) || parseInt(filterString[key]) > 0))) {
            isRowSet = false;
          }
        }
      });
      return isRowSet;
    }
    return filterPred;
  }

  protected _DepFilter(): any[] {
    if (this.bonusArr.length <= 0) {
      return;
    }
    if (this.searchGroup && this.searchGroup.controls['bonusFilterControls'].value && (typeof this.searchGroup.controls['bonusFilterControls'].value == 'string') && this.searchGroup.controls['bonusFilterControls'].value.trim() != '') {
      const depfilterValue = this.searchGroup.controls['bonusFilterControls'].value.toLowerCase();
      this.bonusFilteredOptions.next(
        this.bonusArr.filter(dep => (dep.bonus_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.bonusFilteredOptions.next(this.bonusArr.slice());
      return;
    }
  }

  protected _empBonusFilter(): any[] {
    if (this.bonusArr.length <= 0) {
      return;
    }
    if (this.bonusmodalFormGroup && this.bonusmodalFormGroup.controls['employeeBonusFilterControls'].value && (typeof this.bonusmodalFormGroup.controls['employeeBonusFilterControls'].value == 'string') && this.bonusmodalFormGroup.controls['employeeBonusFilterControls'].value.trim() != '') {
      const depfilterValue = this.bonusmodalFormGroup.controls['employeeBonusFilterControls'].value.toLowerCase();
      this.empbonusFilteredOptions.next(
        this.bonusArr.filter(dep => (dep.bonus_name.toLowerCase().indexOf(depfilterValue) > -1))
      );
    } else {
      this.empbonusFilteredOptions.next(this.bonusArr.slice());
      return;
    }
  }

  toggleBonusSelectAll(selectAllValue: boolean) {
    let toSetArr = [];
    this.bonusFilteredOptions.pipe(take(1), takeUntil(this._onBonusDestroy))
      .subscribe((val: any) => {
        if (selectAllValue) {
          val.forEach((valObj: any) => {
            toSetArr.push(valObj.id);
          });
          this.searchGroup.controls['selectedBonus'].patchValue(toSetArr);
        } else {
          this.searchGroup.controls['selectedBonus'].patchValue([]);
        }
      });
  }

  getIndividualBonusList(employeeId) {
    this.tBonusRowNoRecord = false;
    this.tBonusRowErr = false;
    let resultarr = [];
    this.economyService.summaryMonthlyBonus({ "month": this.monthSelected, "year": this.yearSelected, "employee_id": employeeId }).subscribe((res: any) => {
      if (res && res[0].bonus_summary && res[0].bonus_summary.length > 0) {
        res[0].bonus_summary.forEach((obj) => {
          let datasourceObj: any = {};
          datasourceObj = obj;
          resultarr.push(datasourceObj);
        });
        this.bonusSource = new MatTableDataSource(resultarr);
        this.loader = false;
      } else {
        this.bonusSource = new MatTableDataSource([]);
        this.tBonusRowNoRecord = true;
        this.loader = false;
      }
      this._ref.detectChanges();
    }, err => {
      this.tBonusRowErr = true;
      this._ref.detectChanges();
      this.loader = false;
    });
  }

  applyBonusColumnFilter() {
    this.bonusSource.filterPredicate = this.columnwiseFilter();
    this.bonusSource.filter = JSON.stringify(this.bonusColFilter);
    if (this.bonusSource.paginator) {
      this.bonusSource.paginator.firstPage();
    }
  }
}
