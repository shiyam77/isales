import { Component, OnInit, ChangeDetectionStrategy, ViewChild, ChangeDetectorRef } from "@angular/core";
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { CommonErrorStateMatcher } from "../../../../core/models/common-error-state-matcher";
import * as Moment from "moment";
import * as _moment from "moment";
import * as Xlsx from "xlsx";
import { NgbTimeStruct, ModalDismissReasons, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ProfileService } from "../../header/profile/_core/services/profile.service";
import { PersonalService } from "../personal/_core/services/personal.service";
import { SharedService } from "../../../../core/services/pages/shared.service";
import { SpinnerButtonOptions } from "../../../partials/content/general/spinner-button/button-options.interface";
import { FileUploader } from "ng2-file-upload";
import { ImportordertimeService } from "../importordertime/_core/services/importordertime.service";

const URL = 'https://viafoneerp.azurewebsites.net/api/File/DocumentsUploadForLeaves ';

const dateObj = new Date();
const yearMonth = dateObj.getUTCFullYear() + "-" + (dateObj.getUTCMonth() + 1);

@Component({
    selector: "m-leave",
    templateUrl: "./leave.component.html",
    styleUrls: ["./leave.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LeaveComponent implements OnInit {
    public uploader:FileUploader = new FileUploader({url: URL, allowedMimeType: ['image/jpeg','image/jpg','image/png','application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document']});
    isRole: boolean;
    todayDate = Moment().unix();
    reqFilterOptions: any;
    emp_dataSource: any = [];
    displayColumnToShow = [
        "name",
        "mobile",
        "client_name",
        "fromdate",
        "todate",
        "starttime",
        "endtime",
        "created_at",
        "note",
        "document",
        "status",
        "approval_note",
        "actions",
    ];
    leaveDatasource: any = [];
    leavetottRowNoRecord: boolean;
    leavetottRowErr: boolean;
    nameOfFile: any;
    isSticky(column: string): boolean {
        return column === "employee" ? true : false;
    }
    stat: any;
    attendance_id: any;
    dataSource: any;
    loader: boolean = false;
    isLinear = false;
    leaveList: FormGroup;
    addLeave: FormGroup;
    submitted = false;
    matcher = new CommonErrorStateMatcher();
    userData: any = {};
    getUserData: any = {};
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    resMessage: {
        success?: boolean;
        error?: boolean;
        message?: string;
    } = {
        success: false,
        error: false,
        message: "",
    };
    leaveId: any;
    scriveDynamicDownload: any;
    spinners = false;
    schedule: FormGroup;
    errorMsg: string = "";
    selectedMode: string = "leave";
    datas: any = [];
    edit: boolean = false;
    timpepicker: any = [];
    modalRef: any;
    closeResult: any;
    time1: NgbTimeStruct;
    time2: NgbTimeStruct;
    time3: NgbTimeStruct;
    note: string;
    leaves: boolean = false;
    days: string = "";
    start_dates: any;
    end_dates: any;
    empArr: any = [];
    eventData: any = [];
    time = { hour: "", minute: "" };
    ctrl = new FormControl("", (control: FormControl) => {
        const value = control.value;
        if (!value) {
            return null;
        }
    });
    clientProjectsSumArr: Array<any> = [];
    scheduler: FormGroup;
    empLeave: FormGroup;
    leaveStatus: FormGroup;
    start_time: FormControl;
    end_time: FormControl;
    lunch: FormControl;
    leave: FormControl;
    notes: FormControl;
    day: FormControl;
    leaveDate: FormControl;
    leaveNotes: FormControl;
    modified_by: string = "";
    File:string = "";
    isFileName: boolean = false;
    html: any = "";
    itemsPerPage: number = 50;
    itemsInPageList: Array<number> = [50, 100, 500];
    leaveApprovalStatus: string = "";
    spinner: SpinnerButtonOptions = {
        active: false,
        spinnerSize: 18,
        raised: true,
        buttonColor: "primary",
        spinnerColor: "accent",
        fullWidth: false,
    };
    approverName: any = "";
    isLeavePendingList: boolean = true;
    isLeaveApprovedList: boolean = false;
    isLeaveRejectedList: boolean = false;
    isPastLeaveList: boolean = false;
    momentDateFormat = Moment;
    multiColFilter = {
        name: "",
        fromdate: "",
        todate: "",
        start_time: "",
        end_time: "",
        created_time: "",
        note: "",
        document:"",
        status: "",
        approval_note: "",
        client_name: "",
        mobile: "",
    };
    leaveFilterColumns: any = [
        "Names",
        "Mobile",
        "Client_Name",
        "From_Date",
        "To_Date",
        "Start_Time",
        "End_Time",
        "Create_At",
        "Notes",
        "Document",
        "Statuses",
        "Approval_Notes",
        "Action",
    ];
    leavesList: Array<any> = [
        { value: "Ledighet - påverkar timmarna", viewValue: "Ledighet - påverkar timmarna" },
        { value: "Ledighet - påverkar inte timmarna", viewValue: "Ledighet - påverkar inte timmarna" },
    ];
    imageUrl:string;
    filedata: any = new Array<string>();
    uspFile: any = new Array<string>();
    updateUspFileErrMsg: boolean = false;
    uploadOption: any = '0';
    updateErrMsg: boolean = false;
    ErrMsg: boolean = false;
    emp_id : number;
    resCreateMessage: {
        success?: boolean;
        error?: boolean;
    } = {
            success: false,
            error: false
        };

    constructor(
        private _formBuilder: FormBuilder,
        private profileService: ProfileService,
        private _ref: ChangeDetectorRef,
        private personalService: PersonalService,
        private sharedService: SharedService,
        private modalService: NgbModal,
        private impOrderService: ImportordertimeService,
    ) {
        this.getUserData = this.personalService.getRoleAndId();
        this.getUserData.userId.subscribe((id) => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.getUserData.role.subscribe((role) => {
            this.userData.role = role.toString();
        });
    }
    convertBase64ToImage(base64String: string): void {
        this.imageUrl = 'data:image/jpeg;base64,' + base64String;
      }

    ngOnInit() {
        this.sharedService.employeeListSub$.subscribe((isEmployeeListSet) => {
            if (isEmployeeListSet) {
                this.sharedService.allEmployeeListData.forEach((obj) => {
                    this.empArr.push({
                        id: obj.Employee_id,
                        name: obj.first_name + " " + obj.last_name,
                    });
                });
            }
        });
        this.leaveForm();
        this.loadEmployee();
        this.loadLeaveEmployee();
        this.onSelectionChange({ value: "leave" });
        this.leaveStatus = this._formBuilder.group({
            leave_status: ["", Validators.required],
        });
        this.onSelectionChange({ value: "leave" });
    }

    loadEmployee() {
        this.sharedService.getAllEmployees().subscribe((res) => {
            res.forEach((obj) => {
                this.empArr.push({
                    id: obj.Employee_id,
                    name: obj.first_name + " " + obj.last_name,
                });
            });
        });
    }

    loadLeaveEmployee() {
        this.loader = true;
        let toSendReq: any = {
            status: "",
        };
        if (!this.isLeaveApprovedList && this.isLeavePendingList && !this.isLeaveRejectedList && !this.isPastLeaveList) {
            toSendReq.status = "Pending";
            this.displayColumnToShow = [
                "name",
                "mobile",
                "client_name",
                "fromdate",
                "todate",
                "created_at",
                "note",
                "document",
                "status",
                "approval_note",
                "actions",
            ];
            this.leaveFilterColumns = [
                "Names",
                "Mobile",
                "Client_Name",
                "From_Date",
                "To_Date",
                "Create_At",
                "Notes",
                "Document",
                "Statuses",
                "Approval_Notes",
                "Action",
            ];
        }
        if (this.isLeaveApprovedList && !this.isLeavePendingList && !this.isLeaveRejectedList && !this.isPastLeaveList) {
            toSendReq.status = "Approved";
            this.displayColumnToShow = [
                "name",
                "mobile",
                "client_name",
                "fromdate",
                "todate",
                "created_at",
                "note",
                "status",
                "approval_note",
                "actions",
            ];
            this.leaveFilterColumns = [
                "Names",
                "Mobile",
                "Client_Name",
                "From_Date",
                "To_Date",
                "Create_At",
                "Notes",
                "Statuses",
                "Approval_Notes",
                "Action",
            ];
        }
        if (!this.isLeaveApprovedList && !this.isLeavePendingList && this.isLeaveRejectedList && !this.isPastLeaveList) {
            toSendReq.status = "Rejected";
            this.displayColumnToShow = [
                "name",
                "mobile",
                "client_name",
                "fromdate",
                "todate",
                "created_at",
                "note",
                "status",
                "approval_note",
            ];
            this.leaveFilterColumns = [
                "Names",
                "Mobile",
                "Client_Name",
                "From_Date",
                "To_Date",
                "Create_At",
                "Notes",
                "Statuses",
                "Approval_Notes",
            ];
        }
        if(!this.isLeaveApprovedList && !this.isLeavePendingList && !this.isLeaveRejectedList && this.isPastLeaveList){
            toSendReq.status = "Approved1";
            this.displayColumnToShow = [
                "name",
                "mobile",
                "client_name",
                "fromdate",
                "todate",
                "created_at",
                "note",
                "status",
                "approval_note",
                "actions",
            ];
            this.leaveFilterColumns = [
                "Names",
                "Mobile",
                "Client_Name",
                "From_Date",
                "To_Date",
                "Create_At",
                "Notes",
                "Statuses",
                "Approval_Notes",
                "Action",
            ];
        }
        this.sharedService.getAllLeave(toSendReq).subscribe(
            (res: any) => {
                            console.log(res)
                this.loader = false;
                if (res) {
                    res.forEach((elObj: any) => {
                        if (elObj.start_time) {
                            elObj.start_time = elObj.start_time.split(":")[0] + ":" + elObj.start_time.split(":")[1];
                        }
                        if (elObj.end_time) {
                            elObj.end_time = elObj.end_time.split(":")[0] + ":" + elObj.end_time.split(":")[1];
                        }
                        if (elObj.created_time) {
                            elObj.created_at = elObj.created_time;
                        }
                        if(elObj.filename) {
                            this.nameOfFile = elObj.filename.split('-').slice(1).join('-');
                            elObj.filename = this.nameOfFile;
                        }
                    });
                    this.leaveDatasource = new MatTableDataSource(res);
                    this.leaveDatasource.paginator = this.paginator;
                    this.leaveDatasource.sort = this.sort;
                    this.leaveDatasource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split(".").reduce((o, i) => o[i], item);
                        if (typeof sortString === "string") {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    };
                    if (this.leaveDatasource.data.length > 0) {
                        this.leavetottRowErr = false;
                        this.leavetottRowNoRecord = false;
                    } else {
                        this.leavetottRowErr = false;
                        this.leavetottRowNoRecord = true;
                    }

                    this._ref.detectChanges();
                } else {
                    this.leavetottRowErr = false;
                    this.leavetottRowNoRecord = true;
                    this._ref.detectChanges();
                }
            },
            (err) => {
                this.loader = false;
                this.leavetottRowErr = true;
                this.leavetottRowNoRecord = false;
                this._ref.detectChanges();
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            }
        );
    }

    leaveForm() {
        this.addLeave = this._formBuilder.group({
            employee: ["", [Validators.required]],
            fromdate: ["", Validators.required],
            todate: ["", Validators.required],
            note: ["", Validators.required],
            start_time: ["", Validators.required],
            end_time: ["", Validators.required],
            options: ["leave"],
            approval_note: [""],
            leave_status: ["", Validators.required],
        });
    }

    onSelectionChange(event: any) {
        this.selectedMode = event.value;
        if (this.selectedMode == "permission") {
            this.addLeave.controls["todate"].setErrors(null);
        } else {
            this.addLeave.controls["start_time"].setErrors(null);
            this.addLeave.controls["end_time"].setErrors(null);
        }
    }

    submitStatus() {
        this.spinner.active = true;
        let datas: any = {
            leave_id: this.leaveId,
            status: this.leaveApprovalStatus,
            admin_notes: this.addLeave.controls["approval_note"].value,
            leave_status: this.addLeave.controls["leave_status"].value,
            approver_id: this.userData.id,
        };
        if (this.leaveApprovalStatus == "Deleted") {
            delete datas.admin_notes;
        }
        this.sharedService.getApproveLeave(datas).subscribe(
            (res: any) => {
                this.spinner.active = false;
                if (res[0].message === "Leave status updated successfully") {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                    if (this.userData.role === "admin" || this.userData.role === "superadmin") {
                        this.sharedService.getNotifications().subscribe((notificationData) => {
                            if (notificationData && notificationData.count) {
                                this.sharedService.notificationSub.next(notificationData.count);
                            }
                        });
                    }
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this.loadLeaveEmployee();
                this._ref.detectChanges();
                this.modalRef.close();
                this.resetAlert();
            },
            (err) => {
                this.spinner.active = false;
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            }
        );
    }

    submitLeave() {
        if (this.selectedMode != "permission") {
            this.addLeave.controls["start_time"].setErrors(null);
            this.addLeave.controls["end_time"].setErrors(null);
            this.addLeave.controls["leave_status"].setErrors(null);
        }
        if (this.selectedMode == "permission") {
            this.addLeave.controls["todate"].setErrors(null);
            this.addLeave.controls["leave_status"].setErrors(null);
        }
        if (this.addLeave.status == "VALID") {
            let toSendFromDate = Moment(this.addLeave.value.fromdate)
                .set({ hour: 0, minute: 0, second: 0 })
                .format("YYYY-MM-DDTHH:mm:ss");
            let toSendToDate =
                this.selectedMode == "leave"
                    ? Moment(this.addLeave.value.todate)
                          .set({ hour: 0, minute: 0, second: 0 })
                          .format("YYYY-MM-DDTHH:mm:ss")
                    : toSendFromDate;
            toSendFromDate = toSendFromDate + "Z";
            toSendToDate = toSendToDate + "Z";
            let startTime =
                this.selectedMode == "permission"
                    ? this.addLeave.value.start_time.hour + ":" + this.addLeave.value.start_time.minute
                    : "";
            let endTime =
                this.selectedMode == "permission"
                    ? this.addLeave.value.end_time.hour + ":" + this.addLeave.value.end_time.minute
                    : "";
            let datas = {
                leave: [
                    {
                        note: this.addLeave.value.note,
                        fromdate: toSendFromDate,
                        todate: toSendToDate,
                        start_time: startTime,
                        end_time: endTime,
                        leave_id: "",
                        modified_by: this.userData.id,
                    },
                ],
                Employee_id: this.addLeave.value.employee,
            };
            if(this.edit == true){
                datas.leave[0].leave_id = this.leaveId;
            }
            this.profileService.updateLeave(datas).subscribe(
                (res: any) => {
                    if (res.message === "Updated Successfully") {
                        if (this.filedata.length != 0 && this.uploader.queue.length != 0) {
                            this.UploadFile();
                        }
                        else{
                            this.loadLeaveEmployee();
                        }
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                    } else {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                    }
                    this._ref.detectChanges();
                    this.modalRef.close();
                    this.resetAlert();
                },
                (err) => {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this._ref.detectChanges();
                    this.resetAlert();
                }
            );
        }
    }

    openModal(content, contentAccessId, toContent?) {
        this.addLeave.enable();
        if (content == "ledghit") {
            this.uploader.clearQueue();
            this.isFileName = false;
            this.edit = false;
            this.addLeave.reset();
            this.leaveId = null;
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });
        } else if (content == "edit_ledghit") {
            this.uploader.clearQueue();
            this.edit = true;
            this.modified_by = "";
            this.filedata = [];
            if(toContent.filename){
                this.File = toContent.filename;
                this.isFileName = true;
            }
            if (toContent.leave_id) {
                this.leaveId = toContent.leave_id;
            }
            this.empArr.forEach((val) => {
                if (val.id == toContent.modifier_id) {
                    this.modified_by = val.name;
                }
            })
            this.addLeave.patchValue({
                employee: toContent.employee_id,
            });
            let start = toContent.start_time ? toContent.start_time : "00:00:00";
            let end = toContent.end_time ? toContent.end_time : "00:00:00";
            let time_start = start.split(":");
            let time_end = end.split(":");
            this.time1 = { hour: parseInt(time_start[0]), minute: parseInt(time_start[1]), second: 0 };
            this.time2 = { hour: parseInt(time_end[0]), minute: parseInt(time_end[1]), second: 0 };
            this.addLeave.controls["fromdate"].setValue(toContent.fromdate);
            this.addLeave.controls["todate"].setValue(toContent.todate);
            this.addLeave.controls["note"].setValue(toContent.note);
            if (!toContent.start_time && !toContent.end_time) {
                this.addLeave.controls["options"].setValue("leave");
                this.onSelectionChange({ value: "leave" });
            } else {
                this.addLeave.controls["options"].setValue("permission");
                this.onSelectionChange({ value: "permission" });
            }
            this.addLeave.addControl("leave_id", new FormControl(toContent.leave_id));
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });
            this.empArr.push({
                id: toContent.employee_id,
                name: toContent.first_name + " " + toContent.last_name,
            });
        } else if (content == "notes") {
            this.addLeave.patchValue({
                note: toContent.note,
            });
            this.addLeave.disable();
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-timersattning-modal",
                backdrop: "static",
            });
        } else if (content == "approval") {
            if (this.leaveApprovalStatus != "Deleted") {
                this.addLeave.patchValue({
                    approval_note: toContent.approval_note,
                    leave_status: "",
                });
                this.addLeave.enable();
            }
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-timersattning-modal",
                backdrop: "static",
            });
        } else if (content == "approval_note") {
            this.addLeave.patchValue({
                approval_note: toContent.approval_note,
            });
            if (toContent.leave_id) {
                this.leaveId = toContent.leave_id;
            }
            if (toContent.status) {
                this.leaveApprovalStatus = toContent.status;
            }
            if (toContent.approval_note) {
                this.approverName = toContent.approver_firstname + " " + toContent.approver_lastname;
            }
            this.addLeave.enable();
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-timersattning-modal",
                backdrop: "static",
            });
        }
        this.modalRef.result.then(
            (result) => {
                this.closeResult = `Closed with: ${result}`;
            },
            (reason) => {
                this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
            }
        );
    }
    removeFileName(){
        this.File = "";
        if(this.uploader.queue.length >= 0){
            this.isFileName = false;
        }
        this.ErrMsg = false;
    }
    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return "by pressing ESC";
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return "by clicking on a backdrop";
        } else {
            return `with: ${reason}`;
        }
    }

    private resetAlert() {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this.updateUspFileErrMsg = false;
            this.updateErrMsg = false;
            this._ref.detectChanges();
        }, 5000);
    }

    setApprovalDetails(leaveData, modalContent, approvalStatus) {
        this.leaveApprovalStatus = approvalStatus;

        if (approvalStatus == "Approved") {
            this.leaveId = leaveData.leave_id;
        } else if (approvalStatus == "Deleted") {
            this.leaveId = leaveData;
        } else if (approvalStatus == "Rejected") {
            this.leaveId = leaveData.leave_id;
        }

        if (leaveData.role == "sales") {
            this.isRole = true;
        } else {
            this.isRole = false;
        }
        this.openModal("approval", modalContent, leaveData);
    }

    toggleApprovedLeaveList(isApproved: boolean, isPending?: boolean, isRejected?: boolean, isPastLeave?: boolean) {
            this.isLeaveApprovedList = isApproved;
            this.isLeavePendingList = isPending;
            this.isLeaveRejectedList = isRejected;
            this.isPastLeaveList = isPastLeave;
            this.loadLeaveEmployee();
    }

    applyColumnFilter() {
        this.leaveDatasource.filterPredicate = this.columnwiseFilter();
        this.leaveDatasource.filter = JSON.stringify(this.multiColFilter);
        if (this.leaveDatasource.paginator) {
            this.leaveDatasource.paginator.firstPage();
        }
    }

    private columnwiseFilter() {
        let filterPred = (item, filter) => {
            let filterString = JSON.parse(filter);
            let isRowSet: boolean = true;
            Object.keys(filterString).forEach((key) => {
                let keyNodeValue: any;
                if (key != "name") {
                    keyNodeValue = key.split(".").reduce((o, i) => {
                        if (o) {
                            return o[i];
                        }
                    }, item);
                } else {
                    let nameKey1 = "first_name";
                    let nameKey2 = "last_name";
                    keyNodeValue = nameKey1.split(".").reduce((o, i) => {
                        if (o) {
                            return o[i];
                        }
                    }, item);
                    keyNodeValue +=
                        " " +
                        nameKey2.split(".").reduce((o, i) => {
                            if (o) {
                                return o[i];
                            }
                        }, item);
                }
                if (key == "fromdate" || key == "todate") {
                    if (key == "fromdate") {
                        let nameKey1 = "fromdate";
                        let nameKey2 = "start_time";
                        let toAppendKNV = nameKey1.split(".").reduce((o, i) => {
                            if (o) {
                                return o[i];
                            }
                        }, item);
                        keyNodeValue = Moment(toAppendKNV).format("YYYY-MM-DD");
                        let toAppendKNV2 =
                            " " +
                            nameKey2.split(".").reduce((o, i) => {
                                if (o) {
                                    return o[i];
                                }
                            }, item);
                        if (toAppendKNV2 != " undefined" && toAppendKNV2 != " null") {
                            keyNodeValue += toAppendKNV2;
                        }
                    }
                    if (key == "todate") {
                        let nameKey1 = "todate";
                        let nameKey2 = "end_time";
                        let toAppendKNV = nameKey1.split(".").reduce((o, i) => {
                            if (o) {
                                return o[i];
                            }
                        }, item);
                        keyNodeValue = Moment(toAppendKNV).format("YYYY-MM-DD");
                        let toAppendKNV2 =
                            " " +
                            nameKey2.split(".").reduce((o, i) => {
                                if (o) {
                                    return o[i];
                                }
                            }, item);
                        if (toAppendKNV2 != " undefined" && toAppendKNV2 != " null") {
                            keyNodeValue += toAppendKNV2;
                        }
                    }
                }
                if ((keyNodeValue && filterString[key]) || (keyNodeValue >= 0 && filterString[key] >= 0)) {
                    let itemString = "";
                    if (keyNodeValue && typeof keyNodeValue != "string") {
                        itemString = keyNodeValue.toString();
                    } else if (keyNodeValue) {
                        itemString = keyNodeValue;
                    }
                    if (filterString[key]) {
                        isRowSet =
                            isRowSet &&
                            (itemString != ""
                                ? itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1
                                : false);
                    } else {
                        isRowSet =
                            isRowSet &&
                            itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1;
                    }
                } else {
                    if (
                        (!keyNodeValue || keyNodeValue <= 0) &&
                        (filterString[key] || parseInt(filterString[key]) === 0 || parseInt(filterString[key]) > 0)
                    ) {
                        isRowSet = false;
                    }
                }
            });
            return isRowSet;
        };
        return filterPred;
    }

    applyFilter(filterValue: string) {
        this.dataSource.filterPredicate = (item, filter) => {
            let filterString =
                item.Employee_id +
                item.personal_id +
                item.first_name +
                item.last_name +
                item.contact[0].email +
                item.contact[0].mobile +
                item.contact[0].place +
                item.department +
                item.loxysoft_id;
            filterString = filterString.trim().toLocaleLowerCase();
            return filterString.indexOf(filter) != -1;
        };
        this.dataSource.filter = filterValue.trim().toLowerCase();
        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    }

    submitLeaveDetails() {
        let leaveData: any = {};
        leaveData.leave = this.leaveList.controls["leaveListFormArray"].value;
        leaveData.leave.forEach((obj) => {
            let toSendFromDate = Moment(obj.fromdate)
                .set({ hour: 0, minute: 0, second: 0 })
                .format("YYYY-MM-DDTHH:mm:ss");
            let toSendToDate = Moment(obj.todate).set({ hour: 0, minute: 0, second: 0 }).format("YYYY-MM-DDTHH:mm:ss");
            toSendFromDate = toSendFromDate + "Z";
            toSendToDate = toSendToDate + "Z";
            obj.fromdate = toSendFromDate;
            obj.todate = toSendToDate;
        });
        this.profileService.updateLeave(leaveData).subscribe(
            (res: any) => {
                if (res.message === "Updated Successfully") {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                }
                this.resetForm(this.addLeave);
                this.modalRef.close();
                this._ref.detectChanges();
                this.resetAlert();
            },
            (err) => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            }
        );
    }

    downloadLeaveDoc(client) {
        this.personalService.getLeaveDoc(client.leave_id).subscribe((res: any) => {
            if (res) {
                if (!this.scriveDynamicDownload) {
                    this.scriveDynamicDownload = document.createElement('a');
                }
                const element = this.scriveDynamicDownload;
                const dFileName = `${client.first_name.trim()}_${client.last_name.trim()}_${_moment().format("YYYY-MM-DD")}`;
                if (res.fileType == 'application/msword') {

                    element.setAttribute('href', `data:application/msword;base64,${res.document_bytes}`);
                }
                else if (res.fileType == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {

                    element.setAttribute('href', `data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,${res.document_bytes}`)
                }
                else if (res.fileType == 'application/pdf') {
                    element.setAttribute('href', `data:application/pdf;base64,${res.document_bytes}`);

                }
                else {
                    const val = res.document_bytes;
                    this.convertBase64ToImage(val);
                    element.setAttribute('href', `${this.imageUrl}`);
                }
                element.setAttribute('download', dFileName);
                var event = new MouseEvent("click");
                element.dispatchEvent(event);
                this.resMessage.success = true;
                this.resMessage.error = false;
                this.resetAlert();
            } 
        },err => {
            this.resMessage.success = false;
            this.resMessage.error = true;
            this.resetAlert();
        });
    }

    dropped(event) {
        this.updateUspFileErrMsg = false;
        this.filedata = [];
        this.uspFile = [];
        
    
        for (let i = 0; i < event.length; i++) {
          if (event[i].type != "image/jpeg" && event[i].type != "image/jpg" && event[i].type != "image/png" && event[i].type != "application/pdf" && event[i].type != "application/msword" && event[i].type != "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
            this.updateUspFileErrMsg = true;
            this.uspFile.push(event[i].name);
            this.resetAlert();
          }
        }
        if(this.isFileName == true){
            this.ErrMsg = true;
        }
        if (this.uploader.queue.length > 1){
            this.uploader.queue.length = 1;
            this.filedata.push(this.uploader.queue[0]);
            this.updateErrMsg = true;
            this.resetAlert();
        }
        else if (this.uploader.queue.length === 1) {
          this.filedata.push(this.uploader.queue[0]);
        } else {
          for (let i = 0; i < this.uploader.queue.length; i++) {
            this.filedata.push(this.uploader.queue[i]);
          }
        }
    }
    
    UploadFile() {
        if (this.filedata.length != 0) {
            this.emp_id = this.addLeave.value.employee;
            this.impOrderService.uploadDocumentsForLeave(this.filedata, this.uploadOption, this.emp_id).subscribe((res: any) => {
                if (res && res.message == "Uploaded Successfully") {
                    this.resCreateMessage.success = true;
                    this.resCreateMessage.error = false;
                    this.loadLeaveEmployee();
                    this._ref.detectChanges();
                    this.resetAlert();
                }
            }, err => {
                this.resCreateMessage.success = false;
                this.resCreateMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
                this.loadLeaveEmployee();
            });
        }
    }
    resetForm(form: FormGroup) {
        form.reset();
        Object.keys(form.controls).forEach((key) => {
            form.get(key).setErrors(null);
        });
    }

    generateAndDownloadDoc() {
        if (this.userData.role === "admin" || this.userData.role === "superadmin") {
            /* generate worksheet */
            const ws: Xlsx.WorkSheet = Xlsx.utils.json_to_sheet(this.leaveDatasource.data);
            /* generate workbook and add the worksheet */
            const wb: Xlsx.WorkBook = Xlsx.utils.book_new();
            Xlsx.utils.book_append_sheet(wb, ws, "Sheet 1");

            let listType = this.isLeavePendingList ? "Pending" : this.isLeaveApprovedList ? "Approved" : this.isPastLeaveList ? "Approved_Archived" : "Rejected";

            /* save to file */
            Xlsx.writeFile(wb, "Leave_List_" + listType + "_" + _moment().format("x") + ".xlsx", {
                bookType: "xlsx",
                type: "array",
            });
        }
    }
}
