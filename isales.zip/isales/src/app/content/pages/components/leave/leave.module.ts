import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeaveComponent } from './leave.component';

import { RouterModule } from '@angular/router';
import { LayoutModule } from '../../../layout/layout.module';
import { PartialsModule } from '../../../partials/partials.module';
import { ListTimelineModule } from '../../../partials/layout/quick-sidebar/list-timeline/list-timeline.module';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
import { PersonalService } from '../personal/_core/services/personal.service';
import { NgbModule, NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import {
    MatInputModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatSliderModule,
    MatListModule,
    MatCardModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    MatMenuModule,
    MatTabsModule,
    MatTooltipModule,
    MatSidenavModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatGridListModule,
    MatTableModule,
    MatExpansionModule,
    MatToolbarModule,
    MatSortModule,
    MatDividerModule,
    MatStepperModule,
    MatChipsModule,
    MatPaginatorModule,
    MatDialogModule,
    MatRadioModule,
    MatPaginatorIntl,
} from '@angular/material';
import { FileUploadModule } from 'ng2-file-upload';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
};

const swedishRangeLabel = (page: number, pageSize: number, length: number) => {
    if (length == 0 || pageSize == 0) { return `0 av ${length}`; }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    // If the start index exceeds the list length, do not try and fix the end index to the end.
    const endIndex = startIndex < length ?
        Math.min(startIndex + pageSize, length) :
        startIndex + pageSize;
    return `${startIndex + 1} - ${endIndex} av ${length}`;
  }
  
  function getSwedishPaginatorIntl() {
    const paginatorIntl = new MatPaginatorIntl();
    paginatorIntl.itemsPerPageLabel = 'Objekt per sida:';
    paginatorIntl.getRangeLabel = swedishRangeLabel;
    return paginatorIntl;
  }

@NgModule({
    imports: [
        CommonModule,
        LayoutModule,
        PartialsModule,
        NgbModule,
        ListTimelineModule,
        WidgetChartsModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild([
            {
                path: '',
                component: LeaveComponent,
                data:{
					permissions:{
						only:['admin','superadmin'],
						redirectTo:'/my-salary/list'
					}
				}
            }
        ]),
        NgxPermissionsModule.forChild(),
        MatInputModule,
        MatDatepickerModule,
        MatFormFieldModule,
        MatAutocompleteModule,
        MatSliderModule,
        MatListModule,
        MatCardModule,
        MatSelectModule,
        MatButtonModule,
        MatIconModule,
        MatNativeDateModule,
        MatSlideToggleModule,
        MatCheckboxModule,
        MatMenuModule,
        MatTabsModule,
        MatTooltipModule,
        MatSidenavModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatSnackBarModule,
        MatGridListModule,
        MatTableModule,
        MatExpansionModule,
        MatToolbarModule,
        MatSortModule,
        MatDividerModule,
        MatStepperModule,
        MatChipsModule,
        MatPaginatorModule,
        MatDialogModule,
        MatRadioModule,
        TranslateModule.forChild(),
        FullCalendarModule,
        PerfectScrollbarModule,
        FileUploadModule
    ],
    providers: [PersonalService,
        NgbAlertConfig, 
        {
            provide: PERFECT_SCROLLBAR_CONFIG,
            useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
        },
        { provide: MatPaginatorIntl, useValue: getSwedishPaginatorIntl() }
    ],
    declarations: [LeaveComponent]
})
export class LeaveModule { }
