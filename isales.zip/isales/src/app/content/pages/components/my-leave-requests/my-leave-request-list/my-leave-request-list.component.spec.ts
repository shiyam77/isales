import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyLeaveRequestListComponent } from './my-leave-request-list.component';

describe('MyLeaveRequestListComponent', () => {
  let component: MyLeaveRequestListComponent;
  let fixture: ComponentFixture<MyLeaveRequestListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyLeaveRequestListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyLeaveRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
