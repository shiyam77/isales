
import { NgModule, LOCALE_ID } from '@angular/core';
import { CommonModule, registerLocaleData } from '@angular/common';

import { AngularEditorModule } from '@kolkov/angular-editor';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import {
	MatIconRegistry,
	MatInputModule,
	MatDatepickerModule,
	MatFormFieldModule,
	MatAutocompleteModule,
	MatSliderModule,
	MatListModule,
	MatCardModule,
	MatSelectModule,
	MatButtonModule,
	MatIconModule,
	MatNativeDateModule,
	MatSlideToggleModule,
	MatCheckboxModule,
	MatMenuModule,
	MatTabsModule,
	MatTooltipModule,
	MatSidenavModule,
	MatProgressBarModule,
	MatProgressSpinnerModule,
	MatSnackBarModule,
	MatGridListModule,
	MatTableModule,
	MatExpansionModule,
	MatToolbarModule,
	MatSortModule,
	MatDividerModule,
	MatStepperModule,
	MatChipsModule,
	MatPaginatorModule,
	MatDialogModule,
	MatRadioModule,
	MAT_DATE_LOCALE,
	MAT_DATE_FORMATS,
	DateAdapter,
	MatPaginatorIntl
} from '@angular/material';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { QRCodeModule } from 'angularx-qrcode';
import { TranslateModule } from '@ngx-translate/core';
import { PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface, PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { FullCalendarModule } from 'ng-fullcalendar';
import { NgxPermissionsModule } from 'ngx-permissions';
import localeSvSe from '@angular/common/locales/sv';
import { CoreModule } from '../../../../core/core.module';
import { PartialsModule } from '../../../partials/partials.module';
import { WidgetChartsModule } from '../../../partials/content/widgets/charts/widget-charts.module';
import { ProfileService } from '../../header/profile/_core/services/profile.service';
import { PersonalService } from '../personal/_core/services/personal.service';
import { CommonInterceptService } from '../../../../core/services/common-intercept.service';
import { SubheaderService } from '../../../../core/services/layout/subheader.service';
import { SharedService } from '../../../../core/services/pages/shared.service';
import { EconomyService } from '../economy/_core/services/economy.service';
import { RouterModule } from '@angular/router';
import { MyLeaveRequestListComponent } from './my-leave-request-list/my-leave-request-list.component';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { FileUploadModule } from 'ng2-file-upload';

registerLocaleData(localeSvSe);

export const MY_FORMATS = {
	parse: {
	  dateInput: 'LL',
	},
	display: {
	  dateInput: 'YYYY-MM-DD',
	  monthYearLabel: 'YYYY',
	  dateA11yLabel: 'LL',
	  monthYearA11yLabel: 'YYYY',
	},
};

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
};

const swedishRangeLabel = (page: number, pageSize: number, length: number) => {
	if (length == 0 || pageSize == 0) { return `0 av ${length}`; }
	length = Math.max(length, 0);
	const startIndex = page * pageSize;
	// If the start index exceeds the list length, do not try and fix the end index to the end.
	const endIndex = startIndex < length ?
		Math.min(startIndex + pageSize, length) :
		startIndex + pageSize;
	return `${startIndex + 1} - ${endIndex} av ${length}`;
  }
  
  
  function getSwedishPaginatorIntl() {
	const paginatorIntl = new MatPaginatorIntl();
	paginatorIntl.itemsPerPageLabel = 'Objekt per sida:'; 
	paginatorIntl.getRangeLabel = swedishRangeLabel;
	return paginatorIntl;
  }

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
		ReactiveFormsModule,
		CoreModule,
		PartialsModule,
		AngularEditorModule,
		MatInputModule,
		MatDatepickerModule,
		MatFormFieldModule,
		MatAutocompleteModule,
		MatSliderModule,
		MatListModule,
		MatCardModule,
		MatSelectModule,
		MatButtonModule,
		MatIconModule,
		MatNativeDateModule,
		MatSlideToggleModule,
		MatCheckboxModule,
		MatMenuModule,
		MatTabsModule,
		MatTooltipModule,
		MatSidenavModule,
		MatProgressBarModule,
		MatProgressSpinnerModule,
		MatSnackBarModule,
		MatGridListModule,
		MatTableModule,
		MatExpansionModule,
		MatToolbarModule,
		MatSortModule,
		MatDividerModule,
		MatStepperModule,
		MatChipsModule,
		MatPaginatorModule,
		MatDialogModule,
		MatRadioModule,
		QRCodeModule,
		WidgetChartsModule,
		TranslateModule,
		NgbModule,
		FullCalendarModule,
		PerfectScrollbarModule,
		FileUploadModule,
		RouterModule.forChild([
			{
			path: '',
			component: MyLeaveRequestListComponent
			}
		]),
		NgxPermissionsModule.forChild()
	],
	providers: [
		MatIconRegistry,
		ProfileService,
		PersonalService,
		{
            provide: HTTP_INTERCEPTORS,
            useClass: CommonInterceptService,
            multi: true
		},
		NgbAlertConfig, 
		{
			provide: PERFECT_SCROLLBAR_CONFIG,
			useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
		},
		SubheaderService,
		SharedService,
		EconomyService,
		{
			provide: LOCALE_ID,
			useValue:'sv-SE'
		},
		{provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
		{provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
		{ provide: MatPaginatorIntl, useValue: getSwedishPaginatorIntl() }
  ],
  declarations:[MyLeaveRequestListComponent]
})
export class MyLeaveRequestsModule { }
