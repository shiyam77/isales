import { Component, OnInit, ViewChild, ChangeDetectorRef, Inject } from "@angular/core";
import { FormGroup, Validators, FormControl, FormBuilder, AbstractControl } from "@angular/forms";
import { MatDatepickerInputEvent, MatPaginator, MatSort, MatStepper, MatTableDataSource } from "@angular/material";
import { NgbTimeStruct, NgbModal, ModalDismissReasons } from "@ng-bootstrap/ng-bootstrap";
import * as _moment from "moment";
import { ProfileService } from "../../../header/profile/_core/services/profile.service";
import { PersonalService } from "../../personal/_core/services/personal.service";
import { SharedService } from "../../../../../core/services/pages/shared.service";
import { SpinnerButtonOptions } from "../../../../partials/content/general/spinner-button/button-options.interface";
import { FileUploader } from "ng2-file-upload";
import { DOCUMENT } from '@angular/platform-browser';
import { ImportordertimeService } from "../../importordertime/_core/services/importordertime.service";
const URL = 'https://viafoneerp.azurewebsites.net/api/File/DocumentsUploadForLeaves ';
@Component({
    selector: "m-my-leave-request-list",
    templateUrl: "./my-leave-request-list.component.html",
    styleUrls: ["./my-leave-request-list.component.scss"],
})
export class MyLeaveRequestListComponent implements OnInit {
    public uploader:FileUploader = new FileUploader({url: URL, allowedMimeType: ['image/jpeg','image/jpg','image/png','application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document']});
    fTotOrder: number = 0;
    fRejOrder: number = 0;
    fTotProvision: number = 0;
    fTotTimlon: number = 0;
    fTotlon: number = 0;
    fTotLonInkSem: number = 0;
    fTotLonInkSoc: number = 0;
    fTotHour: number = 0;
    fTotMin: number = 0;
    fTotsec: number = 0;
    fTotTime: string = "00:00:00";
    attendanceStatuswiseSummaryData: any = {};
    attendanceSummaryMonthYear: any = {
        month: "",
        year: "",
    };
    loader: boolean = false;
    submitted = false;
    espDetail: Array<any> = [];
    userData: any = {};
    getUserData: any = {};
    filedata: any = new Array<string>();
    uspFile: any = new Array<string>();
    updateUspFileErrMsg: boolean = false;
    uploadOption: any = '0';
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    resMessage: {
        success?: boolean;
        error?: boolean;
        message?: string;
    } = {
        success: false,
        error: false,
        message: "",
    };

    
      resCreateMessage: {
        success?: boolean;
        error?: boolean;
      } = {
          success: false,
          error: false
        };

    salaryYearSelected = 2020;
    spinners = false;
    week: any = [
        "",
        {
            day: "Mån",
            start_time: { hour: "", minute: "" },
            end_time: { hour: "", minute: "" },
            lunch: { hour: "", minute: "" },
            status: { start_time: false, end_time: false, lunch: false },
        },
        {
            day: "Tis",
            start_time: { hour: "", minute: "" },
            end_time: { hour: "", minute: "" },
            lunch: { hour: "", minute: "" },
            status: { start_time: false, end_time: false, lunch: false },
        },
        {
            day: "Ons",
            start_time: { hour: "", minute: "" },
            end_time: { hour: "", minute: "" },
            lunch: { hour: "", minute: "" },
            status: { start_time: false, end_time: false, lunch: false },
        },
        {
            day: "Tor",
            start_time: { hour: "", minute: "" },
            end_time: { hour: "", minute: "" },
            lunch: { hour: "", minute: "" },
            status: { start_time: false, end_time: false, lunch: false },
        },
        {
            day: "Fre",
            start_time: { hour: "", minute: "" },
            end_time: { hour: "", minute: "" },
            lunch: { hour: "", minute: "" },
            status: { start_time: false, end_time: false, lunch: false },
        },
        {
            day: "Lör",
            start_time: { hour: "", minute: "" },
            end_time: { hour: "", minute: "" },
            lunch: { hour: "", minute: "" },
            status: { start_time: false, end_time: false, lunch: false },
        },
        {
            day: "Sön",
            start_time: { hour: "", minute: "" },
            end_time: { hour: "", minute: "" },
            lunch: { hour: "", minute: "" },
            status: { start_time: false, end_time: false, lunch: false },
        },
    ];

    schedule: FormGroup;
    timings: any = ["Fran", "Till", "Lunch"];
    errorMsg: string = "";
    datas: any = [];
    timpepicker: any = [];
    modalRef: any;
    modalConfirmRef: any;
    closeResult: any;
    time1: NgbTimeStruct;
    time2: NgbTimeStruct;
    time3: NgbTimeStruct;
    note: string;
    leaves: boolean = false;
    days: string = "";
    start_dates: any;
    end_dates: any;
    empLeave: FormGroup;
    html: any = "";
    addLeave: FormGroup;
    selectedMode: string = "leave";
    displayColumnToShow = [
        "fromdate",
        "todate",
        "starttime",
        "endtime",
        "created_at",
        "notes",
        "status",
        "approval_note",
        "actions",
    ];
    leaveDatasource: any = [];
    todayDate = _moment().unix();
    itemsPerPage: number = 50;
    itemsInPageList: Array<number> = [50, 100, 500];
    isLeavePendingList: boolean = true;
    isLeaveApprovedList: boolean = false;
    isLeaveRejectedList: boolean = false;
    momentDateFormat = _moment;
    leavetottRowErr: boolean = false;
    leavetottRowNoRecord: boolean = false;
    multiColFilter = {
        name: "",
        fromdate: "",
        todate: "",
        start_time: "",
        end_time: "",
        created_time: "",
        note: "",
        status: "",
        approval_note: "",
    };
    minLeaveApplicationDate: any = _moment(new Date()).add(6, "days").format("YYYY-MM-DD");
    minLeaveApplicationToDate: any = _moment(new Date()).add(6, "days").format("YYYY-MM-DD");
    minPermissionApplicationDate: any = _moment().format("YYYY-MM-DD");
    deleteErrMsg: boolean = false;
    updateErrMsg: boolean = false;
    spinner: SpinnerButtonOptions = {
        active: false,
        spinnerSize: 18,
        raised: true,
        buttonColor: "primary",
        spinnerColor: "accent",
        fullWidth: false,
    };
    delLeaveData: any;
    isValidFromDate: boolean = false;
    isValidToDate: boolean = false;
    emp_id : number;

    constructor(
        private _formBuilder: FormBuilder,
        private profileService: ProfileService,
        private _ref: ChangeDetectorRef,
        private personalService: PersonalService,
        private sharedService: SharedService,
        @Inject(DOCUMENT) private documentObj: Document,
        private impOrderService: ImportordertimeService,
        private modalService: NgbModal
    ) {}

    monthList = [
        { label: "Januari", value: 1 },
        { label: "Februari", value: 2 },
        { label: "Mars", value: 3 },
        { label: "April", value: 4 },
        { label: "Maj", value: 5 },
        { label: "Juni", value: 6 },
        { label: "Juli", value: 7 },
        { label: "Augusti", value: 8 },
        { label: "September", value: 9 },
        { label: "Oktober", value: 10 },
        { label: "November", value: 11 },
        { label: "December", value: 12 },
    ];
    yearList = [new Date().getFullYear()];
    monthSelected = new Date().getMonth() + 1;
    yearSelected = new Date().getFullYear();

    ngOnInit() {
        this.yearList = [];
        for (let y = 0; y <= 5; y++) {
            this.yearList.push(2020 + y);
        }
        if (new Date().getMonth() > 0) {
            this.monthSelected = new Date().getMonth();
            this.attendanceSummaryMonthYear.month = new Date().getMonth();
            this.attendanceSummaryMonthYear.year = new Date().getFullYear();
        } else {
            this.monthSelected = 1;
        }
        this.getUserData = this.profileService.getRoleAndId();
        this.getUserData.role.subscribe((role) => {
            this.userData.role = role.toString();
        });
        this.getUserData.userId.subscribe((id) => {
            if (id) {
                this.userData.id = parseInt(id);
            }
        });
        this.leaveForm();
        this.empLeave = this._formBuilder.group({
            leaveNotes: ["", Validators.required],
            leaveDate: ["", Validators.required],
        });
        this.loadLeaveEmployee();
    }

    addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
        this.minLeaveApplicationToDate = _moment(new Date(event.value)).format("YYYY-MM-DD");
    }

    onChangeEvent(event: any) {
        this.minLeaveApplicationToDate = _moment(new Date(event.target.value)).format("YYYY-MM-DD");
    }

    getClientList() {
        this.sharedService.getClientList().subscribe((res: any) => {
            if (res) {
            }
        });
    }

    getESPMonthlyReport() {
        this.fTotOrder = 0;
        this.fRejOrder = 0;
        this.fTotProvision = 0;
        this.fTotTimlon = 0;
        this.fTotlon = 0;
        this.fTotLonInkSem = 0;
        this.fTotLonInkSoc = 0;
        this.fTotHour = 0;
        this.fTotMin = 0;
        this.fTotsec = 0;
        let espData = {
            year: this.yearSelected,
            Employee_id: this.userData.id,
        };
        this.personalService.getESPMonthlyReport(espData).subscribe((res: any) => {
            if (res) {
                this.espDetail = res;
                this.espDetail.forEach((esObj) => {
                    esObj.tot_salary_amount = 0;
                    esObj.tot_salary_sem_amount = 0;
                    esObj.tot_salary_soc_amount = 0;
                    if (esObj.salary_data.length > 0) {
                        esObj.salary_data.forEach((sdataObj) => {
                            this.fTotOrder += sdataObj.total_orders;
                            this.fRejOrder += sdataObj.rejected_orders;
                            this.fTotProvision += sdataObj.total_provision;
                            this.fTotTimlon += sdataObj.total_hourly_salary;
                            this.fTotlon += sdataObj.total_salary;
                            this.fTotLonInkSem += sdataObj.total_salary_sem;
                            this.fTotLonInkSoc += sdataObj.total_salary_soc;
                            esObj.tot_salary_amount += sdataObj.total_salary;
                            esObj.tot_salary_sem_amount += sdataObj.total_salary_sem;
                            esObj.tot_salary_soc_amount += sdataObj.total_salary_soc;
                            var a = sdataObj.total_time.split(":");
                            if (a.length == 3) {
                                this.fTotHour += parseInt(a[0]);
                                this.fTotMin += parseInt(a[1]);
                                this.fTotsec += parseInt(a[2]);
                            }
                        });
                    }
                });
                this.fTotTime = this.getTotalTime();
            }
            this._ref.detectChanges();
        });
    }

    getTotalTime() {
        var hh1 = this.fTotHour;
        var mm1 = this.fTotMin;
        var ss1 = this.fTotsec;
        if (ss1 > 59) {
            var ss2 = ss1 % 60;
            var ssx = ss1 / 60;
            //add into min
            var ss3 = ssx;
            var mm1 = mm1 + ss3;
            var ss1 = ss2;
        }
        if (mm1 > 59) {
            var mm2 = mm1 % 60;
            var mmx = mm1 / 60;
            //add into hour
            var mm3 = mmx;
            var hh1 = hh1 + mm3;
            var mm1 = mm2;
        }
        var finaladd = hh1.toFixed(0) + ":" + mm1.toFixed(0) + ":" + ss1.toFixed(0);
        return finaladd;
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach((field) => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup) {
                this.validateAllFormFields(control);
            }
        });
    }

    slideToggleChange(e) {}

    openModal(content, contentAccessId, toContent?) {
        this.addLeave.enable();
        if (content === "schedule") {
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-schedule-modal",
                size: "lg",
                backdrop: "static",
            });
        } else if (content === "leave") {
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });
        } else if (content === "checkEvent") {
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });
        } else if (content === "leave") {
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });
        } else if (content === "checkEvent") {
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });
        } else if (content == "ledghit") {
            this.addLeave.reset();
            this.uploader.clearQueue();
            this.addLeave.patchValue({
                options: "leave",
            });
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });
        } else if (content == "edit_ledghit") {
            var start = toContent.start_time ? toContent.start_time : "00:00";
            var end = toContent.end_time ? toContent.end_time : "00:00";
            var time_start = start.split(":");
            var time_end = end.split(":");
            this.time1 = { hour: parseInt(time_start[0]), minute: parseInt(time_start[1]), second: 0 };
            this.time2 = { hour: parseInt(time_end[0]), minute: parseInt(time_end[1]), second: 0 };
            this.addLeave.controls["fromdate"].setValue(_moment(toContent.fromdate).format("YYYY-MM-DD"));
            this.addLeave.controls["todate"].setValue(_moment(toContent.todate).format("YYYY-MM-DD"));
            this.addLeave.controls["note"].setValue(toContent.note);
            if (!toContent.start_time && !toContent.end_time) {
                this.addLeave.controls["options"].setValue("leave");
                this.onSelectionChange({ value: "leave" });
            } else {
                this.addLeave.controls["options"].setValue("permission");
                this.onSelectionChange({ value: "permission" });
            }
            this.addLeave.addControl("leave_id", new FormControl(toContent.leave_id));
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "lg",
                backdrop: "static",
            });

            this.modalRef.result.then(
                (result) => {
                    this.closeResult = `Closed with: ${result}`;
                },
                (reason) => {
                    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
                }
            );
        } else if (content == "notes") {
            this.addLeave.patchValue({
                note: toContent.note,
            });
            this.addLeave.disable();
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-timersattning-modal",
                backdrop: "static",
            });
        } else if (content == "approval_notes") {
            this.addLeave.patchValue({
                approval_note: toContent.approval_note,
            });
            this.addLeave.disable();
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-timersattning-modal",
                backdrop: "static",
            });
        } else if (content == "delete_leave") {
            this.delLeaveData = toContent;
            this.deleteErrMsg = false;
            this.modalRef = this.modalService.open(contentAccessId, {
                windowClass: "create-timersattning-modal",
                backdrop: "static",
            });
        } else if (content === "confirm") {
            this.modalConfirmRef = this.modalService.open(contentAccessId, {
                windowClass: "create-leave-modal",
                size: "sm",
                backdrop: "static",
            });
        }
    }
    dropped(event) {
        this.updateUspFileErrMsg = false;
        this.filedata = [];
        this.uspFile = [];
        
    
        for (let i = 0; i < event.length; i++) {
          if (event[i].type != "image/jpeg" && event[i].type != "image/jpg" && event[i].type != "image/png" && event[i].type != "application/pdf" && event[i].type != "application/msword" && event[i].type != "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
            this.updateUspFileErrMsg = true;
            this.uspFile.push(event[i].name);
            this.resetAlert();
          }
        }
        if (this.uploader.queue.length > 1){
            this.uploader.queue.length = 1;
            this.updateErrMsg = true;
            this.resetAlert();
        }
        else if (this.uploader.queue.length === 1) {
          this.filedata.push(this.uploader.queue[0]);
        } else {
          for (let i = 0; i < this.uploader.queue.length; i++) {
            this.filedata.push(this.uploader.queue[i]);
          }
        }
    }
    
    UploadFile() {
        if (this.filedata.length != 0) {
            this.emp_id = this.userData.id;
            this.impOrderService.uploadDocumentsForLeave(this.filedata, this.uploadOption, this.emp_id).subscribe((res: any) => {
                if (res && res.message == "Uploaded Successfully") {
                    this.resCreateMessage.success = true;
                    this.resCreateMessage.error = false;
                    this._ref.detectChanges();
                    this.resetAlert();
                }
            }, err => {
                this.resCreateMessage.success = false;
                this.resCreateMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            });
        }
    }

    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return "by pressing ESC";
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return "by clicking on a backdrop";
        } else {
            return `with: ${reason}`;
        }
    }

    private resetAlert() {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this.resCreateMessage.success = false;
            this.resCreateMessage.error = false;
            this.updateUspFileErrMsg = false;
            this.updateErrMsg = false;
            this._ref.detectChanges();
        }, 5000);
    }

    getLeave(stepper: MatStepper, stayInStep: any) {
        this.submitted = true;
        if (this.empLeave.invalid) {
            return;
        }
        let input_data = {
            date: _moment(this.empLeave.value.leaveDate).format("YYYY-MM-DD"),
            start_time: "00:00",
            end_time: "00:00",
            lunch: "00:00",
            convertleave: 1,
            notes: this.empLeave.value.leaveNotes,
        };
        this.personalService.calendarSchedule(this.userData.id, input_data, 1).subscribe(
            (res) => {
                if (res) {
                    this.resMessage.success = true;
                    this.resMessage.error = false;
                    this.resMessage.message = "Lämna Utated framgångsrikt";
                    this.empLeave.reset();
                    this.modalRef.close();
                } else {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this.resMessage.message = "Lämna utated misslyckades";
                }
                this._ref.detectChanges();
                this.resetsStepAlert(stepper, stayInStep);
            },
            (err) => {
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetsStepAlert(stepper, true);
            }
        );
    }

    private resetsStepAlert(stepper, stayInStep) {
        setTimeout(() => {
            this.resMessage.success = false;
            this.resMessage.error = false;
            this.resMessage.message = "";
            this._ref.detectChanges();
        }, 5000);
    }

    resetForm(form: FormGroup) {
        form.reset();
        Object.keys(form.controls).forEach((key) => {
            form.get(key).setErrors(null);
        });
    }

    closeLeaveConfirm() {
        this.modalConfirmRef.close();
    }

    submitLeave(confirmLeaveContent) {
        if (this.selectedMode != "permission") {
            this.addLeave.controls["start_time"].setErrors(null);
            this.addLeave.controls["end_time"].setErrors(null);
        }
        let toSendFromDate = _moment(this.addLeave.value.fromdate)
            .set({ hour: 0, minute: 0, second: 0 })
            .format("YYYY-MM-DDTHH:mm:ss");
        let toSendToDate =
            this.selectedMode == "leave"
                ? _moment(this.addLeave.value.todate)
                      .set({ hour: 0, minute: 0, second: 0 })
                      .format("YYYY-MM-DDTHH:mm:ss")
                : toSendFromDate;
        if (this.addLeave.status == "VALID" && toSendFromDate != "Invalid date" && toSendToDate != "Invalid date") {
            toSendFromDate = _moment(this.addLeave.value.fromdate)
                .set({ hour: 0, minute: 0, second: 0 })
                .format("YYYY-MM-DDTHH:mm:ss");
            toSendToDate =
                this.selectedMode == "leave"
                    ? _moment(this.addLeave.value.todate)
                          .set({ hour: 0, minute: 0, second: 0 })
                          .format("YYYY-MM-DDTHH:mm:ss")
                    : toSendFromDate;
            toSendFromDate = toSendFromDate + "Z";
            toSendToDate = toSendToDate + "Z";
            let startTime =
                this.selectedMode == "permission"
                    ? this.addLeave.value.start_time.hour + ":" + this.addLeave.value.start_time.minute
                    : "";
            let endTime =
                this.selectedMode == "permission"
                    ? this.addLeave.value.end_time.hour + ":" + this.addLeave.value.end_time.minute
                    : "";
            let datas = {
                leave: [
                    {
                        note: this.addLeave.value.note,
                        fromdate: toSendFromDate,
                        todate: toSendToDate,
                        start_time: startTime,
                        end_time: endTime,
                        leave_id: "",
                    },
                ],
                Employee_id: this.userData.id,
            };
            let leave_id = this.addLeave.value.leave_id ? this.addLeave.value.leave_id : "";
            if (leave_id != "") {
                datas.leave[0].leave_id = leave_id;
            }
            this.profileService.updateLeave(datas).subscribe(
                (res: any) => {
                    if (res.message === "Updated Successfully") {
                        if (this.filedata.length != 0) {
                            this.UploadFile();
                        }
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                        this.openModal("confirm", confirmLeaveContent);
                    } else {
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                    }
                    this.loadLeaveEmployee();
                    this._ref.detectChanges();
                    this.modalRef.close();
                    this.resetAlert();
                },
                (err) => {
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this._ref.detectChanges();
                    this.resetAlert();
                }
            );
        }
    }

    deleteMethod() {
        if (this.todayDate <= _moment(this.delLeaveData.fromdate).valueOf()) {
            this.spinner.active = true;
            this.profileService.deleteLeave(this.delLeaveData.leave_id).subscribe(
                (res: any) => {
                    if (res.message === "Deleted Successfully") {
                        this.deleteErrMsg = false;
                        this.resMessage.success = true;
                        this.resMessage.error = false;
                        this.modalRef.close("submitted");
                        this.loadLeaveEmployee();
                        this._ref.detectChanges();
                        this.resetAlert();
                    } else {
                        this.deleteErrMsg = true;
                        this.resMessage.success = false;
                        this.resMessage.error = true;
                    }
                    this.spinner.active = false;
                },
                (err) => {
                    this.deleteErrMsg = true;
                    this.resMessage.success = false;
                    this.resMessage.error = true;
                    this.spinner.active = false;
                }
            );
        }
    }

    loadLeaveEmployee() {
        this.loader = true;
        let toSendReq: any = {
            status: "",
        };
        if (!this.isLeaveApprovedList && this.isLeavePendingList) {
            toSendReq.status = "Pending";
        }
        if (this.isLeaveApprovedList && !this.isLeavePendingList) {
            toSendReq.status = "Approved";
        }
        if (!this.isLeaveApprovedList && !this.isLeavePendingList) {
            toSendReq.status = "Rejected";
        }
        this.sharedService.getDashboardLeaveByStatus(this.userData.id, toSendReq).subscribe(
            (res: any) => {
                this.loader = false;
                if (res && res[0] && res[0].el.length > 0 && res[0].el[0].fromdate) {
                    res[0].el.forEach((elObj: any) => {
                        if (elObj.start_time) {
                            elObj.start_time = elObj.start_time.split(":")[0] + ":" + elObj.start_time.split(":")[1];
                        }
                        if (elObj.end_time) {
                            elObj.end_time = elObj.end_time.split(":")[0] + ":" + elObj.end_time.split(":")[1];
                        }
                    });
                    this.leaveDatasource = new MatTableDataSource(res[0].el);
                    this.leaveDatasource.paginator = this.paginator;
                    this.leaveDatasource.sort = this.sort;
                    this.leaveDatasource.sortingDataAccessor = (item, property) => {
                        let sortString = property.split(".").reduce((o, i) => o[i], item);
                        if (typeof sortString === "string") {
                            sortString = sortString.toLowerCase();
                        }
                        return sortString;
                    };
                    if (this.leaveDatasource.data.length > 0) {
                        this.leavetottRowErr = false;
                        this.leavetottRowNoRecord = false;
                    } else {
                        this.leavetottRowErr = false;
                        this.leavetottRowNoRecord = true;
                    }
                    this._ref.detectChanges();
                } else {
                    this.leaveDatasource = new MatTableDataSource([]);
                    this.leavetottRowErr = false;
                    this.leavetottRowNoRecord = true;
                    this._ref.detectChanges();
                }
            },
            (err) => {
                this.loader = false;
                this.leavetottRowErr = true;
                this.leavetottRowNoRecord = false;
                this._ref.detectChanges();
                this.resMessage.success = false;
                this.resMessage.error = true;
                this._ref.detectChanges();
                this.resetAlert();
            }
        );
    }

    dateValidator(c: AbstractControl): { [key: string]: boolean } {
        let value = c.value;
        if (value && typeof value === "string") {
            let match = value.match(/^([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))/);
            if (!match) {
                return { dateInvalid: true };
            } else if (match && match[0] !== value) {
                return { dateInvalid: true };
            }
        }
        return null;
    }

    leaveForm() {
        this.addLeave = this._formBuilder.group({
            fromdate: ["", [Validators.required]],
            todate: ["", [Validators.required]],
            note: ["", [Validators.required]],
            start_time: ["", Validators.required],
            end_time: ["", Validators.required],
            options: ["leave"],
            approval_note: [""],
        });
    }

    onSelectionChange(event) {
        this.selectedMode = event.value;
        if (this.selectedMode == "permission") {
            this.addLeave.controls["todate"].setErrors(null);
        } else {
            this.addLeave.controls["start_time"].setErrors(null);
            this.addLeave.controls["end_time"].setErrors(null);
        }
    }

    toggleApprovedLeaveList(isApproved: boolean, isPending?: boolean) {
        if (this.isLeaveApprovedList != isApproved || this.isLeavePendingList != isPending) {
            this.isLeaveApprovedList = isApproved;
            this.isLeavePendingList = isPending;
            this.loadLeaveEmployee();
        }
    }

    applyColumnFilter() {
        this.leaveDatasource.filterPredicate = this.columnwiseFilter();
        this.leaveDatasource.filter = JSON.stringify(this.multiColFilter);
        if (this.leaveDatasource.paginator) {
            this.leaveDatasource.paginator.firstPage();
        }
    }

    private columnwiseFilter() {
        let filterPred = (item, filter) => {
            let filterString = JSON.parse(filter);
            let isRowSet: boolean = true;
            Object.keys(filterString).forEach((key) => {
                let keyNodeValue = key.split(".").reduce((o, i) => {
                    if (o) {
                        return o[i];
                    }
                }, item);
                if ((keyNodeValue && filterString[key]) || (keyNodeValue >= 0 && filterString[key] >= 0)) {
                    let itemString = "";
                    if (keyNodeValue && typeof keyNodeValue != "string") {
                        itemString = keyNodeValue.toString();
                    } else if (keyNodeValue) {
                        itemString = keyNodeValue;
                    }
                    if (filterString[key]) {
                        isRowSet =
                            isRowSet &&
                            (itemString != ""
                                ? itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1
                                : false);
                    } else {
                        isRowSet =
                            isRowSet &&
                            itemString.trim().toLowerCase().indexOf(filterString[key].trim().toLowerCase()) != -1;
                    }
                } else {
                    if (
                        (!keyNodeValue || keyNodeValue <= 0) &&
                        (filterString[key] || parseInt(filterString[key]) === 0 || parseInt(filterString[key]) > 0)
                    ) {
                        isRowSet = false;
                    }
                }
            });
            return isRowSet;
        };
        return filterPred;
    }

    toFormattedDate(iso: string) {
        const date = _moment(new Date(iso)).format("YYYY-MM-DD");
        return date;
    }
}
