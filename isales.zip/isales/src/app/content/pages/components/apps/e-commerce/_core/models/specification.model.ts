import { BaseModel } from './_base.model';

export class SpecificationModel extends BaseModel {
	id: number;
	name: string;
	sort: number;
}
