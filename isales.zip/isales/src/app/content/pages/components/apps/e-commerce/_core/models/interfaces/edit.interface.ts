export interface IEdit {
	_isEditMode: boolean;
	_isNew: boolean;
	_isDeleted: boolean;
	_isUpdated: boolean;
	_prevState: any;
}
