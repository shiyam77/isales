import { Injectable, Injector } from '@angular/core';
import {
	HttpEvent,
	HttpInterceptor,
	HttpHandler,
	HttpRequest,
	HttpResponse
} from '@angular/common/http';
import { Observable,EMPTY } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { AuthenticationService } from '../../../../../../../core/auth/authentication.service';
import { TokenStorage } from '../../../../../../../core/auth/token-storage.service';

@Injectable()
export class InterceptService implements HttpInterceptor {
	// intercept request and add token
	// intercept(
	// 	request: HttpRequest<any>,
	// 	next: HttpHandler
	// ): Observable<HttpEvent<any>>{
	// 	return EMPTY;
	// }
	private authService:AuthenticationService;
	constructor(private injector: Injector,private tokenStorage: TokenStorage) { 
		this.authService = injector.get(AuthenticationService);
	}
	intercept(
		request: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		// let userAccessToken;
		// this.authService.getAccessToken().subscribe((token)=>{
		// 	userAccessToken = token;
		// })
		// if(userAccessToken){
		// 	request = request.clone({
		// 	setHeaders: {
		// 		'authToken': userAccessToken
		// 	}
		// 	});
		// }
		// modify request
		// request = request.clone({
			// setHeaders: {
			// 	Authorization: `Base ${localStorage.getItem('accessToken')}`
			// }
		// });
		return next.handle(request).pipe(
			tap(
				event => {
					if (event instanceof HttpResponse) {
						// http response status code
					}
				},
				error => {
					// http response status code
				}
			)
		);
	}
}
