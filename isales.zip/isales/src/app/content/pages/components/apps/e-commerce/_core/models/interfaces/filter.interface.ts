export interface IFilter {
	_defaultFieldName: string; // Field which should filtered first
}
