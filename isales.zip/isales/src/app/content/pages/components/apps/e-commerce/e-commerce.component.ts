import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
	selector: 'm-e-commerce',
	templateUrl: './e-commerce.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class ECommerceComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
