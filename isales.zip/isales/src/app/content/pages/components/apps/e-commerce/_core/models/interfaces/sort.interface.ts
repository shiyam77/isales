export interface ISort {
	_sortField: string;
	_direction: string; // asc / desc
}
