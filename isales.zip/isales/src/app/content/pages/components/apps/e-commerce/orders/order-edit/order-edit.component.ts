import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'm-order-edit',
	templateUrl: './order-edit.component.html'
})
export class OrderEditComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
