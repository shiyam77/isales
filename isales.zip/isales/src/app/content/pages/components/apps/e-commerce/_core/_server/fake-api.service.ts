import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { ECommerceDataContext } from './fake-db/_e-commerce.data-context';

@Injectable()
export class FakeApiService implements InMemoryDbService {
	constructor() {}

	createDb(): {} | Observable<{}> {
		return {
			// e-commerce
			// customers
			customers: ECommerceDataContext.customers,
			// products
			products: ECommerceDataContext.cars,
			specs: ECommerceDataContext.specs,
			productRemarks: ECommerceDataContext.remarks,
			productSpecs: ECommerceDataContext.carSpecs,

			// orders
			orders: ECommerceDataContext.orders
		};
	}
}
