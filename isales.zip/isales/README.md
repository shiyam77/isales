# README #

# Viafone-Frontend

## Installation

1.Install angular globally: `npm install -g @angular/cli`

2.Clone the "viafonefrontend" repository or download the repository. The repository contains the Angular 6.1 app for "Viafone ERP", use the branch "tech-viafone" for running the app with support for your respective version.

3.Run `npm install` to install all dev dependencies.

## How to run?

1.Run ng serve --open

2.Navigate to http://localhost:4200/. The app will automatically reload if you change any of the source files.